# Cypress Test Automation

This project will consist of all the information, packages and test files required to run the automated integration test suites for Health Director. The aim is to use the Cypress framework to create an automation test suite that will cover the bulk of the acceptance tests needed for release with e2e test to follow in time.

### Getting Started

Upon cloning this repo, open a CMD line inside the containing folder and run

```
npm install
```

This should update and replace any of the vendors needed to run this.

## Running the Cypress GUI

For testing individual components, debugging, or writing tests, the provided GUI that comes with Cypress is easier to use albeit slower. This will allow you access to a DOM snapshots for each test step as well as the ability to directly interact with each snapshot with dev tools. The ENV flag must be passed in as shown below or else it will not open correctly and tests will not run.

```
npx gulp cypress --env dev
```

### Additional Flags

The following flags can also be passed in along with the given values to further restrict or alter how the tests are run.

| Flag         | Description                                                                                                                   | Values                                                                                                                 |
| ------------ | ----------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------- |
| `--env`      | The environment the test should be pointed at. **This is always required**                                                    | `dev, qa`                                                                                                              |
| `--role`     | The user role to run the tests as. This will only run tests that have been defined as runnable for this role.                 | `cancerCareAdmin, corporateAdmin, nurse, pharmacist, pharmacyAdmin, pharmacyTechnician, accounts, doctor, globalAdmin` |
| `--priority` | The maximum test priority level to run. This will run all tests of this priority and higher, i.e. P2 will run P1 AND P2 cases | `p1, p2, p3, p4`                                                                                                       |
| `--suite`    | The test suite to run, i.e. regression will only run regression test cases                                                    | `regression, scenarios, ui, integrations`                                                                              |

## Running Cypress Headless

For full test runs or running in CI, we append the correct cypress command above with the --run tag. This will instead run the test headlessly on electron leading to a much faster run as well as video capture for each spec file.

```
npx gulp cypress --env dev --run
```

### Additional Flags

The additional flags found in the Cypress GUI section will also work here, as well as a new one:

`--spec 'cypress/specs/**/*'`

This flag will allow us to restrict what spec files are run by cypress to those that match the provided glob.

More flags can be found at https://docs.cypress.io/guides/guides/command-line.html#cypress-run and can be added to the gulpfile.ts

### Recording

To record the results to the Cypress dashboard we need to add the --record tag to the above commands. This can only be used in conjunction with the --run tag.

```
npx gulp cypress --env dev --run --record
```

## Common Runs

Run P1, P2 & P3 patient profile tests against QA

```
npx  gulp cypress --env qa --priority p3 --run --spec 'cypress/integration/PatientProfile/**/*'
```

## Built With

- [Cypress.io](https://www.cypress.io/) - The Cypress framework

## Versioning

We use [SemVer](http://semver.org/) for versioning. For the versions available, see the [tags on this repository](https://github.com/epicdigital/cypress-automation/tags).

## Authors

- **Ben Spinks** - _Initial work_ - (https://github.com/bspinks)
- **Bailey Nahi** - (https://github.com/epicbailey)

See also the list of [contributors](https://github.com/epicdigital/cypress-automation/graphs/contributors) who participated in this project.
