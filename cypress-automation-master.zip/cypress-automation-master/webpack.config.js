var path = require('path')

module.exports = {
  node: {
    fs: 'empty',
    module: 'empty',
  },
  resolve: {
    extensions: ['.js', '.ts'],
  },
  module: {
    rules: [
      {
        test: /\.ts$/,
        include: [
          path.resolve(__dirname, 'cypress'),
          path.resolve(__dirname, 'schemas'),
          path.resolve(__dirname, 'formats'),
          path.resolve(__dirname, 'node_modules/@cypress'),
        ],
        use: [
          {
            loader: 'ts-loader',
            options: {
              allowTsInNodeModules: true,
              transpileOnly: true,
            },
          },
        ],
      },
    ],
  },
  resolve: {
    extensions: ['.js', '.ts'],
    alias: {
      '@support': path.resolve(__dirname, 'cypress/support/'),
      '@schemas': path.resolve(__dirname, 'schemas/'),
      '@formats': path.resolve(__dirname, 'formats/'),
      '@testcases': path.resolve(__dirname, 'cypress/testcases/'),
    },
  },
}
