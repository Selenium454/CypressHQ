import { UserRoles, GeneratedContact, UserDictionary } from '@support/types'
import { generateContact, createPatientViaApi, setupRoutes } from '@support/functions'
import { PatientsRoutes, UsersRoutes, AddressFinderRoutes } from '@support/api'
import { fillField, epicSelect } from '@support/commands/general.commands'

export const canAddContact = (): void => {
  const userRole: UserRoles = Cypress.env('role')
  const contact: GeneratedContact = generateContact()

  context('C53583 - Can add a contact to a patient', () => {
    before(() => {
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('pharmacyAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('password')
      )
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([
        UsersRoutes.GetUsersDetails,
        UsersRoutes.GetUsersPreferences,
        PatientsRoutes.GetPatientsByUserIdContacts,
        PatientsRoutes.PostPatientsByUserIdContacts,
        AddressFinderRoutes.GetAddressFinderAutoComplete,
        AddressFinderRoutes.GetAddressFinderAddressInfo,
      ])

      createPatientViaApi().then(({ userId }) => {
        cy.visit(`/customer/profile/${userId}/details#/contacts`)
        PatientsRoutes.GetPatientsByUserIdContacts.check("Gets patient's contacts")
      })
    })

    it(`Can add a contact to a patient`, () => {
      cy.contains('a.epic-button', 'Add Contact').click()

      fillField({ locator: '[name="firstName"]', inputValue: contact.firstName })
      fillField({ locator: '[name="lastName"]', inputValue: contact.surName })
      fillField({ locator: '[name="email"]', inputValue: contact.email })
      fillField({ locator: '[name="phone"]', inputValue: '66286453' })
      fillField({ locator: '[name="mobile"]', inputValue: '0400921335' })
      epicSelect({
        container: '#contact-edit-form',
        inputLocator: '[name="relationship-select-input-wide"]',
        dropdownLocator: 'div.el-popper.relationship-select-dropdown-wide .epic-text',
        option: 'Neighbour',
      })

      fillField({ locator: '#street', inputValue: '12345 h' })

      AddressFinderRoutes.GetAddressFinderAutoComplete.check()

      cy.contains('li.af_item', '12345')
        .first()
        .should('be.visible')
        .click()

      AddressFinderRoutes.GetAddressFinderAddressInfo.check()

      cy.get('[name="isMainContact"]').check()

      cy.contains('button.epic-button', 'Save').click()

      PatientsRoutes.PostPatientsByUserIdContacts.check('Add the contact to the patient')
    })
  })
}
