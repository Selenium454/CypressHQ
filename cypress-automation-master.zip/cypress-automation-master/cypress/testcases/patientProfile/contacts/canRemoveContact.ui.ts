import { UserRoles, UserDictionary } from '@support/types'
import { ContactLatest } from '@schemas/api/models'
import { createPatientViaApi, addContactToPatientViaApi, epicHdId, setupRoutes } from '@support/functions'
import { UsersRoutes, PatientsRoutes } from '@support/api'

export const canRemoveContact = (): void => {
  const userRole: UserRoles = Cypress.env('role')
  let contact: ContactLatest

  context('C56032 - Can remove a contact from a patient', () => {
    before(() => {
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('pharmacyAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('password')
      )
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([
        UsersRoutes.GetUsersDetails,
        UsersRoutes.GetUsersPreferences,
        PatientsRoutes.GetPatientsByUserIdContacts,
        PatientsRoutes.PostPatientsByUserIdContacts,
      ])

      createPatientViaApi().then(customerModel => {
        addContactToPatientViaApi({ customer: customerModel })
        cy.visit(`/customer/profile/${customerModel.userId}/details#/contacts`)

        PatientsRoutes.GetPatientsByUserIdContacts.check("Get patient's contacts").then(({ response: contacts }) => {
          contact = contacts.model![0]
        })
      })
    })

    it(`Can remove a contact from a patient`, () => {
      cy.get(epicHdId('container-contact-0'))
        .as('contactContainer')
        .should('be.visible')

      cy.contains('.danger', 'Delete')
        .should('be.visible')
        .click()

      cy.get(epicHdId('dialog-container'))
        .should('contain', `Delete ${contact.firstName} ${contact.surName} from contacts?`)
        .contains('button.btn-action', 'Delete')
        .click()

      PatientsRoutes.PostPatientsByUserIdContacts.check()

      cy.get('@contactContainer').should('not.exist')
    })
  })
}
