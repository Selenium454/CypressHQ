import { UserDictionary, UserRoles } from '@support/types'
import { createPatientViaApi, addContactToPatientViaApi, setupRoutes } from '@support/functions'

import { fillField, checkGrowlAndClose, checkGrowlsAreNotVisible } from '@support/commands/general.commands'
import { UsersRoutes, PatientsRoutes } from '@support/api'

export const canOnlyHaveOneMainContact = (): void => {
  const userRole: UserRoles = Cypress.env('role')
  const firstName: string = 'Test'
  const surname: string = 'Contact'

  context('C53584 - Can only have a single main contact', () => {
    before(() => {
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('pharmacyAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('password')
      )
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([
        UsersRoutes.GetUsersDetails,
        UsersRoutes.GetUsersPreferences,
        PatientsRoutes.GetPatientsByUserIdContacts,
        PatientsRoutes.PostPatientsByUserIdContacts,
      ])

      createPatientViaApi().then(customerModel => {
        addContactToPatientViaApi({ customer: customerModel })
        cy.visit(`/customer/profile/${customerModel.userId}/details#/contacts`)

        PatientsRoutes.GetPatientsByUserIdContacts.check("Get the patient's contacts")
      })
    })

    it(`Can only have a single main contact`, () => {
      cy.contains('a.epic-button', 'Add Contact').click()

      fillField({ locator: '[name="firstName"]', inputValue: firstName })
      fillField({ locator: '[name="lastName"]', inputValue: surname })

      cy.get('[name="isMainContact"]').check()

      cy.contains('button.epic-button', 'Save').click()

      checkGrowlAndClose({
        growlMessage: 'Failed to save contacts.',
        growlType: '.growl-error',
      })
      checkGrowlsAreNotVisible()
    })
  })
}
