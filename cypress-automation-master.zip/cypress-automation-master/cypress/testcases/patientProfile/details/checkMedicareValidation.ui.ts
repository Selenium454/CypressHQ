import { UserDictionary, UserRoles } from '@support/types'
import { createPatientViaApi, epicHdId, setupRoutes } from '@support/functions'
import { fillField, checkGrowlAndClose } from '@support/commands/general.commands'
import { UsersRoutes } from '@support/api'

export const checkMedicareValidation = (): void => {
  const userRole: UserRoles = Cypress.env('role')
  const invalidMedicareNumber: string = '27210984527'
  const validMedicare: string = '27210984521'

  context('C53579 - Check medicare validation', () => {
    before(() => {
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('pharmacyAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('password')
      )
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([UsersRoutes.GetUsersDetails, UsersRoutes.GetUsersPreferences])

      createPatientViaApi().then(({ userId }) => {
        cy.visit(`/customer/profile/${userId}/details#/view`)
      })
    })
    it(`Check invalid medicare`, () => {
      cy.contains('Edit')
        .scrollIntoView()
        .click()

      fillField({ locator: epicHdId('input-medicare-number'), inputValue: invalidMedicareNumber })
      checkGrowlAndClose({ growlMessage: 'Cannot determine patient eligibility', growlType: '.growl-warning' })
      checkGrowlAndClose({
        growlMessage: 'The patient data supplied failed validation checks against Medicare data',
        growlType: '.growl-warning',
      })
    })

    it(`Check valid medicare`, () => {
      cy.contains('Edit')
        .scrollIntoView()
        .click()

      fillField({ locator: 'input[name="first-name"]', inputValue: 'Ben' })
      fillField({ locator: 'input[name="surname"]', inputValue: 'Spinks' })
      fillField({ locator: '#date-of-birth', inputValue: '22 / 11 / 1993' })
      fillField({ locator: epicHdId('input-medicare-number'), inputValue: validMedicare })
      checkGrowlAndClose({
        growlMessage: 'The Medicare details for this patient have been validated with Medicare and are correct.',
        growlType: '.growl-notice',
      })
      checkGrowlAndClose({ growlMessage: 'Card holder name:BENJAMIN', growlType: '.growl-warning' })
      checkGrowlAndClose({
        growlMessage: 'A concessional entitlement has not been found for this patient',
        growlType: '.growl-warning',
      })
    })
  })
}
