import { UserRoles, UserDictionary } from '@support/types'
import { createPatientViaApi, epicHdId, setupRoutes } from '@support/functions'

import { fillField, selectField } from '@support/commands/general.commands'
import { UsersRoutes, PatientsRoutes, AddressFinderRoutes } from '@support/api'

export const canSetPatientToDeceased = (): void => {
  const userRole: UserRoles = Cypress.env('role')
  const dateOfDeath: string = '22/11/2018'

  context('C53578 - Can set a patient to deceased', () => {
    before(() => {
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('pharmacyAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('password')
      )
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([
        UsersRoutes.GetUsersDetails,
        UsersRoutes.GetUsersPreferences,
        PatientsRoutes.GetPatientsByUserIdContacts,
        PatientsRoutes.PostPatientsByUserIdContacts,
        PatientsRoutes.PutPatientsByUserIdDetails,
        AddressFinderRoutes.GetAddressFinderAutoComplete,
        AddressFinderRoutes.GetAddressFinderAddressInfo,
      ])

      createPatientViaApi().then(({ userId }) => {
        cy.visit(`/customer/profile/${userId}/details#/view`)
      })
    })

    it(`Can set a patient to deceased`, () => {
      cy.contains('Edit').click()

      cy.get(epicHdId('input-medicare-number')).clear()

      cy.get(epicHdId('radio-active-in-hub'))
        .find('[value="false"]')
        .click()

      selectField({ locator: epicHdId('select-non-active-reason'), selectValue: 'deceased' })
      fillField({
        locator: epicHdId('input-date-of-deceased'),
        inputValue: '22/11/2018',
      })

      cy.get(epicHdId('button-save')).click()

      PatientsRoutes.PutPatientsByUserIdDetails.check('Update patient to deceased')

      cy.reload()

      cy.get(epicHdId('row-patient-status'))
        .contains('Inactive')
        .should('be.visible')

      cy.get(epicHdId('row-inactive-reason'))
        .contains('Deceased')
        .should('be.visible')

      cy.get(epicHdId('row-date-of-death'))
        .contains(dateOfDeath)
        .should('be.visible')
    })
  })
}
