import { UserRoles, UserDictionary } from '@support/types'
import { createPatientViaApi, setupRoutes } from '@support/functions'
import { fillField, checkGrowlAndClose } from '@support/commands/general.commands'
import { UsersRoutes } from '@support/api'

export const checkRepatValidation = (): void => {
  const userRole: UserRoles = Cypress.env('role')
  const invalidRepat: string = 'Q1'
  const validRepat: string = 'QX173831A'

  context('C53580 - Check repat validation', () => {
    before(() => {
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('pharmacyAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('password')
      )
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([UsersRoutes.GetUsersDetails, UsersRoutes.GetUsersPreferences])

      createPatientViaApi().then(({ userId }) => {
        cy.visit(`/customer/profile/${userId}/details#/view`)
      })
    })

    it(`Check invalid repat`, () => {
      cy.contains('Edit')
        .scrollIntoView()
        .click()

      fillField({ locator: '#repat-number', inputValue: invalidRepat })
      checkGrowlAndClose({
        growlMessage: 'The patient data supplied failed validation checks against Medicare data.',
        growlType: '.growl-warning',
      })

      cy.get('.invalidrepat').should('be.visible')
    })

    it(`Check valid repat`, () => {
      cy.contains('Edit')
        .scrollIntoView()
        .click()

      fillField({ locator: 'input[name="first-name"]', inputValue: 'Heather' })
      fillField({ locator: 'input[name="surname"]', inputValue: 'Quinn' })
      fillField({ locator: '#date-of-birth', inputValue: '07 / 04 / 1931' })
      fillField({ locator: '#repat-number', inputValue: validRepat })
      checkGrowlAndClose({
        growlMessage: 'Card First Name: HEATHER',
        growlType: '.growl-notice',
      })

      cy.get('.validrepat').should('be.visible')
    })
  })
}
