import { UserRoles, UserDictionary } from '@support/types'
import { createPatientViaApi, epicHdId, setupRoutes } from '@support/functions'
import { fillField, checkGrowlAndClose } from '@support/commands/general.commands'
import { UsersRoutes } from '@support/api'

export const checkConcessionValidation = (): void => {
  const userRole: UserRoles = Cypress.env('role')
  const validConcession: string = 'CN901757525'
  const validMedicare: string = '21950372921'

  context('C53581 - Check concession validation', () => {
    before(() => {
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('pharmacyAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('password')
      )
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([UsersRoutes.GetUsersDetails, UsersRoutes.GetUsersPreferences])

      createPatientViaApi().then(({ userId }) => {
        cy.visit(`/customer/profile/${userId}/details#/view`)
      })
    })

    it(`Check valid concession`, () => {
      cy.contains('Edit')
        .scrollIntoView()
        .click()

      fillField({ locator: 'input[name="first-name"]', inputValue: 'Heather' })
      fillField({ locator: 'input[name="surname"]', inputValue: 'Quinn' })
      fillField({ locator: '#date-of-birth', inputValue: '07 / 04 / 1931' })
      fillField({ locator: '#concession-number', inputValue: validConcession })
      fillField({ locator: epicHdId('input-medicare-number'), inputValue: validMedicare })
      checkGrowlAndClose({
        growlMessage: 'The Medicare details for this patient have been validated with Medicare and are correct.',
        growlType: '.growl-notice',
      })
      checkGrowlAndClose({
        growlMessage: 'Entitled.',
        growlType: '.growl-notice',
      })
    })
  })
}
