import { UserRoles, UserDictionary } from '@support/types'
import { createPatientViaApi, setupRoutes } from '@support/functions'
import { checkForValidationError } from '@support/commands/general.commands'
import { UsersRoutes } from '@support/api'

export const checkMandatoryFields = (): void => {
  const userRole: UserRoles = Cypress.env('role')
  const firstNameLocator: string = 'input[name="first-name"]'
  const surnameLocator: string = 'input[name="surname"]'
  const dateOfBirthLocator: string = '#date-of-birth'
  const addressLocator: string = '#address'
  const suburbLocator: string = '#suburb'
  const postcodeLocator: string = '#postCode'

  context('C53582 - Check mandatory fields', () => {
    before(() => {
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('pharmacyAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('password')
      )
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([UsersRoutes.GetUsersDetails, UsersRoutes.GetUsersPreferences])

      createPatientViaApi().then(({ userId }) => {
        cy.visit(`/customer/profile/${userId}/details#/view`)
      })
    })

    it(`Check mandatory fields`, () => {
      cy.contains('Edit').click()

      cy.get(firstNameLocator).clear()

      checkForValidationError({
        locator: firstNameLocator,
        errorMessage: 'The Legal First Name field is required.',
      })

      cy.get(surnameLocator).clear()

      checkForValidationError({
        locator: surnameLocator,
        errorMessage: 'The Legal Last Name field is required.',
      })

      cy.get(dateOfBirthLocator).clear()

      checkForValidationError({
        locator: dateOfBirthLocator,
        errorMessage: 'The Date of Birth must be in the format DD / MM / YYYY.',
      })

      cy.get(addressLocator).clear()

      checkForValidationError({
        locator: addressLocator,
        errorMessage: 'The Address field is required.',
      })

      cy.get(suburbLocator).clear()

      checkForValidationError({ locator: suburbLocator, errorMessage: 'The Suburb field is required.' })

      cy.get(postcodeLocator).clear()

      checkForValidationError({
        locator: postcodeLocator,
        errorMessage: 'The Postcode field is required.',
      })
    })
  })
}
