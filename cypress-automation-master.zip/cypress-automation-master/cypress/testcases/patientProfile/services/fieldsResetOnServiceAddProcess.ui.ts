import { createPatientViaApi, ServiceTypes, epicHdId, setupRoutes } from '@support/functions'
import { ServiceDetails, ServiceTypesList, UserRoles, UserDictionary } from '@support/types'
import { epicSelect } from '@support/commands/general.commands'
import { UsersRoutes, PatientsRoutes, FacilitiesRoutes } from '@support/api'

export const fieldsResetOnServiceAddProcess = (): void => {
  const serviceDetails: ServiceDetails = ServiceTypes[ServiceTypesList.Hospital]
  const altServiceDetails: ServiceDetails = ServiceTypes[ServiceTypesList.HospitalAlt]
  const otherServiceDetails: ServiceDetails = ServiceTypes[ServiceTypesList.AgedCare]
  const userRole: UserRoles = Cypress.env('role')

  context(`C53343 - ${serviceDetails.serviceName} - Fields reset when changing a selector in the add process`, () => {
    before(() => {
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('pharmacyAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('password')
      )
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([
        UsersRoutes.GetUsersDetails,
        UsersRoutes.GetUsersPreferences,
        PatientsRoutes.GetPatientsByUserIdDetails,
        FacilitiesRoutes.GetFacilities,
      ])

      createPatientViaApi().then(({ userId }) => {
        cy.visit(`/customer/profile/${userId}/details#/services`)

        FacilitiesRoutes.GetFacilities.check()
      })
    })

    it(`Fields reset when changing a selector in the add process`, () => {
      cy.get('.btn-add')
        .scrollIntoView()
        .click()

      epicSelect({
        container: epicHdId('dialog-container'),
        inputLocator: '[name="serviceType-select-input-wide"]',
        dropdownLocator: '.el-popper.serviceType-select-dropdown-wide .epic-text',
        option: serviceDetails.serviceName,
      })
      epicSelect({
        container: epicHdId('dialog-container'),
        inputLocator: '[name="facility-select-input-wide"]',
        dropdownLocator: '.el-popper.facility-select-dropdown-wide .epic-text',
        option: serviceDetails.facilityName,
      })
      epicSelect({
        container: epicHdId('dialog-container'),
        inputLocator: '[name="ward-select-input-wide"]',
        dropdownLocator: '.el-popper.ward-select-dropdown-wide .epic-text',
        option: serviceDetails.wardName,
      })
      epicSelect({
        container: epicHdId('dialog-container'),
        inputLocator: '[name="facility-select-input-wide"]',
        dropdownLocator: '.el-popper.facility-select-dropdown-wide:visible .epic-text',
        option: altServiceDetails.facilityName,
      })

      cy.get('[name="ward-select-input-wide"]').should('have.value', '')

      epicSelect({
        container: epicHdId('dialog-container'),
        inputLocator: '[name="ward-select-input-wide"]',
        dropdownLocator: '.el-popper.ward-select-dropdown-wide:visible .epic-text',
        option: altServiceDetails.wardName,
      })
      epicSelect({
        container: epicHdId('dialog-container'),
        inputLocator: '[name="serviceType-select-input-wide"]',
        dropdownLocator: '.el-popper.serviceType-select-dropdown-wide:visible .epic-text',
        option: otherServiceDetails.serviceName,
      })

      cy.get('[name="facility-select-input-wide"]').should('have.value', '')

      cy.get('[name="ward-select-input-wide"]').should('have.value', '')
    })
  })
}
