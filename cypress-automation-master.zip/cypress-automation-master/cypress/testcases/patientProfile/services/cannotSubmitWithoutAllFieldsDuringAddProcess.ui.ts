import { ServiceDetails, ServiceTypesList, UserRoles, UserDictionary } from '@support/types'
import { ServiceTypes, createPatientViaApi, epicHdId, setupRoutes } from '@support/functions'
import { epicSelect } from '@support/commands/general.commands'
import { UsersRoutes, PatientsRoutes, FacilitiesRoutes } from '@support/api'

export const cannotSubmitWithoutAllFieldsDuringAddProcess = (): void => {
  const serviceDetails: ServiceDetails = ServiceTypes[ServiceTypesList.Hospital]
  const userRole: UserRoles = Cypress.env('role')

  context(`C53344 - ${serviceDetails.serviceName} - Cannot submit adding a service without all fields filled`, () => {
    before(() => {
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('pharmacyAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('password')
      )
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([
        UsersRoutes.GetUsersDetails,
        UsersRoutes.GetUsersPreferences,
        PatientsRoutes.GetPatientsByUserIdDetails,
        FacilitiesRoutes.GetFacilities,
      ])

      createPatientViaApi().then(({ userId }) => {
        cy.visit(`/customer/profile/${userId}/details#/services`)

        FacilitiesRoutes.GetFacilities.check()
      })
    })

    it(`Cannot submit adding a service without all fields filled`, () => {
      cy.get('.btn-add')
        .scrollIntoView()
        .click()

      epicSelect({
        container: epicHdId('dialog-container'),
        inputLocator: '[name="serviceType-select-input-wide"]',
        dropdownLocator: '.el-popper.serviceType-select-dropdown-wide .epic-text',
        option: serviceDetails.serviceName,
      })

      cy.get(epicHdId('button-add-service')).should('be.disabled')

      epicSelect({
        container: epicHdId('dialog-container'),
        inputLocator: '[name="facility-select-input-wide"]',
        dropdownLocator: '.el-popper.facility-select-dropdown-wide .epic-text',
        option: serviceDetails.facilityName,
      })

      cy.get(epicHdId('button-add-service')).should('be.disabled')

      epicSelect({
        container: epicHdId('dialog-container'),
        inputLocator: '[name="ward-select-input-wide"]',
        dropdownLocator: '.el-popper.ward-select-dropdown-wide .epic-text',
        option: serviceDetails.wardName,
      })

      cy.get(epicHdId('button-add-service')).should('not.be.disabled')
    })
  })
}
