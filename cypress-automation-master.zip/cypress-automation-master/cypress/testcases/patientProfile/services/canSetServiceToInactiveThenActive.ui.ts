import { ServiceDetails, UserRoles, UserDictionary, ServiceTypesList } from '@support/types'
import { ServiceTypes, createPatientViaApi, addServiceToPatientViaApi, epicHdId, setupRoutes } from '@support/functions'
import { RegistrationModelLatest } from '@schemas/api/models'
import {
  setServiceStateToInactive,
  submitServiceUpdate,
  setServiceStateToActive,
  checkAndCloseAgedCareConfirmation,
} from '@support/commands/services.commands'
import { UsersRoutes, PatientsRoutes, FacilitiesRoutes, ServicesRoutes, HealthFundsRoutes } from '@support/api'

export const canSetServiceToInactiveThenActive = (options: { serviceType: string; testId: string }): void => {
  const { serviceType, testId } = options
  const serviceDetails: ServiceDetails = ServiceTypes[serviceType]
  const userRole: UserRoles = Cypress.env('role')
  let registration: RegistrationModelLatest

  context(`${testId} - ${serviceDetails.serviceName} - Can set a service to inactive and then active again`, () => {
    before(() => {
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('pharmacyAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('password')
      )
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([
        UsersRoutes.GetUsersDetails,
        UsersRoutes.GetUsersPreferences,
        PatientsRoutes.GetPatientsByUserIdDetails,
        FacilitiesRoutes.GetFacilities,
        ServicesRoutes.PutServicesByUserIdUpdate,
        ServicesRoutes.GetServicesByUserIdAll,
        HealthFundsRoutes.GetHealthfundsByHealthFundCodeInsurer,
      ])

      createPatientViaApi().then(patient => {
        registration = patient
        cy.wait(2000) //TODO: Replace with redis?

        addServiceToPatientViaApi({ serviceDetails, patient }).then(({ userId }) => {
          cy.visit(`/customer/profile/${userId}/details#/services`)

          FacilitiesRoutes.GetFacilities.check()
        })
      })
    })

    it(`Can set a service to inactive and then active again`, () => {
      const { serviceType, facilityCode } = registration.patient.services![0]

      cy.get(epicHdId(`item-${serviceType}-${facilityCode}`)).click()

      setServiceStateToInactive({
        inactiveReason: 'Discharged',
      })
      submitServiceUpdate(serviceDetails)

      ServicesRoutes.PutServicesByUserIdUpdate.check()

      cy.contains('.btn', 'Back to Services').click()

      ServicesRoutes.GetServicesByUserIdAll.check()

      cy.get(epicHdId(`item-${serviceType}-${facilityCode}`))
        .scrollIntoView()
        .should('be.visible')
        .and('contain', 'Inactive')
        .click()

      HealthFundsRoutes.GetHealthfundsByHealthFundCodeInsurer.check()

      setServiceStateToActive()
      submitServiceUpdate(serviceDetails)

      ServicesRoutes.PutServicesByUserIdUpdate.check()

      if (serviceDetails.type === ServiceTypesList.AgedCare) {
        checkAndCloseAgedCareConfirmation()
      }

      cy.contains('.btn', 'Back to Services').click()

      ServicesRoutes.GetServicesByUserIdAll.check()

      cy.get(epicHdId(`item-${serviceType}-${facilityCode}`))
        .scrollIntoView()
        .should('be.visible')
        .and('contain', 'Active')
    })
  })
}
