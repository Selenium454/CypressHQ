import { UserDictionary, ServiceDetails, UserRoles } from '@support/types'
import { ServiceTypes, createPatientViaApi, epicHdId, setupRoutes } from '@support/functions'
import { addServiceToPatientProfileViaVue, cancelService } from '@support/commands/services.commands'
import { UsersRoutes, PatientsRoutes, FacilitiesRoutes } from '@support/api'

export const canCancelServiceCreationOnProfile = (options: { serviceType: string; testId: string }): void => {
  const { serviceType, testId } = options
  const serviceDetails: ServiceDetails = ServiceTypes[serviceType]
  const service = serviceDetails.serviceGenerator()
  const userRole: UserRoles = Cypress.env('role')

  context(`${testId} - ${serviceDetails.serviceName} - Can cancel a service`, () => {
    before(() => {
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('pharmacyAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('password')
      )
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([
        UsersRoutes.GetUsersDetails,
        UsersRoutes.GetUsersPreferences,
        PatientsRoutes.GetPatientsByUserIdDetails,
        FacilitiesRoutes.GetFacilities,
      ])

      createPatientViaApi().then(patient => {
        cy.visit(`/customer/profile/${patient.userId}/details#/services`)

        FacilitiesRoutes.GetFacilities.check()
      })

      addServiceToPatientProfileViaVue({ serviceType: serviceDetails, service })
      cy.get(epicHdId('epic-loader-container')).should('be.visible')
      cy.get(epicHdId('epic-loader-container')).should('not.be.visible')
    })

    it(`Can cancel a service`, () => {
      cancelService()
      cy.get('.medical-service-header').should('not.exist')
    })
  })
}
