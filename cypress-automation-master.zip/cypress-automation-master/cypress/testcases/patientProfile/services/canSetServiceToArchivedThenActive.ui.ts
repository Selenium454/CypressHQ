import { createPatientViaApi, addServiceToPatientViaApi, ServiceTypes, epicHdId, setupRoutes } from '@support/functions'
import { UserRoles, ServiceDetails, UserDictionary, ServiceTypesList } from '@support/types'
import { RegistrationModelLatest } from '@schemas/api/models'
import {
  setServiceStateToArchived,
  submitServiceUpdate,
  setServiceStateToActive,
  checkAndCloseAgedCareConfirmation,
} from '@support/commands/services.commands'
import { UsersRoutes, PatientsRoutes, FacilitiesRoutes, ServicesRoutes, HealthFundsRoutes } from '@support/api'

export const canSetServiceToArchivedThenActive = (options: { serviceType: string; testId: string }): void => {
  const { serviceType, testId } = options
  const serviceDetails: ServiceDetails = ServiceTypes[serviceType]
  const userRole: UserRoles = Cypress.env('role')
  let registration: RegistrationModelLatest

  context(`${testId} - ${serviceDetails.serviceName} - Can set a service to archived and then active again`, () => {
    before(() => {
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('globalAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('adminPassword')
      )
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([
        UsersRoutes.GetUsersDetails,
        UsersRoutes.GetUsersPreferences,
        PatientsRoutes.GetPatientsByUserIdDetails,
        FacilitiesRoutes.GetFacilities,
        ServicesRoutes.PutServicesByUserIdUpdate,
        ServicesRoutes.GetServicesByUserIdAll,
        HealthFundsRoutes.GetHealthfundsByHealthFundCodeInsurer,
      ])

      createPatientViaApi().then(patient => {
        registration = patient
        cy.wait(1000) //TODO: Replace with redis?

        addServiceToPatientViaApi({ serviceDetails, patient }).then(({ userId }) => {
          cy.visit(`/customer/profile/${userId}/details#/services`)

          FacilitiesRoutes.GetFacilities.check()
        })
      })
    })

    it(`Can set a service to archived and then active again`, () => {
      const { serviceType, facilityCode } = registration.patient.services![0]

      cy.get(epicHdId(`item-${serviceType}-${facilityCode}`)).click()

      setServiceStateToArchived({
        inactiveReason: 'None',
      })
      submitServiceUpdate(serviceDetails)

      ServicesRoutes.PutServicesByUserIdUpdate.check()

      cy.contains('.btn', 'Back to Services').click()

      ServicesRoutes.GetServicesByUserIdAll.check()

      cy.get(epicHdId(`item-${serviceType}-${facilityCode}`))
        .scrollIntoView()
        .should('be.visible')
        .and('contain', 'Archived')
        .click()

      HealthFundsRoutes.GetHealthfundsByHealthFundCodeInsurer.check()

      setServiceStateToActive()
      submitServiceUpdate(serviceDetails)

      if (serviceDetails.type === ServiceTypesList.AgedCare) {
        checkAndCloseAgedCareConfirmation()
      }

      ServicesRoutes.PutServicesByUserIdUpdate.check()

      cy.contains('.btn', 'Back to Services').click()

      ServicesRoutes.GetServicesByUserIdAll.check()

      cy.get(epicHdId(`item-${serviceType}-${facilityCode}`))
        .scrollIntoView()
        .should('be.visible')
        .and('contain', 'Active')
    })
  })
}
