import { ServiceDetails, UserRoles, UserDictionary } from '@support/types'
import {
  ServiceTypes,
  createPatientViaApi,
  addServiceToPatientViaApi,
  generateNumbers,
  epicHdId,
  setupRoutes,
} from '@support/functions'
import { RegistrationModelLatest } from '@schemas/api/models'
import { addAdditionalIdentifier, setAdditionalIdentifier } from '@support/commands/services.commands'
import {
  UsersRoutes,
  VisitsRoutes,
  HealthFundsRoutes,
  PatientsRoutes,
  ServicesRoutes,
  FacilitiesRoutes,
} from '@support/api'

export const canAddAndEditAdditionalIds = (options: { serviceType: string; testId: string }): void => {
  const { serviceType, testId } = options
  const serviceDetails: ServiceDetails = ServiceTypes[serviceType]
  const userRole: UserRoles = Cypress.env('role')
  let registration: RegistrationModelLatest

  context(`${testId} - ${serviceDetails.serviceName} - Can add and edit additional IDs`, () => {
    before(() => {
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('globalAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('adminPassword')
      )
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([
        UsersRoutes.GetUsersDetails,
        UsersRoutes.GetUsersPreferences,
        HealthFundsRoutes.GetHealthfundsByHealthFundCodeInsurer,
        VisitsRoutes.PostVisitsSearch,
        PatientsRoutes.GetPatientsByUserIdDetails,
        FacilitiesRoutes.GetFacilities,
        ServicesRoutes.PutServicesByUserIdUpdate,
        ServicesRoutes.GetServicesByUserIdAll,
      ])

      createPatientViaApi().then(patient => {
        registration = patient
        cy.wait(1000) //TODO: Replace with redis?

        addServiceToPatientViaApi({ serviceDetails, patient }).then(({ userId }) => {
          cy.visit(`/customer/profile/${userId}/details#/services`)

          FacilitiesRoutes.GetFacilities.check()
        })
      })
    })

    it(`Can add and edit additional IDs`, () => {
      const { serviceType, facilityCode } = registration.patient.services![0]
      const tcId: string = `${generateNumbers(4)}`
      const gpId: string = `${generateNumbers(4)}`
      const rcId: string = `${generateNumbers(4)}`

      cy.get(epicHdId(`item-${serviceType}-${facilityCode}`)).click()

      addAdditionalIdentifier({ typeValue: 'tcid', identifierType: 'TC ID', identifierValue: tcId })
      addAdditionalIdentifier({ typeValue: 'gpid', identifierType: 'GP ID', identifierValue: gpId })
      addAdditionalIdentifier({ typeValue: 'rcid', identifierType: 'ROC ID', identifierValue: rcId })
      cy.get(epicHdId('button-save-service')).click()

      cy.contains('.btn', 'Back to Services').click()

      const newTcId: string = `${generateNumbers(4)}`
      const newGpId: string = `${generateNumbers(4)}`
      const newRcId: string = `${generateNumbers(4)}`
      cy.get(epicHdId(`item-${serviceType}-${facilityCode}`)).click()

      setAdditionalIdentifier({ typeValue: 'tcid', identifierType: 'TC ID', identifierValue: newTcId })
      setAdditionalIdentifier({ typeValue: 'gpid', identifierType: 'ROC ID', identifierValue: newRcId })
      setAdditionalIdentifier({ typeValue: 'rcid', identifierType: 'GP ID', identifierValue: newGpId })
      cy.get(epicHdId('button-save-service')).click()
    })
  })
}
