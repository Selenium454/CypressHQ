import {
  createPatientViaApi,
  addServiceToPatientViaApi,
  ServiceTypes,
  epicHdId,
  generateNumbers,
  setupRoutes,
} from '@support/functions'
import { ServiceDetails, UserRoles, UserDictionary } from '@support/types'
import { RegistrationModelLatest } from '@schemas/api/models'
import { addHealthFundInfo, submitServiceUpdate } from '@support/commands/services.commands'
import {
  UsersRoutes,
  HealthFundsRoutes,
  VisitsRoutes,
  PatientsRoutes,
  FacilitiesRoutes,
  ServicesRoutes,
} from '@support/api'

export const canAddAndEditHealthFundInfo = (options: { serviceType: string; testId: string }): void => {
  const { serviceType, testId } = options
  const serviceDetails: ServiceDetails = ServiceTypes[serviceType]
  const userRole: UserRoles = Cypress.env('role')
  let registration: RegistrationModelLatest

  context(`${testId} - ${serviceDetails.serviceName} - Can add and remove health fund info from a service`, () => {
    before(() => {
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('pharmacyAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('password')
      )
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([
        UsersRoutes.GetUsersDetails,
        UsersRoutes.GetUsersPreferences,
        HealthFundsRoutes.GetHealthfundsByHealthFundCodeInsurer,
        HealthFundsRoutes.PostHealthFundsInsurers,
        VisitsRoutes.PostVisitsSearch,
        PatientsRoutes.GetPatientsByUserIdDetails,
        FacilitiesRoutes.GetFacilities,
        ServicesRoutes.PutServicesByUserIdUpdate,
        ServicesRoutes.GetServicesByUserIdAll,
      ])

      createPatientViaApi().then(patient => {
        registration = patient
        cy.wait(1000) //TODO: Replace with redis?

        addServiceToPatientViaApi({ serviceDetails, patient }).then(({ userId }) => {
          cy.visit(`/customer/profile/${userId}/details#/services`)

          FacilitiesRoutes.GetFacilities.check()
        })
      })
    })

    it(`Can add health fund info to a service`, () => {
      const { serviceType, facilityCode } = registration.patient.services![0]

      cy.get(epicHdId(`item-${serviceType}-${facilityCode}`)).click()

      HealthFundsRoutes.GetHealthfundsByHealthFundCodeInsurer.check()

      addHealthFundInfo({
        healthFundId: 'HCF',
        coverLevel: 'TOP',
        membershipNumber: generateNumbers(10).toString(),
      })

      submitServiceUpdate(serviceDetails)

      ServicesRoutes.PutServicesByUserIdUpdate.check()

      cy.contains('.btn', 'Back to Services').click()

      ServicesRoutes.GetServicesByUserIdAll.check()

      cy.get(epicHdId(`item-${serviceType}-${facilityCode}`)).click()

      HealthFundsRoutes.GetHealthfundsByHealthFundCodeInsurer.check()

      addHealthFundInfo({
        healthFundId: 'ESH',
        coverLevel: 'BOT',
        membershipNumber: generateNumbers(10).toString(),
      })

      submitServiceUpdate(serviceDetails)

      ServicesRoutes.PutServicesByUserIdUpdate.check()
    })
  })
}
