import { createPatientViaApi, addServiceToPatientViaApi, epicHdId, ServiceTypes, setupRoutes } from '@support/functions'
import { ServiceDetails, UserRoles, UserDictionary } from '@support/types'
import { RegistrationModelLatest } from '@schemas/api/models'
import { UsersRoutes, PatientsRoutes, FacilitiesRoutes, HealthFundsRoutes, VisitsRoutes } from '@support/api'

export const visitsAreShownOnService = (options: { serviceType: string; testId: string }): void => {
  const { serviceType, testId } = options
  const serviceDetails: ServiceDetails = ServiceTypes[serviceType]
  const userRole: UserRoles = Cypress.env('role')
  let registration: RegistrationModelLatest

  context(`${testId} - ${serviceDetails.serviceName} - Can view last X visits on a service`, () => {
    before(() => {
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('cancerCareAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('password')
      )
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([
        UsersRoutes.GetUsersDetails,
        UsersRoutes.GetUsersPreferences,
        PatientsRoutes.GetPatientsByUserIdDetails,
        FacilitiesRoutes.GetFacilities,
        HealthFundsRoutes.GetHealthfundsByHealthFundCodeInsurer,
        VisitsRoutes.PostVisitsSearch,
      ])

      createPatientViaApi().then(patient => {
        registration = patient
        cy.wait(1000) //TODO: Replace with redis?

        addServiceToPatientViaApi({ serviceDetails, patient }).then(({ userId }) => {
          cy.visit(`/customer/profile/${userId}/details#/services`)

          FacilitiesRoutes.GetFacilities.check()
        })
      })
    })

    it(`Can view last 5 visits on a service`, () => {
      const { serviceType, facilityCode } = registration.patient.services![0]

      cy.get(epicHdId(`item-${serviceType}-${facilityCode}`)).click()

      HealthFundsRoutes.GetHealthfundsByHealthFundCodeInsurer.check()

      cy.contains('.title', 'Last 0 Consultation Visits')
        .scrollIntoView()
        .should('be.visible')
    })
  })
}
