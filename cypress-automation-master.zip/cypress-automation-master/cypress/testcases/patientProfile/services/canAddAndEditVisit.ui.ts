import { ServiceDetails, UserRoles, UserDictionary } from '@support/types'
import { ServiceTypes, createPatientViaApi, addServiceToPatientViaApi, epicHdId, setupRoutes } from '@support/functions'
import { RegistrationModelLatest } from '@schemas/api/models'
import { setTreatingDoctor } from '@support/commands/visits.commands'
import {
  UsersRoutes,
  HealthFundsRoutes,
  PatientsRoutes,
  VisitsRoutes,
  FacilitiesRoutes,
  DoctorsRoutes,
} from '@support/api'

export const canAddAndEditVisit = (options: { serviceType: string; testId: string }): void => {
  const { serviceType, testId } = options
  const serviceDetails: ServiceDetails = ServiceTypes[serviceType]
  const doctorLastName: string = Cypress.env('doctorLastName')
  const userRole: UserRoles = Cypress.env('role')
  let registration: RegistrationModelLatest

  context(`${testId} - ${serviceDetails.serviceName} -Can add and edit visits`, () => {
    before(() => {
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('cancerCareAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('password')
      )
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([
        UsersRoutes.GetUsersDetails,
        UsersRoutes.GetUsersPreferences,
        HealthFundsRoutes.GetHealthfundsByHealthFundCodeInsurer,
        VisitsRoutes.PostVisitsSearch,
        VisitsRoutes.PostVisits,
        VisitsRoutes.GetVisitsById,
        VisitsRoutes.PutVisits,
        PatientsRoutes.GetPatientsByUserIdDetails,
        FacilitiesRoutes.GetFacilities,
        DoctorsRoutes.PostDoctorsSearch,
      ])

      createPatientViaApi().then(patient => {
        registration = patient
        cy.wait(1000) //TODO: Replace with redis?

        addServiceToPatientViaApi({ serviceDetails, patient }).then(({ userId }) => {
          cy.visit(`/customer/profile/${userId}/details#/services`)

          FacilitiesRoutes.GetFacilities.check()
        })
      })
    })

    it(`Can add and edit visits`, () => {
      const { serviceType, facilityCode } = registration.patient.services![0]
      const todaysDate = Cypress.moment().format('DD/MM/Y')

      cy.visit(`/customer/profile/${registration.userId}/details#/services`)

      cy.get(epicHdId(`item-${serviceType}-${facilityCode}`)).click()

      VisitsRoutes.PostVisitsSearch.check()

      cy.contains('ADD VISIT')
        .scrollIntoView()
        .should('be.visible')
        .click()

      cy.contains('.tab', 'Visit Details')
        .scrollIntoView()
        .should('be.visible')

      cy.get('#epic-appointment-date-placeholder').contains(todaysDate)

      setTreatingDoctor(doctorLastName)

      cy.contains('.btn-action', 'Save').click()

      VisitsRoutes.PostVisits.check()

      cy.contains('.tab', 'Visits').click()

      VisitsRoutes.PostVisitsSearch.check()

      cy.visit(`/customer/profile/${registration.userId}/details#/services`)
        .get(epicHdId(`item-${serviceType}-${facilityCode}`))
        .click()

      VisitsRoutes.GetVisitsById.check()

      cy.contains('.tab', 'Visits').click()

      cy.get('.visit-header').should('be.visible')

      cy.get('.data-row').click()

      if (userRole === 'doctor') {
        cy.contains('Visit Information')
          .closest('.billing-information')
          .as('visitSection')
      } else {
        cy.contains('Billed Information')
          .closest('.billing-information')
          .as('visitSection')
      }

      cy.get('@visitSection').within(() => {
        cy.contains('132').click()
        cy.contains('13915').click()
      })

      cy.contains('.btn-action', 'Save').click()

      VisitsRoutes.PutVisits.check()
    })
  })
}
