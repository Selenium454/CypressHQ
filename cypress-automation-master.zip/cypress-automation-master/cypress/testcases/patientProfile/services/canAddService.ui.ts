import { ServiceDetails, UserRoles, UserDictionary, ServiceTypesList } from '@support/types'
import { ServiceTypes, createPatientViaApi, epicHdId, setupRoutes } from '@support/functions'
import {
  addServiceToPatientProfileViaVue,
  submitServiceCreation,
  checkAndCloseAgedCareConfirmation,
  addNewService,
} from '@support/commands/services.commands'
import { RegistrationModelLatest } from '@schemas/api/models'
import { UsersRoutes, PatientsRoutes, FacilitiesRoutes, ServicesRoutes } from '@support/api'

export const canAddService = (options: {
  serviceType: string
  canAddMoreThanOneTestId: string
  cannotAddMoreThanOneTestId: string
}): void => {
  const { serviceType, canAddMoreThanOneTestId, cannotAddMoreThanOneTestId } = options
  const serviceDetails: ServiceDetails = ServiceTypes[serviceType]
  const altServiceDetails: ServiceDetails = ServiceTypes[serviceType + 'Alt']
  const userRole: UserRoles = Cypress.env('role')
  const service = ServiceTypes[serviceType].serviceGenerator()
  let registration: RegistrationModelLatest

  context(`${serviceDetails.serviceName} - Can add and cancel services in patient profile`, () => {
    before(() => {
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('pharmacyAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('password')
      )
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([
        UsersRoutes.GetUsersDetails,
        UsersRoutes.GetUsersPreferences,
        PatientsRoutes.GetPatientsByUserIdDetails,
        FacilitiesRoutes.GetFacilities,
        ServicesRoutes.GetServicesByUserIdAll,
        ServicesRoutes.ProfilePostServicesByUserIdAdd,
      ])

      createPatientViaApi().then(patient => {
        registration = patient
        cy.visit(`/customer/profile/${patient.userId}/details#/services`)

        FacilitiesRoutes.GetFacilities.check()
      })

      addServiceToPatientProfileViaVue({ serviceType: serviceDetails, service })
      cy.get(epicHdId('epic-loader-container')).should('be.visible')
      cy.get(epicHdId('epic-loader-container')).should('not.be.visible')
    })

    it(`${canAddMoreThanOneTestId} - Can add more than one service for a different facility`, () => {
      if (serviceDetails.type === ServiceTypesList.Hospital) {
        cy.get('[name="Ur Number"]')
          .first()
          .clear()
          .type(registration.userId!)
      }

      submitServiceCreation(serviceDetails)
      if (serviceDetails.type === ServiceTypesList.AgedCare) {
        checkAndCloseAgedCareConfirmation()
      }

      ServicesRoutes.ProfilePostServicesByUserIdAdd.check()

      cy.contains('.btn', 'Back to Services').click()

      addNewService({ serviceDetails: altServiceDetails, selectType: 'wide' })
      if (serviceDetails.type === ServiceTypesList.Hospital) {
        cy.get('[name="Ur Number"]')
          .first()
          .clear()
          .type(registration.userId!)
      }

      submitServiceCreation(serviceDetails)
      if (altServiceDetails.type === ServiceTypesList.AgedCareAlt) {
        checkAndCloseAgedCareConfirmation()
      }

      ServicesRoutes.ProfilePostServicesByUserIdAdd.check()
    })

    it(`${cannotAddMoreThanOneTestId} - Cannot add more than one service for the same facility`, () => {
      if (serviceDetails.type === ServiceTypesList.Hospital) {
        cy.get('[name="Ur Number"]')
          .first()
          .clear()
          .type(registration.userId!)
      }

      submitServiceCreation(serviceDetails)

      ServicesRoutes.ProfilePostServicesByUserIdAdd.check()

      if (serviceDetails.type === ServiceTypesList.AgedCare) {
        checkAndCloseAgedCareConfirmation()
      }

      cy.contains('.btn', 'Back to Services').click()

      addNewService({ serviceDetails, selectType: 'wide', alreadyExists: true })

      cy.get(epicHdId('dialog-container')).within(() => {
        cy.contains('This service already exists.').should('be.visible')
      })
    })
  })
}
