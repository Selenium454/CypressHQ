import { ServiceDetails, UserRoles, UserDictionary } from '@support/types'
import { ServiceTypes, createPatientViaApi, addServiceToPatientViaApi, epicHdId, setupRoutes } from '@support/functions'
import { PostPatientsRegisterRequestLatest } from '@schemas/api/endpoints'
import {
  searchForDoctor,
  addDoctorReferral,
  deleteDoctorReferral,
  deleteDoctor,
  checkForDoctorAndAdd,
} from '@support/commands/doctors.commands'
import { submitServiceUpdate } from '@support/commands/services.commands'
import {
  UsersRoutes,
  DoctorsRoutes,
  HealthFundsRoutes,
  VisitsRoutes,
  PatientsRoutes,
  FacilitiesRoutes,
  ServicesRoutes,
} from '@support/api'

export const canAddAndDeleteDoctorWithReferralOnProfile = (options: { serviceType: string; testId: string }): void => {
  const { serviceType, testId } = options
  const serviceDetails: ServiceDetails = ServiceTypes[serviceType]
  const userRole: UserRoles = Cypress.env('role')
  const doctorFullName: string = Cypress.env('doctorFullName')
  const contextTag = `${testId} - ${serviceDetails.serviceName}`

  context(`${contextTag} - Can add and remove a doctor from a service with a referral`, () => {
    before(() => {
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('pharmacyAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('password')
      )
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([
        UsersRoutes.GetUsersDetails,
        UsersRoutes.GetUsersPreferences,
        DoctorsRoutes.PostDoctorsSearch,
        HealthFundsRoutes.GetHealthfundsByHealthFundCodeInsurer,
        VisitsRoutes.PostVisitsSearch,
        PatientsRoutes.GetPatientsByUserIdDetails,
        FacilitiesRoutes.GetFacilities,
        ServicesRoutes.PutServicesByUserIdUpdate,
        ServicesRoutes.GetServicesByUserIdAll,
      ])

      createPatientViaApi().then(patient => {
        cy.wait(1000) //TODO: Replace with redis?

        addServiceToPatientViaApi({ serviceDetails, patient }).then(({ userId }) => {
          cy.visit(`/customer/profile/${userId}/details#/services`)
          FacilitiesRoutes.GetFacilities.check()
        })
      })
    })

    it(`Can add and remove a doctor from a service with a referral`, () => {
      cy.fixture('patient').then($customer => {
        const customer = $customer as PostPatientsRegisterRequestLatest
        const { serviceType, facilityCode } = customer.patient.services![0]

        cy.get(epicHdId(`item-${serviceType}-${facilityCode}`))
          .click()
          .wait(1000)
      })

      cy.contains('.epic-link', 'ADD DOCTOR').click()

      searchForDoctor({ searchMethodSelector: '.el-popper [value="name"]', searchTerm: doctorFullName })

      DoctorsRoutes.PostDoctorsSearch.check().then(({ response }) => {
        checkForDoctorAndAdd(response)
      })

      submitServiceUpdate(serviceDetails)

      ServicesRoutes.PutServicesByUserIdUpdate.check().then(() => {
        cy.get(epicHdId('epic-loader-container')).should('not.be.visible')
        ServicesRoutes.GetServicesByUserIdAll.check()
      })

      addDoctorReferral()
      submitServiceUpdate(serviceDetails)

      ServicesRoutes.PutServicesByUserIdUpdate.check().then(() => {
        cy.get(epicHdId('epic-loader-container')).should('not.be.visible')
        ServicesRoutes.GetServicesByUserIdAll.check()
      })

      deleteDoctorReferral()
      submitServiceUpdate(serviceDetails)

      ServicesRoutes.PutServicesByUserIdUpdate.check().then(() => {
        cy.get(epicHdId('epic-loader-container')).should('not.be.visible')
        ServicesRoutes.GetServicesByUserIdAll.check()
      })

      cy.get('.referral-container').should('not.exist')

      deleteDoctor()
      submitServiceUpdate(serviceDetails)

      ServicesRoutes.PutServicesByUserIdUpdate.check().then(() => {
        cy.get(epicHdId('epic-loader-container')).should('not.be.visible')
        ServicesRoutes.GetServicesByUserIdAll.check()
      })

      cy.get('.doctor-panel').should('not.exist')
    })
  })
}
