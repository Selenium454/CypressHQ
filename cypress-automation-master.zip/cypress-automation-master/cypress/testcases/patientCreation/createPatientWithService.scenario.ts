import { ServiceDetails, ServiceTypesList, GeneratedRegistrationModel, UserRoles, UserDictionary } from '@support/types'
import { ServiceTypes, generateRegistrationModel, capitaliseFirstLetter, setupRoutes } from '@support/functions'
import { MedicalServiceLatest, SuccessResponseLatest } from '@schemas/api/models'
import { fillField, epicSelect } from '@support/commands/general.commands'
import { addNewService } from '@support/commands/services.commands'
import {
  UsersRoutes,
  FacilitiesRoutes,
  PatientsRoutes,
  ServicesRoutes,
  AddressFinderRoutes,
  MedicareRoutes,
} from '@support/api'

const testCases = [
  {
    viewportX: Cypress.env('desktop_x'),
    viewportY: Cypress.env('desktop_y'),
    contextName: 'Viewport - Desktop',
    name: 'desktop',
    openMenu: false,
    selectType: 'wide',
  },
  {
    viewportX: Cypress.env('tab2_x'),
    viewportY: Cypress.env('tab2_y'),
    contextName: 'Viewport - Tablet 2',
    name: 'tab 2',
    openMenu: true,
    selectType: 'narrow',
  },
  {
    viewportX: Cypress.env('tab4_x'),
    viewportY: Cypress.env('tab4_x'),
    contextName: 'Viewport - Tablet 4',
    name: 'tab 4',
    openMenu: true,
    selectType: 'narrow',
  },
]

export const createPatientWithService = (): void => {
  const serviceDetails: ServiceDetails = ServiceTypes[ServiceTypesList.Hospital]
  let service: MedicalServiceLatest
  let registration: GeneratedRegistrationModel

  context('C51757 - Can create a hospital patient with additional information', () => {
    before(() => {
      const userRole: UserRoles = Cypress.env('role')
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('pharmacyAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('password')
      )
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([
        UsersRoutes.GetUsersDetails,
        UsersRoutes.GetUsersPreferences,
        FacilitiesRoutes.GetFacilities,
        PatientsRoutes.PostPatientsRegister,
        PatientsRoutes.SearchForEmail,
        ServicesRoutes.PostServicesByUserIdAdd,
        ServicesRoutes.GetServicesByUserIdAll,
        AddressFinderRoutes.GetAddressFinderAddressInfo,
        AddressFinderRoutes.GetAddressFinderAutoComplete,
        MedicareRoutes.PostMedicareValidateRepat,
      ])

      registration = generateRegistrationModel()
      service = serviceDetails.serviceGenerator()
    })

    testCases.forEach(testCase => {
      context(testCase.contextName, () => {
        beforeEach(() => {
          cy.viewport(testCase.viewportX, testCase.viewportY)
        })

        it(`Can create a hospital patient with additional information on ${testCase.name}`, () => {
          cy.get('ul.main-navigation').then(navDrawer => {
            if (navDrawer.has('.closed')) {
              cy.get('.hamburger-box').click()
            }
          })

          cy.contains('li', 'Create Customer').click()

          UsersRoutes.GetUsersDetails.check()

          //Personal Details Section
          fillField({ locator: '#txt-firstname', inputValue: registration.firstName })
          fillField({ locator: '#txt-mid-name', inputValue: registration.middleName })
          fillField({ locator: '#txt-surname', inputValue: registration.surName })
          fillField({
            locator: '#txt-dob',
            inputValue: Cypress.moment(registration.dateOfBirth).format('DD / MM / YYYY'),
          })
          fillField({ locator: '#postCode', inputValue: registration.address.postCode })
          fillField({ locator: '#txt-phone', inputValue: registration.phoneNumber })
          fillField({ locator: '#txt-mobile', inputValue: registration.mobileNumber })
          fillField({ locator: '#txt-email', inputValue: registration.email })

          PatientsRoutes.SearchForEmail.check()

          cy.get(`input[value="${registration.sex}"]`).check()

          fillField({ locator: '#street', inputValue: '12345 h' })

          AddressFinderRoutes.GetAddressFinderAutoComplete.check()

          cy.contains('li.af_item', '12345')
            .first()
            .should('be.visible')
            .click({ force: true })

          AddressFinderRoutes.GetAddressFinderAddressInfo.check()

          cy.contains('button.epic-button', 'Next').click()

          //Medicare
          fillField({
            locator: '#medicare-exp',
            inputValue: Cypress.moment(registration.patient.medicareValidDate).format('MM / YYYY'),
          })
          fillField({ locator: '#txt-concession', inputValue: registration.patient.concessionNumber })

          //TODO: Replace with datepicker set
          // fillField({
          //   locator: '#txt-concession-exp',
          //   inputValue: Cypress.moment(registration.patient.concessionValidToDate).format('DD/MM/YYYY'),
          // })

          fillField({ locator: '#txt-safety-net', inputValue: registration.patient.safetyNetNumber })
          fillField({ locator: '#txt-repat-num', inputValue: registration.patient.repatNumber })
          epicSelect({
            container: 'div.patient-creation-step',
            inputLocator: '#repat-card-type',
            dropdownLocator: `.el-popper.Type-select-dropdown-${testCase.selectType} .epic-text`,
            option: capitaliseFirstLetter(registration.patient.repatCardType),
          })

          MedicareRoutes.PostMedicareValidateRepat.check()

          cy.contains('button.epic-button', 'Next').click()

          //Medical Services
          FacilitiesRoutes.GetFacilities.check()

          addNewService({ serviceDetails, selectType: 'wide' })

          cy.get('[name="Ur Number"]')
            .first()
            .clear()
            .type(service.urNumber!)

          cy.contains('button.epic-button', 'Next').click()

          //Additional Information
          epicSelect({
            container: 'div.patient-creation-step',
            inputLocator: '#select-marital-status',
            dropdownLocator: `.el-popper.Status-select-dropdown-${testCase.selectType} .epic-text`,
            option: capitaliseFirstLetter(registration.maritalStatus),
          })
          epicSelect({
            container: 'div.patient-creation-step',
            inputLocator: '#select-indigenous-status',
            dropdownLocator: `.el-popper.Identification-select-dropdown-${testCase.selectType} .epic-text`,
            option: capitaliseFirstLetter(registration.indigenousStatus),
          })
          epicSelect({
            container: 'div.patient-creation-step',
            inputLocator: '[name="islanderStatus-select-input-wide"]',
            dropdownLocator: `.el-popper.islanderStatus-select-dropdown-${testCase.selectType} .epic-text`,
            option: capitaliseFirstLetter(registration.australianSouthSeaIslanderStatus),
          })
          epicSelect({
            container: 'div.patient-creation-step',
            inputLocator: '#select-ethnicity',
            dropdownLocator: `.el-popper.Ethnicity-select-dropdown-${testCase.selectType} .epic-text`,
            option: capitaliseFirstLetter(registration.ethnicGroup),
          })
          epicSelect({
            container: 'div.patient-creation-step',
            inputLocator: '#select-lang',
            dropdownLocator: `.el-popper.Language-select-dropdown-${testCase.selectType} .epic-text`,
            option: capitaliseFirstLetter(registration.language),
          })
          fillField({ locator: '#allergies', inputValue: 'peanuts' })
          fillField({ locator: '[name="txt-notes"]', inputValue: 'customer notes' })
          epicSelect({
            container: 'div.patient-creation-step',
            inputLocator: '#select-employment-status',
            dropdownLocator: `.el-popper.Status-select-dropdown-${testCase.selectType} .epic-text`,
            option: capitaliseFirstLetter(registration.employmentStatus),
          })
          epicSelect({
            container: 'div.patient-creation-step',
            inputLocator: '#select-country-birth',
            dropdownLocator: `.el-popper.Birth-select-dropdown-${testCase.selectType} .epic-text`,
            option: capitaliseFirstLetter(registration.countryOfBirth),
          })
          epicSelect({
            container: 'div.patient-creation-step',
            inputLocator: '#select-nationality',
            dropdownLocator: `.el-popper.Nationality-select-dropdown-${testCase.selectType} .epic-text`,
            option: capitaliseFirstLetter(registration.nationality),
          })

          cy.contains('button.epic-button', 'Save Profile').click()

          cy.wait('@createCustomer').then($xhrRequest => {
            const typedResponse = $xhrRequest.responseBody as SuccessResponseLatest
            const { model } = typedResponse
            if (model) {
              cy.task('storeUserIdForDeletion', model.toString())
            }
          })
        })
      })
    })
  })
}
