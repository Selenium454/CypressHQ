import { ServiceDetails, GeneratedRegistrationModel, UserRoles, UserDictionary } from '@support/types'
import { ServiceTypes, generateVueRegistrationModel, setupRoutes, epicHdId, generateNumbers } from '@support/functions'
import { MedicalServiceLatest } from '@schemas/api/models'
import { UsersRoutes, FacilitiesRoutes, HealthFundsRoutes } from '@support/api'
import { addPersonalDetailsToStore, goToCreationStep } from '@support/commands/patient.commands'
import { addServiceViaVue, addHealthFundInfo } from '@support/commands/services.commands'

export const canAddHealthFundInfo = (options: { serviceType: string; testId: string }): void => {
  const { serviceType, testId } = options
  const serviceDetails: ServiceDetails = ServiceTypes[serviceType]
  const service: MedicalServiceLatest = serviceDetails.serviceGenerator()
  const patient: GeneratedRegistrationModel = generateVueRegistrationModel()
  const contextTag = `${testId} - ${serviceDetails.serviceName}`

  context(`${contextTag} - Can add health fund info to a service`, () => {
    before(() => {
      const userRole: UserRoles = Cypress.env('role')
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('pharmacyAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('password')
      )
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([
        UsersRoutes.GetUsersDetails,
        UsersRoutes.GetUsersPreferences,
        FacilitiesRoutes.GetFacilities,
        HealthFundsRoutes.PostHealthFundsInsurers,
        HealthFundsRoutes.GetHealthfundsByHealthFundCodeInsurer,
      ])

      cy.visit('/v/#/customer/create').then(() => {
        addPersonalDetailsToStore(patient)
        goToCreationStep(2)
        addServiceViaVue({ serviceDetails, service })

        cy.get(epicHdId('epic-loader-container')).should('be.visible')
        cy.get(epicHdId('epic-loader-container')).should('not.be.visible')
      })
    })

    it(`Can add health fund info to a service`, () => {
      addHealthFundInfo({
        healthFundId: 'HCF',
        coverLevel: 'TOP',
        membershipNumber: generateNumbers(10).toString(),
      })
    })
  })
}
