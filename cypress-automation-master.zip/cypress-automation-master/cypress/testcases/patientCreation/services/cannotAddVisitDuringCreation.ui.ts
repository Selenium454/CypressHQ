import { ServiceDetails, GeneratedRegistrationModel, UserRoles, UserDictionary } from '@support/types'
import { ServiceTypes, generateVueRegistrationModel, epicHdId, setupRoutes } from '@support/functions'
import { MedicalServiceLatest } from '@schemas/api/models'
import { addPersonalDetailsToStore, goToCreationStep } from '@support/commands/patient.commands'
import { addServiceViaVue } from '@support/commands/services.commands'
import { FacilitiesRoutes, UsersRoutes } from '@support/api'

export const cannotAddVisitDuringCreation = (options: { serviceType: string; testId: string }): void => {
  const { serviceType, testId } = options
  const serviceDetails: ServiceDetails = ServiceTypes[serviceType]
  const service: MedicalServiceLatest = serviceDetails.serviceGenerator()
  const patient: GeneratedRegistrationModel = generateVueRegistrationModel()
  const contextTag = `${testId} - ${serviceDetails.serviceName}`

  context(`${contextTag} - Cannot add a visit to a service on patient cration`, () => {
    before(() => {
      const userRole: UserRoles = Cypress.env('role')
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('pharmacyAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('password')
      )
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([UsersRoutes.GetUsersDetails, UsersRoutes.GetUsersPreferences, FacilitiesRoutes.GetFacilities])

      cy.visit('/v/#/customer/create').then(() => {
        addPersonalDetailsToStore(patient)
        goToCreationStep(2)

        addServiceViaVue({ serviceDetails, service })

        cy.get(epicHdId('epic-loader-container')).should('be.visible')
        cy.get(epicHdId('epic-loader-container')).should('not.be.visible')
      })
    })

    it(`Cannot add a visit to a service on patient cration`, () => {
      cy.contains('.epic-link', 'ADD VISIT +').should('not.exist')
    })
  })
}
