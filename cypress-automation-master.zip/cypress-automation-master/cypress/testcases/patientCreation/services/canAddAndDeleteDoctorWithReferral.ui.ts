import { ServiceDetails, GeneratedRegistrationModel, UserRoles, UserDictionary, ServiceTypesList } from '@support/types'
import { ServiceTypes, generateVueRegistrationModel, setupRoutes, epicHdId } from '@support/functions'
import { MedicalServiceLatest } from '@schemas/api/models'
import { UsersRoutes, DoctorsRoutes, FacilitiesRoutes } from '@support/api'
import { goToCreationStep, addPersonalDetailsToStore } from '@support/commands/patient.commands'
import { addServiceViaVue } from '@support/commands/services.commands'
import {
  searchForDoctor,
  checkForDoctorAndAdd,
  addDoctorReferral,
  deleteDoctorReferral,
  deleteDoctor,
} from '@support/commands/doctors.commands'

export const canAddAndDeleteDoctorWithReferral = (options: { serviceType: string; testId: string }): void => {
  const { serviceType, testId } = options
  const serviceDetails: ServiceDetails = ServiceTypes[serviceType]
  const service: MedicalServiceLatest = serviceDetails.serviceGenerator()
  const patient: GeneratedRegistrationModel = generateVueRegistrationModel()
  const contextTag = `${testId} - ${serviceDetails.serviceName}`

  context(`${contextTag} - Can add and remove a doctor from a service with a referral`, () => {
    const userRole: UserRoles = Cypress.env('role')
    before(() => {
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('pharmacyAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('password')
      )
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([
        UsersRoutes.GetUsersDetails,
        UsersRoutes.GetUsersPreferences,
        DoctorsRoutes.PostDoctorsSearch,
        FacilitiesRoutes.GetFacilities,
      ])

      cy.visit('/v/#/customer/create')
      UsersRoutes.GetUsersDetails.check()
      addPersonalDetailsToStore(patient)
      goToCreationStep(2)
      addServiceViaVue({ serviceDetails: serviceDetails, service })
      cy.get(epicHdId('epic-loader-container')).should('be.visible')
      cy.get(epicHdId('epic-loader-container')).should('not.be.visible')
    })

    it(`Can add and remove a doctor from a service with a referral`, () => {
      if (serviceDetails.type === ServiceTypesList.Hospital) {
        cy.get('[name="Ur Number"]')
          .first()
          .clear()
          .type(service.urNumber!)
      }

      cy.contains('.epic-link', 'ADD DOCTOR').click()

      searchForDoctor({
        searchMethodSelector: '.el-popper [value="name"]',
        searchTerm: Cypress.env('doctorFullName'),
      })

      DoctorsRoutes.PostDoctorsSearch.check().then(({ response }) => {
        checkForDoctorAndAdd(response)
      })

      addDoctorReferral()
      deleteDoctorReferral()
      deleteDoctor()
    })
  })
}
