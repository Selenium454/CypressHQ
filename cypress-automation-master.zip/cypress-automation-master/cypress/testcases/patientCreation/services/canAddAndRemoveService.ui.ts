import { ServiceDetails, GeneratedRegistrationModel, UserRoles, UserDictionary, ServiceTypesList } from '@support/types'
import { ServiceTypes, generateVueRegistrationModel, setupRoutes, epicHdId } from '@support/functions'
import { MedicalServiceLatest } from '@schemas/api/models'
import { UsersRoutes, FacilitiesRoutes } from '@support/api'
import { addPersonalDetailsToStore, goToCreationStep } from '@support/commands/patient.commands'
import {
  addServiceViaVue,
  checkAndCloseAgedCareConfirmation,
  addNewService,
  removeService,
} from '@support/commands/services.commands'

export const canAddAndRemoveService = (options: {
  serviceType: string
  canAddMoreThanOneTestId: string
  cannotAddMoreThanOneTestId: string
  canRemoveTestId: string
}): void => {
  const { serviceType, canAddMoreThanOneTestId, cannotAddMoreThanOneTestId, canRemoveTestId } = options
  const serviceDetails: ServiceDetails = ServiceTypes[serviceType]
  const altServiceDetails: ServiceDetails = ServiceTypes[serviceType + 'Alt']
  const service: MedicalServiceLatest = serviceDetails.serviceGenerator()
  const patient: GeneratedRegistrationModel = generateVueRegistrationModel()

  context(`${serviceDetails.serviceName} - Can add and remove services during patient creation`, () => {
    before(() => {
      const userRole: UserRoles = Cypress.env('role')
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('pharmacyAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('password')
      )
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([UsersRoutes.GetUsersDetails, UsersRoutes.GetUsersPreferences, FacilitiesRoutes.GetFacilities])

      cy.visit('/v/#/customer/create').then(() => {
        addPersonalDetailsToStore(patient)
        goToCreationStep(2)
        addServiceViaVue({ serviceDetails, service })

        cy.get(epicHdId('epic-loader-container')).should('be.visible')
        cy.get(epicHdId('epic-loader-container')).should('not.be.visible')
      })
    })

    it(`${canAddMoreThanOneTestId} - Can add more than one service for a different facility`, () => {
      if (serviceDetails.type === ServiceTypesList.AgedCare) {
        cy.contains('button.epic-button', 'Next').click() //TODO: ?
        checkAndCloseAgedCareConfirmation()
      }

      addNewService({ serviceDetails: altServiceDetails, selectType: 'wide' })

      cy.get(epicHdId('dialog-container')).should('not.exist')
    })

    it(`${cannotAddMoreThanOneTestId} - Cannot add more than one service for the same facility`, () => {
      addNewService({ serviceDetails, selectType: 'wide', alreadyExists: true })

      cy.get(epicHdId('dialog-container')).within(() => {
        cy.contains('This service already exists.').should('be.visible')
      })
    })

    it(`${canRemoveTestId} - Can remove a service during creation`, () => {
      removeService()

      cy.get('.medical-service-header').should('not.exist')
    })
  })
}
