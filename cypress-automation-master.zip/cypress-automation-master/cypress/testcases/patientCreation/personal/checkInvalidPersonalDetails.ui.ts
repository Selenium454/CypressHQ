import { GeneratedRegistrationModel, UserRoles, UserDictionary } from '@support/types'
import { generateRegistrationModel, setupRoutes } from '@support/functions'
import { UsersRoutes, PatientsRoutes, ServicesRoutes } from '@support/api'
import { checkForValidationError, checkForInvalidValues } from '@support/commands/general.commands'

export const checkInvalidPersonalDetails = (): void => {
  let registrationModel: GeneratedRegistrationModel = generateRegistrationModel()

  context('C51760 - Check field validation & mandatory fields', () => {
    before(() => {
      const userRole: UserRoles = Cypress.env('role')
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('pharmacyAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('password')
      )
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([
        UsersRoutes.GetUsersDetails,
        PatientsRoutes.PostPatientsRegister,
        ServicesRoutes.PostServicesByUserIdAdd,
        ServicesRoutes.GetServicesByUserIdAll,
      ])
    })

    const firstNameLocator: string = '#txt-firstname'
    const middleNameLocator: string = '#txt-mid-name'
    const surnameLocator: string = '#txt-surname'
    const dobLocator: string = '#txt-dob'
    const genderLocator: string = `input[value="${registrationModel.sex}"]`
    const streetLocator: string = '#street'
    const suburbLocator: string = '#suburb'
    const stateLocator: string = '#state'
    const postCodeLocator: string = '#postCode'

    it('Check mandatory fields', () => {
      cy.visit('v/#/customer/create')

      cy.contains('button.epic-button', 'Next').click()

      checkForValidationError({
        locator: firstNameLocator,
        errorMessage: 'The legal first name field is required.',
      })
      checkForValidationError({
        locator: surnameLocator,
        errorMessage: 'The legal last name field is required.',
      })
      checkForValidationError({
        locator: dobLocator,
        errorMessage: 'The date of birth must be in the format DD / MM / YYYY.',
      })
      checkForValidationError({
        locator: genderLocator,
        errorMessage: 'The gender field must be a valid value.',
      })
      checkForValidationError({ locator: streetLocator, errorMessage: 'The street field is required.' })
      checkForValidationError({ locator: suburbLocator, errorMessage: 'The suburb field is required.' })
      checkForValidationError({ locator: stateLocator, errorMessage: 'The state field is required.' })
      checkForValidationError({ locator: postCodeLocator, errorMessage: 'The postcode field is required.' })

      cy.get('.help')
        .its('length')
        .should('equal', 8)
    })

    context('Check field validation', () => {
      const invalidNames = ['Name!', '1000', '⭐️⭐️⭐']
      const invalidBirthDates = ['01 / 01 / 0000', '01 / 01 / 9999']
      const invalidPostCodes = ['!!!!', '+100']
      const nameErrorMessage = 'Invalid characters or numbers found'
      const dobErrorMessage = `The date of birth must be`
      const postCodeErrorMessage = 'The postcode field must be numeric and contain exactly 4 digits.'

      before(() => {
        cy.visit('v/#/customer/create')
      })

      it('First Name', () => {
        checkForInvalidValues({
          locator: firstNameLocator,
          invalidValues: invalidNames,
          errorMessage: nameErrorMessage,
        })
      })

      it('Middle Name', () => {
        checkForInvalidValues({
          locator: middleNameLocator,
          invalidValues: invalidNames,
          errorMessage: nameErrorMessage,
        })
      })

      it('Last Name', () => {
        checkForInvalidValues({
          locator: surnameLocator,
          invalidValues: invalidNames,
          errorMessage: nameErrorMessage,
        })
      })

      it('Date of Birth', () => {
        checkForInvalidValues({
          locator: dobLocator,
          invalidValues: invalidBirthDates,
          errorMessage: dobErrorMessage,
        })
      })

      it('Postcode', () => {
        checkForInvalidValues({
          locator: postCodeLocator,
          invalidValues: invalidPostCodes,
          errorMessage: postCodeErrorMessage,
        })
      })
    })
  })
}
