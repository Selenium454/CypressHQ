import { UserRoles, UserDictionary, GeneratedRegistrationModel } from '@support/types'
import { generateRegistrationModel, setupRoutes } from '@support/functions'
import { PatientsRoutes, ServicesRoutes, UsersRoutes } from '@support/api'

export const checkPersonalPageGrowls = (): void => {
  let registrationModel: GeneratedRegistrationModel = generateRegistrationModel()

  context('C52411 - Check personal page growl messages', () => {
    before(() => {
      const userRole: UserRoles = Cypress.env('role')
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('pharmacyAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('password')
      )
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([
        UsersRoutes.GetUsersDetails,
        PatientsRoutes.PostPatientsRegister,
        ServicesRoutes.PostServicesByUserIdAdd,
        ServicesRoutes.GetServicesByUserIdAll,
      ])

      cy.visit('/customer/create#/')
    })
  })
}
