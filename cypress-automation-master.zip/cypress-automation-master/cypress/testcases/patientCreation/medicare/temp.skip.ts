const medicareNumberErrorMessage = 'Invalid Medicare Number'
const medicareDateErrorMessage =
  'The expiry date must be future date in format MM / YYYY and not more than 10 years from now.'
const concessionNumberErrorMessage = 'Invalid Concession Number'
const safetyNetNumberErrorMessage = 'Invalid Safety Net Number'
const invalidCardNumbers = ['abcdefghijk', '!@#$%^&*()', '000000000000', '1234567890', 'CN123456789', 'SN312345678']
const invalidMedicareDates = ['01 / 1990', '07 / 2042']
