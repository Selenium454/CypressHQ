import { UserRoles, chartJobStatus, UserDictionary, GrowlTypes } from '@support/types'
import { PostPatientsRegisterRequestLatest } from '@schemas/api/endpoints'
import { setupRoutes, epicHdId } from '@support/functions'
import { UsersRoutes, OrdersRoutes, JobsRoutes, PatientsRoutes } from '@support/api'
import {
  selectChartFacility,
  searchPatientViaUrnAndSet,
  fillChartCommentSection,
  takePhoto,
  submitChartJobForCreation,
  goToJobsDashboard,
  getLatestOrder,
  checkOrder,
  lockOrder,
  setChartJobStatus,
  submitChartJobUpdate,
} from '@support/commands/orders.commands'
import { checkGrowlAndClose } from '@support/commands/general.commands'

const testCases = [
  {
    viewportX: Cypress.env('desktop_x'),
    viewportY: Cypress.env('desktop_y'),
    contextName: 'Viewport - Desktop',
    name: 'desktop',
    openMenu: false,
    selectType: 'wide',
  },
  {
    viewportX: Cypress.env('tab2_x'),
    viewportY: Cypress.env('tab2_y'),
    contextName: 'Viewport - Tablet 2',
    name: 'tab 2',
    openMenu: true,
    selectType: 'narrow',
  },
  {
    viewportX: Cypress.env('tab4_x'),
    viewportY: Cypress.env('tab4_x'),
    contextName: 'Viewport - Tablet 4',
    name: 'tab 4',
    openMenu: true,
    selectType: 'narrow',
  },
]

export const createPatientChartJobAndSubmit = (): void => {
  const userRole: UserRoles = Cypress.env('role')
  const chartComment: string = 'Patient Scenario'
  const chartStatus = chartJobStatus.check
  const patientPharmacyName: string = Cypress.env('hospitalPharmacyName')
  let patientFacilityName: string
  let patientFacilityCode: string
  let patientUserId: string
  let patientUrn: string

  context('C51734 - Create patient chart job and then submit it from the dashboard', () => {
    before(() => {
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('pharmacyAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('password')
      )

      cy.fixture('patient').then($patient => {
        const patientDetails = $patient as PostPatientsRegisterRequestLatest
        patientFacilityName = patientDetails.patient.services![0].facilityName!
        patientFacilityCode = patientDetails.patient.services![0].facilityCode
        patientUserId = patientDetails.userId!
        patientUrn = patientDetails.patient.services![0].urNumber!
      })
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([
        UsersRoutes.GetUsersDetails,
        UsersRoutes.CheckUserSessionValid,
        UsersRoutes.GetUsersPreferences,
        OrdersRoutes.PostOrdersNew,
        OrdersRoutes.UploadImageToBlob,
        OrdersRoutes.PutOrdersLock,
        JobsRoutes.PostJobsOrders,
        PatientsRoutes.PostPatientsSearch,
      ])
    })

    testCases.forEach(testCase => {
      context(testCase.contextName, () => {
        beforeEach(() => {
          cy.viewport(testCase.viewportX, testCase.viewportY)
        })

        it(`Create patient chart job and then submit it from the dashboard on ${testCase.name}`, () => {
          cy.visit('/dashboards/pharmacy/take-photo#/')

          UsersRoutes.GetUsersDetails.check()

          cy.get(epicHdId('radio-patient')).should('be.checked')

          selectChartFacility({ facilityName: patientFacilityName, facilityCode: patientFacilityCode })
          searchPatientViaUrnAndSet(patientUrn)
          fillChartCommentSection(chartComment)
          takePhoto()

          OrdersRoutes.UploadImageToBlob.check()

          submitChartJobForCreation()

          OrdersRoutes.PostOrdersNew.check()

          checkGrowlAndClose({
            growlMessage: 'Order has been sent to the pharmacy for processing.',
            growlType: GrowlTypes.success,
          })
          goToJobsDashboard({
            pharmacyName: patientPharmacyName,
            facilityName: patientFacilityName,
          })
          getLatestOrder({ orderFor: patientUserId, comment: chartComment, snapshotName: 'C51734 - Desktop' }).then(
            latestOrder => {
              cy.get(`[data-batchid="${latestOrder.batchId}"]`)
                .last()
                .click()

              UsersRoutes.GetUsersDetails.check()

              checkOrder(latestOrder)
              lockOrder()

              OrdersRoutes.PutOrdersLock.check()

              checkGrowlAndClose({
                growlMessage: 'Order locked.',
                growlType: GrowlTypes.success,
              })
              setChartJobStatus(chartStatus.value)
              submitChartJobUpdate({
                pin: userRole ? UserDictionary[userRole].pin : Cypress.env('pharmacyAdminPin'),
              })

              JobsRoutes.PostJobsOrders.check()
            }
          )
        })
      })
    })
  })
}
