import { UserRoles, UserDictionary, GrowlTypes } from '@support/types'
import { PostPatientsRegisterRequestLatest } from '@schemas/api/endpoints'
import { setupRoutes, epicHdId } from '@support/functions'
import { UsersRoutes, OrdersRoutes, PatientsRoutes } from '@support/api'
import { checkGrowlAndClose, checkGrowlsAreNotVisible } from '@support/commands/general.commands'
import {
  selectChartFacility,
  selectChartWard,
  searchPatientViaUrnAndSet,
  takePhoto,
} from '@support/commands/orders.commands'

export const checkGrowlMessagesOnPatientChartJobCreation = (): void => {
  const userRole: UserRoles = Cypress.env('role')
  let patientFacilityName: string
  let patientFacilityCode: string
  let wardCode: string
  let patientUrn: string

  context('C51747 - Check growl messages on creation', () => {
    before(() => {
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('pharmacyAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('password')
      )

      cy.fixture('patient').then($patient => {
        const patientDetails = $patient as PostPatientsRegisterRequestLatest
        patientFacilityName = patientDetails.patient.services![0].facilityName!
        patientFacilityCode = patientDetails.patient.services![0].facilityCode
        patientUrn = patientDetails.patient.services![0].urNumber!
        wardCode = patientDetails.patient.services![0].wardCode!
      })
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([
        UsersRoutes.GetUsersDetails,
        UsersRoutes.CheckUserSessionValid,
        UsersRoutes.GetUsersPreferences,
        OrdersRoutes.PutOrdersLock,
        PatientsRoutes.PostPatientsSearch,
      ])

      cy.route({
        ...OrdersRoutes.PostOrdersNew,
        response: { message: 'Successfully mocked' },
        status: 200,
      }).as(OrdersRoutes.PostOrdersNew.alias)

      cy.route({
        ...OrdersRoutes.UploadImageToBlob,
        response: { message: 'Successfully mocked' },
        status: 200,
      }).as(OrdersRoutes.UploadImageToBlob.alias)
    })

    it('Creating a chart job without filling any fields', () => {
      cy.visit('/dashboards/pharmacy/take-photo#/')

      UsersRoutes.GetUsersDetails.check()

      cy.get(epicHdId('radio-patient')).should('be.checked')

      cy.get(epicHdId('select-facility')).select('Select Facility')

      cy.get(epicHdId('button-submit-chart-job')).click()

      checkGrowlAndClose({
        growlMessage: 'You need to select a facility!',
        growlType: GrowlTypes.warning,
      })
      checkGrowlAndClose({
        growlMessage: 'You need to select a ward!',
        growlType: GrowlTypes.warning,
      })
      checkGrowlsAreNotVisible()
    })

    it('Creating a chart job after only setting facility', () => {
      cy.visit('/dashboards/pharmacy/take-photo#/')

      UsersRoutes.GetUsersDetails.check()

      cy.get(epicHdId('radio-patient')).should('be.checked')

      selectChartFacility({ facilityName: patientFacilityName, facilityCode: patientFacilityCode })

      cy.get(epicHdId('button-submit-chart-job')).click()

      checkGrowlAndClose({
        growlMessage: 'You need to select a ward!',
        growlType: GrowlTypes.warning,
      })
    })

    it('Creating a chart job after setting facility and ward', () => {
      cy.visit('/dashboards/pharmacy/take-photo#/')

      UsersRoutes.GetUsersDetails.check()

      cy.get(epicHdId('radio-patient')).should('be.checked')

      selectChartFacility({ facilityName: patientFacilityName, facilityCode: patientFacilityCode })
      selectChartWard(wardCode)

      cy.get(epicHdId('button-submit-chart-job')).click()

      checkGrowlAndClose({
        growlMessage: 'You need to select a patient!',
        growlType: GrowlTypes.warning,
      })
      checkGrowlsAreNotVisible()
    })

    it('Creating a chart job after setting facility, ward and patient', () => {
      cy.visit('/dashboards/pharmacy/take-photo#/')

      UsersRoutes.GetUsersDetails.check()

      cy.get(epicHdId('radio-patient')).should('be.checked')

      selectChartFacility({ facilityName: patientFacilityName, facilityCode: patientFacilityCode })
      searchPatientViaUrnAndSet(patientUrn)
      selectChartWard(wardCode)

      cy.get(epicHdId('button-submit-chart-job')).click()

      checkGrowlAndClose({
        growlMessage: 'You need to take a photo of a patient chart!',
        growlType: GrowlTypes.warning,
      })
      checkGrowlsAreNotVisible()
    })

    it('Creating a chart job after filling required details', () => {
      cy.visit('/dashboards/pharmacy/take-photo#/')

      UsersRoutes.GetUsersDetails.check()

      cy.get(epicHdId('radio-patient')).should('be.checked')

      selectChartFacility({ facilityName: patientFacilityName, facilityCode: patientFacilityCode })
      searchPatientViaUrnAndSet(patientUrn)
      selectChartWard(wardCode)
      takePhoto(1)

      OrdersRoutes.UploadImageToBlob.check()

      cy.get(epicHdId('button-submit-chart-job')).click()

      OrdersRoutes.PostOrdersNew.check()

      checkGrowlAndClose({
        growlMessage: 'Order has been sent to the pharmacy for processing.',
        growlType: GrowlTypes.success,
      })
      checkGrowlsAreNotVisible()
    })

    it('Creating a chart job with due time "other" but no date or time', () => {
      cy.visit('/dashboards/pharmacy/take-photo#/')

      UsersRoutes.GetUsersDetails.check()

      cy.get(epicHdId('radio-patient')).should('be.checked')

      selectChartFacility({ facilityName: patientFacilityName, facilityCode: patientFacilityCode })
      searchPatientViaUrnAndSet(patientUrn)
      takePhoto(1)

      OrdersRoutes.UploadImageToBlob.check()

      cy.get('#jobDue')
        .should('be.visible')
        .select('other')

      cy.get(epicHdId('button-submit-chart-job')).click()

      checkGrowlAndClose({
        growlMessage: 'Due date/time is missing.',
        growlType: GrowlTypes.warning,
      })
      checkGrowlsAreNotVisible()
    })

    it('Creating a chart job with due time "other" but only date', () => {
      const date: string = Cypress.moment().format('DD/MM/YYYY')

      cy.visit('/dashboards/pharmacy/take-photo#/')

      UsersRoutes.GetUsersDetails.check()

      cy.get(epicHdId('radio-patient')).should('be.checked')

      selectChartFacility({ facilityName: patientFacilityName, facilityCode: patientFacilityCode })
      searchPatientViaUrnAndSet(patientUrn)
      takePhoto(1)

      OrdersRoutes.UploadImageToBlob.check()

      cy.get('#jobDue')
        .should('be.visible')
        .select('other')

      cy.get('#jobDueDate-chart-flow')
        .should('be.visible')
        .type(date)
        .should('have.value', date)

      cy.get(epicHdId('button-submit-chart-job')).click()

      checkGrowlAndClose({
        growlMessage: 'Due date/time is missing.',
        growlType: GrowlTypes.warning,
      })
      checkGrowlsAreNotVisible()
    })

    it('Creating a chart job with due time "other" but only time', () => {
      const time: string = Cypress.moment().format('HH:mm')

      cy.visit('/dashboards/pharmacy/take-photo#/')

      UsersRoutes.GetUsersDetails.check()

      cy.get(epicHdId('radio-patient')).should('be.checked')

      selectChartFacility({ facilityName: patientFacilityName, facilityCode: patientFacilityCode })
      searchPatientViaUrnAndSet(patientUrn)
      takePhoto(1)

      cy.get('#jobDue')
        .should('be.visible')
        .select('other')

      cy.get('[name="jobDueTime"]').type(time)

      cy.get(epicHdId('button-submit-chart-job')).click()

      checkGrowlAndClose({
        growlMessage: 'Due date/time is missing.',
        growlType: GrowlTypes.warning,
      })
      checkGrowlsAreNotVisible()
    })

    it('Creating a chart job returns a status of 500', () => {
      cy.route({
        ...OrdersRoutes.PostOrdersNew,
        response: { message: 'Error and stuff!' },
        status: 500,
      }).as(OrdersRoutes.PostOrdersNew.alias)

      cy.visit('/dashboards/pharmacy/take-photo#/')

      UsersRoutes.GetUsersDetails.check()

      cy.get(epicHdId('radio-patient')).should('be.checked')

      selectChartFacility({ facilityName: patientFacilityName, facilityCode: patientFacilityCode })
      searchPatientViaUrnAndSet(patientUrn)
      takePhoto(1)

      cy.get(epicHdId('button-submit-chart-job')).click()

      OrdersRoutes.PostOrdersNew.check()

      checkGrowlAndClose({
        growlMessage: 'There has been an error creating this order. Please try again.',
        growlType: GrowlTypes.error,
      })
      checkGrowlsAreNotVisible()
    })
  })
}
