import { dueTimes, UserRoles, UserDictionary } from '@support/types'
import { PostPatientsRegisterRequestLatest } from '@schemas/api/endpoints'
import { setupRoutes, epicHdId } from '@support/functions'
import { UsersRoutes, OrdersRoutes, PatientsRoutes } from '@support/api'
import {
  selectChartFacility,
  searchPatientViaUrnAndSet,
  selectDueTime,
  fillChartCommentSection,
  takePhoto,
  submitChartJobForCreation,
  getLatestOrder,
  checkOrder,
  checkDueTime,
} from '@support/commands/orders.commands'

const testCases = [
  {
    dueTimeType: dueTimes.hour,
    testLabel: 'within an hour',
    testId: 'C51743',
    comment: 'Due time within an hour',
  },
  {
    dueTimeType: dueTimes.today,
    testLabel: 'today',
    testId: 'C51744',
    comment: 'Due time today',
  },
  {
    dueTimeType: dueTimes.tomorrow,
    testLabel: 'tomorrow',
    testId: 'C51745',
    comment: 'Due time tomorrow',
  },
  {
    dueTimeType: dueTimes.other,
    testLabel: 'other',
    testId: 'C51746',
    comment: 'Due time other',
  },
]

export const checkPatientChartJobDueTimeSubmission = (): void => {
  const userRole: UserRoles = Cypress.env('role')
  let patientFacilityName: string
  let patientFacilityCode: string
  let patientUserId: string
  let patientUrn: string

  context('Create and cancel facilities with differing due times', () => {
    before(() => {
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('pharmacyAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('password')
      )

      cy.fixture('patient').then($patient => {
        const patientDetails = $patient as PostPatientsRegisterRequestLatest
        patientFacilityName = patientDetails.patient.services![0].facilityName!
        patientFacilityCode = patientDetails.patient.services![0].facilityCode
        patientUserId = patientDetails.userId!
        patientUrn = patientDetails.patient.services![0].urNumber!
      })
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([
        UsersRoutes.GetUsersDetails,
        UsersRoutes.CheckUserSessionValid,
        UsersRoutes.GetUsersPreferences,
        OrdersRoutes.PostOrdersNew,
        OrdersRoutes.UploadImageToBlob,
        PatientsRoutes.PostPatientsSearch,
      ])
    })

    testCases.forEach((testCase: any) => {
      let testId: string = testCase.testId
      let testLabel: string = testCase.testLabel
      let dueTimeType: string = testCase.dueTimeType
      let chartComment: string = testCase.comment

      it(`${testId} - Create a patient chart job with due time ${testLabel}`, () => {
        cy.visit('/dashboards/pharmacy/take-photo#/')

        UsersRoutes.GetUsersDetails.check()

        cy.get(epicHdId('radio-patient')).should('be.checked')

        selectChartFacility({ facilityName: patientFacilityName, facilityCode: patientFacilityCode })
        searchPatientViaUrnAndSet(patientUrn)
        selectDueTime(dueTimeType)
        fillChartCommentSection(chartComment)
        takePhoto()

        OrdersRoutes.UploadImageToBlob.check()

        submitChartJobForCreation()

        OrdersRoutes.PostOrdersNew.check()

        getLatestOrder({
          orderFor: patientUserId,
          comment: chartComment,
          snapshotName: `${testId} - ${chartComment}`,
        }).then(latestOrder => {
          const { pharmacyId, batchId, dueTime } = latestOrder

          cy.visit(`/dashboards/pharmacy/${pharmacyId}/${batchId}/chartflow/job#/`)

          UsersRoutes.GetUsersDetails.check()

          checkOrder(latestOrder)
          checkDueTime({ dueTime: dueTime!, dueTimeType: dueTimeType })
        })
      })
    })
  })
}
