import { UserRoles, chartJobTypes, chartJobStatus, UserDictionary, GrowlTypes } from '@support/types'
import { PostPatientsRegisterRequestLatest } from '@schemas/api/endpoints'
import { setupRoutes, epicHdId } from '@support/functions'
import { UsersRoutes, OrdersRoutes, JobsRoutes } from '@support/api'
import { createChartJob, lockOrder, setChartJobStatus } from '@support/commands/orders.commands'
import { checkGrowlAndClose, checkGrowlsAreNotVisible } from '@support/commands/general.commands'

export const checkGrowlMessagesOnPatientChartJobSubmission = (): void => {
  const userRole: UserRoles = Cypress.env('role')
  const chartJobType = chartJobTypes.regular
  const status = chartJobStatus.cancel.value
  let patientUserId: string
  let patientUrn: string

  context('C51748 - Check growl messages on submission', () => {
    before(() => {
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('pharmacyAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('password')
      )

      cy.fixture('patient').then($customer => {
        const customer = $customer as PostPatientsRegisterRequestLatest
        patientUserId = customer.userId!
        patientUrn = customer.patient.services![0].urNumber!
      })
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([
        UsersRoutes.GetUsersDetails,
        UsersRoutes.CheckUserSessionValid,
        UsersRoutes.GetUsersPreferences,
        OrdersRoutes.PutOrdersLock,
      ])

      createChartJob({
        context: 'personal',
        orderFor: patientUserId,
        deliveryType: chartJobType.deliveryType,
        tags: chartJobType.tags,
        urn: patientUrn,
        snapshotName: 'Generate chart job',
      }).then(({ pharmacyId, batchId }) => {
        cy.visit(`/dashboards/pharmacy/${pharmacyId}/${batchId}/chartflow/job#/`)

        UsersRoutes.GetUsersDetails.check()
      })
    })

    it('Submitting a chart job without picking a status', () => {
      lockOrder()

      OrdersRoutes.PutOrdersLock.check()

      checkGrowlAndClose({
        growlMessage: 'Order locked.',
        growlType: GrowlTypes.success,
      })

      cy.get(epicHdId('button-submit-job'))
        .first()
        .click()

      checkGrowlAndClose({
        growlMessage: 'You must select a job status.',
        growlType: GrowlTypes.warning,
      })
      checkGrowlsAreNotVisible()
    })

    it('Canceling a chart job returns a status of 500', () => {
      cy.route({
        ...JobsRoutes.PostJobsOrders,
        response: { message: 'Error and stuff!' },
        status: 500,
      }).as(JobsRoutes.PostJobsOrders.alias)

      lockOrder()

      OrdersRoutes.PutOrdersLock.check()

      checkGrowlAndClose({
        growlMessage: 'Order locked.',
        growlType: GrowlTypes.success,
      })
      setChartJobStatus(status)

      cy.get(epicHdId('button-submit-job'))
        .first()
        .click()

      JobsRoutes.PostJobsOrders.check()

      checkGrowlAndClose({
        growlMessage: 'Error updating job. Please refresh and try again. ',
        growlType: GrowlTypes.error,
      })
      checkGrowlsAreNotVisible()
    })
  })
}
