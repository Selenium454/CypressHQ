import { UserRoles, chartJobStatus, UserDictionary } from '@support/types'
import { PostPatientsRegisterRequestLatest } from '@schemas/api/endpoints'
import { setupRoutes, epicHdId } from '@support/functions'
import { UsersRoutes, OrdersRoutes, PatientsRoutes, JobsRoutes } from '@support/api'
import {
  selectChartFacility,
  searchPatientViaUrnAndSet,
  fillChartCommentSection,
  takePhoto,
  submitChartJobForCreation,
  getLatestOrder,
  checkOrder,
  setChartJobStatus,
  lockOrder,
  submitChartJobUpdate,
} from '@support/commands/orders.commands'

export const checkMultiplePatientChartImages = (): void => {
  const userRole: UserRoles = Cypress.env('role')
  const chartComment: string = 'Patient Chart Image Check'
  const status = chartJobStatus.completed.value
  let patientFacilityName: string
  let patientFacilityCode: string
  let patientUserId: string
  let patientUrn: string

  context('Check patient chart jobs with multiple images', () => {
    before(() => {
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('pharmacyAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('password')
      )

      cy.fixture('patient').then($patient => {
        const patientDetails = $patient as PostPatientsRegisterRequestLatest
        patientFacilityName = patientDetails.patient.services![0].facilityName!
        patientFacilityCode = patientDetails.patient.services![0].facilityCode
        patientUserId = patientDetails.userId!
        patientUrn = patientDetails.patient.services![0].urNumber!
      })
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([
        UsersRoutes.GetUsersDetails,
        UsersRoutes.CheckUserSessionValid,
        UsersRoutes.GetUsersPreferences,
        OrdersRoutes.PutOrdersLock,
        OrdersRoutes.PostOrdersNew,
        OrdersRoutes.UploadImageToBlob,
        PatientsRoutes.PostPatientsSearch,
        JobsRoutes.PostJobsOrders,
      ])
    })

    it('C51754 - Check multiple chart images', () => {
      cy.visit('/dashboards/pharmacy/take-photo#/')

      UsersRoutes.GetUsersDetails.check()

      cy.get(epicHdId('radio-patient')).should('be.checked')

      selectChartFacility({ facilityName: patientFacilityName, facilityCode: patientFacilityCode })
      searchPatientViaUrnAndSet(patientUrn)
      fillChartCommentSection(chartComment)
      takePhoto(11)

      OrdersRoutes.UploadImageToBlob.check()
      OrdersRoutes.UploadImageToBlob.check()
      OrdersRoutes.UploadImageToBlob.check()
      OrdersRoutes.UploadImageToBlob.check()
      OrdersRoutes.UploadImageToBlob.check()
      OrdersRoutes.UploadImageToBlob.check()
      OrdersRoutes.UploadImageToBlob.check()
      OrdersRoutes.UploadImageToBlob.check()
      OrdersRoutes.UploadImageToBlob.check()
      OrdersRoutes.UploadImageToBlob.check()
      OrdersRoutes.UploadImageToBlob.check()

      cy.get('.badge')
        .contains('11')
        .scrollIntoView()
        .should('be.visible')

      cy.get('#numPhotos')
        .should('contain', '11')
        .scrollIntoView()
        .and('be.visible')

      submitChartJobForCreation()

      OrdersRoutes.PostOrdersNew.check()

      getLatestOrder({
        orderFor: patientUserId,
        comment: chartComment,
      }).then(latestOrder => {
        const { batchId, pharmacyId } = latestOrder

        cy.visit(`/dashboards/pharmacy/${pharmacyId}/${batchId}/chartflow/job#/`)

        UsersRoutes.GetUsersDetails.check()

        checkOrder(latestOrder)
        lockOrder()

        OrdersRoutes.PutOrdersLock.check()

        cy.contains('Photo 11').should('exist')

        setChartJobStatus(status)
        submitChartJobUpdate({
          pin: userRole ? UserDictionary[userRole].pin : Cypress.env('pharmacyAdminPin'),
        })

        JobsRoutes.PostJobsOrders.check()
      })

      cy.url().should('include', '/new-jobs/')
    })
  })
}
