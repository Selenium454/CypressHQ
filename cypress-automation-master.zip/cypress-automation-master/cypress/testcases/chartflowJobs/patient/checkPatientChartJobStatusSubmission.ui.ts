import { UserRoles, chartJobStatus, chartJobTypes, UserDictionary } from '@support/types'
import { OrderLatest } from '@schemas/api/models'
import { PostPatientsRegisterRequestLatest } from '@schemas/api/endpoints'
import { setupRoutes } from '@support/functions'
import { UsersRoutes, OrdersRoutes, JobsRoutes, PatientsRoutes } from '@support/api'
import {
  createChartJob,
  checkOrder,
  lockOrder,
  setChartJobStatus,
  submitChartJobUpdate,
} from '@support/commands/orders.commands'

interface TestCases {
  statusLabel: string
  status: string
  testId: string
  roles: UserRoles[]
}

const testCases: TestCases[] = [
  {
    statusLabel: chartJobStatus.pick.displayName,
    status: chartJobStatus.cancel.value,
    testId: 'C51738',
    roles: [UserRoles.pharmacist, UserRoles.pharmacyAdmin, UserRoles.pharmacyTechnician, UserRoles.corporateAdmin],
  },
  {
    statusLabel: chartJobStatus.label.displayName,
    status: chartJobStatus.cancel.value,
    testId: 'C51739',
    roles: [UserRoles.pharmacist, UserRoles.pharmacyAdmin, UserRoles.pharmacyTechnician, UserRoles.corporateAdmin],
  },
  {
    statusLabel: chartJobStatus.check.displayName,
    status: chartJobStatus.check.value,
    testId: 'C51740',
    roles: [UserRoles.pharmacist, UserRoles.pharmacyAdmin, UserRoles.corporateAdmin],
  },
  {
    statusLabel: chartJobStatus.hold.displayName,
    status: chartJobStatus.hold.value,
    testId: 'C51741',
    roles: [UserRoles.pharmacist, UserRoles.pharmacyAdmin, UserRoles.pharmacyTechnician, UserRoles.corporateAdmin],
  },
  {
    statusLabel: chartJobStatus.cancel.displayName,
    status: chartJobStatus.cancel.value,
    testId: 'C51742',
    roles: [UserRoles.pharmacist, UserRoles.pharmacyAdmin, UserRoles.pharmacyTechnician, UserRoles.corporateAdmin],
  },
]

export const checkPatientChartJobStatusSubmission = (): void => {
  const userRole: UserRoles = Cypress.env('role') ? Cypress.env('role') : UserRoles.pharmacyAdmin
  const chartJobType = chartJobTypes.regular
  let order: OrderLatest
  let patientUserId: string
  let patientUrn: string

  let applicableTestCases = testCases.filter(testCase => Object.values(testCase.roles).includes(userRole))

  context('Check patient status submissions', () => {
    before(() => {
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('pharmacyAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('password')
      )

      cy.fixture('patient').then($patient => {
        const patient = $patient as PostPatientsRegisterRequestLatest
        patientUserId = patient.userId!
        patientUrn = patient.patient.services![0].urNumber!
      })
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([
        UsersRoutes.GetUsersDetails,
        UsersRoutes.CheckUserSessionValid,
        UsersRoutes.GetUsersPreferences,
        OrdersRoutes.PostOrdersNew,
        OrdersRoutes.UploadImageToBlob,
        OrdersRoutes.PutOrdersLock,
        JobsRoutes.PostJobsOrders,
        PatientsRoutes.PostPatientsSearch,
      ])

      createChartJob({
        context: 'personal',
        orderFor: patientUserId,
        deliveryType: chartJobType.deliveryType,
        tags: chartJobType.tags,
        urn: patientUrn,
        snapshotName: 'Generate chart job',
      }).then(latestOrder => {
        order = latestOrder
        const { pharmacyId, batchId } = latestOrder
        cy.visit(`/dashboards/pharmacy/${pharmacyId}/${batchId}/chartflow/job#/`)

        UsersRoutes.GetUsersDetails.check()
      })
    })

    applicableTestCases.forEach((testCase: any) => {
      let status: string = testCase.status
      let testId: string = testCase.testId
      let statusLabelLower: string = testCase.statusLabel.toLowerCase()

      it(`${testId} - Submit a patient chart job as ${statusLabelLower}`, () => {
        checkOrder(order)
        lockOrder()

        OrdersRoutes.PutOrdersLock.check()

        setChartJobStatus(status)
        submitChartJobUpdate({
          pin: userRole ? UserDictionary[userRole].pin : Cypress.env('pharmacyAdminPin'),
        })

        JobsRoutes.PostJobsOrders.check()
      })
    })
  })
}
