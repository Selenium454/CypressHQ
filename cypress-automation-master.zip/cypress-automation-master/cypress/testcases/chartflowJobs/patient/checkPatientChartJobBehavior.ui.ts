import { UserRoles, chartJobTypes, UserDictionary } from '@support/types'
import { PostPatientsRegisterRequestLatest } from '@schemas/api/endpoints'
import { setupRoutes } from '@support/functions'
import { UsersRoutes, JobsRoutes } from '@support/api'
import { createChartJob } from '@support/commands/orders.commands'

export const checkPatientChartJobBehavior = (): void => {
  const userRole: UserRoles = Cypress.env('role')
  const chartJobType = chartJobTypes.regular
  let patientUserId: string
  let patientUrn: string

  context('Check patient chart job behaviour', () => {
    before(() => {
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('pharmacyAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('password')
      )

      cy.fixture('patient').then($customer => {
        const customer = $customer as PostPatientsRegisterRequestLatest
        patientUserId = customer.userId!
        patientUrn = customer.patient.services![0].urNumber!
      })
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([
        UsersRoutes.GetUsersDetails,
        UsersRoutes.CheckUserSessionValid,
        UsersRoutes.GetUsersPreferences,
        JobsRoutes.PostJobsOrders,
      ])
    })

    it('C51751 - Check refresh on patient chart job creation', () => {
      const labels = ['Facility *', 'Patient *', 'Ward *', 'Urgent Job', 'Discharge Job', 'Due Time']

      cy.visit('/dashboards/pharmacy/take-photo#/')

      UsersRoutes.GetUsersDetails.check()

      cy.reload()

      UsersRoutes.GetUsersDetails.check()

      cy.url().should('contain', 'take-photo')

      labels.forEach(label => {
        cy.get('.control-label')
          .contains(label)
          .should('be.visible')
      })
    })

    it('C51752 - Check refresh on patient chart job submission', () => {
      const labels = ['Job ID', 'Status', 'Name', 'Ward', 'Comments', 'URN', 'Medicare Number', 'Date of Birth']

      createChartJob({
        context: 'personal',
        orderFor: patientUserId,
        deliveryType: chartJobType.deliveryType,
        tags: chartJobType.tags,
        urn: patientUrn,
        snapshotName: 'Generate chart job',
      }).then(({ pharmacyId, batchId }) => {
        cy.visit(`/dashboards/pharmacy/${pharmacyId}/${batchId}/chartflow/job#/`, { retryOnStatusCodeFailure: true })

        UsersRoutes.GetUsersDetails.check()
      })

      cy.reload()

      UsersRoutes.GetUsersDetails.check()

      cy.url().should('contain', 'chartflow/job')

      labels.forEach(label => {
        cy.get('.control-label')
          .contains(label)
          .should('be.visible')
      })

      cy.get('.photo-title').should('contain', 'Photo 1')
    })
  })
}
