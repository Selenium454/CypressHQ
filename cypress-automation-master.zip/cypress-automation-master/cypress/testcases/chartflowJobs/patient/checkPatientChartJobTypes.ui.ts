import { chartJobTypes, UserRoles, UserDictionary } from '@support/types'
import { PostPatientsRegisterRequestLatest } from '@schemas/api/endpoints'
import { setupRoutes, epicHdId } from '@support/functions'
import { UsersRoutes, OrdersRoutes, PatientsRoutes } from '@support/api'
import {
  selectChartFacility,
  searchPatientViaUrnAndSet,
  fillChartCommentSection,
  setChartTags,
  takePhoto,
  submitChartJobForCreation,
  getLatestOrder,
  checkOrder,
} from '@support/commands/orders.commands'

const testCases = [
  {
    chartTags: chartJobTypes.urgent.tagArray,
    testLabel: 'an urgent',
    testId: 'C51735',
    comment: 'Urgent Patient Chart Job - Automation Test',
  },
  {
    chartTags: chartJobTypes.discharge.tagArray,
    testLabel: 'a discharge',
    testId: 'C51736',
    comment: 'Discharge Patient Chart Job - Automation Test',
  },
  {
    chartTags: chartJobTypes.urgentDischarge.tagArray,
    testLabel: 'an urgent discharge',
    testId: 'C51737',
    comment: 'Urgent Discharge Patient Chart Job - Automation Test',
  },
]

export const checkPatientChartJobTypes = (): void => {
  const userRole: UserRoles = Cypress.env('role')
  let patientFacilityName: string
  let patientFacilityCode: string
  let patientUserId: string
  let patientUrn: string

  context('Check patient chart job types', () => {
    before(() => {
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('pharmacyAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('password')
      )

      cy.fixture('patient').then($patient => {
        const patientDetails = $patient as PostPatientsRegisterRequestLatest
        patientFacilityName = patientDetails.patient.services![0].facilityName!
        patientFacilityCode = patientDetails.patient.services![0].facilityCode
        patientUserId = patientDetails.userId!
        patientUrn = patientDetails.patient.services![0].urNumber!
      })
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([
        UsersRoutes.GetUsersDetails,
        UsersRoutes.CheckUserSessionValid,
        UsersRoutes.GetUsersPreferences,
        OrdersRoutes.PostOrdersNew,
        OrdersRoutes.UploadImageToBlob,
        PatientsRoutes.PostPatientsSearch,
      ])
    })

    testCases.forEach(testCase => {
      let testId: string = testCase.testId
      let testLabel: string = testCase.testLabel
      let chartComment: string = testCase.comment
      let chartTags: string[] = testCase.chartTags

      it(`${testId} - Create ${testLabel} patient chart job`, () => {
        cy.visit('/dashboards/pharmacy/take-photo#/')

        UsersRoutes.GetUsersDetails.check()

        cy.get(epicHdId('radio-patient')).should('be.checked')

        selectChartFacility({ facilityName: patientFacilityName, facilityCode: patientFacilityCode })
        searchPatientViaUrnAndSet(patientUrn)
        setChartTags(chartTags)
        fillChartCommentSection(chartComment)
        takePhoto()

        OrdersRoutes.UploadImageToBlob.check()

        submitChartJobForCreation()

        OrdersRoutes.PostOrdersNew.check()

        getLatestOrder({ orderFor: patientUserId, comment: chartComment, snapshotName: testId }).then(latestOrder => {
          const { pharmacyId, batchId } = latestOrder

          cy.visit(`/dashboards/pharmacy/${pharmacyId}/${batchId}/chartflow/job#/`)

          UsersRoutes.GetUsersDetails.check()

          checkOrder(latestOrder)
        })
      })
    })
  })
}
