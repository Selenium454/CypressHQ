import { UserRoles, UserDictionary, GrowlTypes } from '@support/types'
import { setupRoutes, epicHdId } from '@support/functions'
import { UsersRoutes, OrdersRoutes } from '@support/api'
import { checkGrowlAndClose, checkGrowlsAreNotVisible } from '@support/commands/general.commands'
import { selectChartFacility, selectChartWard, takePhoto } from '@support/commands/orders.commands'

export const checkGrowlMessagesOnFacilityChartJobCreation = (): void => {
  const userRole: UserRoles = Cypress.env('role')
  let facilityCode: string
  let facilityName: string
  let facilityWardCode: string

  context('C51732 - Check growl messages on creation', () => {
    before(() => {
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('pharmacyAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('password')
      )

      cy.fixture('facility').then($facility => {
        facilityCode = $facility.code
        facilityName = $facility.name
        facilityWardCode = $facility.rounds[0].roundCode
      })
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([UsersRoutes.GetUsersDetails, UsersRoutes.CheckUserSessionValid, UsersRoutes.GetUsersPreferences])

      cy.route({
        ...OrdersRoutes.PostOrdersNew,
        response: { message: 'Successfully mocked' },
        status: 200,
      }).as(OrdersRoutes.PostOrdersNew.alias)

      cy.route({
        ...OrdersRoutes.UploadImageToBlob,
        response: { message: 'Successfully mocked' },
        status: 200,
      }).as(OrdersRoutes.UploadImageToBlob.alias)
    })

    it('Creating a chart job without filling any fields', () => {
      cy.visit('/dashboards/pharmacy/take-photo#/')

      UsersRoutes.GetUsersDetails.check()

      cy.get(epicHdId('radio-non-patient')).click()

      cy.get(epicHdId('select-facility')).select('Select Facility')

      cy.get(epicHdId('button-submit-chart-job')).click()

      checkGrowlAndClose({
        growlMessage: 'You need to select a facility!',
        growlType: GrowlTypes.warning,
      })
      checkGrowlAndClose({
        growlMessage: 'You need to select a ward!',
        growlType: GrowlTypes.warning,
      })
      checkGrowlsAreNotVisible()
    })

    it('Creating a chart job after only setting facility', () => {
      cy.visit('/dashboards/pharmacy/take-photo#/')

      UsersRoutes.GetUsersDetails.check()

      cy.get(epicHdId('radio-non-patient')).click()

      selectChartFacility({
        facilityName: facilityName,
        facilityCode: facilityCode,
      })

      cy.get(epicHdId('button-submit-chart-job')).click()

      checkGrowlAndClose({
        growlMessage: 'You need to select a ward!',
        growlType: GrowlTypes.warning,
      })
      checkGrowlsAreNotVisible()
    })

    it('Creating a chart job after setting facility and ward', () => {
      cy.visit('/dashboards/pharmacy/take-photo#/')

      UsersRoutes.GetUsersDetails.check()

      cy.get(epicHdId('radio-non-patient')).click()

      selectChartFacility({ facilityName: facilityName, facilityCode: facilityCode })
      selectChartWard(facilityWardCode)

      cy.get(epicHdId('button-submit-chart-job')).click()

      checkGrowlAndClose({
        growlMessage: 'You need to take a photo of the item for this order!',
        growlType: GrowlTypes.warning,
      })
      checkGrowlsAreNotVisible()
    })

    it('Creating a chart job after filling required details', () => {
      cy.visit('/dashboards/pharmacy/take-photo#/')

      UsersRoutes.GetUsersDetails.check()

      cy.get(epicHdId('radio-non-patient')).click()

      selectChartFacility({ facilityName: facilityName, facilityCode: facilityCode })
      selectChartWard(facilityWardCode)
      takePhoto()

      cy.get(epicHdId('button-submit-chart-job')).click()

      checkGrowlAndClose({
        growlMessage: 'Order has been sent to the pharmacy for processing.',
        growlType: GrowlTypes.success,
      })
      checkGrowlsAreNotVisible()
    })

    it('Creating a chart job with due time "other" but no date or time', () => {
      cy.visit('/dashboards/pharmacy/take-photo#/')

      UsersRoutes.GetUsersDetails.check()

      cy.get(epicHdId('radio-non-patient')).click()

      selectChartFacility({ facilityName: facilityName, facilityCode: facilityCode })
      selectChartWard(facilityWardCode)
      takePhoto()

      cy.get('#jobDue')
        .should('be.visible')
        .select('other')

      cy.get(epicHdId('button-submit-chart-job')).click()

      checkGrowlAndClose({
        growlMessage: 'Due date/time is missing.',
        growlType: GrowlTypes.warning,
      })
      checkGrowlsAreNotVisible()
    })

    it('Creating a chart job with due time "other" but only date', () => {
      const date: string = Cypress.moment().format('DD/MM/YYYY')

      cy.visit('/dashboards/pharmacy/take-photo#/')

      UsersRoutes.GetUsersDetails.check()

      cy.get(epicHdId('radio-non-patient')).click()

      selectChartFacility({ facilityName: facilityName, facilityCode: facilityCode })
      selectChartWard(facilityWardCode)
      takePhoto()

      cy.get('#jobDue')
        .should('be.visible')
        .select('other')

      cy.get('#jobDueDate-chart-flow')
        .should('be.visible')
        .type(date)
        .should('have.value', date)

      cy.get(epicHdId('button-submit-chart-job')).click()

      checkGrowlAndClose({
        growlMessage: 'Due date/time is missing.',
        growlType: GrowlTypes.warning,
      })
      checkGrowlsAreNotVisible()
    })

    it('Creating a chart job with due time "other" but only time', () => {
      const time: string = Cypress.moment().format('HH:mm')

      cy.visit('/dashboards/pharmacy/take-photo#/')

      UsersRoutes.GetUsersDetails.check()

      cy.get(epicHdId('radio-non-patient')).click()

      selectChartFacility({ facilityName: facilityName, facilityCode: facilityCode })
      selectChartWard(facilityWardCode)
      takePhoto()

      cy.get('#jobDue')
        .should('be.visible')
        .select('other')

      cy.get('[name="jobDueTime"]').type(time)

      cy.get(epicHdId('button-submit-chart-job')).click()

      checkGrowlAndClose({
        growlMessage: 'Due date/time is missing.',
        growlType: GrowlTypes.warning,
      })
      checkGrowlsAreNotVisible()
    })

    it('Creating a chart job returns a status of 500', () => {
      cy.route({
        ...OrdersRoutes.PostOrdersNew,
        response: { message: 'Error and stuff!' },
        status: 500,
      }).as(OrdersRoutes.PostOrdersNew.alias)

      cy.visit('/dashboards/pharmacy/take-photo#/')

      UsersRoutes.GetUsersDetails.check()

      cy.get(epicHdId('radio-non-patient')).click()

      selectChartFacility({ facilityName: facilityName, facilityCode: facilityCode })
      selectChartWard(facilityWardCode)
      takePhoto()

      cy.get(epicHdId('button-submit-chart-job')).click()

      checkGrowlAndClose({
        growlMessage: 'There has been an error creating this order. Please try again.',
        growlType: GrowlTypes.error,
      })
      checkGrowlsAreNotVisible()
    })
  })
}
