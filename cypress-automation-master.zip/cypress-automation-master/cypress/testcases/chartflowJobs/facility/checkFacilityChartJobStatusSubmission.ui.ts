import { OrderLatest } from '@schemas/api/models'
import { UserRoles, chartJobTypes, chartJobStatus, UserDictionary } from '@support/types'
import { setupRoutes } from '@support/functions'
import { UsersRoutes, JobsRoutes, OrdersRoutes } from '@support/api'
import {
  createChartJob,
  checkOrder,
  lockOrder,
  setChartJobStatus,
  submitChartJobUpdate,
} from '@support/commands/orders.commands'

export const checkFacilityChartJobStatusSubmission = (): void => {
  const userRole: UserRoles = Cypress.env('role')
  const chartJobType = chartJobTypes.regular
  let facilityCode: string
  let facilityWardCode: string
  let order: OrderLatest

  const testCases = [
    {
      statusLabel: chartJobStatus.completed.displayName,
      status: chartJobStatus.completed.value,
      testId: 'C51725',
    },
    {
      statusLabel: chartJobStatus.hold.displayName,
      status: chartJobStatus.hold.value,
      testId: 'C51726',
    },
    {
      statusLabel: chartJobStatus.cancel.displayName,
      status: chartJobStatus.cancel.value,
      testId: 'C51727',
    },
  ]

  context('Check facility status submissions', () => {
    before(() => {
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('pharmacyAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('password')
      )

      cy.fixture('facility').then($facility => {
        facilityCode = $facility.code
        facilityWardCode = $facility.rounds[0].roundCode
      })
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([
        UsersRoutes.GetUsersDetails,
        UsersRoutes.CheckUserSessionValid,
        UsersRoutes.GetUsersPreferences,
        JobsRoutes.PostJobsOrders,
        OrdersRoutes.PutOrdersLock,
      ])

      createChartJob({
        context: 'facility',
        orderFor: facilityCode,
        deliveryType: chartJobType.deliveryType,
        tags: chartJobType.tags,
        wardCode: facilityWardCode,
        snapshotName: 'Check facility status submissions',
      }).then(latestOrder => {
        order = latestOrder
        const { pharmacyId, batchId } = latestOrder
        cy.visit(`/dashboards/pharmacy/${pharmacyId}/${batchId}/chartflow/job#/`, { retryOnStatusCodeFailure: true })
      })
    })

    testCases.forEach(testCase => {
      let status: string = testCase.status
      let testId: string = testCase.testId
      let statusLabelLower: string = testCase.statusLabel.toLowerCase()

      it(`${testId} - Submit a facility chart job as ${statusLabelLower}`, () => {
        UsersRoutes.GetUsersDetails.check()

        checkOrder(order)
        lockOrder()

        OrdersRoutes.PutOrdersLock.check()

        setChartJobStatus(status)
        submitChartJobUpdate()

        JobsRoutes.PostJobsOrders.check()

        cy.url().should('include', '/new-jobs/')
      })
    })
  })
}
