import { UserRoles, chartJobTypes, UserDictionary } from '@support/types'
import { setupRoutes, epicHdId } from '@support/functions'
import { UsersRoutes } from '@support/api'
import { createChartJob } from '@support/commands/orders.commands'

export const checkFacilityChartJobBehavior = (): void => {
  const userRole: UserRoles = Cypress.env('role')
  const chartJobType = chartJobTypes.regular
  let facilityCode: string
  let facilityWardCode: string

  context('Check facility chart job behaviour', () => {
    before(() => {
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('pharmacyAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('password')
      )

      cy.fixture('facility').then($facility => {
        facilityCode = $facility.code
        facilityWardCode = $facility.rounds[0].roundCode
      })
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([UsersRoutes.GetUsersDetails])
    })

    it('C51749 - Check refresh on facility chart job creation', () => {
      const labels = ['Facility *', 'Ward *', 'Urgent Job', 'Discharge Job', 'Due Time']

      cy.visit('/dashboards/pharmacy/take-photo#/')
        .get(epicHdId('radio-non-patient'))
        .click()

      UsersRoutes.GetUsersDetails.check()

      cy.reload()

      UsersRoutes.GetUsersDetails.check()

      cy.get(epicHdId('radio-non-patient'))
        .click()
        .url()
        .should('contain', 'take-photo')

      labels.forEach(label => {
        cy.get('.control-label')
          .contains(label)
          .should('be.visible')
      })
    })

    it('C51750 - Check refresh on facility chart job submission', () => {
      const labels = ['Job ID', 'Status', 'Facility', 'Ward', 'Comments']

      createChartJob({
        context: 'facility',
        orderFor: facilityCode,
        deliveryType: chartJobType.deliveryType,
        tags: chartJobType.tags,
        wardCode: facilityWardCode,
        snapshotName: 'C51750 - Check refresh on facility chart job submission',
      }).then(({ batchId, pharmacyId }) => {
        cy.visit(`/dashboards/pharmacy/${pharmacyId}/${batchId}/chartflow/job#/`)
      })

      UsersRoutes.GetUsersDetails.check()

      cy.reload()

      UsersRoutes.GetUsersDetails.check()

      cy.url().should('contain', 'chartflow/job')

      labels.forEach(label => {
        cy.get('.control-label')
          .contains(label)
          .should('be.visible')
      })

      cy.get('.photo-title').should('contain', 'Photo 1')
    })
  })
}
