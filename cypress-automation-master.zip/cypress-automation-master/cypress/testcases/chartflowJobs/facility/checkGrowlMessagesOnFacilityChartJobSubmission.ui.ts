import { UserRoles, chartJobTypes, chartJobStatus, UserDictionary, GrowlTypes } from '@support/types'
import { setupRoutes, epicHdId } from '@support/functions'
import { UsersRoutes, OrdersRoutes, JobsRoutes } from '@support/api'
import { createChartJob, lockOrder, setChartJobStatus } from '@support/commands/orders.commands'
import { checkGrowlAndClose, checkGrowlsAreNotVisible } from '@support/commands/general.commands'

export const checkGrowlMessagesOnFacilityChartJobSubmission = (): void => {
  const userRole: UserRoles = Cypress.env('role')
  const chartJobType = chartJobTypes.regular
  const status = chartJobStatus.completed.value
  let facilityCode: string
  let facilityWardCode: string

  context('C51733 - Check growl messages on submission', () => {
    before(() => {
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('pharmacyAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('password')
      )

      cy.fixture('facility').then($facility => {
        facilityCode = $facility.code
        facilityWardCode = $facility.rounds[0].roundCode
      })
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([
        UsersRoutes.GetUsersDetails,
        UsersRoutes.CheckUserSessionValid,
        UsersRoutes.GetUsersPreferences,
        OrdersRoutes.PutOrdersLock,
      ])

      createChartJob({
        context: 'facility',
        orderFor: facilityCode,
        deliveryType: chartJobType.deliveryType,
        tags: chartJobType.tags,
        wardCode: facilityWardCode,
        snapshotName: 'Generate chart job',
      }).then(latestOrder => {
        let { pharmacyId, batchId } = latestOrder
        cy.visit(`/dashboards/pharmacy/${pharmacyId}/${batchId}/chartflow/job#/`)

        UsersRoutes.GetUsersDetails.check()
      })
    })

    it('Submitting a chart job without picking a status', () => {
      lockOrder()

      OrdersRoutes.PutOrdersLock.check()

      checkGrowlAndClose({
        growlMessage: 'Order locked.',
        growlType: GrowlTypes.success,
      })

      cy.get(epicHdId('button-submit-job'))
        .first()
        .click()

      checkGrowlAndClose({
        growlMessage: 'You must select a job status.',
        growlType: GrowlTypes.warning,
      })
      checkGrowlsAreNotVisible()
    })

    it('Submitting a chart job returns a status of 500', () => {
      cy.route({
        ...JobsRoutes.PostJobsOrders,
        response: { message: 'Error and stuff!' },
        status: 500,
      }).as(JobsRoutes.PostJobsOrders.alias)

      lockOrder()

      OrdersRoutes.PutOrdersLock.check()

      checkGrowlAndClose({
        growlMessage: 'Order locked.',
        growlType: GrowlTypes.success,
      })
      setChartJobStatus(status)

      cy.get(epicHdId('button-submit-job'))
        .first()
        .click()

      checkGrowlAndClose({
        growlMessage: 'Error updating job. Please refresh and try again. ',
        growlType: GrowlTypes.error,
      })
      checkGrowlsAreNotVisible()
    })
  })
}
