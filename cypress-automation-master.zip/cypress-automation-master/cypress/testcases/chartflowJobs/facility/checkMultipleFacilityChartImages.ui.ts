import { UserRoles, chartJobStatus, UserDictionary } from '@support/types'
import { setupRoutes, epicHdId } from '@support/functions'
import { UsersRoutes, OrdersRoutes, JobsRoutes } from '@support/api'
import {
  selectChartFacility,
  selectChartWard,
  fillChartCommentSection,
  takePhoto,
  submitChartJobForCreation,
  getLatestOrder,
  checkOrder,
  setChartJobStatus,
  lockOrder,
  submitChartJobUpdate,
} from '@support/commands/orders.commands'

export const checkMultipleFacilityChartImages = (): void => {
  const userRole: UserRoles = Cypress.env('role')
  const chartComment: string = 'Facility Chart Image Check'
  const status = chartJobStatus.completed.value
  let facilityCode: string
  let facilityWardCode: string

  context('C51753 - Check facility chart jobs with multiple images', () => {
    before(() => {
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('pharmacyAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('password')
      )

      cy.fixture('facility').then($facility => {
        facilityCode = $facility.code
        facilityWardCode = $facility.rounds[0].roundCode
      })
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([
        UsersRoutes.GetUsersDetails,
        UsersRoutes.CheckUserSessionValid,
        UsersRoutes.GetUsersPreferences,
        OrdersRoutes.PutOrdersLock,
        OrdersRoutes.PostOrdersNew,
        OrdersRoutes.UploadImageToBlob,
        JobsRoutes.PostJobsOrders,
      ])
    })

    it('Check multiple chart images dont break creation', () => {
      cy.visit('/dashboards/pharmacy/take-photo#/')

      UsersRoutes.GetUsersDetails.check()

      cy.get(epicHdId('radio-non-patient')).click()

      selectChartFacility({ facilityName: facilityCode, facilityCode: facilityCode })
      selectChartWard(facilityWardCode)
      fillChartCommentSection(chartComment)
      takePhoto(11)

      OrdersRoutes.UploadImageToBlob.check()
      OrdersRoutes.UploadImageToBlob.check()
      OrdersRoutes.UploadImageToBlob.check()
      OrdersRoutes.UploadImageToBlob.check()
      OrdersRoutes.UploadImageToBlob.check()
      OrdersRoutes.UploadImageToBlob.check()
      OrdersRoutes.UploadImageToBlob.check()
      OrdersRoutes.UploadImageToBlob.check()
      OrdersRoutes.UploadImageToBlob.check()
      OrdersRoutes.UploadImageToBlob.check()
      OrdersRoutes.UploadImageToBlob.check()

      cy.get('.badge')
        .contains('11')
        .scrollIntoView()
        .should('be.visible')

      cy.get('#numPhotos')
        .should('contain', '11')
        .and('be.visible')

      submitChartJobForCreation()

      OrdersRoutes.PostOrdersNew.check()

      getLatestOrder({
        orderFor: facilityCode,
        comment: chartComment,
      }).then(latestOrder => {
        const { batchId, pharmacyId } = latestOrder

        cy.visit(`/dashboards/pharmacy/${pharmacyId}/${batchId}/chartflow/job#/`, { retryOnStatusCodeFailure: true })

        UsersRoutes.GetUsersDetails.check()

        checkOrder(latestOrder)
        lockOrder()

        OrdersRoutes.PutOrdersLock.check()

        cy.contains('Photo 11').should('exist')

        setChartJobStatus(status)
        submitChartJobUpdate()

        JobsRoutes.PostJobsOrders.check()

        cy.url().should('include', '/new-jobs/')
      })
    })
  })
}
