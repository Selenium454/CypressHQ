import { UserRoles, dueTimes, UserDictionary } from '@support/types'
import { setupRoutes, epicHdId } from '@support/functions'
import { UsersRoutes, OrdersRoutes } from '@support/api'
import {
  selectChartFacility,
  selectChartWard,
  selectDueTime,
  fillChartCommentSection,
  takePhoto,
  submitChartJobForCreation,
  getLatestOrder,
  checkOrder,
  checkDueTime,
} from '@support/commands/orders.commands'

export const checkFacilityChartJobDueTimeSubmission = (): void => {
  const userRole: UserRoles = Cypress.env('role')
  let facilityCode: string
  let facilityName: string
  let facilityWardCode: string

  const testCases = [
    {
      dueTimeType: dueTimes.hour,
      testLabel: 'within an hour',
      testId: 'C51728',
      comment: 'Due time within an hour',
    },
    {
      dueTimeType: dueTimes.today,
      testLabel: 'today',
      testId: 'C51729',
      comment: 'Due time today',
    },
    {
      dueTimeType: dueTimes.tomorrow,
      testLabel: 'tomorrow',
      testId: 'C51730',
      comment: 'Due time tomorrow',
    },
    {
      dueTimeType: dueTimes.other,
      testLabel: 'other',
      testId: 'C51731',
      comment: 'Due time other',
    },
  ]

  context('Create and submit facilities with differing due times', () => {
    before(() => {
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('pharmacyAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('password')
      )

      cy.fixture('facility').then($facility => {
        facilityCode = $facility.code
        facilityName = $facility.name
        facilityWardCode = $facility.rounds[0].roundCode
      })
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([
        UsersRoutes.GetUsersDetails,
        UsersRoutes.CheckUserSessionValid,
        UsersRoutes.GetUsersPreferences,
        OrdersRoutes.PostOrdersNew,
        OrdersRoutes.UploadImageToBlob,
      ])
    })

    testCases.forEach(testCase => {
      let testId: string = testCase.testId
      let testLabel: string = testCase.testLabel
      let dueTimeType: string = testCase.dueTimeType
      let chartComment: string = testCase.comment

      it(`${testId} - Create a facility chart job with due time ${testLabel} and submit`, () => {
        cy.visit('/dashboards/pharmacy/take-photo#/')

        UsersRoutes.GetUsersDetails.check()

        cy.get(epicHdId('radio-non-patient')).click()

        selectChartFacility({ facilityName: facilityName, facilityCode: facilityCode })
        selectChartWard(facilityWardCode)
        selectDueTime(dueTimeType)
        fillChartCommentSection(chartComment)
        takePhoto()

        OrdersRoutes.UploadImageToBlob.check()

        submitChartJobForCreation()

        OrdersRoutes.PostOrdersNew.check()

        getLatestOrder({
          orderFor: facilityCode,
          comment: chartComment,
          snapshotName: `${testId} - ${chartComment}`,
        }).then(latestOrder => {
          const { pharmacyId, batchId, dueTime } = latestOrder

          cy.visit(`/dashboards/pharmacy/${pharmacyId}/${batchId}/chartflow/job#/`)

          UsersRoutes.GetUsersDetails.check()

          checkOrder(latestOrder)
          checkDueTime({ dueTime: dueTime!, dueTimeType: dueTimeType })
        })
      })
    })
  })
}
