import { UserRoles, chartJobTypes, UserDictionary } from '@support/types'
import { setupRoutes, epicHdId } from '@support/functions'
import { UsersRoutes, OrdersRoutes } from '@support/api'
import {
  selectChartFacility,
  selectChartWard,
  setChartTags,
  fillChartCommentSection,
  takePhoto,
  submitChartJobForCreation,
  getLatestOrder,
  checkOrder,
} from '@support/commands/orders.commands'

export const checkFaciltyChartJobTypes = (): void => {
  const userRole: UserRoles = Cypress.env('role')
  let facilityCode: string
  let facilityName: string
  let facilityWardCode: string

  const testCases = [
    {
      chartTags: chartJobTypes.urgent.tagArray,
      testLabel: 'an urgent',
      testId: 'C51722',
      comment: 'Urgent Facility Chart Job',
    },
    {
      chartTags: chartJobTypes.discharge.tagArray,
      testLabel: 'a discharge',
      testId: 'C51723',
      comment: 'Discharge Facility Chart Job',
    },
    {
      chartTags: chartJobTypes.urgentDischarge.tagArray,
      testLabel: 'an urgent discharge',
      testId: 'C51724',
      comment: 'Urgent Discharge Facility Chart Job',
    },
  ]

  context(' Check facility chart job types', () => {
    before(() => {
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('pharmacyAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('password')
      )

      cy.fixture('facility').then($facility => {
        facilityCode = $facility.code
        facilityName = $facility.name
        facilityWardCode = $facility.rounds[0].roundCode
      })
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([
        UsersRoutes.GetUsersDetails,
        UsersRoutes.CheckUserSessionValid,
        UsersRoutes.GetUsersPreferences,
        OrdersRoutes.PostOrdersNew,
        OrdersRoutes.UploadImageToBlob,
      ])
    })

    testCases.forEach(testCase => {
      let testId: string = testCase.testId
      let testLabel: string = testCase.testLabel
      let chartComment: string = testCase.comment
      let chartTags: string[] = testCase.chartTags

      it(`${testId} - Create ${testLabel} facility chart job and then submit`, () => {
        cy.visit('/dashboards/pharmacy/take-photo#/')

        UsersRoutes.GetUsersDetails.check()

        cy.get(epicHdId('radio-non-patient')).click()

        selectChartFacility({ facilityName: facilityName, facilityCode: facilityCode })
        selectChartWard(facilityWardCode)
        setChartTags(chartTags)
        fillChartCommentSection(chartComment)
        takePhoto()

        OrdersRoutes.UploadImageToBlob.check()

        submitChartJobForCreation()

        OrdersRoutes.PostOrdersNew.check()

        getLatestOrder({
          orderFor: facilityCode,
          comment: chartComment,
          snapshotName: `${testId} - ${chartComment}`,
        }).then(latestOrder => {
          const { pharmacyId, batchId } = latestOrder

          cy.visit(`/dashboards/pharmacy/${pharmacyId}/${batchId}/chartflow/job#/`)

          UsersRoutes.GetUsersDetails.check()

          checkOrder(latestOrder)
        })
      })
    })
  })
}
