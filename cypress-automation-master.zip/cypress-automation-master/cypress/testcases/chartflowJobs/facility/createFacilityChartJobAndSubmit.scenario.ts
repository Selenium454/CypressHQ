import { UserRoles, chartJobStatus, UserDictionary, GrowlTypes } from '@support/types'
import { setupRoutes, epicHdId } from '@support/functions'
import { UsersRoutes, OrdersRoutes, JobsRoutes } from '@support/api'
import {
  selectChartFacility,
  selectChartWard,
  fillChartCommentSection,
  takePhoto,
  submitChartJobForCreation,
  goToJobsDashboard,
  getLatestOrder,
  checkOrder,
  setChartJobStatus,
  submitChartJobUpdate,
  lockOrder,
} from '@support/commands/orders.commands'
import { checkGrowlAndClose } from '@support/commands/general.commands'

const testCases = [
  {
    viewportX: Cypress.env('desktop_x'),
    viewportY: Cypress.env('desktop_y'),
    contextName: 'Viewport - Desktop',
    name: 'desktop',
    openMenu: false,
    selectType: 'wide',
  },
  {
    viewportX: Cypress.env('tab2_x'),
    viewportY: Cypress.env('tab2_y'),
    contextName: 'Viewport - Tablet 2',
    name: 'tab 2',
    openMenu: true,
    selectType: 'narrow',
  },
  {
    viewportX: Cypress.env('tab4_x'),
    viewportY: Cypress.env('tab4_x'),
    contextName: 'Viewport - Tablet 4',
    name: 'tab 4',
    openMenu: true,
    selectType: 'narrow',
  },
]

export const createFacilityChartJobAndSubmit = (): void => {
  const userRole: UserRoles = Cypress.env('role')
  const chartComment: string = 'Facility Scenario'
  const chartStatus = chartJobStatus.completed
  let facilityName: string
  let facilityCode: string
  let facilityWardCode: string
  let pharmacyName: string

  context('C51721 - Create facility chart job and then submit it from the dashboard', () => {
    before(() => {
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('pharmacyAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('password')
      )

      cy.fixture('facility').then($facility => {
        facilityCode = $facility.code
        facilityName = $facility.name
        facilityWardCode = $facility.rounds[0].roundCode
        pharmacyName = $facility.pharmacyName
      })
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([
        UsersRoutes.GetUsersDetails,
        UsersRoutes.CheckUserSessionValid,
        UsersRoutes.GetUsersPreferences,
        OrdersRoutes.PutOrdersLock,
        OrdersRoutes.PostOrdersNew,
        OrdersRoutes.UploadImageToBlob,
        JobsRoutes.PostJobsOrders,
      ])
    })

    testCases.forEach(testCase => {
      context(testCase.contextName, () => {
        beforeEach(() => {
          cy.viewport(testCase.viewportX, testCase.viewportY)
        })

        it(`Create facility chart job and then submit it from the dashboard on ${testCase.name}`, () => {
          cy.visit('/dashboards/pharmacy/take-photo#/')

          UsersRoutes.GetUsersDetails.check()

          cy.get(epicHdId('radio-non-patient')).click()

          selectChartFacility({ facilityName: facilityName, facilityCode: facilityCode })
          selectChartWard(facilityWardCode)
          fillChartCommentSection(chartComment)
          takePhoto()

          OrdersRoutes.UploadImageToBlob.check()

          submitChartJobForCreation()

          OrdersRoutes.PostOrdersNew.check()

          checkGrowlAndClose({
            growlMessage: 'Order has been sent to the pharmacy for processing.',
            growlType: GrowlTypes.success,
          })

          goToJobsDashboard({
            pharmacyName: pharmacyName,
            facilityName: facilityName,
          })

          getLatestOrder({ orderFor: facilityCode, comment: chartComment, snapshotName: 'C51721 - Desktop' }).then(
            latestOrder => {
              cy.get(`[data-batchid="${latestOrder.batchId}"]`)
                .last()
                .click()

              checkOrder(latestOrder)
              lockOrder()

              OrdersRoutes.PutOrdersLock.check()

              checkGrowlAndClose({
                growlMessage: 'Order locked.',
                growlType: GrowlTypes.success,
              })
              setChartJobStatus(chartStatus.value)
              submitChartJobUpdate()

              JobsRoutes.PostJobsOrders.check()
            }
          )
        })
      })
    })
  })
}
