import { UserDictionary, UserRoles, searchTypes } from '@support/types'
import { setupRoutes } from '@support/functions'
import { SearchRoutes, UsersRoutes } from '@support/api'

export const canSetSearchDefaults = (): void => {
  const userRole: UserRoles = Cypress.env('role')

  context(`C56031 - Can set search defaults`, () => {
    before(() => {
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('pharmacyAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('password')
      )
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([
        UsersRoutes.GetUsersDetails,
        UsersRoutes.GetUsersPreferences,
        SearchRoutes.GetSearchById,
        SearchRoutes.GetSearchByName,
        SearchRoutes.PostSearchByUrn,
        SearchRoutes.GetSearchByMedicare,
      ])
    })

    const searchOptions = searchTypes
    for (let option in searchOptions) {
      it(`Set default as ${searchOptions[option].name}`, () => {
        cy.get('#searchSettings').click()

        cy.get(`${searchOptions[option].searchTypeSelector}`)
          .parent()
          .find('[class*="ion-android-favorite"]')
          .click()

        cy.get('.growl-notice')
          .contains('Success')
          .reload()

        UsersRoutes.GetUsersPreferences.check()

        cy.get('#searchSettings').click()

        cy.get(`${searchOptions[option].searchTypeSelector}`)
          .parent()
          .find('.ion-android-favorite')

        cy.reload()

        UsersRoutes.GetUsersPreferences.check()
      })
    }
  })
}
