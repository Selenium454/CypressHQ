import { ServiceTypes, createPatientViaApi, addServiceToPatientViaApi, setupRoutes } from '@support/functions'
import { ServiceTypesList, UserRoles, UserDictionary, searchTypes, searchTypeList } from '@support/types'
import { RegistrationModelLatest } from '@schemas/api/models'
import { setSearchType, searchForPatientBy, checkUiContainsFormattedName } from '@support/commands/search.commands'
import { SearchRoutes } from '@support/api'

export const canSearchForInactivePatients = (): void => {
  const serviceDetails = ServiceTypes[ServiceTypesList.Hospital]
  const userRole: UserRoles = Cypress.env('role')
  let registration: RegistrationModelLatest
  let fullName: string

  context('Can search for an inactive patient', () => {
    before(() => {
      cy.login(
        userRole ? UserDictionary[userRole].email : Cypress.env('pharmacyAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('password')
      )

      createPatientViaApi({ activeInHub: false }).then(patient => {
        cy.wait(1000) //TODO: Replace with redis?

        addServiceToPatientViaApi({ serviceDetails, patient }).then(patient => {
          registration = patient
          if (patient.middleName) {
            fullName = `${patient.firstName} ${patient.middleName} ${patient.surName}`
          } else {
            fullName = `${patient.firstName} ${patient.surName}`
          }
        })
      })
    })

    beforeEach(() => {
      cy.server()
      setupRoutes([
        SearchRoutes.GetSearchById,
        SearchRoutes.GetSearchByName,
        SearchRoutes.PostSearchByUrn,
        SearchRoutes.GetSearchByMedicare,
      ])
    })

    it('C56027 - Search for patient by last name', () => {
      const searchType = searchTypes[searchTypeList.Surname]

      setSearchType(searchType)
      searchForPatientBy(searchType, `${registration.firstName} ${registration.surName}`)

      SearchRoutes.GetSearchByName.check()

      checkUiContainsFormattedName(fullName)
    })

    it('C56028 - Search for patient by medicare number', () => {
      const searchType = searchTypes[searchTypeList.Medicare]

      setSearchType(searchType)
      searchForPatientBy(searchType, registration.patient.medicareNumber!)

      SearchRoutes.GetSearchByMedicare.check()

      checkUiContainsFormattedName(fullName)
    })

    it('C56029 - Search for patient by URN', () => {
      const searchType = searchTypes[searchTypeList.Urn]

      setSearchType(searchType)
      searchForPatientBy(searchType, registration.patient.services![0].urNumber!)

      SearchRoutes.PostSearchByUrn.check()

      checkUiContainsFormattedName(fullName)
    })

    it('C56030 - Search for patient by customer ID', () => {
      const searchType = searchTypes[searchTypeList.CustomerId]

      setSearchType(searchType)
      searchForPatientBy(searchType, registration.userId!)

      SearchRoutes.GetSearchById.check()

      checkUiContainsFormattedName(fullName)
    })
  })
}
