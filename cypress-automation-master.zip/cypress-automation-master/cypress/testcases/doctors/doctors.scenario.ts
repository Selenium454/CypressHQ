import { UserRoles, UserDictionary } from '@support/types'
import { searchForDoctor, checkDoctorSearchResults } from '@support/commands/doctors.commands'
import { generateProviderNumber } from '@support/functions'

export const doctorScenarios = (): void => {
  const doctorFullName: string = Cypress.env('doctorFullName')
  const doctorPrescriberNumber: string = Cypress.env('doctorPrescriberNumber')
  const doctorProviderNumber: string = Cypress.env('doctorProviderNumber')
  const doctorPracticeName: string = Cypress.env('doctorPracticeName')
  const userRole: UserRoles = Cypress.env('role')

  context('Doctor Scenarios', () => {
    before(() => {
      cy.logout().login(
        userRole ? UserDictionary[userRole].email : Cypress.env('globalAdminEmail'),
        userRole ? UserDictionary[userRole].password : Cypress.env('adminPassword')
      )
    })

    beforeEach(() => {
      cy.server()
      cy.route({ method: 'POST', url: '/doctor/search' }).as('postDoctorSearch')
      cy.route({ method: 'POST', url: '/doctor' }).as('postAddDoctor')
      cy.route({ method: 'GET', url: '/doctor/*' }).as('getDoctor')
      cy.route({ method: 'PUT', url: '/doctor/*' }).as('putUpdateDoctor')
    })

    context('Searching', () => {
      it('Search for a doctor by provider number', () => {
        cy.contains('.menu-label', 'Doctors').click()

        cy.get('.header-title').should('be.visible')

        cy.contains('Doctor Search')

        searchForDoctor({
          searchMethodSelector: '.el-popper [value="provider"]',
          searchTerm: doctorProviderNumber,
        })

        checkDoctorSearchResults({
          fullName: doctorFullName,
          prescriberNumber: doctorPrescriberNumber,
          providerNumber: doctorProviderNumber,
          practiceName: doctorPracticeName,
        })
      })

      it('Search for a doctor by prescriber number', () => {
        cy.contains('.menu-label', 'Doctors').click()

        cy.get('.header-title').should('be.visible')

        cy.contains('Doctor Search')

        searchForDoctor({
          searchMethodSelector: '.el-popper [value="prescriber"]',
          searchTerm: doctorPrescriberNumber,
        })

        checkDoctorSearchResults({
          fullName: doctorFullName,
          prescriberNumber: doctorPrescriberNumber,
          providerNumber: doctorProviderNumber,
          practiceName: doctorPracticeName,
        })
      })

      it('Search for a doctor by name', () => {
        cy.contains('.menu-label', 'Doctors')
          .click()
          .get('.header-title')
          .should('be.visible')
          .contains('Doctor Search')

        searchForDoctor({
          searchMethodSelector: '.el-popper [value="name"]',
          searchTerm: doctorFullName,
        })

        checkDoctorSearchResults({
          fullName: doctorFullName,
          prescriberNumber: doctorPrescriberNumber,
          providerNumber: doctorProviderNumber,
          practiceName: doctorPracticeName,
        })
      })
    })

    context('Creating', () => {
      const providerNumber = generateProviderNumber()
      const altProviderNumber = generateProviderNumber()

      it('Can add a new doctor then add multiple practices', () => {
        cy.contains('.menu-label', 'Doctors').click()

        searchForDoctor({
          searchMethodSelector: '.el-popper [value="name"]',
          searchTerm: doctorFullName,
        })

        cy.contains('.btn-action', 'Add New Doctor').click()

        cy.get('.header-title')
          .should('be.visible')
          .contains('Doctor Details')

        cy.get('[name="First Name"]')
          .clear()
          .type('Ben')

        cy.get('[name="Last Name"]')
          .clear()
          .type('Spinks')

        cy.get('[name="Practice 0 Name"]')
          .clear()
          .type('Automated Practice')

        cy.get('[name="Practice 0 Provider Number"]')
          .clear()
          .type(providerNumber)

        cy.contains('.btn-action', 'Save').click()

        cy.get('.growl-notice')
          .find('.growl-title')
          .contains('Success')

        cy.wait('@getDoctor')

        cy.contains('.btn-primary', 'Add Practice').click()

        cy.get('[name="Practice 1 Name"]')
          .clear()
          .type('Automated Practice')

        cy.get('[name="Practice 1 Provider Number"]')
          .clear()
          .type(altProviderNumber)

        cy.contains('.btn-action', 'Save').click()

        cy.wait('@putUpdateDoctor')

        cy.get('.growl-notice')
          .find('.growl-title')
          .contains('Success')
      })
    })
  })
}
