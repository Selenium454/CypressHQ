import { AllTestCases, Suites, UserRoles } from '@support/types'
import { setupTestState, determineTestsAndRun } from '@support/functions'
import { canSearchForActivePatients, canSearchForInactivePatients, canSetSearchDefaults } from '@testcases/search'
import { setupSnapshots } from '@support/commands'

const allTestCases: AllTestCases[] = [
  {
    run: canSearchForActivePatients,
    priority: 1,
    suite: Suites.ui,
    roles: [
      UserRoles.pharmacist,
      UserRoles.pharmacyAdmin,
      UserRoles.pharmacyTechnician,
      UserRoles.corporateAdmin,
      UserRoles.globalAdmin,
      UserRoles.cancerCareAdmin,
      UserRoles.accounts,
      UserRoles.doctor,
    ],
  },
  {
    run: canSearchForInactivePatients,
    priority: 1,
    suite: Suites.ui,
    roles: [
      UserRoles.pharmacist,
      UserRoles.pharmacyAdmin,
      UserRoles.pharmacyTechnician,
      UserRoles.corporateAdmin,
      UserRoles.globalAdmin,
      UserRoles.cancerCareAdmin,
      UserRoles.accounts,
      UserRoles.doctor,
    ],
  },
  {
    run: canSetSearchDefaults,
    priority: 2,
    suite: Suites.ui,
    roles: [
      UserRoles.pharmacist,
      UserRoles.pharmacyAdmin,
      UserRoles.pharmacyTechnician,
      UserRoles.corporateAdmin,
      UserRoles.globalAdmin,
      UserRoles.cancerCareAdmin,
      UserRoles.accounts,
      UserRoles.doctor,
    ],
  },
]

describe(`${Cypress.env('env').toUpperCase()} - Search`, function() {
  setupSnapshots('search')

  before(() => {
    setupTestState()
  })

  determineTestsAndRun(allTestCases)
})
