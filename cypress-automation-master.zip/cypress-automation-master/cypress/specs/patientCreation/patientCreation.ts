import { AllTestCases, Suites, UserRoles } from '@support/types'
import { setupTestState, determineTestsAndRun } from '@support/functions'

import {
  createPatientWithService,
  checkInvalidPersonalDetails,
  checkPersonalPageGrowls,
} from '@testcases/patientCreation'
import { setupSnapshots } from '@support/commands'

const allTestCases: AllTestCases[] = [
  {
    run: createPatientWithService,
    priority: 1,
    suite: Suites.scenarios,
    roles: [
      UserRoles.pharmacist,
      UserRoles.pharmacyAdmin,
      UserRoles.pharmacyTechnician,
      UserRoles.cancerCareAdmin,
      UserRoles.corporateAdmin,
    ],
  },
  {
    run: checkInvalidPersonalDetails,
    priority: 3,
    suite: Suites.ui,
    roles: [
      UserRoles.pharmacist,
      UserRoles.pharmacyAdmin,
      UserRoles.pharmacyTechnician,
      UserRoles.cancerCareAdmin,
      UserRoles.corporateAdmin,
    ],
  },
  {
    run: checkPersonalPageGrowls,
    priority: 4,
    suite: Suites.ui,
    roles: [
      UserRoles.pharmacist,
      UserRoles.pharmacyAdmin,
      UserRoles.pharmacyTechnician,
      UserRoles.cancerCareAdmin,
      UserRoles.corporateAdmin,
    ],
  },
]

describe(`${Cypress.env('env').toUpperCase()} - Patient Creation`, () => {
  setupSnapshots('patientCreation')

  before(() => {
    setupTestState()
  })

  determineTestsAndRun(allTestCases)
})
