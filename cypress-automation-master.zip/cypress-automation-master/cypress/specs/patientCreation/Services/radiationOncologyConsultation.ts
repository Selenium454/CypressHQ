import { ServiceTypesList, AllTestCases, Suites, UserRoles } from '@support/types'
import { setupTestState, determineTestsAndRun } from '@support/functions'

import {
  canAddHealthFundInfo,
  canAddAndDeleteDoctorWithReferral,
  canAddAndRemoveService,
} from '@testcases/patientCreation/services'
import { setupSnapshots } from '@support/commands'

const serviceType = ServiceTypesList.RadiationOncologyConsultation

const allTestCases: AllTestCases[] = [
  {
    run: canAddAndRemoveService,
    priority: 1,
    suite: Suites.ui,
    roles: [UserRoles.cancerCareAdmin, UserRoles.corporateAdmin],
    options: {
      serviceType: serviceType,
      canRemoveTestId: 'C51781',
      canAddMoreThanOneTestId: 'C51782',
      cannotAddMoreThanOneTestId: 'C51783',
    },
  },
  {
    run: canAddHealthFundInfo,
    priority: 3,
    suite: Suites.ui,
    roles: [UserRoles.cancerCareAdmin, UserRoles.corporateAdmin],
    options: { serviceType: serviceType, testId: 'C51784' },
  },
  {
    run: canAddAndDeleteDoctorWithReferral,
    priority: 2,
    suite: Suites.ui,
    roles: [UserRoles.cancerCareAdmin, UserRoles.corporateAdmin],
    options: { serviceType: serviceType, testId: 'C51785' },
  },
]

describe(`${Cypress.env('env').toUpperCase()} - Patient Creation - Radiation Oncology Consultation Service`, () => {
  setupSnapshots('radiationOncologyConsultation')

  before(() => {
    setupTestState()
  })

  determineTestsAndRun(allTestCases)
})
