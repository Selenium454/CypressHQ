import { ServiceTypesList, AllTestCases, Suites, UserRoles } from '@support/types'
import { setupTestState, determineTestsAndRun } from '@support/functions'

import {
  canAddHealthFundInfo,
  canAddAndDeleteDoctorWithReferral,
  cannotAddVisitDuringCreation,
  canAddAndRemoveService,
} from '@testcases/patientCreation/services'
import { setupSnapshots } from '@support/commands'

const serviceType = ServiceTypesList.MedicalOncologyConsultation

const allTestCases: AllTestCases[] = [
  {
    run: canAddAndRemoveService,
    priority: 1,
    suite: Suites.ui,
    roles: [UserRoles.cancerCareAdmin, UserRoles.corporateAdmin],
    options: {
      serviceType: serviceType,
      canRemoveTestId: 'C51770',
      canAddMoreThanOneTestId: 'C51771',
      cannotAddMoreThanOneTestId: 'C51772',
    },
  },
  {
    run: canAddHealthFundInfo,
    priority: 3,
    suite: Suites.ui,
    roles: [UserRoles.cancerCareAdmin, UserRoles.corporateAdmin],
    options: { serviceType: serviceType, testId: 'C51773' },
  },
  {
    run: canAddAndDeleteDoctorWithReferral,
    priority: 1,
    suite: Suites.ui,
    roles: [UserRoles.cancerCareAdmin, UserRoles.corporateAdmin],
    options: { serviceType: serviceType, testId: 'C51774' },
  },
  {
    run: cannotAddVisitDuringCreation,
    priority: 4,
    suite: Suites.ui,
    roles: [UserRoles.cancerCareAdmin, UserRoles.corporateAdmin],
    options: { serviceType: serviceType, testId: 'C51775' },
  },
]

describe(`${Cypress.env('env').toUpperCase()} - Patient Creation - Medical Oncology Consultation Service`, () => {
  setupSnapshots('medicalOncologyConsultation')

  before(() => {
    setupTestState()
  })

  determineTestsAndRun(allTestCases)
})
