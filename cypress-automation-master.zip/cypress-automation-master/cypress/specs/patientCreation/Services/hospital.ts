import { ServiceTypesList, AllTestCases, Suites, UserRoles } from '@support/types'
import { setupTestState, determineTestsAndRun } from '@support/functions'

import { canAddHealthFundInfo, canAddAndRemoveService } from '@testcases/patientCreation/services'
import { setupSnapshots } from '@support/commands'

const serviceType = ServiceTypesList.Hospital

const allTestCases: AllTestCases[] = [
  {
    run: canAddHealthFundInfo,
    priority: 3,
    suite: Suites.ui,
    roles: [UserRoles.pharmacist, UserRoles.pharmacyAdmin, UserRoles.pharmacyTechnician, UserRoles.corporateAdmin],
    options: { serviceType: serviceType, testId: 'C51764' },
  },
  {
    run: canAddAndRemoveService,
    priority: 1,
    suite: Suites.ui,
    roles: [UserRoles.pharmacist, UserRoles.pharmacyAdmin, UserRoles.pharmacyTechnician, UserRoles.corporateAdmin],
    options: {
      serviceType: serviceType,
      canRemoveTestId: 'C51761',
      canAddMoreThanOneTestId: 'C51762',
      cannotAddMoreThanOneTestId: 'C51763',
    },
  },
]

describe(`${Cypress.env('env').toUpperCase()} - Patient Creation - Hospital Service`, () => {
  setupSnapshots('hospital')

  before(() => {
    setupTestState()
  })

  determineTestsAndRun(allTestCases)
})
