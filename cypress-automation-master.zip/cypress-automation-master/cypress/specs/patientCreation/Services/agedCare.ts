import { ServiceTypesList, AllTestCases, Suites, UserRoles } from '@support/types'
import { setupTestState, determineTestsAndRun } from '@support/functions'

import {
  canAddHealthFundInfo,
  canAddAndDeleteDoctorWithReferral,
  canAddAndRemoveService,
} from '@testcases/patientCreation/services'
import { setupSnapshots } from '@support/commands'

const serviceType = ServiceTypesList.AgedCare

const allTestCases: AllTestCases[] = [
  {
    run: canAddAndRemoveService,
    priority: 1,
    suite: Suites.ui,
    roles: [UserRoles.pharmacist, UserRoles.pharmacyAdmin, UserRoles.pharmacyTechnician, UserRoles.corporateAdmin],
    options: {
      serviceType: serviceType,
      canRemoveTestId: 'C51765',
      canAddMoreThanOneTestId: 'C51766',
      cannotAddMoreThanOneTestId: 'C51767',
    },
  },
  {
    run: canAddHealthFundInfo,
    priority: 3,
    suite: Suites.ui,
    roles: [UserRoles.pharmacist, UserRoles.pharmacyAdmin, UserRoles.pharmacyTechnician, UserRoles.corporateAdmin],
    options: { serviceType, testId: 'C51768' },
  },
  {
    run: canAddAndDeleteDoctorWithReferral,
    priority: 2,
    suite: Suites.ui,
    roles: [UserRoles.pharmacist, UserRoles.pharmacyAdmin, UserRoles.pharmacyTechnician, UserRoles.corporateAdmin],
    options: { serviceType, testId: 'C51769' },
  },
]

describe(`${Cypress.env('env').toUpperCase()} - Patient Creation - Aged Care Service`, () => {
  setupSnapshots('agedCare')

  before(() => {
    setupTestState()
  })

  determineTestsAndRun(allTestCases)
})
