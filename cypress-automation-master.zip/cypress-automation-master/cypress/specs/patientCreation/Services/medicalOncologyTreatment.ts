import { ServiceTypesList, AllTestCases, Suites, UserRoles } from '@support/types'
import { setupTestState, determineTestsAndRun } from '@support/functions'

import {
  canAddHealthFundInfo,
  canAddAndDeleteDoctorWithReferral,
  canAddAndRemoveService,
} from '@testcases/patientCreation/services'
import { setupSnapshots } from '@support/commands'

const serviceType = ServiceTypesList.MedicalOncologyTreatment

const allTestCases: AllTestCases[] = [
  {
    run: canAddAndRemoveService,
    priority: 1,
    suite: Suites.ui,
    roles: [UserRoles.cancerCareAdmin, UserRoles.corporateAdmin],
    options: {
      serviceType: serviceType,
      canRemoveTestId: 'C51776',
      canAddMoreThanOneTestId: 'C51777',
      cannotAddMoreThanOneTestId: 'C51778',
    },
  },
  {
    run: canAddHealthFundInfo,
    priority: 3,
    suite: Suites.ui,
    roles: [UserRoles.cancerCareAdmin, UserRoles.corporateAdmin],
    options: { serviceType: serviceType, testId: 'C51779' },
  },
  {
    run: canAddAndDeleteDoctorWithReferral,
    priority: 2,
    suite: Suites.ui,
    roles: [UserRoles.cancerCareAdmin, UserRoles.corporateAdmin],
    options: { serviceType: serviceType, testId: 'C51780' },
  },
]

describe(`${Cypress.env('env').toUpperCase()} - Patient Creation - Medical Oncology Treatment Service`, () => {
  setupSnapshots('MedicalOncologyTreatment')

  before(() => {
    setupTestState()
  })

  determineTestsAndRun(allTestCases)
})
