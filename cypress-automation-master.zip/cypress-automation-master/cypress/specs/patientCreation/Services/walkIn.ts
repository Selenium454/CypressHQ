import { ServiceTypesList, AllTestCases, Suites, UserRoles } from '@support/types'
import { setupTestState, determineTestsAndRun } from '@support/functions'

import { canAddHealthFundInfo, canAddAndRemoveService } from '@testcases/patientCreation/services'
import { setupSnapshots } from '@support/commands'

const serviceType = ServiceTypesList.WalkIn

const allTestCases: AllTestCases[] = [
  {
    run: canAddAndRemoveService,
    priority: 1,
    suite: Suites.ui,
    roles: [UserRoles.pharmacist, UserRoles.pharmacyAdmin, UserRoles.pharmacyTechnician, UserRoles.corporateAdmin],
    options: {
      serviceType: serviceType,
      canRemoveTestId: 'C51791',
      canAddMoreThanOneTestId: 'C51792',
      cannotAddMoreThanOneTestId: 'C51793',
    },
  },
  {
    run: canAddHealthFundInfo,
    priority: 3,
    suite: Suites.ui,
    roles: [UserRoles.pharmacist, UserRoles.pharmacyAdmin, UserRoles.pharmacyTechnician, UserRoles.corporateAdmin],
    options: { serviceType: serviceType, testId: 'C51794' },
  },
]

describe(`${Cypress.env('env').toUpperCase()} - Patient Creation - Walk In Service`, () => {
  setupSnapshots('walkIn')

  before(() => {
    setupTestState()
  })

  determineTestsAndRun(allTestCases)
})
