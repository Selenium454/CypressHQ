import { AllTestCases, UserRoles, Suites } from '@support/types'
import { setupTestState, determineTestsAndRun } from '@support/functions'

import {
  canSetPatientToDeceased,
  checkMedicareValidation,
  checkRepatValidation,
  checkConcessionValidation,
  checkMandatoryFields,
} from '@testcases/patientProfile/details'
import { setupSnapshots } from '@support/commands'

const allTestCases: AllTestCases[] = [
  {
    run: canSetPatientToDeceased,
    priority: 2,
    suite: Suites.ui,
    roles: [
      UserRoles.pharmacist,
      UserRoles.pharmacyAdmin,
      UserRoles.pharmacyTechnician,
      UserRoles.corporateAdmin,
      UserRoles.globalAdmin,
      UserRoles.cancerCareAdmin,
    ],
  },
  {
    run: checkMedicareValidation,
    priority: 2,
    suite: Suites.ui,
    roles: [
      UserRoles.pharmacist,
      UserRoles.pharmacyAdmin,
      UserRoles.pharmacyTechnician,
      UserRoles.corporateAdmin,
      UserRoles.globalAdmin,
      UserRoles.cancerCareAdmin,
    ],
  },
  {
    run: checkRepatValidation,
    priority: 2,
    suite: Suites.ui,
    roles: [
      UserRoles.pharmacist,
      UserRoles.pharmacyAdmin,
      UserRoles.pharmacyTechnician,
      UserRoles.corporateAdmin,
      UserRoles.globalAdmin,
      UserRoles.cancerCareAdmin,
    ],
  },
  {
    run: checkConcessionValidation,
    priority: 2,
    suite: Suites.ui,
    roles: [
      UserRoles.pharmacist,
      UserRoles.pharmacyAdmin,
      UserRoles.pharmacyTechnician,
      UserRoles.corporateAdmin,
      UserRoles.globalAdmin,
      UserRoles.cancerCareAdmin,
    ],
  },
  {
    run: checkMandatoryFields,
    priority: 4,
    suite: Suites.ui,
    roles: [
      UserRoles.pharmacist,
      UserRoles.pharmacyAdmin,
      UserRoles.pharmacyTechnician,
      UserRoles.corporateAdmin,
      UserRoles.globalAdmin,
      UserRoles.cancerCareAdmin,
    ],
  },
]

describe(`${Cypress.env('env').toUpperCase()} - Patient Profile - Details`, () => {
  setupSnapshots('details')

  before(() => {
    setupTestState()
  })

  determineTestsAndRun(allTestCases)
})
