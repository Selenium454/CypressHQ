import { AllTestCases, Suites, UserRoles } from '@support/types'
import { setupTestState, determineTestsAndRun } from '@support/functions'

import {
  canDiscardServiceDuringAddProcess,
  fieldsResetOnServiceAddProcess,
  cannotSubmitWithoutAllFieldsDuringAddProcess,
} from '@testcases/patientProfile/services'
import { setupSnapshots } from '@support/commands'

const allTestCases: AllTestCases[] = [
  {
    run: canDiscardServiceDuringAddProcess,
    priority: 4,
    suite: Suites.ui,
    roles: [
      UserRoles.pharmacist,
      UserRoles.pharmacyAdmin,
      UserRoles.pharmacyTechnician,
      UserRoles.corporateAdmin,
      UserRoles.globalAdmin,
      UserRoles.cancerCareAdmin,
    ],
  },
  {
    run: fieldsResetOnServiceAddProcess,
    priority: 4,
    suite: Suites.ui,
    roles: [
      UserRoles.pharmacist,
      UserRoles.pharmacyAdmin,
      UserRoles.pharmacyTechnician,
      UserRoles.corporateAdmin,
      UserRoles.globalAdmin,
      UserRoles.cancerCareAdmin,
    ],
  },
  {
    run: cannotSubmitWithoutAllFieldsDuringAddProcess,
    priority: 4,
    suite: Suites.ui,
    roles: [
      UserRoles.pharmacist,
      UserRoles.pharmacyAdmin,
      UserRoles.pharmacyTechnician,
      UserRoles.corporateAdmin,
      UserRoles.globalAdmin,
      UserRoles.cancerCareAdmin,
    ],
  },
]

describe(`${Cypress.env('env').toUpperCase()} - Patient Profile - Base Services`, () => {
  setupSnapshots('baseService')

  before(() => {
    setupTestState()
  })

  determineTestsAndRun(allTestCases)
})
