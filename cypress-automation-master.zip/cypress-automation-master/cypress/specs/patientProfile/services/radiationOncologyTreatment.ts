import { ServiceTypesList, AllTestCases, Suites, UserRoles } from '@support/types'
import { setupTestState, determineTestsAndRun } from '@support/functions'

import {
  canViewAdditionalIdsOnService,
  canCancelServiceCreationOnProfile,
  canAddAndEditHealthFundInfo,
  canSetServiceToInactiveThenActive,
  canSetServiceToArchivedThenActive,
  canAddAndEditAdditionalIds,
  canAddAndDeleteDoctorWithReferralOnProfile,
  canAddService,
} from '@testcases/patientProfile/services'
import { setupSnapshots } from '@support/commands'

const serviceType = ServiceTypesList.RadiationOncologyTreatment

const allTestCases: AllTestCases[] = [
  {
    run: canViewAdditionalIdsOnService,
    priority: 4,
    suite: Suites.ui,
    roles: [
      UserRoles.pharmacist,
      UserRoles.pharmacyAdmin,
      UserRoles.pharmacyTechnician,
      UserRoles.cancerCareAdmin,
      UserRoles.corporateAdmin,
      UserRoles.globalAdmin,
      UserRoles.accounts,
    ],
    options: { serviceType: serviceType, testId: 'C53553' },
  },
  {
    run: canCancelServiceCreationOnProfile,
    priority: 3,
    suite: Suites.ui,
    roles: [UserRoles.cancerCareAdmin, UserRoles.corporateAdmin, UserRoles.globalAdmin],
    options: { serviceType: serviceType, testId: 'C53554' },
  },
  {
    run: canAddService,
    priority: 1,
    suite: Suites.ui,
    roles: [UserRoles.cancerCareAdmin, UserRoles.corporateAdmin, UserRoles.globalAdmin],
    options: { serviceType: serviceType, canAddMoreThanOneTestId: 'C53555', cannotAddMoreThanOneTestId: 'C53556' },
  },
  {
    run: canAddAndEditHealthFundInfo,
    priority: 3,
    suite: Suites.ui,
    roles: [UserRoles.cancerCareAdmin, UserRoles.corporateAdmin, UserRoles.globalAdmin],
    options: { serviceType: serviceType, testId: 'C53557' },
  },
  {
    run: canSetServiceToInactiveThenActive,
    priority: 2,
    suite: Suites.ui,
    roles: [UserRoles.cancerCareAdmin, UserRoles.corporateAdmin, UserRoles.globalAdmin],
    options: { serviceType: serviceType, testId: 'C53558' },
  },
  {
    run: canSetServiceToArchivedThenActive,
    priority: 3,
    suite: Suites.ui,
    roles: [UserRoles.globalAdmin],
    options: { serviceType: serviceType, testId: 'C53559' },
  },
  {
    run: canAddAndEditAdditionalIds,
    priority: 3,
    suite: Suites.ui,
    roles: [UserRoles.globalAdmin, UserRoles.cancerCareAdmin],
    options: { serviceType: serviceType, testId: 'C53560' },
  },
  {
    run: canAddAndDeleteDoctorWithReferralOnProfile,
    priority: 2,
    suite: Suites.ui,
    roles: [UserRoles.cancerCareAdmin, UserRoles.corporateAdmin, UserRoles.globalAdmin],
    options: { serviceType: serviceType, testId: 'C53561' },
  },
]

describe(`${Cypress.env('env').toUpperCase()} - Patient Profile - Radiation Oncology Treatment Service`, () => {
  setupSnapshots('radiationOncologyTreatment')

  before(() => {
    setupTestState()
  })

  determineTestsAndRun(allTestCases)
})
