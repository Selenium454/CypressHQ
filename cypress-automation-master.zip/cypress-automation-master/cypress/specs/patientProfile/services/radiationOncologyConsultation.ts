import { ServiceTypesList, AllTestCases, Suites, UserRoles } from '@support/types'
import { setupTestState, determineTestsAndRun } from '@support/functions'

import {
  canViewAdditionalIdsOnService,
  canCancelServiceCreationOnProfile,
  canAddAndEditHealthFundInfo,
  canSetServiceToInactiveThenActive,
  canSetServiceToArchivedThenActive,
  canAddAndEditAdditionalIds,
  canAddAndDeleteDoctorWithReferralOnProfile,
  canAddService,
} from '@testcases/patientProfile/services'
import { setupSnapshots } from '@support/commands'

const serviceType = ServiceTypesList.RadiationOncologyConsultation

const allTestCases: AllTestCases[] = [
  {
    run: canViewAdditionalIdsOnService,
    priority: 4,
    suite: Suites.ui,
    roles: [
      UserRoles.pharmacist,
      UserRoles.pharmacyAdmin,
      UserRoles.pharmacyTechnician,
      UserRoles.cancerCareAdmin,
      UserRoles.corporateAdmin,
      UserRoles.globalAdmin,
      UserRoles.accounts,
    ],
    options: { serviceType: serviceType, testId: 'C53544' },
  },
  {
    run: canCancelServiceCreationOnProfile,
    priority: 3,
    suite: Suites.ui,
    roles: [UserRoles.cancerCareAdmin, UserRoles.corporateAdmin, UserRoles.globalAdmin],
    options: { serviceType: serviceType, testId: 'C53545' },
  },
  {
    run: canAddService,
    priority: 1,
    suite: Suites.ui,
    roles: [UserRoles.cancerCareAdmin, UserRoles.corporateAdmin, UserRoles.globalAdmin],
    options: { serviceType: serviceType, canAddMoreThanOneTestId: 'C53546', cannotAddMoreThanOneTestId: 'C53547' },
  },
  {
    run: canAddAndEditHealthFundInfo,
    priority: 3,
    suite: Suites.ui,
    roles: [UserRoles.cancerCareAdmin, UserRoles.corporateAdmin, UserRoles.globalAdmin],
    options: { serviceType: serviceType, testId: 'C53548' },
  },
  {
    run: canSetServiceToInactiveThenActive,
    priority: 2,
    suite: Suites.ui,
    roles: [UserRoles.cancerCareAdmin, UserRoles.corporateAdmin, UserRoles.globalAdmin],
    options: { serviceType: serviceType, testId: 'C53549' },
  },
  {
    run: canSetServiceToArchivedThenActive,
    priority: 3,
    suite: Suites.ui,
    roles: [UserRoles.globalAdmin],
    options: { serviceType: serviceType, testId: 'C53550' },
  },
  {
    run: canAddAndEditAdditionalIds,
    priority: 3,
    suite: Suites.ui,
    roles: [UserRoles.globalAdmin, UserRoles.cancerCareAdmin],
    options: { serviceType: serviceType, testId: 'C53551' },
  },
  {
    run: canAddAndDeleteDoctorWithReferralOnProfile,
    priority: 2,
    suite: Suites.ui,
    roles: [UserRoles.cancerCareAdmin, UserRoles.corporateAdmin, UserRoles.globalAdmin],
    options: { serviceType: serviceType, testId: 'C53552' },
  },
]

describe(`${Cypress.env('env').toUpperCase()} - Patient Profile - Radiation Oncology Consultation Service`, () => {
  setupSnapshots('radiationOncologyConsultation')

  before(() => {
    setupTestState()
  })

  determineTestsAndRun(allTestCases)
})
