import { ServiceTypesList, AllTestCases, Suites, UserRoles } from '@support/types'
import { setupTestState, determineTestsAndRun } from '@support/functions'
import {
  canViewAdditionalIdsOnService,
  canCancelServiceCreationOnProfile,
  canAddAndEditHealthFundInfo,
  canSetServiceToInactiveThenActive,
  canSetServiceToArchivedThenActive,
  canAddAndEditAdditionalIds,
  canAddService,
} from '@testcases/patientProfile/services'
import { setupSnapshots } from '@support/commands'

const serviceType = ServiceTypesList.Hospital

const allTestCases: AllTestCases[] = [
  {
    run: canViewAdditionalIdsOnService,
    priority: 4,
    suite: Suites.ui,
    roles: [
      UserRoles.pharmacist,
      UserRoles.pharmacyAdmin,
      UserRoles.pharmacyTechnician,
      UserRoles.cancerCareAdmin,
      UserRoles.corporateAdmin,
      UserRoles.globalAdmin,
      UserRoles.accounts,
    ],
    options: { serviceType: serviceType, testId: 'C53345' },
  },
  {
    run: canCancelServiceCreationOnProfile,
    priority: 3,
    suite: Suites.ui,
    roles: [
      UserRoles.pharmacist,
      UserRoles.pharmacyAdmin,
      UserRoles.pharmacyTechnician,
      UserRoles.corporateAdmin,
      UserRoles.globalAdmin,
    ],
    options: { serviceType: serviceType, testId: 'C53346' },
  },
  {
    run: canAddService,
    priority: 1,
    suite: Suites.ui,
    roles: [
      UserRoles.pharmacist,
      UserRoles.pharmacyAdmin,
      UserRoles.pharmacyTechnician,
      UserRoles.corporateAdmin,
      UserRoles.globalAdmin,
    ],
    options: { serviceType: serviceType, canAddMoreThanOneTestId: 'C53501', cannotAddMoreThanOneTestId: 'C53502' },
  },
  {
    run: canAddAndEditHealthFundInfo,
    priority: 3,
    suite: Suites.ui,
    roles: [
      UserRoles.pharmacist,
      UserRoles.pharmacyAdmin,
      UserRoles.pharmacyTechnician,
      UserRoles.corporateAdmin,
      UserRoles.globalAdmin,
    ],
    options: { serviceType: serviceType, testId: 'C53503' },
  },
  {
    run: canSetServiceToInactiveThenActive,
    priority: 1,
    suite: Suites.ui,
    roles: [
      UserRoles.pharmacist,
      UserRoles.pharmacyAdmin,
      UserRoles.pharmacyTechnician,
      UserRoles.corporateAdmin,
      UserRoles.globalAdmin,
    ],
    options: { serviceType: serviceType, testId: 'C53504' },
  },
  {
    run: canSetServiceToArchivedThenActive,
    priority: 3,
    suite: Suites.ui,
    roles: [UserRoles.globalAdmin],
    options: { serviceType: serviceType, testId: 'C53505' },
  },
  {
    run: canAddAndEditAdditionalIds,
    priority: 3,
    suite: Suites.ui,
    roles: [UserRoles.globalAdmin, UserRoles.cancerCareAdmin],
    options: { serviceType: serviceType, testId: 'C53506' },
  },
]

describe(`${Cypress.env('env').toUpperCase()} - Patient Profile - Hospital Service`, () => {
  setupSnapshots('hospital')

  before(() => {
    setupTestState()
  })

  determineTestsAndRun(allTestCases)
})
