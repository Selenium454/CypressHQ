import { ServiceTypesList, AllTestCases, Suites, UserRoles } from '@support/types'
import { setupTestState, determineTestsAndRun } from '@support/functions'

import {
  canCancelServiceCreationOnProfile,
  canAddAndEditHealthFundInfo,
  canSetServiceToInactiveThenActive,
  canSetServiceToArchivedThenActive,
  canAddAndDeleteDoctorWithReferralOnProfile,
  canAddService,
} from '@testcases/patientProfile/services'
import { setupSnapshots } from '@support/commands'

const serviceType = ServiceTypesList.AgedCare

const allTestCases: AllTestCases[] = [
  {
    run: canCancelServiceCreationOnProfile,
    priority: 3,
    suite: Suites.ui,
    roles: [
      UserRoles.pharmacist,
      UserRoles.pharmacyAdmin,
      UserRoles.pharmacyTechnician,
      UserRoles.corporateAdmin,
      UserRoles.globalAdmin,
    ],
    options: { serviceType: serviceType, testId: 'C53519' },
  },
  {
    run: canAddService,
    priority: 1,
    suite: Suites.ui,
    roles: [
      UserRoles.pharmacist,
      UserRoles.pharmacyAdmin,
      UserRoles.pharmacyTechnician,
      UserRoles.corporateAdmin,
      UserRoles.globalAdmin,
    ],
    options: { serviceType: serviceType, canAddMoreThanOneTestId: 'C53520', cannotAddMoreThanOneTestId: 'C53521' },
  },
  {
    run: canAddAndEditHealthFundInfo,
    priority: 3,
    suite: Suites.ui,
    roles: [
      UserRoles.pharmacist,
      UserRoles.pharmacyAdmin,
      UserRoles.pharmacyTechnician,
      UserRoles.corporateAdmin,
      UserRoles.globalAdmin,
    ],
    options: { serviceType: serviceType, testId: 'C53522' },
  },
  {
    run: canSetServiceToInactiveThenActive,
    priority: 2,
    suite: Suites.ui,
    roles: [
      UserRoles.pharmacist,
      UserRoles.pharmacyAdmin,
      UserRoles.pharmacyTechnician,
      UserRoles.corporateAdmin,
      UserRoles.globalAdmin,
    ],
    options: { serviceType: serviceType, testId: 'C53523' },
  },
  {
    run: canSetServiceToArchivedThenActive,
    priority: 3,
    suite: Suites.ui,
    roles: [UserRoles.globalAdmin],
    options: { serviceType: serviceType, testId: 'C53524' },
  },
  {
    run: canAddAndDeleteDoctorWithReferralOnProfile,
    priority: 1,
    suite: Suites.ui,
    roles: [
      UserRoles.pharmacist,
      UserRoles.pharmacyAdmin,
      UserRoles.pharmacyTechnician,
      UserRoles.corporateAdmin,
      UserRoles.globalAdmin,
    ],
    options: { serviceType: serviceType, testId: 'C53526' },
  },
]

describe(`${Cypress.env('env').toUpperCase()} - Patient Profile - Aged Care Service`, () => {
  setupSnapshots('agedCare')

  before(() => {
    setupTestState()
  })

  determineTestsAndRun(allTestCases)
})
