import { ServiceTypesList, AllTestCases, Suites, UserRoles } from '@support/types'
import { setupTestState, determineTestsAndRun } from '@support/functions'

import {
  canViewAdditionalIdsOnService,
  canCancelServiceCreationOnProfile,
  canAddAndEditHealthFundInfo,
  canSetServiceToInactiveThenActive,
  canSetServiceToArchivedThenActive,
  canAddAndEditAdditionalIds,
  canAddService,
} from '@testcases/patientProfile/services'
import { setupSnapshots } from '@support/commands'

const serviceType = ServiceTypesList.WalkIn

const allTestCases: AllTestCases[] = [
  {
    run: canViewAdditionalIdsOnService,
    priority: 4,
    suite: Suites.ui,
    roles: [
      UserRoles.pharmacist,
      UserRoles.pharmacyAdmin,
      UserRoles.pharmacyTechnician,
      UserRoles.cancerCareAdmin,
      UserRoles.corporateAdmin,
      UserRoles.globalAdmin,
      UserRoles.accounts,
    ],
    options: { serviceType: serviceType, testId: 'C53568' },
  },
  {
    run: canCancelServiceCreationOnProfile,
    priority: 3,
    suite: Suites.ui,
    roles: [
      UserRoles.pharmacist,
      UserRoles.pharmacyAdmin,
      UserRoles.pharmacyTechnician,
      UserRoles.corporateAdmin,
      UserRoles.globalAdmin,
    ],
    options: { serviceType: serviceType, testId: 'C53569' },
  },
  {
    run: canAddService,
    priority: 1,
    suite: Suites.ui,
    roles: [
      UserRoles.pharmacist,
      UserRoles.pharmacyAdmin,
      UserRoles.pharmacyTechnician,
      UserRoles.corporateAdmin,
      UserRoles.globalAdmin,
    ],
    options: { serviceType: serviceType, canAddMoreThanOneTestId: 'C53570', cannotAddMoreThanOneTestId: 'C53571' },
  },
  {
    run: canAddAndEditHealthFundInfo,
    priority: 3,
    suite: Suites.ui,
    roles: [
      UserRoles.pharmacist,
      UserRoles.pharmacyAdmin,
      UserRoles.pharmacyTechnician,
      UserRoles.corporateAdmin,
      UserRoles.globalAdmin,
    ],
    options: { serviceType: serviceType, testId: 'C53572' },
  },
  {
    run: canSetServiceToInactiveThenActive,
    priority: 2,
    suite: Suites.ui,
    roles: [
      UserRoles.pharmacist,
      UserRoles.pharmacyAdmin,
      UserRoles.pharmacyTechnician,
      UserRoles.corporateAdmin,
      UserRoles.globalAdmin,
    ],
    options: { serviceType: serviceType, testId: 'C53573' },
  },
  {
    run: canSetServiceToArchivedThenActive,
    priority: 3,
    suite: Suites.ui,
    roles: [UserRoles.globalAdmin],
    options: { serviceType: serviceType, testId: 'C53574' },
  },
  {
    run: canAddAndEditAdditionalIds,
    priority: 2,
    suite: Suites.ui,
    roles: [UserRoles.globalAdmin, UserRoles.cancerCareAdmin],
    options: { serviceType: serviceType, testId: 'C53575' },
  },
]

describe(`${Cypress.env('env').toUpperCase()} - Patient Profile - Walk In Service`, () => {
  setupSnapshots('walkIn')

  before(() => {
    setupTestState()
  })

  determineTestsAndRun(allTestCases)
})
