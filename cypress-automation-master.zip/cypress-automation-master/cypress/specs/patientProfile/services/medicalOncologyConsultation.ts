import { ServiceTypesList, AllTestCases, Suites, UserRoles } from '@support/types'
import { setupTestState, determineTestsAndRun } from '@support/functions'

import {
  canViewAdditionalIdsOnService,
  canCancelServiceCreationOnProfile,
  canAddAndEditHealthFundInfo,
  canSetServiceToInactiveThenActive,
  canSetServiceToArchivedThenActive,
  canAddAndEditAdditionalIds,
  canAddAndDeleteDoctorWithReferralOnProfile,
  visitsAreShownOnService,
  canAddAndEditVisit,
  canAddService,
} from '@testcases/patientProfile/services'
import { setupSnapshots } from '@support/commands'

const serviceType = ServiceTypesList.MedicalOncologyConsultation

const allTestCases: AllTestCases[] = [
  {
    run: canViewAdditionalIdsOnService,
    priority: 4,
    suite: Suites.ui,
    roles: [
      UserRoles.pharmacist,
      UserRoles.pharmacyAdmin,
      UserRoles.pharmacyTechnician,
      UserRoles.cancerCareAdmin,
      UserRoles.corporateAdmin,
      UserRoles.globalAdmin,
      UserRoles.accounts,
    ],
    options: { serviceType: serviceType, testId: 'C53525' },
  },
  {
    run: canCancelServiceCreationOnProfile,
    priority: 3,
    suite: Suites.ui,
    roles: [UserRoles.cancerCareAdmin, UserRoles.corporateAdmin, UserRoles.globalAdmin],
    options: { serviceType: serviceType, testId: 'C53527' },
  },
  {
    run: canAddService,
    priority: 1,
    suite: Suites.ui,
    roles: [UserRoles.cancerCareAdmin, UserRoles.corporateAdmin, UserRoles.globalAdmin],
    options: { serviceType: serviceType, canAddMoreThanOneTestId: 'C53528', cannotAddMoreThanOneTestId: 'C53529' },
  },
  {
    run: canAddAndEditHealthFundInfo,
    priority: 3,
    suite: Suites.ui,
    roles: [UserRoles.cancerCareAdmin, UserRoles.corporateAdmin, UserRoles.globalAdmin],
    options: { serviceType: serviceType, testId: 'C53530' },
  },
  {
    run: canSetServiceToInactiveThenActive,
    priority: 2,
    suite: Suites.ui,
    roles: [UserRoles.cancerCareAdmin, UserRoles.corporateAdmin, UserRoles.globalAdmin],
    options: { serviceType: serviceType, testId: 'C53531' },
  },
  {
    run: canSetServiceToArchivedThenActive,
    priority: 3,
    suite: Suites.ui,
    roles: [UserRoles.globalAdmin],
    options: { serviceType: serviceType, testId: 'C53532' },
  },
  {
    run: canAddAndEditAdditionalIds,
    priority: 1,
    suite: Suites.ui,
    roles: [UserRoles.globalAdmin, UserRoles.cancerCareAdmin],
    options: { serviceType: serviceType, testId: 'C53533' },
  },
  {
    run: canAddAndDeleteDoctorWithReferralOnProfile,
    priority: 1,
    suite: Suites.ui,
    roles: [UserRoles.cancerCareAdmin, UserRoles.corporateAdmin, UserRoles.globalAdmin],
    options: { serviceType: serviceType, testId: 'C53534' },
  },
  {
    run: visitsAreShownOnService,
    priority: 3,
    suite: Suites.ui,
    roles: [
      UserRoles.pharmacist,
      UserRoles.pharmacyAdmin,
      UserRoles.pharmacyTechnician,
      UserRoles.cancerCareAdmin,
      UserRoles.corporateAdmin,
      UserRoles.globalAdmin,
      UserRoles.accounts,
      UserRoles.doctor,
    ],
    options: { serviceType: serviceType, testId: 'C53576' },
  },
  {
    run: canAddAndEditVisit,
    priority: 1,
    suite: Suites.ui,
    roles: [UserRoles.cancerCareAdmin, UserRoles.doctor],
    options: { serviceType: serviceType, testId: 'C53577' },
  },
]

describe(`${Cypress.env('env').toUpperCase()} - Patient Profile - Medical Oncology Consultation Service`, () => {
  setupSnapshots('medicalOncologyConsultation')

  before(() => {
    setupTestState()
  })

  determineTestsAndRun(allTestCases)
})
