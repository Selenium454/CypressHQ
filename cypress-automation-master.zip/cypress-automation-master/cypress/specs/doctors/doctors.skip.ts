import { AllTestCases } from '@support/types'
import { setupSnapshots } from '@support/commands'
import { setupTestState, determineTestsAndRun } from '@support/functions'

const testEnv: string = Cypress.env('env')
const readableEnv: string = testEnv.toUpperCase()

const allTestCases: AllTestCases[] = []

describe(`${readableEnv} - Doctors`, () => {
  setupSnapshots('doctors')

  before(() => {
    setupTestState()
  })

  determineTestsAndRun(allTestCases)
})
