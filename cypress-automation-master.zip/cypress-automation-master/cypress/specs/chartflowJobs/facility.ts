import { AllTestCases, Suites, UserRoles } from '@support/types'

import {
  createFacilityChartJobAndSubmit,
  checkFaciltyChartJobTypes,
  checkFacilityChartJobStatusSubmission,
  checkFacilityChartJobDueTimeSubmission,
  checkGrowlMessagesOnFacilityChartJobCreation,
  checkGrowlMessagesOnFacilityChartJobSubmission,
  checkFacilityChartJobBehavior,
  checkMultipleFacilityChartImages,
} from '@testcases/chartflowJobs/facility'

import { setupTestState, createFacilityViaApi, determineTestsAndRun } from '@support/functions'
import { setupSnapshots } from '@support/commands'

const allTestCases: AllTestCases[] = [
  {
    run: createFacilityChartJobAndSubmit,
    priority: 1,
    suite: Suites.scenarios,
    roles: [UserRoles.pharmacist, UserRoles.pharmacyAdmin, UserRoles.pharmacyTechnician, UserRoles.corporateAdmin],
  },
  {
    run: checkFaciltyChartJobTypes,
    priority: 2,
    suite: Suites.ui,
    roles: [UserRoles.pharmacist, UserRoles.pharmacyAdmin, UserRoles.pharmacyTechnician, UserRoles.corporateAdmin],
  },
  {
    run: checkFacilityChartJobStatusSubmission,
    priority: 2,
    suite: Suites.ui,
    roles: [UserRoles.pharmacist, UserRoles.pharmacyAdmin, UserRoles.pharmacyTechnician, UserRoles.corporateAdmin],
  },
  {
    run: checkFacilityChartJobDueTimeSubmission,
    priority: 3,
    suite: Suites.ui,
    roles: [UserRoles.pharmacist, UserRoles.pharmacyAdmin, UserRoles.pharmacyTechnician, UserRoles.corporateAdmin],
  },
  {
    run: checkGrowlMessagesOnFacilityChartJobCreation,
    priority: 4,
    suite: Suites.ui,
    roles: [UserRoles.pharmacist, UserRoles.pharmacyAdmin, UserRoles.pharmacyTechnician, UserRoles.corporateAdmin],
  },
  {
    run: checkGrowlMessagesOnFacilityChartJobSubmission,
    priority: 4,
    suite: Suites.ui,
    roles: [UserRoles.pharmacist, UserRoles.pharmacyAdmin, UserRoles.pharmacyTechnician, UserRoles.corporateAdmin],
  },
  {
    run: checkFacilityChartJobBehavior,
    priority: 4,
    suite: Suites.ui,
    roles: [UserRoles.pharmacist, UserRoles.pharmacyAdmin, UserRoles.pharmacyTechnician, UserRoles.corporateAdmin],
  },
  {
    run: checkMultipleFacilityChartImages,
    priority: 3,
    suite: Suites.ui,
    roles: [UserRoles.pharmacist, UserRoles.pharmacyAdmin, UserRoles.corporateAdmin],
  },
]

describe(`${Cypress.env('env').toUpperCase()} - Facility Chartflow Jobs`, () => {
  setupSnapshots('facility')

  before(() => {
    setupTestState().then(() => {
      createFacilityViaApi().then($response => {
        cy.writeFile('cypress/fixtures/facility.json', $response)
        cy.task('storeFacilityForDeletion', $response.code)
      })
    })
  })

  determineTestsAndRun(allTestCases)
})
