import { AllTestCases, Suites, UserRoles, ServiceTypesList } from '@support/types'
import {
  ServiceTypes,
  setupTestState,
  determineTestsAndRun,
  createPatientViaApi,
  addServiceToPatientViaApi,
} from '@support/functions'

import {
  createPatientChartJobAndSubmit,
  checkPatientChartJobTypes,
  checkPatientChartJobStatusSubmission,
  checkPatientChartJobDueTimeSubmission,
  checkGrowlMessagesOnPatientChartJobCreation,
  checkGrowlMessagesOnPatientChartJobSubmission,
  checkPatientChartJobBehavior,
  checkMultiplePatientChartImages,
} from '@testcases/chartflowJobs/patient'
import { setupSnapshots } from '@support/commands'

const allTestCases: AllTestCases[] = [
  {
    run: createPatientChartJobAndSubmit,
    priority: 1,
    suite: Suites.scenarios,
    roles: [UserRoles.pharmacist, UserRoles.pharmacyAdmin, UserRoles.pharmacyTechnician, UserRoles.corporateAdmin],
  },
  {
    run: checkPatientChartJobTypes,
    priority: 2,
    suite: Suites.ui,
    roles: [UserRoles.pharmacist, UserRoles.pharmacyAdmin, UserRoles.pharmacyTechnician, UserRoles.corporateAdmin],
  },
  {
    run: checkPatientChartJobStatusSubmission,
    priority: 2,
    suite: Suites.ui,
    roles: [UserRoles.pharmacist, UserRoles.pharmacyAdmin, UserRoles.pharmacyTechnician, UserRoles.corporateAdmin],
  },
  {
    run: checkPatientChartJobDueTimeSubmission,
    priority: 3,
    suite: Suites.ui,
    roles: [UserRoles.pharmacist, UserRoles.pharmacyAdmin, UserRoles.pharmacyTechnician, UserRoles.corporateAdmin],
  },
  {
    run: checkGrowlMessagesOnPatientChartJobCreation,
    priority: 4,
    suite: Suites.ui,
    roles: [UserRoles.pharmacist, UserRoles.pharmacyAdmin, UserRoles.pharmacyTechnician, UserRoles.corporateAdmin],
  },
  {
    run: checkGrowlMessagesOnPatientChartJobSubmission,
    priority: 4,
    suite: Suites.ui,
    roles: [UserRoles.pharmacist, UserRoles.pharmacyAdmin, UserRoles.pharmacyTechnician, UserRoles.corporateAdmin],
  },
  {
    run: checkPatientChartJobBehavior,
    priority: 4,
    suite: Suites.ui,
    roles: [UserRoles.pharmacist, UserRoles.pharmacyAdmin, UserRoles.pharmacyTechnician, UserRoles.corporateAdmin],
  },
  {
    run: checkMultiplePatientChartImages,
    priority: 3,
    suite: Suites.ui,
    roles: [UserRoles.pharmacist, UserRoles.pharmacyAdmin, UserRoles.pharmacyTechnician, UserRoles.corporateAdmin],
  },
]

describe(`${Cypress.env('env').toUpperCase()} - Patient Chartflow Jobs`, function() {
  const serviceDetails = ServiceTypes[ServiceTypesList.Hospital]

  setupSnapshots('patient')

  before(() => {
    setupTestState().then(() => {
      createPatientViaApi().then(patient => {
        cy.wait(1000) //TODO: Replace with redis?

        addServiceToPatientViaApi({
          serviceDetails,
          patient,
        }).then(patient => {
          cy.writeFile('cypress/fixtures/patient.json', patient)
        })

        cy.wait(1000) //Wait for the patient to exist?
      })
    })
  })

  determineTestsAndRun(allTestCases)
})
