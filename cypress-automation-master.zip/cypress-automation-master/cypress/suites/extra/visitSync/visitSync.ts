import { PatientDetails } from 'Interfaces/cypress'
import { VisitsGenerator } from 'Helpers/visits'
import { VisitsAudit } from 'Helpers/audits'
import { Generator } from 'Helpers/general'

describe('Helpers', () => {
  context('Visit Creation', () => {
    it('Sync in a patient visit', () => {
      const trackId = Generator.generateUniqueTrackId()

      const patientDetails: PatientDetails = {
        wardCode: 'chemotherapy',
        facilityCode: 'HOB',
        totalCareId: '1235242',
        doctorProviderNumber: '1635098W', //145363EB: Jane, 156086DY: Itamar
        appointmentNumber: null,
        visitSk: null,
        visitTimeUtc: '2019-11-13T09:00:00Z', //'2019-04-24T05:19:00+00:00'
      }
      const visitModel = VisitsGenerator.generateVisit(patientDetails)

      VisitsAudit.postVisit(trackId, visitModel)
    })
  })
})
