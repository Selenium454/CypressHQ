import { PatientGenerator } from 'Helpers/patients'
import { ServicesGenerator } from 'Helpers/services'
import { Generator } from 'Helpers/general'
import { OnPremiseDiagnostics } from 'Helpers/audits'
import { PatientsApi } from 'Api/patients.api'

describe('Helpers', () => {
  before(() => {
    // cy.logout()
  })

  beforeEach(() => {
    cy.server()

    cy.route({ method: 'POST', url: '**/profile/*/update' }).as('updateService')

    // cy.login(Cypress.env('pharmacyAdminEmail'), Cypress.env('password'))
  })

  context('Patient Creation', () => {
    it('Sync in a patient with a hospital service', () => {
      const customer = new PatientGenerator().generateRegistrationModel()
      const hospitalService = ServicesGenerator.generateHospitalService()
      const trackId = Generator.generateUniqueTrackId()
      customer.patient.services!.push(hospitalService)

      cy.log(customer.surName)

      OnPremiseDiagnostics.syncPatient(customer, trackId)
      // AuditDiagnosticsApi.checkAudit(trackId, 'Hub2Fred', hospitalService.facilityCode).then(response => {
      //   const auditResponse: PlainObject = JSON.parse(response.body.model.auditPatient.payload)
      //   LaravelSchemaLibrary.assertSchema('getFredAudit', '4.0.1')(auditResponse)
      // })
    })
  })
})
