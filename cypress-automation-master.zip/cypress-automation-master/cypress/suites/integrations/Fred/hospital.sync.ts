import { PlainObject } from '@cypress/schema-tools'
import { SyncSchemaLibrary } from 'Schemas/Sync'
import { AuditDiagnostics, PatientsApi, OnPremiseDiagnostics, SearchApi } from 'Support/Api'
import { PatientGenerator, ServicesGenerator, Generator } from 'Support/Generators'
import { prefix } from 'Support/functions'
import { PatientCreationComponent, ServicesComponent } from 'Support/Components'
import { PutPatientDetails420, PostServicesAdd420 } from '@schemas/api'
import { ServiceObjectFull } from 'Interfaces/cypress'

const pharmacyAdminEmail: string = Cypress.env('pharmacyAdminEmail'),
  pharmacyAdminPassword: string = Cypress.env('password'),
  hospitalFacilityCode: string = Cypress.env('hospitalFacilityCode')

const checkFredAudit = (trackId: string, facilityCode: string) => {
  return new Cypress.Promise((resolve, reject) => {
    AuditDiagnostics.checkAudit(trackId, 'Hub2Fred', facilityCode).then($response => {
      const auditResponse: PlainObject = JSON.parse($response.body[0].payload)
      SyncSchemaLibrary.assertSchema('getFredAudit', '4.0.1')(auditResponse)

      const sanitised = SyncSchemaLibrary.sanitize('getFredAudit', '4.0.1')(auditResponse)
      try {
        resolve(sanitised)
      } catch {
        reject('Failed to sanitise object')
      }
    })
  })
}

describe('Fred - Hospital Service', () => {
  before(() => {
    cy.logout().then(() => {
      cy.login(pharmacyAdminEmail, pharmacyAdminPassword)
    })
  })

  beforeEach(() => {
    cy.server()

    cy.route({ method: 'POST', url: '**/customer/create' }).as('createCustomer')

    cy.route({ method: 'POST', url: '**/profile/*/details' }).as('updateCustomer')

    cy.route({ method: 'POST', url: '**/profile/*/add/**' }).as('addService')

    cy.route({ method: 'POST', url: '**/profile/*/update' }).as('updateService')
  })

  context('Sync', () => {
    it('Sync in a hospital patient then set service to inactive and check Fred', () => {
      const customer = PatientGenerator.generatePatient()
      const hospitalService = ServicesGenerator.generateHospitalService()
      const trackId = Generator.generateUniqueTrackId()
      const hospitalPatient = PatientsApi.generatePatientJson(customer, hospitalService)

      OnPremiseDiagnostics.syncPatient(hospitalPatient, trackId)

      cy.log(
        `Generated Surname: ${customer.surName}; TrackID: ${trackId}; Audit Type: 'Hub2Fred'; Facility Code: ${hospitalService.facilityCode}`
      )

      checkFredAudit(trackId, hospitalService.facilityCode).then(sanitised => {
        cy.wrap(sanitised).snapshot({ name: 'Check new patient sent to Fred' })
      })

      SearchApi.searchByName(hospitalPatient.surName).then(response => {
        hospitalPatient.customerNumber = response.model[0].userId
        cy.visit('/customer/profile/' + hospitalPatient.customerNumber + '/details#/services')
      })

      cy.get(epicHdId('item-admission-SJGM')).click()

      cy.get(epicHdId('service-state-container'))
        .find('[value="inactive"]')
        .should('be.visible')
        .click()

      cy epicSelect({
        container: prefix('dialog-container'),
        inputLocator: '[name="inactiveReasons-select-input-wide"]',
        dropdownLocator: '.el-popper.inactiveReasons-select-dropdown-wide',
        option: 'Discharged',
      })

      cy.get(epicHdId('button-save-service')).click()

      cy.wait('@updateService').then($response => {
        const trackId = $response.responseHeaders['x-hub-trackid']

        checkFredAudit(trackId, hospitalService.facilityCode).then(sanitised => {
          cy.wrap(sanitised).snapshot({ name: 'Check patient update is sent to fred as inactive' })
        })
      })
    })
  })

  context('Manual', () => {
    it('Create a hospital patient manually then set service to inactive and check Fred', () => {
      const customer = PatientGenerator.generatePatient()
      let customerNumber
      customer.supportingInformation.medicareNumber = null

      cy.visit('/customer/create#/')

      cy.get(epicHdId('dialog-container')).within(() => {
        cy.contains('Yes, I have').click()
      })

      cy.get(epicHdId('dialog-container')).should('not.exist')

      PatientCreationComponent.fillAllPersonalDetails(customer)

      cy.contains('Create & Next').click()

      cy.wait('@createCustomer').then($response => {
        const options = {
          request: $response.requestBody as PutPatientDetails420,
          snapshotName: 'Send Create Patient',
        }
        PatientCreationComponent.checkPutPatientDetails(options)
      })

      cy.get(epicHdId('button-add-service'))
        .click()
        .get(epicHdId('dialog-container'))
        .within(() => {
          ServicesComponent.createService('hospital')
        })
        .get(epicHdId('button-use-urn'))
        .click()
        .get(epicHdId('button-create-service'))
        .scrollIntoView()
        .should('be.visible')
        .click()

      cy.wait('@addService').then($response => {
        const trackId = $response.responseHeaders['x-hub-trackid']

        const { service: request } = $response.requestBody as ServiceObjectFull
        const options = {
          request: request as PostServicesAdd420,
          snapshotName: 'Post hospital service creation',
        }
        PatientCreationComponent.checkPostServicesAdd(options)

        checkFredAudit(trackId, hospitalFacilityCode).then(sanitised => {
          cy.wrap(sanitised).snapshot({ name: 'Check patient is sent to Fred' })
        })
      })

      SearchApi.searchByName(customer.surName).then(response => {
        customerNumber = response.model[0].userId
        cy.visit('/customer/profile/' + customerNumber + '/details#/services')
      })

      cy.get(epicHdId('item-admission-SJGM')).click()

      cy.get(epicHdId('service-state-container'))
        .find('[value="inactive"]')
        .should('be.visible')
        .click()

      cy epicSelect({
        container: prefix('dialog-container'),
        inputLocator: '[name="inactiveReasons-select-input-wide"]',
        dropdownLocator: '.el-popper.inactiveReasons-select-dropdown-wide',
        option: 'Discharged',
      })

      cy.get(epicHdId('button-save-service')).click()

      cy.wait('@updateService').then($response => {
        const trackId = $response.responseHeaders['x-hub-trackid']

        checkFredAudit(trackId, hospitalFacilityCode).then(sanitised => {
          cy.wrap(sanitised).snapshot({ name: 'Check patient update is sent to fred as inactive' })
        })
      })
    })

    it('Sync a Hospital patient in, update all details and then check they update correctly', () => {
      const customer = PatientGenerator.generatePatient()
      const hospitalService = ServicesGenerator.generateHospitalService()
      const trackId = Generator.generateUniqueTrackId()
      const hospitalPatient = PatientsApi.generatePatientJson(customer, hospitalService)

      cy.log(`Generated Surname: ${customer.surName}`)
      cy.wrap(customer).then($customer => {
        cy.log('Initial customer object')
      })

      OnPremiseDiagnostics.syncPatient(hospitalPatient, trackId)

      cy.log(`TrackID: ${trackId}; Audit Type: 'Hub2Fred'; Facility Code: ${hospitalService.facilityCode}`)

      checkFredAudit(trackId, hospitalService.facilityCode).then(sanitised => {
        cy.wrap(sanitised).snapshot({ name: 'Create patient' })
      })

      SearchApi.searchByName(hospitalPatient.surName).then(response => {
        hospitalPatient.customerNumber = response.model[0].userId
        cy.visit('/customer/profile/' + hospitalPatient.customerNumber + '/details#/services')
      })

      cy.contains('a', 'Details').click()

      cy.contains('a', 'Edit').click()

      const newCustomer = PatientGenerator.generatePatient()
      newCustomer.supportingInformation.medicareNumber = null

      PatientCreationComponent.fillAllPersonalDetails(newCustomer)

      cy.get('#medicare-number').clear()

      cy.contains('.btn', 'Save').click()

      cy.wait('@updateCustomer').then($response => {
        const trackId = $response.responseHeaders['x-hub-trackid']

        checkFredAudit(trackId, hospitalService.facilityCode).then(sanitised => {
          cy.wrap(sanitised).snapshot({ name: 'Check patient update is sent to fred with new details' })
        })

        cy.log(`New Generated Surname: ${newCustomer.surName}`)
        cy.wrap(newCustomer).then($newCustomer => {
          cy.log('Customer update object')
        })
      })
    })
  })
})
