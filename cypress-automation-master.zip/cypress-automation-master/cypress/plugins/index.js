// ***********************************************************
// This example plugins/index.js can be used to load plugins
//
// You can change the location of this file or turn off loading
// the plugins file with the 'pluginsFile' configuration option.
//
// You can read more here:
// https://on.cypress.io/plugins-guide
// ***********************************************************

// This function is called when a project is opened or re-opened (e.g. due to
// the project's config changing)

// promisified fs module
const path = require('path')
const fs = require('fs-extra')
const wp = require('@cypress/webpack-preprocessor')
const istanbul = require('istanbul-lib-coverage')
const { join } = require('path')
const { existsSync, mkdirSync, readFileSync, writeFileSync } = fs
const execa = require('execa')
const run = require('gulp-run-command')
const { fixSourcePathes } = require('@cypress/code-coverage/utils')

const debug = require('debug')('code-coverage')

// these are standard folder and file names used by NYC tools
const processWorkingDirectory = path.resolve(process.cwd(), '../..')
const outputFolder = '.nyc_output'
const coverageFolder = join(processWorkingDirectory, outputFolder)
const nycFilename = join(coverageFolder, 'out.json')

// there might be custom "nyc" options in the user package.json
// see https://github.com/istanbuljs/nyc#configuring-nyc
// potentially there might be "nyc" options in other configuration files
// it allows, but for now ignore those options
const pkgFilename = join(processWorkingDirectory, 'package.json')
const pkg = fs.existsSync(pkgFilename) ? JSON.parse(fs.readFileSync(pkgFilename, 'utf8')) : {}
const nycOptions = pkg.nyc || {}

const baseData = { userIds: [], facilities: [] }

function getLoggedUser() {
  if (fs.existsSync('cypress/fixtures/loggedUser.json')) {
    const loggedUser = JSON.parse(data)
    return loggedUser
  } else {
    return false
  }
}

function getStoredData() {
  if (fs.existsSync('cypress/fixtures/dataForDeletion.json')) {
    const data = fs.readFileSync('cypress/fixtures/dataForDeletion.json')

    try {
      const storedData = JSON.parse(data)
      return storedData
    } catch (err) {
      console.log('There has been an error.')
      console.log(err)
      return
    }
  } else {
    let data = baseData
    storeData(data)
    return data
  }
}

function storeData(data) {
  data = JSON.stringify(data)
  fs.writeFile('cypress/fixtures/dataForDeletion.json', data, function(err) {
    if (err) {
      console.log('Failed to store datas')
      console.log(err.message)
      return
    }
  })
}

function getConfigurationByFile(file) {
  const pathToConfigFile = path.resolve('.', 'cypress/config', `cypress.${file}.json`)
  return fs.readJson(pathToConfigFile)
}

function saveCoverage(coverage) {
  if (!existsSync(coverageFolder)) {
    mkdirSync(coverageFolder)
    debug('created folder %s for output coverage', coverageFolder)
  }

  writeFileSync(nycFilename, JSON.stringify(coverage, null, 2))
}

module.exports = (on, config) => {
  const options = {
    webpackOptions: require('../../webpack.config'),
  }

  on('file:preprocessor', wp(options))

  on('task', {
    readFileMaybe(filename) {
      if (fs.existsSync(filename)) {
        return fs.readFileSync(filename, 'utf8')
      }
      return null
    },

    storeUserIdForDeletion(userId) {
      let data = getStoredData()
      let userIds = data.userIds
      userIds.push(userId)
      data.userIds = userIds
      storeData(data)

      return null
    },

    storeFacilityForDeletion(facilityCode) {
      let data = getStoredData()
      let facilities = data.facilities
      facilities.push(facilityCode)
      data.facilities = facilities
      storeData(data)

      return null
    },

    getDataForDeletion() {
      return getStoredData()
    },

    resetDataForDeletion() {
      let data = baseData
      storeData(data)

      return null
    },

    getLoggedUser() {
      return getLoggedUser()
    },
  })

  on('task', {
    /**
     * Clears accumulated code coverage information.
     *
     * Interactive mode with "cypress open"
     *    - running a single spec or "Run all specs" needs to reset coverage
     * Headless mode with "cypress run"
     *    - runs EACH spec separately, so we cannot reset the coverage
     *      or we will lose the coverage from previous specs.
     */
    resetCoverage({ isInteractive }) {
      if (isInteractive) {
        debug('reset code coverage in interactive mode')
        const coverageMap = istanbul.createCoverageMap({})
        saveCoverage(coverageMap)
      }
      /*
          Else:
            in headless mode, assume the coverage file was deleted
            before the `cypress run` command was called
            example: rm -rf .nyc_output || true
        */

      return null
    },

    /**
     * Combines coverage information from single test
     * with previously collected coverage.
     */
    combineCoverage(coverage) {
      fixSourcePathes(coverage)
      const previous = existsSync(nycFilename) ? JSON.parse(readFileSync(nycFilename)) : istanbul.createCoverageMap({})
      const coverageMap = istanbul.createCoverageMap(previous)
      coverageMap.merge(coverage)
      saveCoverage(coverageMap)
      debug('wrote coverage file %s', nycFilename)

      return null
    },

    /**
     * Saves coverage information as a JSON file and calls
     * NPM script to generate HTML report
     */
    coverageReport() {
      if (!existsSync(nycFilename)) {
        console.warn('Cannot find coverage file %s', nycFilename)
        // console.warn('Skipping coverage report')
        return null
      }

      // const reportDir = nycOptions['report-dir'] || `.coverage`
      // const reporter = nycOptions['reporter'] || ['lcov']
      // const reporters = Array.isArray(reporter) ? reporter.map(name => `--reporter=${name}`) : `--reporter=${reporter}`
      //
      // // should we generate report via NYC module API?
      // const command = 'nyc'
      // const args = ['--cwd', '../../', 'report', '--report-dir', reportDir, '--temp-dir', coverageFolder].concat(
      //   reporters
      // )
      // debug('saving coverage report using command: "%s %s"', command, args.join(' '))
      // debug('current working directory is %s', process.cwd())
      // return execa(command, args, { stdio: 'inherit' })
      return null
    },
  })

  const file = config.env.configFile || 'dev'
  return getConfigurationByFile(file)
}
