export const setupAdmissionRoutes = () => {
  cy.route({ method: 'GET', url: '**/admission/generateAdmissionNumber' }).as('getAdmissionGenerateAdmissionNumber')
  cy.route({ method: 'GET', url: '**/admission/document' }).as('getAdmissionDocument')
  cy.route({ method: 'GET', url: '**/admission/current' }).as('getAdmissionCurrent')
  cy.route({ method: 'GET', url: '**/admission/recentFacility' }).as('getAdmissionRecentFacility')
  cy.route({ method: 'GET', url: '**/admission/recent' }).as('getAdmissionRecent')
  cy.route({ method: 'PUT', url: '**/admission/update' }).as('putAdmissionUpdate')
}
