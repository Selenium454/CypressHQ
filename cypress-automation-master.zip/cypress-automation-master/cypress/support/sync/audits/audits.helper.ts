import { RegistrationModelLatest } from '@schemas/api/models/registrationModel.models.webApi.cloudServices'

export class AuditDiagnostics {
  /**
   * Checks for an audit entry based on trackID, application (i.e. Hub2Fred), and facility code.
   */
  public static checkAudit = (trackId: string, application: string, facilityCode: string): Cypress.Chainable => {
    let counter: number = 0,
      $request

    const maxCounter: number = 50,
      successStatus: number = 200

    const getAudit = (() => {
      const url = encodeURI(
        `http://localhost:9000/PatientAudit/outbound?trackId=${trackId}&applicationName=${application}&facilityCode=${facilityCode}`
      )

      const requestBody: Partial<Cypress.RequestOptions> = {
        method: 'GET',
        url,
        headers: {
          'Content-Type': 'application/json',
        },
        failOnStatusCode: false,
      }

      $request = cy.request(requestBody).then(response => {
        if (response.status !== successStatus) {
          if (counter < maxCounter) {
            counter += 1
            cy.wait(1000, { log: false })
            getAudit
          } else {
            throw new Error('Not Found')
          }
        } else {
          return
        }
      })
    })()
    return $request
  }
}

export class OnPremiseDiagnostics {
  /**
   * Syncs a new patient into Health Director.
   */
  public static syncPatient = (json: RegistrationModelLatest, trackId: string): Cypress.Chainable => {
    const url = encodeURI(`http://localhost:9000/Patty/SyncPatient?trackId=${trackId}`)
    const requestBody: Partial<Cypress.RequestOptions> = {
      method: 'PUT',
      url,
      headers: {
        'Content-Type': 'application/json',
      },
      body: json,
    }

    return cy.request(requestBody).then(response => {
      return response
    })
  }
}

export class VisitDiagnostics {
  /**
   * Sync in a new visit usign Sam's endpoints.
   */
  public static postVisit = (trackId: string, visitModel: VisitModelSync): Cypress.Chainable => {
    let counter: number = 0,
      $request

    const maxCounter: number = 50,
      successStatus: number = 200

    const getAudit = (() => {
      const url = encodeURI(`http://localhost:9000/VisitsAudit?trackId=${trackId}`)

      const requestBody: Partial<Cypress.RequestOptions> = {
        method: 'POST',
        url,
        headers: {
          'Content-Type': 'application/json',
        },
        body: visitModel,
      }

      $request = cy.request(requestBody).then(response => {
        if (response.status !== successStatus) {
          if (counter < maxCounter) {
            counter += 1
            cy.wait(1000)
            getAudit
          } else {
            throw new Error('Not Found')
          }
        } else {
          return
        }
      })
    })()
    return $request
  }
}
