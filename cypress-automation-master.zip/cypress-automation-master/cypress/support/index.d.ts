/// <reference types="cypress" />
import { FillField } from 'Interfaces/cypress'

declare namespace Cypress {
  interface Chainable<Subject> {
    /**
     * Logs into Health Director with the given email and password.
     * @param {string} email The email to log in with
     * @param {string} password The password to log in with
     */
    login(email: string, password: string): Chainable

    /**
     * Logs out of Health Director.
     */
    logout(): Chainable
  }
}
