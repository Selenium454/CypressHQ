import * as faker from 'faker/locale/en_AU'
import { UserRoles, RouteDetails, AllTestCases, GeneratedAddress, DatesObject, Suites } from '@support/types'
import { authenticateWithMicrosoft } from '@support/api'

export const suite: string = Cypress.env('suite')
export const priority: number = Cypress.env('priority')
export const role: UserRoles = Cypress.env('role')
export const globalAdminEmail = Cypress.env('globalAdminEmail')
export const adminPassword = Cypress.env('adminPassword')
export class FunctionsClass {}

export const setupRoutes = (routes: RouteDetails[]) => {
  routes.forEach(routeDetails => {
    cy.route({ method: routeDetails.method, url: routeDetails.url }).as(routeDetails.alias)
  })
}

export const generateGlobalAdminToken = () => {
  if (Cypress.env('GA_ACCESS_TOKEN')) {
    return cy
  } else {
    return authenticateWithMicrosoft(globalAdminEmail, adminPassword).then((response: any) => {
      Cypress.env('GA_ACCESS_TOKEN', response)
    })
  }
}

export const userRoleIsOneOf = (array: UserRoles[]): boolean => {
  return array.includes(Cypress.env('role'))
}

export const userRoleIsSpecified = () => {
  return Cypress.env('role') != undefined
}

export const epicHdId = (dataAttribute: string): string => {
  return `[epic-hd-id="${dataAttribute}"]`
}

/**
 * Converts the first letter of a string to upper case.
 */
export const capitaliseFirstLetter = (givenString: string) => {
  return givenString.charAt(0).toUpperCase() + givenString.slice(1)
}

export const determineTestsAndRun = (allTestCases: AllTestCases[]): void => {
  let filteredTestCases = allTestCases.filter(testCase => testCase.priority <= priority)
  if (suite) filteredTestCases = filteredTestCases.filter(testCase => testCase.suite === suite)
  if (role) filteredTestCases = filteredTestCases.filter(testCase => Object.values(testCase.roles).includes(role))

  let scenarioTests = filteredTestCases.filter(testCase => testCase.suite === Suites.scenarios)
  let regressionTests = filteredTestCases.filter(testCase => testCase.suite === Suites.regression)
  let integrationTests = filteredTestCases.filter(testCase => testCase.suite === Suites.integration)
  let uiTests = filteredTestCases.filter(testCase => testCase.suite === Suites.ui)

  if (scenarioTests.length > 0) {
    context('Scenario Test Cases', () => {
      scenarioTests.forEach((testCase: any) => {
        testCase.options ? testCase.run(testCase.options) : testCase.run()
      })
    })
  }

  if (regressionTests.length > 0) {
    context('Regression Test Cases', () => {
      regressionTests.forEach((testCase: any) => {
        testCase.options ? testCase.run(testCase.options) : testCase.run()
      })
    })
  }

  if (uiTests.length > 0) {
    context('UI Test Cases', () => {
      uiTests.forEach((testCase: any) => {
        testCase.options ? testCase.run(testCase.options) : testCase.run()
      })
    })
  }

  if (integrationTests.length > 0) {
    context('Integrations Test Cases', () => {
      integrationTests.forEach((testCase: any) => {
        testCase.options ? testCase.run(testCase.options) : testCase.run()
      })
    })
  }
}

export const setupTestState = () => {
  return generateGlobalAdminToken().then(() => {
    cy.cleanCreatedData()

    cy.clearCookie('logged_role')
  })
}

export const generateAddressModel = (): GeneratedAddress => {
  return {
    street: `${generateNumbers(2).toString()} ${faker.address.streetName().substring(0, 19)}`,
    secondaryStreet: `${generateNumbers(2).toString()} ${faker.address.streetName()}`,
    suburb: faker.address.city().substring(0, 18),
    state: 'Queensland',
    postCode: generateNumbers(4).toString(),
  }
}
/**
 * Generates a number of given digits. I.e. A 4 digit number would be 1234.
 */
export const generateNumbers = (count: number): number => {
  let min = 1
  let max = 9
  let multiplier = Math.pow(10, count - 1)

  min = min * multiplier
  max = max * multiplier + max

  let numbers = Math.floor(Math.random() * (max - min + 1)) + min
  return numbers
}

/**
 * Generates a unique track Id based on a random uuid.
 */
export const generateUniqueTrackId = (): string => {
  return 'QA' + faker.random.uuid().replace(/-/g, '')
}

/**
 * Generates an object containing two variables, 'from' and 'till', and populates them with the date yesterday and the date tomorrow in 'YYYY-MM-DDTHH:mm:ss' format.
 */
export const generateDates = (): DatesObject => {
  const from = Cypress.moment()
    .subtract(1, 'days')
    .format('YYYY-MM-DDTHH:mm:ss')

  const till = Cypress.moment()
    .add(1, 'days')
    .format('YYYY-MM-DDTHH:mm:ss')

  return { from, till }
}

/**
 * Generates a string with a givin number of digits. I.e. A 4 digit string would return as 'abcd'.
 */
export const generateLetters = (count: number): string => {
  let letters: string = '',
    i: number = 0

  while (i <= count) {
    letters =
      letters +
      faker.random.arrayElement([
        'a',
        'b',
        'c',
        'd',
        'e',
        'd',
        'e',
        'f',
        'g',
        'h',
        'i',
        'j',
        'k',
        'l',
        'm',
        'n',
        'o',
        'p',
        'q',
        'r',
        's',
        't',
        'u',
        'v',
        'w',
        'x',
        'y',
        'z',
      ])
    i += 1
  }
  return letters
}
