import { PostAdministrationAddFacilityRequestLatest } from '@schemas/api/endpoints/administration/addFacility.post'

import { generateAddressModel, generateLetters } from './general.functions'
import { AdministrationRoutes } from '@support/api'

/**
 * Generates a facility object for API use.
 */
export const generateFacilityModel = (): PostAdministrationAddFacilityRequestLatest => {
  const address = generateAddressModel()
  return {
    address: address,
    businessUnitId: '9002',
    pharmacyName: 'Cypress',
    code: `QA${generateLetters(5)}`,
    doctors: [],
    emails: [],
    name: `Automated Facility - ${generateLetters(4)}`,
    rounds: [{ externalRoundCodes: [], roundCode: 'AAAA', roundName: 'Unknown' }],
    identifiers: [{ mrNumber: null }],
    integrations: [
      { systemType: 'aria', enable: false },
      { systemType: 'ax', enable: false },
      { systemType: 'careRight', enable: false },
      { systemType: 'charm', enable: false },
      { systemType: 'fred', enable: false },
    ],
    facilityType: 'hospital',
    serviceTypes: ['admission'],
  }
}

export const createFacilityViaApi = () => {
  const facility = generateFacilityModel()

  return AdministrationRoutes.PostAdministrationAddFacility.request({ body: facility }).then(() => {
    return facility
  })
}
