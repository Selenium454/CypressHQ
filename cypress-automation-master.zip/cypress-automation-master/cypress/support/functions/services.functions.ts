import * as faker from 'faker/locale/en_AU'
import { MedicalServiceLatest } from '@schemas/api/models/medicalService.cloud.models.core'
import { generateNumbers } from './general.functions'
import { ServiceTypesList, ServiceDetails } from '@support/types'
import { RegistrationModelLatest } from '@schemas/api/models/registrationModel.models.webApi.cloudServices'
import { ServicesRoutes } from '@support/api'
import { PostServicesAddResponseLatest } from '@schemas/api/endpoints/services/add.post'

/**
 * Generates an aged care service object.
 */
export const generateAgedCareService = (): MedicalServiceLatest => {
  return {
    authorizationFormUrl: '',
    facilityType: 'agedCare',
    serviceType: 'agedCare',
    businessUnitId: '72',
    facilityName: 'Regis Yeronga',
    facilityCode: 'YERO',
    wardName: 'Ibis House',
    wardCode: 'YEIB',
    roomNumber: '27',
    bedNumber: '4',
    serviceStatus: 'active',
    statusChangedToInactive: false,
    doctors: [],
    inactiveServiceReason: 'none',
    inactiveServiceOtherReason: '',
    added: null,
    updated: null,
    synced: null,
    identifiers: [],
  }
}

/**
 * Generates a hospital service object.
 */
export const generateHospitalService = (): MedicalServiceLatest => {
  const urNumber: string = '90' + generateNumbers(6).toString()

  return {
    facilityType: 'hospital',
    serviceType: 'admission',
    businessUnitId: Cypress.env('hospitalPharmacyId'),
    facilityName: Cypress.env('hospitalFacilityName'),
    facilityCode: Cypress.env('hospitalFacilityCode'),
    wardName: Cypress.env('hospitalFacilityWardName'),
    wardCode: Cypress.env('hospitalFacilityWardCode'),
    roomNumber: '42',
    bedNumber: '7',
    urNumber,
    serviceStatus: 'active',
    healthFund: {
      id: faker.random.arrayElement(['BDHI', 'CBC', 'ESH', 'BUP']),
      coverLevel: 'TOP',
      expiryDate: Cypress.moment()
        .add(5, 'days')
        .format('YYYY-MM-DDTHH:mm:ss.SSSSZ'),
      membershipNumber: generateNumbers(6).toString(),
    },
    statusChangedToInactive: false,
  }
}

/**
 * Generates a medical oncology consultation service object.
 */
export const generateMedicalOncologyConsultationService = (): MedicalServiceLatest => {
  return {
    facilityType: 'cancerCare',
    serviceType: 'chemotherapyConsultation',
    businessUnitId: Cypress.env('cancerCarePharmacyId'),
    facilityName: Cypress.env('cancerCareFacilityName'),
    facilityCode: Cypress.env('cancerCareFacilityCode'),
    wardName: Cypress.env('cancerCareFacilityWardName'),
    wardCode: Cypress.env('cancerCareFacilityWardCode'),
    serviceStatus: 'active',
    healthFund: {
      id: faker.random.arrayElement(['HCF', 'CBC', 'ESH']),
      coverLevel: 'TOP',
      expiryDate: Cypress.moment()
        .add(5, 'days')
        .format('YYYY-MM-DDTHH:mm:ss.SSSSZ'),
      membershipNumber: generateNumbers(6).toString(),
    },
    statusChangedToInactive: false,
  }
}

/**
 * Generates a medical oncology treatment service object.
 */
export const generateMedicalOncologyTreatmentService = (): MedicalServiceLatest => {
  return {
    facilityType: 'cancerCare',
    serviceType: 'chemotherapy',
    businessUnitId: Cypress.env('cancerCarePharmacyId'),
    facilityName: Cypress.env('cancerCareFacilityName'),
    facilityCode: Cypress.env('cancerCareFacilityCode'),
    wardName: Cypress.env('cancerCareFacilityWardName'),
    wardCode: Cypress.env('cancerCareFacilityWardCode'),
    serviceStatus: 'active',
    healthFund: {
      id: faker.random.arrayElement(['HCF', 'CBC', 'ESH']),
      coverLevel: 'TOP',
      expiryDate: Cypress.moment()
        .add(5, 'days')
        .format('YYYY-MM-DDTHH:mm:ss.SSSSZ'),
      membershipNumber: generateNumbers(6).toString(),
    },
    statusChangedToInactive: false,
  }
}

/**
 * Generates a radiation oncology consultation service object.
 */
export const generateRadiationOncologyConsultationService = (): MedicalServiceLatest => {
  return {
    facilityType: 'cancerCare',
    serviceType: 'radiationOncologyConsultation',
    businessUnitId: Cypress.env('cancerCarePharmacyId'),
    facilityName: Cypress.env('cancerCareFacilityName'),
    facilityCode: Cypress.env('cancerCareFacilityCode'),
    wardName: Cypress.env('cancerCareFacilityWardName'),
    wardCode: Cypress.env('cancerCareFacilityWardCode'),
    serviceStatus: 'active',
    healthFund: {
      id: faker.random.arrayElement(['HCF', 'CBC', 'ESH']),
      coverLevel: 'TOP',
      expiryDate: Cypress.moment()
        .add(5, 'days')
        .format('YYYY-MM-DDTHH:mm:ss.SSSSZ'),
      membershipNumber: generateNumbers(6).toString(),
    },
    statusChangedToInactive: false,
  }
}

/**
 * Generates a radiation oncology treatment service object.
 */
export const generateRadiationOncologyTreatmentService = (): MedicalServiceLatest => {
  return {
    facilityType: 'cancerCare',
    serviceType: 'radiationOncology',
    businessUnitId: Cypress.env('cancerCarePharmacyId'),
    facilityName: Cypress.env('cancerCareFacilityName'),
    facilityCode: Cypress.env('cancerCareFacilityCode'),
    wardName: Cypress.env('cancerCareFacilityWardName'),
    wardCode: Cypress.env('cancerCareFacilityWardCode'),
    serviceStatus: 'active',
    healthFund: {
      id: faker.random.arrayElement(['HCF', 'CBC', 'ESH']),
      coverLevel: 'TOP',
      expiryDate: Cypress.moment()
        .add(5, 'days')
        .format('YYYY-MM-DDTHH:mm:ss.SSSSZ'),
      membershipNumber: generateNumbers(6).toString(),
    },
    statusChangedToInactive: false,
  }
}

/**
 * Generates a walk in service object.
 */
export const generateWalkInService = (): MedicalServiceLatest => {
  const urNumber: string = '90' + generateNumbers(6).toString()

  return {
    facilityType: 'hospital',
    serviceType: 'walkin',
    businessUnitId: Cypress.env('hospitalPharmacyId'),
    facilityName: Cypress.env('hospitalFacilityName'),
    facilityCode: Cypress.env('hospitalFacilityCode'),
    wardName: Cypress.env('hospitalFacilityWardName'),
    wardCode: Cypress.env('hospitalFacilityWardCode'),
    roomNumber: '42',
    bedNumber: '7',
    urNumber,
    serviceStatus: 'active',
    healthFund: {
      id: faker.random.arrayElement(['BDHI', 'CBC', 'ESH', 'BUP']),
      coverLevel: 'TOP',
      expiryDate: Cypress.moment()
        .add(5, 'days')
        .format('YYYY-MM-DDTHH:mm:ss.SSSSZ'),
      membershipNumber: generateNumbers(6).toString(),
    },
    statusChangedToInactive: false,
  }
}

/**
 * Dictionary of service types.
 */
export const ServiceTypes: { [serviceType: string]: ServiceDetails } = Object.freeze({
  [ServiceTypesList.Hospital]: {
    serviceName: 'Hospital',
    type: ServiceTypesList.Hospital,
    facilityName: Cypress.env('hospitalFacilityName'),
    wardName: Cypress.env('hospitalFacilityWardName'),
    serviceGenerator: generateHospitalService,
  },
  [ServiceTypesList.HospitalAlt]: {
    serviceName: 'Hospital',
    type: ServiceTypesList.HospitalAlt,
    facilityName: Cypress.env('hospitalAltFacilityName'),
    wardName: Cypress.env('hospitalAltFacilityWardName'),
    serviceGenerator: generateHospitalService,
  },
  [ServiceTypesList.WalkIn]: {
    serviceName: 'Walk In',
    type: ServiceTypesList.WalkIn,
    facilityName: Cypress.env('hospitalFacilityName'),
    wardName: Cypress.env('hospitalFacilityWardName'),
    serviceGenerator: generateWalkInService,
  },
  [ServiceTypesList.WalkInAlt]: {
    serviceName: 'Walk In',
    type: ServiceTypesList.WalkInAlt,
    facilityName: Cypress.env('hospitalAltFacilityName'),
    wardName: Cypress.env('hospitalAltFacilityWardName'),
    serviceGenerator: generateWalkInService,
  },
  [ServiceTypesList.AgedCare]: {
    serviceName: 'Aged Care',
    type: ServiceTypesList.AgedCare,
    facilityName: Cypress.env('agedCareFacilityName'),
    wardName: Cypress.env('agedCareFacilityWardName'),
    serviceGenerator: generateAgedCareService,
  },
  [ServiceTypesList.AgedCareAlt]: {
    serviceName: 'Aged Care',
    type: ServiceTypesList.AgedCareAlt,
    facilityName: Cypress.env('agedCareAltFacilityName'),
    wardName: Cypress.env('agedCareAltFacilityWardName'),
    serviceGenerator: generateAgedCareService,
  },
  [ServiceTypesList.MedicalOncologyConsultation]: {
    serviceName: 'Medical Oncology Consultation',
    type: ServiceTypesList.MedicalOncologyConsultation,
    facilityName: Cypress.env('cancerCareFacilityName'),
    wardName: Cypress.env('cancerCareFacilityWardName'),
    serviceGenerator: generateMedicalOncologyConsultationService,
  },
  [ServiceTypesList.MedicalOncologyConsultationAlt]: {
    serviceName: 'Medical Oncology Consultation',
    type: ServiceTypesList.MedicalOncologyConsultationAlt,
    facilityName: Cypress.env('cancerCareAltFacilityName'),
    wardName: Cypress.env('cancerCareAltFacilityWardName'),
    serviceGenerator: generateMedicalOncologyConsultationService,
  },
  [ServiceTypesList.MedicalOncologyTreatment]: {
    serviceName: 'Medical Oncology Treatment',
    type: ServiceTypesList.MedicalOncologyTreatment,
    facilityName: Cypress.env('cancerCareFacilityName'),
    wardName: Cypress.env('cancerCareFacilityWardName'),
    serviceGenerator: generateMedicalOncologyTreatmentService,
  },
  [ServiceTypesList.MedicalOncologyTreatmentAlt]: {
    serviceName: 'Medical Oncology Treatment',
    type: ServiceTypesList.MedicalOncologyTreatmentAlt,
    facilityName: Cypress.env('cancerCareAltFacilityName'),
    wardName: Cypress.env('cancerCareAltFacilityWardName'),
    serviceGenerator: generateMedicalOncologyTreatmentService,
  },
  [ServiceTypesList.RadiationOncologyConsultation]: {
    serviceName: 'Radiation Oncology Consultation',
    type: ServiceTypesList.RadiationOncologyConsultation,
    facilityName: Cypress.env('cancerCareFacilityName'),
    wardName: Cypress.env('cancerCareFacilityWardName'),
    serviceGenerator: generateRadiationOncologyConsultationService,
  },
  [ServiceTypesList.RadiationOncologyConsultationAlt]: {
    serviceName: 'Radiation Oncology Consultation',
    type: ServiceTypesList.RadiationOncologyConsultationAlt,
    facilityName: Cypress.env('cancerCareAltFacilityName'),
    wardName: Cypress.env('cancerCareAltFacilityWardName'),
    serviceGenerator: generateRadiationOncologyConsultationService,
  },
  [ServiceTypesList.RadiationOncologyTreatment]: {
    serviceName: 'Radiation Oncology Treatment',
    type: ServiceTypesList.RadiationOncologyTreatment,
    facilityName: Cypress.env('cancerCareFacilityName'),
    wardName: Cypress.env('cancerCareFacilityWardName'),
    serviceGenerator: generateRadiationOncologyTreatmentService,
  },
  [ServiceTypesList.RadiationOncologyTreatmentAlt]: {
    serviceName: 'Radiation Oncology Treatment',
    type: ServiceTypesList.RadiationOncologyTreatmentAlt,
    facilityName: Cypress.env('cancerCareAltFacilityName'),
    wardName: Cypress.env('cancerCareAltFacilityWardName'),
    serviceGenerator: generateRadiationOncologyTreatmentService,
  },
})

/**
 * Adds a service toa  given customer.
 */
export const addServiceToPatientViaApi = (params: {
  serviceDetails: ServiceDetails
  patient: RegistrationModelLatest
}) => {
  const { serviceDetails, patient } = params
  const service = serviceDetails.serviceGenerator()

  return ServicesRoutes.PostServicesByUserIdAdd.request({ customerId: patient.userId!, body: service }).then(
    response => {
      const responseBody = response.body as PostServicesAddResponseLatest

      //TODO: Add schema checks

      service.id = responseBody.model

      patient.patient = {
        ...patient.patient,
        services: [service],
      }

      cy.writeFile('cypress/fixtures/patient.json', patient)

      return cy.wrap(patient)
    }
  )
}
