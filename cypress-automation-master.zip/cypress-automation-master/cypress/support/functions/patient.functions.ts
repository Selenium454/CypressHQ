import * as faker from 'faker/locale/en_AU'
import { generateNumbers, generateLetters, generateAddressModel } from './general.functions'
import { RepatCardTypeValues, SexValues } from '@schemas/api/types'
import {
  GeneratedPatient,
  GeneratedRegistrationModel,
  CustomerSex,
  GeneratedContact,
  ServiceObjectBasic,
  Intervention,
} from '@support/types'
import { RegistrationModelLatest } from '@schemas/api/models/registrationModel.models.webApi.cloudServices'
import { PatientsRoutes } from '@support/api'
import { PostPatientsRegisterResponseLatest } from '@schemas/api/endpoints/patients/register.post'
import { ContactLatest } from '@schemas/api/models/contact.cloud.models.core'
import { PostPatientsContactsResponseLatest } from '@schemas/api/endpoints/patients/contacts.post'

export const generatePatient = (
  params: {
    firstName?: string
    surName?: string
    activeInHub?: boolean
  } = {}
): GeneratedPatient => {
  const { firstName = faker.name.firstName(), surName = `qa${generateLetters(12)}`, activeInHub = true } = params

  const repatNumber = faker.random.arrayElement([
    { value: 'gold', id: 1, abrev: 'G' },
    { value: 'orange', id: 2, abrev: 'O' },
    { value: 'white', id: 3, abrev: 'W' },
  ])

  const patientModel: GeneratedPatient = {
    activeInHub: activeInHub,
    medicationInstructions: 'These are some customer notes',
    allergies: 'Shellfish',
    concessionNumber: `CN${Cypress.moment()
      .format('YY')
      .substring(1)}${generateNumbers(8).toString()}`,
    concessionType: 'S',
    concessionValidToDate: Cypress.moment()
      .add(generateNumbers(2), 'days')
      .format('YYYY-MM-DDTHH:mm:ss'),
    ctg: true,
    medicareFirstName: firstName,
    medicareNumber: generateNumbers(11).toString(),
    medicareSurName: surName,
    medicareValidDate: Cypress.moment()
      .add(generateNumbers(3), 'days')
      .format('YYYY-MM-DDTHH:mm:ss'),
    repatCardType: repatNumber.value as typeof RepatCardTypeValues[number],
    repatNumber: faker.helpers.replaceSymbolWithNumber('QSM#####'),
    safetyNetNumber: `SN${Cypress.moment()
      .format('YY')
      .substring(1)}${generateNumbers(8).toString()}`,
    services: [],
  }

  if (!activeInHub) {
    patientModel.nonActiveReason = 'deceased'
  }

  return patientModel
}

/**
 * Generates a customer object in the format used throughout Health Director.
 */
export const generateRegistrationModel = (activeInHub: boolean = true): GeneratedRegistrationModel => {
  const firstName = faker.name.firstName()
  const surName = `qa${generateLetters(12)}`
  const gender = faker.random.arrayElement([
    { value: 'male', id: CustomerSex.male, title: 'Mr' },
    { value: 'female', id: CustomerSex.female, title: 'Mrs' },
  ])
  const address = generateAddressModel()
  const patient = generatePatient({ activeInHub })

  return {
    address: address,
    billingDetails: {
      billingAddress: address,
      email: faker.internet.email(firstName, surName, `testEmail${generateNumbers(4)}.com`),
      firstName: firstName,
      mobileNumber: faker.helpers.replaceSymbolWithNumber('04########'),
      phoneNumber: faker.helpers.replaceSymbolWithNumber('6628####'),
      surName: surName,
    },
    australianSouthSeaIslanderStatus: 'no',
    countryOfBirth: 'Australia',
    dateOfBirth: Cypress.moment(faker.date.past(100)).format('YYYY-MM-DDTHH:mm:ss'),
    email: faker.internet.email(firstName, surName, `testEmail${generateNumbers(4)}.com`),
    employmentStatus: 'Other',
    ethnicGroup: 'acehnese',
    title: gender.title,
    firstName: firstName,
    surName: surName,
    middleName: faker.name.firstName(),
    preferredName: faker.name.firstName(),
    indigenousStatus: 'aboriginal',
    language: 'Aboriginal English, so described',
    maritalStatus: 'single',
    mobileNumber: faker.helpers.replaceSymbolWithNumber('04########'),
    phoneNumber: faker.helpers.replaceSymbolWithNumber('6628####'),
    nationality: 'Overseas not specified',
    sex: gender.value as typeof SexValues[number],
    timeZoneId: 'E. Australia Standard Time',
    patient: patient,
  }
}

export const generateCustomerWithValidMedicare = (): GeneratedRegistrationModel => {
  const validMedicarePatientModel: GeneratedRegistrationModel = generateRegistrationModel()

  Object.assign(validMedicarePatientModel, {
    firstName: 'Heather',
    surName: 'Quinn',
    dateOfBirth: Cypress.moment('07/04/1931', 'DD/MM/YYYY').toDate(),
    patient: {
      ...validMedicarePatientModel.patient,
      medicareNumber: 27210984521,
      medicareValidDate: '2020-05-23T00:00:00',
      repatNumber: 'QX173831A',
    },
  })

  return validMedicarePatientModel
}

export const generateVueRegistrationModel = (): GeneratedRegistrationModel => {
  const registrationModel = generateRegistrationModel()
  const formattedDateOfBirth = Cypress.moment(registrationModel.dateOfBirth).format('DD/MM/YYYY')
  registrationModel.dateOfBirth = formattedDateOfBirth

  return registrationModel
}

export const generateEmail = (firstName: string, surname: string) => {
  return faker.internet.email(firstName, surname, `testEmail${generateNumbers(4)}.com`)
}

export const generateContact = (isMain: boolean = true): GeneratedContact => {
  const firstName = faker.name.firstName()
  const surname = `qa${generateLetters(12)}`

  return {
    address: {
      country: 'Australia',
      street: `${generateNumbers(2).toString()} ${faker.address.streetName().substring(0, 19)}`,
      secondaryStreet: `${generateNumbers(2).toString()} ${faker.address.streetName()}`,
      suburb: faker.address.city().substring(0, 18),
      state: 'QLD',
      postCode: generateNumbers(4).toString(),
    },
    email: faker.internet.email(firstName, surname, `testEmail${generateNumbers(4)}.com`),
    firstName: firstName,
    isMainContact: isMain,
    phoneNumber: faker.helpers.replaceSymbolWithNumber('6628####'),
    mobileNumber: faker.helpers.replaceSymbolWithNumber('04########'),
    relationship: 'spouse',
    surName: surname,
  }
}

/**
 * Generates a JSON object that can be used to sync a new intervention.
 */
export const generateInterventionJson = (userId: string, service: ServiceObjectBasic): Intervention => {
  return {
    consequenceImpact: 'minor',
    content: 'Test Comment',
    drugNames: ['ADROYD TAB 100mg'],
    drugProblem: 'drugSelection',
    drugProblemDetails: 'duplication',
    facilityCode: service.facilityCode,
    facilityName: service.facilityName,
    fromDate: Cypress.moment()
      .utc()
      .format('YYYY-MM-DDTHH:mm:ss'),
    id: '',
    interventionDate: Cypress.moment()
      .utc()
      .format('YYYY-MM-DDTHH:mm:ss'),
    likelihood: 'likely',
    pharmacyId: String(service.pharmacyId),
    pharmacyName: '',
    recommendation: 'changeInTherapy',
    recommendationDetails: 'prescriptionNotDispensed',
    roundCode: service.facilityWardCode,
    roundName: service.facilityWardName,
    urNumber: userId,
    userReference: '',
    writtenBy: Cypress.env('pharmacyAdminId'),
  }
}

/**
 * Creates a patient via the API and then returns a chainable response.
 */
export const createPatientViaApi = (params: { options?: RegistrationModelLatest; activeInHub?: boolean } = {}) => {
  const { options = {}, activeInHub = true } = params
  let baseCustomer: RegistrationModelLatest = generateRegistrationModel(activeInHub)

  const customer: RegistrationModelLatest = {
    ...baseCustomer,
    ...options,
  }

  return PatientsRoutes.PostPatientsRegister.request({ model: customer }).then(response => {
    const responseBody = response.body as PostPatientsRegisterResponseLatest

    const { model: userId } = responseBody
    customer.userId = userId!.toString()

    return cy.wrap(customer)
  })
}

/**
 * Adds a contact to a given patient
 */
export const addContactToPatientViaApi = (params: { customer: RegistrationModelLatest; contact?: ContactLatest }) => {
  const { contact = generateContact(), customer } = params

  return PatientsRoutes.PostPatientsByUserIdContacts.request({ userId: customer.userId!, body: [contact] }).then(
    response => {
      const responseBody = response.body as PostPatientsContactsResponseLatest
      //TODO: Add schema checks

      return cy.wrap(responseBody)
    }
  )
}
