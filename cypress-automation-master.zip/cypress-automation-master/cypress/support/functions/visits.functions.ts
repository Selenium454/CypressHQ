import { PatientDetails, VisitModelSync, VisitsModelManual } from '@support/types'

/**
 * Generates a visit object from given PatientDetails object that can be used for syncing.
 */
export const generateVisit = (patientDetails: PatientDetails): VisitModelSync => {
  const {
    wardCode,
    facilityCode,
    totalCareId,
    doctorProviderNumber,
    appointmentNumber,
    visitTimeUtc,
    visitSk,
  } = patientDetails

  const visitTime =
    visitTimeUtc ||
    Cypress.moment()
      .add(5, 'hours')
      .utc()
      .format('YYYY-MM-DDTHH:mm:ss.SSSSZ')

  const appointmentNo = appointmentNumber || Cypress.moment().valueOf(),
    visitId = visitSk || Cypress.moment().valueOf()

  return {
    visitSk: visitId,
    appointmentNumber: appointmentNo,
    sourceCode: 'TotalCare',
    visitTimeUtc: visitTime,
    preferredVisitSource: 0,
    visitReason: 'Review Appointment',
    duration: '00:15:00',
    wardCode,
    facilityCode,
    totalCareId,
    doctorProviderNumber,
    status: 1,
  }
}

/**
 * Generates a visit object from given PatientDetails object that can be used for manual creation.
 */
export const generateManualVisit = (patientDetails: PatientDetails): VisitsModelManual => {
  const {
    wardCode,
    facilityCode,
    totalCareId,
    doctorProviderNumber,
    visitTimeUtc,
    customerId,
    serviceId,
  } = patientDetails

  const visitTime =
    visitTimeUtc ||
    Cypress.moment()
      .add(5, 'hours')
      .utc()
      .format('YYYY-MM-DDTHH:mm:ss.SSSSZ')

  return {
    appointment: {
      duration: null,
      startDate: visitTime,
    },
    billedInformation: {
      consultationCodes: [],
      billingRate: null,
      note: null,
    },
    created: null,
    externalId: null,
    facilityCode: facilityCode,
    locked: false,
    patientId: customerId,
    rules: null,
    serviceId: serviceId,
    status: 'scheduled',
    totalCareId: totalCareId,
    treatingDoctor: {
      firstName: 'Jane',
      fullName: 'Jane Jones',
      practiceId: '91ac2046c8594f63a6948238bbb27685',
      practiceName: 'Wesley',
      prescriberNumber: '123456754324',
      providerNumber: doctorProviderNumber,
      specializations: ['medicalOncologist'],
      surname: 'Jones',
      userId: '0000568433',
    },
    updateDate: null,
    updating: false,
    visitId: null,
    visitInformation: {
      consultationCodes: [],
      billingRate: null,
      note: null,
    },
    wardCode: wardCode,
  }
}
