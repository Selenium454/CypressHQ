/**
 * Generates a provider number for a doctor's practice
 */
export const generateProviderNumber = (): string => {
  const plv = Math.floor(Math.random() * 31),
    s = Math.floor(Math.random() * 81584 + 100000).toString()

  let sum = plv * 6
  ;[3, 5, 8, 4, 2, 1].forEach((w, i) => {
    sum += parseInt(s.charAt(i)) * w
  })

  const check = 'YXWTLKJHFBA'.charAt(sum % 11)
  return s + '0123456789ABCDEFGHJKLMNPQRTUVWXY'.charAt(plv) + check
}
