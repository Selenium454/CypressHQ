import { PlainObject } from '@cypress/schema-tools/src/objects'
import * as qs from 'qs'
import * as moment from 'moment'
import { Customs, dueTimes } from '@support/types'

import { PostOrdersNewRequestLatest } from '@schemas/api/endpoints/orders/new.post'
import { ChartItemLatest } from '@schemas/api/models/chartItem.orders.cloud.models.core'

/**
 * A set date for the use of creating chart jobs with a time of other
 */
export const manualDueTime = Cypress.moment('2019-01-01 14:15')

/**
 * Parses a given Cypress chartflow job response into a useable JSON object.
 */
export const parseChartItems = (response: Cypress.WaitXHR): PlainObject => {
  const parsedObject: PlainObject = qs.parse(response.requestBody as string)
  const chartItems: string = parsedObject.chartItems as string
  parsedObject.chartItems = JSON.parse(decodeURIComponent(chartItems))

  return parsedObject
}

/**
 * Checks the due time is 1 hour ahead of when it was created.
 */
export const checkDueTimeHour = (dueTime: moment.Moment): void => {
  const startRange = Cypress.moment().add(55, 'minutes')
  const endRange = Cypress.moment().add(65, 'minutes')
  expect(dueTime.isBetween(startRange, endRange))
}

/**
 * Checks the due time is today at 7pm.
 */
export const checkDueTimeToday = (dueTime: moment.Moment): void => {
  const today: string = Cypress.moment().format('YYYY-MM-DD')
  const correctDueTime: moment.Moment = moment(`${today} 19:00`)
  expect(dueTime.isSame(correctDueTime, 'minute'))
}

/**
 * Checks the due time is due tomorrow at 7pm.
 */
export const checkDueTimeTomorrow = (dueTime: moment.Moment): void => {
  const tomorrow: string = Cypress.moment()
    .add(1, 'day')
    .format('YYYY-MM-DD')
  const correctDueTime: moment.Moment = moment(`${tomorrow} 19:00`)
  expect(dueTime.isSame(correctDueTime, 'minute'))
}

/**
 * Checks the due time is due at the given time.
 */
export const checkDueTimeOther = (dueTime: moment.Moment): void => {
  expect(dueTime.isSame(manualDueTime, 'minute'))
}

/**
 * Generate an order JSON object that can be used to add a new chart order via the API.
 */
export const generateOrderJson = (
  orderContext: 'facility' | 'personal',
  customs: Customs
): PostOrdersNewRequestLatest => {
  let chartItems: ChartItemLatest[] = []
  let i: number = 1
  const numberOfPhotos = customs.numberOfPhotos ? customs.numberOfPhotos : 1
  do {
    chartItems.push({
      orderId: i.toString(),
      index: 0,
      residentRequest: orderContext !== 'facility',
      degree: '0',
      notations: [],
      path: Cypress.env(orderContext === 'facility' ? 'facilityChartflowImagePath' : 'patientChartflowImagePath'),
    })
    i += 1
  } while (i <= numberOfPhotos)

  return {
    context: orderContext,
    classification: 'personal',
    roundCode: customs.wardCode ? customs.wardCode : Cypress.env('hospitalFacilityWardCode'),
    facilityCode: orderContext === 'facility' ? customs.orderFor : Cypress.env('hospitalFacilityCode'),
    orders: [
      {
        orderType: 'chart',
        orderFor: orderContext === 'facility' ? null : customs.orderFor,
        urn: customs.urn ? customs.urn : null,
        deliveryOptions: {
          deliveryType: customs.deliveryType ? customs.deliveryType : 'regular',
          deliveryInstructions: null,
        },
        comment: customs.comment,
        chartSource: 'chartFlow',
        alias: 'ChartFlow',
        dueTime: customs.dueTime
          ? Cypress.moment(customs.dueTime).toISOString()
          : Cypress.moment()
              .add(1, 'day')
              .toISOString(),
        scriptLinking: false,
        tags: customs.tags ? customs.tags : null,
        chartStatus: 'none',
        chartItems: chartItems,
      },
    ],
  }
}

/**
 * Dictionary containing links between due time type and the corresponding check.
 */
export const checkDueTimes = Object.freeze({
  [dueTimes.hour]: {
    check: checkDueTimeHour,
  },
  [dueTimes.today]: {
    check: checkDueTimeToday,
  },
  [dueTimes.tomorrow]: {
    check: checkDueTimeTomorrow,
  },
  [dueTimes.other]: {
    check: checkDueTimeOther,
  },
})
