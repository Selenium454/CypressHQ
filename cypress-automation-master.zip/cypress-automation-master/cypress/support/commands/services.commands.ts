import { epicHdId, generateNumbers } from '@support/functions'
import {
  ServiceDetails,
  AddHealthFundInfo,
  AddAdditionalIdentifier,
  InactiveServiceOptions,
  ServiceTypesList,
  VueComponent,
  PatientServicesVue,
} from '@support/types'
import { epicSelect } from './general.commands'
import { RegistrationModelLatest } from '@schemas/api/models/registrationModel.models.webApi.cloudServices'
import { PutServicesUpdateRequestLatest } from '@schemas/api/endpoints/services/update.put'
import { MedicalServiceLatest } from '@schemas/api/models/medicalService.cloud.models.core'
import { HealthFundsRoutes, ServicesRoutes } from '@support/api'

/**
 * Creates a service of the given type via the UI.
 */
export const addNewService = (params: {
  serviceDetails: ServiceDetails
  selectType: 'wide' | 'narrow'
  alreadyExists?: boolean
}) => {
  const { serviceDetails, selectType, alreadyExists = false } = params

  cy.contains('Add Service')
    .scrollIntoView()
    .click()

  epicSelect({
    container: epicHdId('dialog-container'),
    inputLocator: `[name="serviceType-select-input-${selectType}"]`,
    dropdownLocator: `.el-popper.serviceType-select-dropdown-${selectType} .epic-text`,
    option: serviceDetails.serviceName,
  })

  epicSelect({
    container: epicHdId('dialog-container'),
    inputLocator: `[name="facility-select-input-${selectType}"]`,
    dropdownLocator: `.el-popper.facility-select-dropdown-${selectType} .epic-text`,
    option: serviceDetails.facilityName,
  })

  epicSelect({
    container: epicHdId('dialog-container'),
    inputLocator: `[name="ward-select-input-${selectType}"]`,
    dropdownLocator: `.el-popper.ward-select-dropdown-${selectType}:visible .epic-text`,
    option: serviceDetails.wardName,
  })

  cy.contains(epicHdId('button-add-service'), 'Add')
    .click()
    .should('not.exist')

  if (!alreadyExists) {
    cy.get(epicHdId('epic-loader-container')).should('be.visible')
    cy.get(epicHdId('epic-loader-container')).should('not.be.visible')
  }
}

export const removeService = () => {
  const message = 'Are you sure you want to delete this service?'
  const locator = '.medical-service-wrapper'

  cy.contains(` ${locator} button.btn-warning`, 'Remove')
    .scrollIntoView()
    .should('be.visible')
    .click()

  cy.contains(message).should('be.visible')

  cy.contains(`${epicHdId('dialog-container')} button.btn-action`, 'Ok')
    .should('be.visible')
    .click()
    .should('not.exist')
}

/**
 * Creates a service of the given type via the UI.
 */
export const cancelService = () => {
  const message = 'Continuing will discard any unsaved changes, would you like to continue?'

  cy.contains(`${epicHdId('services-wrapper')} .btn-warning`, 'Cancel').click()

  cy.contains(message).should('be.visible')

  cy.contains(`${epicHdId('dialog-container')} .btn-action`, 'Ok')
    .click()
    .should('not.exist')
}

/**
 * Checks and closes the aged care specific dialog confirmation.
 */
export const checkAndCloseAgedCareConfirmation = () => {
  cy.get(epicHdId('dialog-container'))
    .as('agedCareDialogConfirmation')
    .within(() => {
      cy.contains('The patient address will be overwritten').should('be.visible')

      cy.get('.btn-action').click()
    })

  cy.get('@agedCareDialogConfirmation').should('not.exist')
}

/**
 * Submits the service for creation.
 */
export const submitServiceCreation = (serviceType: ServiceDetails) => {
  if (serviceType.type === ServiceTypesList.AgedCare) cy.wait(2000)

  cy.get(epicHdId('button-create-service'))
    .scrollIntoView()
    .should('be.visible')
    .click()
}

/**
 * Adds health fund info via the API.
 */
export const addHealthFundInfo = ({ healthFundId, coverLevel, membershipNumber }: AddHealthFundInfo) => {
  cy.get('.epic-search-field').within(() => {
    cy.get('[name="healthfundId"]')
      .clear()
      .type(healthFundId)

    HealthFundsRoutes.PostHealthFundsInsurers.check()

    cy.contains('.dropdown-menu a', healthFundId).click()

    HealthFundsRoutes.GetHealthfundsByHealthFundCodeInsurer.check()
  })

  cy.get('[name="Cover level"]')
    .clear()
    .type(coverLevel)

  cy.get('[name="Membership Number"]')
    .clear()
    .type(membershipNumber)

  cy.get('.epic-datepicker').click()

  cy.get('.show-calendar [style="display: block;"]')
    .last()
    .within(() => {
      cy.contains('td', '20').click()
    })
}

/**
 * Sets an existing identifier to another value.
 */
export const setAdditionalIdentifier = ({ typeValue, identifierType, identifierValue }: AddAdditionalIdentifier) => {
  cy.get(`[name="identifierValue-${typeValue}"]`)
    .closest('.form-group')
    .find('.select-identifier')
    .should('be.visible')
    .click()

  cy.contains('.epic-text:visible', identifierType).click()

  cy.get(`[name="identifierValue-${typeValue}"]`).type(identifierValue)
}

/**
 * Adds additional identifiers to a service
 */
export const addAdditionalIdentifier = ({ typeValue, identifierType, identifierValue }: AddAdditionalIdentifier) => {
  cy.get('body').then($body => {
    if ($body.find('.add-identifier').length) {
      cy.get('.add-identifier').as('addIdentifier')
    } else {
      cy.get('[title="Add another"]').as('addIdentifier')
    }
  })

  cy.get('@addIdentifier').click()

  setAdditionalIdentifier({ typeValue, identifierType, identifierValue })
}

/**
 * Submits a service to be updated.
 */
export const submitServiceUpdate = (serviceType: ServiceDetails) => {
  if (serviceType.type === ServiceTypesList.AgedCare) cy.wait(2000)

  cy.get(epicHdId('button-save-service'))
    .scrollIntoView()
    .should('be.visible')
    .click()
}

/**
 * Sets a service's status to inactive.
 */
export const setServiceStateToInactive = ({ inactiveReason, inactiveOtherReason }: InactiveServiceOptions) => {
  cy.get(epicHdId('service-state-container'))
    .scrollIntoView()
    .find('[value="inactive"]')
    .should('be.visible')
    .click()

  epicSelect({
    container: '.epic-select-container',
    inputLocator: '[name="inactiveReasons-select-input-wide"]',
    dropdownLocator: '.el-popper.inactiveReasons-select-dropdown-wide',
    option: inactiveReason,
  })

  if (typeof inactiveOtherReason !== 'undefined') {
    cy.get('[name="otherReason"]')
      .clear()
      .type(inactiveOtherReason)
  }
}

/**
 * Sets a service's status to active.
 */
export const setServiceStateToActive = () => {
  cy.get(epicHdId('service-state-container'))
    .scrollIntoView()
    .find('[value="active"]')
    .should('be.visible')
    .click()
}

/**
 * Sets a service's status to archived.
 */
export const setServiceStateToArchived = ({ inactiveReason, inactiveOtherReason }: InactiveServiceOptions) => {
  cy.get(epicHdId('service-state-container'))
    .scrollIntoView()
    .find('[value="deleted"]')
    .should('be.visible')
    .click()

  epicSelect({
    container: '.epic-select-container',
    inputLocator: '[name="inactiveReasons-select-input-wide"]',
    dropdownLocator: '.el-popper.inactiveReasons-select-dropdown-wide:visible .epic-text',
    option: inactiveReason,
  })

  if (typeof inactiveOtherReason !== 'undefined') {
    cy.get('[name="otherReason"]')
      .clear()
      .type(inactiveOtherReason)
  }
}

/**
 * Adds additional Ids to a customer's service
 */
export const addAdditionalIdsViaApi = (customer: RegistrationModelLatest) => {
  if (customer.patient.services) {
    const tcid: string = `${generateNumbers(10)}`
    const gpid: string = `${generateNumbers(10)}`
    const rcid: string = `${generateNumbers(10)}`
    const service = customer.patient.services[0]

    service.identifiers = [{ key: 'tcid', value: tcid }, { key: 'gpid', value: gpid }, { key: 'rcid', value: rcid }]

    return ServicesRoutes.PutServicesByUserIdUpdate.request({
      customerId: customer.userId!,
      body: service,
    }).then($response => {
      return $response.body as PutServicesUpdateRequestLatest
    })
  }
}

export const addServiceViaVue = (params: { serviceDetails: ServiceDetails; service?: MedicalServiceLatest }) => {
  const { serviceDetails, service = serviceDetails.serviceGenerator() } = params

  cy.window({ log: false })
    .getVueComponent('patientServices')
    .then((patientServicesVue: PatientServicesVue) => {
      cy.wrap(patientServicesVue.$refs.servicesList).invoke(
        'onServiceAdded',
        service.serviceType,
        service.facilityCode,
        service.wardCode
      )
    })
}

export const addServiceToPatientProfileViaVue = (params: {
  serviceType: ServiceDetails
  service?: MedicalServiceLatest
}) => {
  const { serviceType, service = serviceType.serviceGenerator() } = params

  cy.window({ log: false })
    .getVueComponent('service-tabs')
    .then((patientServicesVue: VueComponent) => {
      const patient = (patientServicesVue.$parent as unknown) as PatientServicesVue

      cy.wrap(patient).invoke('onServiceAdded', service.serviceType, service.facilityCode, service.wardCode)
    })
}
