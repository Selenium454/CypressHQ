import { epicSelect } from './general.commands'

import { PostDoctorsSearchResponseLatest } from '@schemas/api/endpoints/doctors/search.post'

import { SearchForDoctorOptions, DoctorDetails } from '@support/types'

/**
 * Searches for a doctor via the given method and with the given values
 */
export const searchForDoctor = ({ searchMethodSelector, searchTerm }: SearchForDoctorOptions) => {
  cy.get('.inline-search').within(() => {
    cy.get('.search-by-button').click()
  })

  cy.get(searchMethodSelector).click()

  return cy
    .get('[name="query"]')
    .clear()
    .type(searchTerm)
}

/**
 * Check for a doctor to exist in the dom and add them to the service.
 */
export const checkForDoctorAndAdd = (response: PostDoctorsSearchResponseLatest) => {
  const { prescriberNumber, practices } = response.model!.items![0]
  const { providerNumber, practiceName } = practices![0]

  cy.get('.search-content')
    .find('.data-row')
    .first()
    .contains('Add')
    .click()

  cy.get('.doctor-panel')
    .should('be.visible')
    .within(() => {
      cy.contains('Prescriber No')
        .closest('.doc-details-content')
        .should('contain', prescriberNumber)

      cy.contains('Provider No')
        .closest('.doc-details-content')
        .should('contain', providerNumber)

      cy.contains('Practice')
        .closest('.doc-details-content')
        .should('contain', practiceName)

      cy.get('[name="doctorType-select-input-wide"]:visible').should('have.value', 'Unknown')
    })
}

/**
 * Adds a generic referral to a doctor.
 */
export const addDoctorReferral = () => {
  cy.contains('.btn-misc', 'Add Referral').click()

  cy.get('.referral-container').within(() => {
    cy.contains('label', 'Referral Date')
      .parent()
      .find('.epic-datepicker')
      .click()
  })

  cy.get('.show-calendar')
    .find('.left')
    .find('.today')
    .click()

  cy.get('.referral-container').within(() => {
    cy.contains('label', 'Referral Expiry')
      .parent()
      .find('[type="radio"]')
      .check('12')

    cy.contains('label', 'Referral Type').parent()
  })

  epicSelect({
    container: '.epic-select-container',
    inputLocator: '[name="referralType-select-input-wide"]',
    dropdownLocator: '.el-popper.referralType-select-dropdown-wide:visible .epic-text',
    option: 'Verbal',
  })
}

/**
 * Deletes a referral from a doctor.
 */
export const deleteDoctorReferral = () => {
  cy.get('.referral-container')
    .scrollIntoView()
    .should('be.visible')
    .within(() => {
      cy.contains('.btn-misc', 'Delete').click()
    })

  cy.get('.referral-container').should('not.exist')
}

/**
 * Deletes the first doctor.
 */
export const deleteDoctor = () => {
  cy.get('.doctor-panel')
    .scrollIntoView()
    .should('be.visible')
    .within(() => {
      cy.contains('.epic-link', 'DELETE DOCTOR').click()
    })

  cy.get('.doctor-panel').should('not.be.visible')
}

/**
 * Checks the search results in the UI when searching for a doctor
 */
export const checkDoctorSearchResults = (doctorDetails: DoctorDetails) => {
  const { fullName, practiceName, prescriberNumber, providerNumber } = doctorDetails
  cy.contains('.vuetable-td-providerNumber', providerNumber)
    .should('be.visible')
    .parent()
    .within(() => {
      cy.contains('.vuetable-td-fullName', fullName).should('be.visible')
      cy.contains('.vuetable-td-prescriberNumber', prescriberNumber).should('be.visible')
      cy.contains('.vuetable-td-practiceName', practiceName).should('be.visible')
    })
}
