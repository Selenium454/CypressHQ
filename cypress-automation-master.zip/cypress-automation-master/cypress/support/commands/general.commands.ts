import { VueComponent } from '@support/types'

export const getVueComponent = (vueComponent: VueComponent, componentName: string) => {
  //Early return
  if (vueComponent.$options._componentTag === componentName) {
    return vueComponent
  }

  let result: VueComponent | {} = {}
  vueComponent.$children.forEach(component => {
    result = getVueComponent(component, componentName)
    if (result) {
      return result
    }
  })
  return result
}

/**
 * Checks that the correct growl messsage is shown and then closes it.
 */
export const checkGrowlAndClose = (params: { growlMessage: string; growlType: string }) => {
  const { growlMessage, growlType } = params

  cy.contains(`${growlType}`, growlMessage)
    .should('be.visible')
    .find('.growl-close')
    .click()
    .should('not.exist')
}

/**
 * Check growls are not visible.
 */
export const checkGrowlsAreNotVisible = () => {
  cy.get('.growl').should('not.exist')
}

/**
 * Closes all growls currently open.
 */
export const closeAllGrowls = () => {
  cy.get('.growl-close').each(close => {
    cy.wrap(close).click()
  })
}

/**
 * Fills a field located with a given locator with the given value.
 */
export const fillField = (params: { locator: string; inputValue: string; checkValue?: string }) => {
  const { locator, inputValue, checkValue = null } = params
  cy.get(locator)
    .clear()
    .type(inputValue)
    .should('have.value', checkValue ? checkValue : inputValue)
}

/**
 * Selects a value in a dropdown field located with a given locator with the given value.
 */
export const selectField = (params: { locator: string; selectValue: string; checkValue?: string | null }) => {
  const { locator, selectValue, checkValue = null } = params
  cy.get(locator)
    .select(selectValue)
    .should('have.value', checkValue ? checkValue : selectValue)
}

/**
 * Checks for a given validation error message on a field with a given locator.
 */
export const checkForValidationError = (params: { locator: string; errorMessage: string }) => {
  const { locator, errorMessage } = params
  cy.get(locator)
    .closest('div.epic-input')
    .contains(errorMessage)
    .scrollIntoView()
    .should('be.visible')
}

/**
 * Checks a field throws a given validation error when given values are entered.
 */
export const checkForInvalidValues = (params: { locator: string; invalidValues: string[]; errorMessage: string }) => {
  const { locator, invalidValues, errorMessage } = params
  cy.contains(errorMessage).should('not.be.visible')

  invalidValues.forEach(value => {
    cy.get(locator).clear()
    fillField({ locator: locator, inputValue: value })
    cy.contains(errorMessage).should('be.visible')
  })
  cy.get(locator).clear()
}

export const epicSelect = (params: {
  container: string
  inputLocator: string
  dropdownLocator: string
  option: string
}) => {
  const { container, inputLocator, dropdownLocator, option } = params

  cy.get(container)
    .within(() => {
      cy.get(inputLocator)
        .parent()
        .click()
    })
    .then(() => {
      cy.contains(dropdownLocator, option).click()
    })
}
