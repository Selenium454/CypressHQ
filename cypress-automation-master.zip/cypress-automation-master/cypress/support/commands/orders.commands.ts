import { selectField, fillField } from './general.commands'
import {
  epicHdId,
  generateOrderJson,
  manualDueTime,
  checkDueTimes,
  capitaliseFirstLetter,
  generateDates,
} from '@support/functions'
import { pollRequest, OrdersRoutes, PatientsRoutes } from '@support/api'
import { CreateChartJob, Customs, dueTimes } from '@support/types'

import { PostOrdersNewRequestSchema, PostOrdersNewResponseSchema } from '@schemas/api/endpoints/orders/new.post'
import { OrderLatest } from '@schemas/api/models/order.orders.cloud.models.core'
import {
  GetOrdersHistoryResponseLatest,
  GetOrdersHistoryResponseSchema,
} from '@schemas/api/endpoints/orders/history.get'
import { GetOrdersBatchResponseLatest, GetOrdersBatchResponseSchema } from '@schemas/api/endpoints/orders/batch.get'

/**
 * Takes a photo on the chartflow take photo page and checks that it uploads correctly.
 */
export const takePhoto = (numberOfPhotos: number = 1) => {
  let i: number = 1

  do {
    cy.get(epicHdId('button-take-photo'))
      .click()
      .wait(500)
    i += 1
  } while (i <= numberOfPhotos)
}

/**
 * Selects a facility via given facility name from the facility dropdown on the take photo page and then checks for correct facility code.
 */
export const selectChartFacility = (params: { facilityName: string; facilityCode: string }) => {
  const { facilityName, facilityCode } = params
  selectField({ locator: epicHdId('select-facility'), selectValue: facilityName, checkValue: facilityCode })
}

/**
 * Fills the comment section on the take photo page with a given string.
 */
export const fillChartCommentSection = (comment: string) => {
  fillField({ locator: epicHdId('textarea-comments'), inputValue: comment })
}

/**
 * Selects a ward via given ward code from the ward dropdown on the take photo page.
 */
export const selectChartWard = (wardCode: string) => {
  selectField({ locator: epicHdId('select-ward'), selectValue: wardCode })
}

/**
 * Searches for a patient via a given urn and then sets the order's patient to them.
 */
export const searchPatientViaUrnAndSet = (hospitalCustomerUrn: string) => {
  cy.get(epicHdId('input-patient-name'))
    .clear()
    .type(hospitalCustomerUrn)

  cy.get(epicHdId('button-find-urn')).click()

  PatientsRoutes.PostPatientsSearch.check()

  cy.get(`[data-urn="${hospitalCustomerUrn}"] > ul`)
    .first()
    .click()
}

/**
 * Submits a chart job for creation on the take photo page. The request is checked against the given schema.
 */
export const submitChartJobForCreation = () => {
  cy.get(epicHdId('button-submit-chart-job')).click()
}

/**
 * Takes an array of checkbox locators and checks them.
 */
export const setChartTags = (checkboxesToCheck: string[] = []) => {
  const checkboxes = ['#urgentJob', '#dischargeJob']

  checkboxes.forEach(checkbox => {
    cy.get(`${checkbox}`)
      .as('currentCheckbox')
      .should('not.be.checked')

    if (checkboxesToCheck.includes(checkbox)) {
      cy.get('@currentCheckbox').check()
    }
  })
}

export const generateComment = (): string => {
  const time = new Date().getTime()
  return `Created job at ${time} milliseconds since midnight 1st of Jan 1970`
}

/**
 * Create a facility or personal chart job via the API.
 */
export const createChartJob = (variables: CreateChartJob) => {
  let { context, orderFor, comment = generateComment(), snapshotName, ...optionalCustoms } = variables

  const customs: Customs = { orderFor, comment, ...optionalCustoms }
  const chartOrder = generateOrderJson(context, customs)

  return OrdersRoutes.PostOrdersNew.request({ order: chartOrder }).then(response => {
    const postOrdersNewRequest = new PostOrdersNewRequestSchema()
    const postOrdersNewResponse = new PostOrdersNewResponseSchema()

    postOrdersNewRequest
      .check(chartOrder)
      .sanitize(chartOrder)
      .snapshot({
        name: `Create new chart job - Post Orders New Request`,
      })

    postOrdersNewResponse
      .check(response.body)
      .sanitize(response.body)
      .snapshot({
        name: `Create new chart job - Post Orders New Response`,
      })

    return getLatestOrder({ orderFor: orderFor, comment: customs.comment, snapshotName })
  })
}

/**
 * Sets the due time to one of the default via the dropdown.
 */
export const selectDueTime = (dueTime: string) => {
  cy.get('#jobDue')
    .should('be.visible')
    .select(dueTime)

  if (dueTime === dueTimes.other) {
    const date: string = manualDueTime.format('DD/MM/YYYY')
    const time: string = manualDueTime.format('HH:mm')

    cy.get('#jobDueDate-chart-flow')
      .should('be.visible')
      .type(date)
      .should('have.value', date)
    cy.get('[name="jobDueTime"]').type(time)
  }
}

/**
 * Sets the chart status to the given status on the chart job page.
 */
export const setChartJobStatus = (status: string) => {
  cy.get(`input[value="${status}"]`)
    .first()
    .check()
}

/**
 * Takes the due time and the type to check against and initiates a check.
 */
export const checkDueTime = (options: { dueTime: string; dueTimeType: string }) => {
  const { dueTime, dueTimeType } = options

  checkDueTimes[dueTimeType].check(Cypress.moment(dueTime))
}

/**
 * Checks that a chartflow order is displaying the correct information based on batchId.
 */
export const checkOrder = (batchOrder: OrderLatest) => {
  const {
    dailyChartOrderId,
    batchId: orderbatchId,
    created,
    orderByName,
    state,
    dueTime,
    round,
    orderForName,
    context: orderType,
    urn,
  } = batchOrder

  const formattedOrderId: string = dailyChartOrderId!.replace(/^0+/, '')
  const formattedBatchId: string = orderbatchId!.replace(/^0+/, '')
  const formattedCreated: string = Cypress.moment(created!).format('DD/MM h:mm a')
  const formattedDueTime: string = Cypress.moment(dueTime!)
    .local()
    .format('DD/MM h:mm a')

  cy.contains('.row', 'Job ID:')
    .should('contain', formattedOrderId)
    .and('be.visible')

  cy.contains('.row', 'Job Ref:')
    .should('contain', formattedBatchId)
    .and('be.visible')

  cy.contains('.row', 'Created:')
    .should('contain', orderByName)
    .and('contain', formattedCreated)

  cy.contains('.row', 'Status:')
    .should('contain', state === 'dispatched' ? 'Checked' : state)
    .and('be.visible')

  cy.contains('.row', 'Due Time:')
    .should('contain', formattedDueTime)
    .and('be.visible')

  cy.contains('.row', 'Ward:')
    .should('contain', round)
    .and('be.visible')

  if (orderType === 'personal') {
    const splitName = orderForName!.split(/\s+/)
    const formattedLastName = splitName.pop()!.toUpperCase()
    splitName.forEach((name, index) => {
      splitName[index] = capitaliseFirstLetter(name.toLowerCase())
    })
    const formattedFirstName: string = splitName.join(' ')

    cy.contains('.row', 'URN:')
      .should('contain', urn)
      .and('be.visible')

    cy.contains('.row', 'Name:')
      .should('contain', formattedFirstName)
      .and('contain', formattedLastName)
  } else {
    cy.contains('.row', 'Facility:')
      .should('contain', orderForName)
      .and('be.visible')
  }
}

/**
 * Takes the user agent to the jobs dashboard for a given facility via the UI.
 */
export const goToJobsDashboard = (params: { pharmacyName: string; facilityName: string }) => {
  const { pharmacyName, facilityName } = params

  cy.get('ul.main-navigation').then(navDrawer => {
    if (navDrawer.has('.closed')) {
      cy.get('.hamburger-box').click()
    }
  })

  cy.contains('li', 'Dashboard').click()

  cy.contains('a', pharmacyName).click()

  cy.get('h2').should('be.visible')

  cy.url().then($url => {
    if ($url.includes('overview')) {
      cy.contains('a', facilityName).click()
    }
  })
}

/**
 * Submits a chart job update. The request is checked against the given schema.
 */
export const submitChartJobUpdate = (params: { pin?: string } = {}) => {
  const { pin } = params

  cy.get(epicHdId('button-submit-job')).as('submitButton')

  cy.get(epicHdId('input-pin')).then($inputPin => {
    if ($inputPin.is(':visible') && pin) {
      cy.wrap($inputPin)
        .first()
        .clear()
        .type(pin)
        .should('have.value', pin)

      cy.get(epicHdId('button-submit-pin-job')).as('submitButton')
    }
  })

  cy.get('@submitButton')
    .first()
    .click()
}

/**
 * Locks an order. The request checked against the given schema.
 */
export const lockOrder = () => {
  cy.get(epicHdId('button-lock')).click()
}

/**
 * Gets a list of chart orders for a customer or facility and checks it contains the correct order via the comments.
 */
export const getLatestOrder = (params: {
  orderFor: string
  comment: string
  tries?: number
  snapshotName?: string
}) => {
  const { orderFor, comment, snapshotName } = params

  const maxRetries: number = 20
  let { tries = 0 } = params
  return getOrdersHistory(orderFor).then(responseBody => {
    const historyResponseBody = Cypress._.cloneDeep(responseBody) as GetOrdersHistoryResponseLatest
    const latestOrder = responseBody.model![responseBody.model!.length - 1]

    return OrdersRoutes.GetOrdersBatch.request({ batchId: latestOrder.batchId! }).then(response => {
      const { model: orders } = response.body as GetOrdersBatchResponseLatest
      const latestOrder: OrderLatest = orders![orders!.length - 1]
      if (latestOrder.state == 'new' && latestOrder.comment!.includes(comment)) {
        const responseBody = Cypress._.cloneDeep(response.body) as GetOrdersBatchResponseLatest

        if (snapshotName) {
          new GetOrdersHistoryResponseSchema()
            .check(historyResponseBody)
            .sanitize(historyResponseBody)
            .snapshot({
              name: `${snapshotName} - Get Orders History Response`,
            })

          new GetOrdersBatchResponseSchema()
            .check(responseBody)
            .sanitize(responseBody)
            .snapshot({
              name: `${snapshotName} - Get Orders Batch Response`,
            })
        }
      } else {
        tries += 1
        pollRequest({
          callbackFunction: getLatestOrder,
          callbackParams: { orderFor, comment, tries, snapshotName },
          tries: tries,
          maxRetries: maxRetries,
        })
      }

      return cy.wrap(latestOrder)
    })
  })
}

/**
 * Gets the latest batch of orders for a cutomer or facility.
 */
export const getOrdersHistory = (orderFor: string): Cypress.Chainable<GetOrdersHistoryResponseLatest> => {
  const { from, till } = generateDates()

  return OrdersRoutes.GetOrdersHistory.request({ orderFor, from, till }).its('body')
}
