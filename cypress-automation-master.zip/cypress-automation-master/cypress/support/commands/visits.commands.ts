import { DoctorsRoutes } from '@support/api'

/**
 * Sets the treating doctor of a visit via the UI.
 */
export const setTreatingDoctor = (doctorLastName: string) => {
  cy.contains('.epic-link', 'SET TREATING DOCTOR').click()

  cy.contains('div.header', 'Doctor Search')
    .parent('div.epic-card')
    .find('.epic-input')
    .find('input')
    .type(doctorLastName)

  DoctorsRoutes.PostDoctorsSearch.check()

  cy.contains('.action-cell', 'Set')
    .find('a')
    .click()
}
