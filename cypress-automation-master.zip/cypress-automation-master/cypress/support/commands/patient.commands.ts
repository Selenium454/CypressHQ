import { fillField, selectField } from './general.commands'
import { RegistrationModelLatest } from '@schemas/api/models/registrationModel.models.webApi.cloudServices'
import { GeneratedRegistrationModel, PatientPersonalDetailsFormVue } from '@support/types'
import { generateRegistrationModel } from '@support/functions'

/**
 * Sets the patient details and patient address in the vue store on patient creation.
 */
export const addPersonalDetailsToStore = (patient: GeneratedRegistrationModel) => {
  cy.window({ log: false })
    .getVueComponent('PatientPersonalDetailsForm')
    .then((patientPersonalDetailsForm: PatientPersonalDetailsFormVue) => {
      cy.wrap(patientPersonalDetailsForm).invoke('setPatientDetails', patient)
      cy.wrap(patientPersonalDetailsForm).invoke('setPatientAddress', patient.address)
    })
}

export const goToCreationStep = (step: number) => {
  cy.window({ log: false })
    .getVueComponent('epic-snap-content')
    .then(epicSnapContentVue => {
      const patientCreationVue = epicSnapContentVue.$children[0]

      patientCreationVue.selectStep(step)
    })

  cy.wait(1000)
}

/**
 * Creates a patient manually with all mandatory details filled out with details from a given patient object.
 */
export const fillPersonalDetails = (patient: RegistrationModelLatest = generateRegistrationModel()) => {
  const genderInputSelector = `input[value="${patient.sex}"]`

  let formattedDateOfBirth
  if (patient.dateOfBirth) {
    formattedDateOfBirth = Cypress.moment(patient.dateOfBirth).format('DD / MM / YYYY')
  } else {
    formattedDateOfBirth = Cypress.moment().format('DD / MM / YYYY')
  }

  fillField({ locator: 'input[name="first-name"]', inputValue: patient.firstName })
  fillField({ locator: 'input[name="surname"]', inputValue: patient.surName })
  fillField({ locator: '#date-of-birth', inputValue: formattedDateOfBirth })

  cy.get(genderInputSelector).check()

  if (patient.address) {
    fillField({ locator: '#address', inputValue: patient.address.street! })
    fillField({ locator: '#suburb', inputValue: patient.address.suburb! })
    selectField({ locator: '#state', selectValue: patient.address.state! })
    fillField({ locator: '#postCode', inputValue: patient.address.postCode! })
  }
}
