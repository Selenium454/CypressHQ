import { SearchType } from '@support/types'

/**
 * Checks that the UI contains the patient's name with correct formatting.
 */
export const checkUiContainsFormattedName = (fullName: string) => {
  cy.get('.searchResultTable').contains(fullName)
}

export const setSearchType = (searchType: SearchType) => {
  cy.get('#searchSettings').click()
  cy.get(searchType.searchTypeSelector).click()
}

export const searchForPatientBy = (searchType: SearchType, valueToSearch: string) => {
  cy.get('#patientSearchInput').type(valueToSearch)

  if (!searchType.autoSearch) {
    cy.get('.btn').click()
  }
}
