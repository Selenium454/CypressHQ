import { ApiSchemaLibrary } from '@schemas/api'

const isFollowingSchema = (_chai, utils) => {
  function assertFollowingSchema(schemaName, schemaVersion) {
    ApiSchemaLibrary.assertSchema(schemaName, schemaVersion)(this._obj)

    this.assert(true, `expected subject to follow schema **${schemaName}@${schemaVersion}**`)
  }

  _chai.Assertion.addMethod('followSchema', assertFollowingSchema)
}
chai.use(isFollowingSchema)
