export * from './doctors.types'
export * from './patient.types'
export * from './search.types'
export * from './services.types'
export * from './visits.types'
export * from './orders.types'

export * from './general.types'
