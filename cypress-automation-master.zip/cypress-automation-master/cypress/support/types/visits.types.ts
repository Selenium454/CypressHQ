/**
 * Typings for a visit object used for syncing.
 */
export interface VisitModelSync {
  visitSk?: number
  appointmentNumber?: number
  sourceCode?: string
  visitTimeUtc?: string
  preferredVisitSource?: number
  visitReason?: string
  duration?: string
  wardCode?: string
  facilityCode?: string
  totalCareId?: string
  doctorProviderNumber?: string
  status?: number
}

/**
 * Typings for a visit object used for syncing.
 */
export interface VisitsModelManual {
  appointment: {
    duration: string | null
    startDate: string
  }
  billedInformation: {
    consultationCodes: []
    billingRate: string | null
    note: string | null
  }
  created: string | null
  externalId: string | null
  facilityCode: string
  locked: boolean
  patientId?: string
  rules: string | null
  serviceId?: string
  status: string
  totalCareId: string
  treatingDoctor: {
    firstName: string
    fullName: string
    practiceId: string
    practiceName: string
    prescriberNumber: string
    providerNumber: string
    specializations: string[]
    surname: string
    userId: string
  }
  updateDate: string | null
  updating: boolean
  visitId: string | null
  visitInformation: {
    consultationCodes: string[]
    billingRate: string | null
    note: string | null
  }
  wardCode: string
}

/**
 * Types for the patient's details required for the visit.
 */
export interface PatientDetails {
  wardCode: string
  facilityCode: string
  totalCareId: string
  doctorProviderNumber: string
  appointmentNumber?: number | null
  visitSk?: number | null
  visitTimeUtc?: string | null
  customerId?: string
  serviceId?: string
}
