import { AddressLatest } from '@schemas/api/models/address.cloud.models.core'

export type EnumLiteralsOf<T extends object> = T[keyof T]

export interface VueComponent {
  $parent: VueComponent
  $refs: VueComponent[]
  $children: VueComponent[]
  $options: {
    _componentTag: string
  }
}

export interface GeneratedAddress extends AddressLatest {
  street: string
  secondaryStreet: string
  suburb: string
  state: string
  postCode: string
}

export interface DatesObject {
  from: string
  till: string
}

export interface AllTestCases {
  run: any
  priority: number
  suite: string
  roles: UserRoles[]
  options?: object
}

export interface UserDictionary {
  [userRole: string]: {
    email: string
    password: string
    pin?: string
  }
}

export interface StoredData {
  userIds: string[]
  facilities: string[]
}

export type UserRoles = EnumLiteralsOf<typeof UserRoles>
export const UserRoles = Object.freeze({
  cancerCareAdmin: 'cancerCareAdmin' as 'cancerCareAdmin',
  corporateAdmin: 'corporateAdmin' as 'corporateAdmin',
  nurse: 'nurse' as 'nurse',
  pharmacist: 'pharmacist' as 'pharmacist',
  pharmacyAdmin: 'pharmacyAdmin' as 'pharmacyAdmin',
  pharmacyTechnician: 'pharmacyTechnician' as 'pharmacyTechnician',
  globalAdmin: 'globalAdmin' as 'globalAdmin',
  doctor: 'doctor' as 'doctor',
  accounts: 'accounts' as 'accounts',
})

export const UserDictionary: UserDictionary = Object.freeze({
  [UserRoles.cancerCareAdmin]: { email: Cypress.env('cancerCareAdminEmail'), password: Cypress.env('password') },
  [UserRoles.corporateAdmin]: { email: Cypress.env('corporateAdminEmail'), password: Cypress.env('password') },
  [UserRoles.nurse]: { email: Cypress.env('nurseEmail'), password: Cypress.env('password') },
  [UserRoles.pharmacist]: {
    email: Cypress.env('pharmacistEmail'),
    password: Cypress.env('password'),
    pin: Cypress.env('pharmacistPin'),
  },
  [UserRoles.pharmacyAdmin]: {
    email: Cypress.env('pharmacyAdminEmail'),
    password: Cypress.env('password'),
    pin: Cypress.env('pharmacyAdminPin'),
  },
  [UserRoles.pharmacyTechnician]: {
    email: Cypress.env('pharmacyTechEmail'),
    password: Cypress.env('password'),
    pin: Cypress.env('pharmacyTechPin'),
  },
  [UserRoles.globalAdmin]: { email: Cypress.env('globalAdminEmail'), password: Cypress.env('adminPassword') },
  [UserRoles.doctor]: { email: Cypress.env('doctorEmail'), password: Cypress.env('password') },
})

export type Suites = EnumLiteralsOf<typeof Suites>
export const Suites = Object.freeze({
  scenarios: 'scenario' as 'scenario',
  regression: 'regression' as 'regression',
  integration: 'integration' as 'integration',
  ui: 'ui' as 'ui',
})

export type GrowlTypes = EnumLiteralsOf<typeof GrowlTypes>
export const GrowlTypes = Object.freeze({
  warning: '.growl-warning' as '.growl-warning',
  success: '.growl-notice' as '.growl-notice',
  error: '.growl-error' as '.growl-error',
})

export interface RouteDetails {
  method: string
  url: string
  alias: string
  check?: (snapshotName: string) => Cypress.Chainable
  request?: (params: object) => Cypress.Chainable
}
