import { MedicalServiceLatest } from '@schemas/api/models/medicalService.cloud.models.core'
import { VueComponent } from './general.types'

/**
 * List of service types.
 */
export const ServiceTypesList = Object.freeze({
  Hospital: 'hospital',
  HospitalAlt: 'hospitalAlt',
  WalkIn: 'walkIn',
  WalkInAlt: 'walkInAlt',
  AgedCare: 'agedCare',
  AgedCareAlt: 'agedCareAlt',
  MedicalOncologyConsultation: 'medicalOncologyConsultation',
  MedicalOncologyConsultationAlt: 'medicalOncologyConsultationAlt',
  MedicalOncologyTreatment: 'medicalOncologyTreatment',
  MedicalOncologyTreatmentAlt: 'medicalOncologyTreatmentAlt',
  RadiationOncologyConsultation: 'radiationOncologyConsultation',
  RadiationOncologyConsultationAlt: 'radiationOncologyConsultationAlt',
  RadiationOncologyTreatment: 'radiationOncologyTreatment',
  RadiationOncologyTreatmentAlt: 'radiationOncologyTreatmentAlt',
})

export interface ServiceObjectBasic {
  facilityType: number
  facilityTypeString: string
  serviceType: string
  pharmacyId: number
  facilityName: string
  facilityCode: string
  facilityId: string
  facilityWardName: string
  facilityWardCode: string
  facilityWardNameAlternate?: string
  facilityWardCodeAlternate?: string
  facilityAddress?: string
  facilitySuburb?: string
  facilityState?: string
  facilityPostcode?: string
  roomNumber?: number
  bedNumber?: number
  urn?: number
  status: string
  healthFundId?: string
  healthFundMembershipNumber?: number
  healthFundExpiry?: string
  healthFundCoverLevel?: string
  admissionNumber?: number
  identifiers?: {
    key: string
    value: string
  }[]
}

export interface InactiveServiceOptions {
  inactiveReason: string
  inactiveOtherReason?: string
}

export interface AddHealthFundInfo {
  healthFundId: string
  coverLevel: string
  membershipNumber: string
}

export interface AddAdditionalIdentifier {
  typeValue: 'tcid' | 'gpid' | 'rcid'
  identifierType: string
  identifierValue: string
}

export interface ServiceDetails {
  serviceName: string
  type: string
  facilityName: string
  wardName: string
  serviceGenerator: () => MedicalServiceLatest
}

export interface PatientServicesVue {
  $parent: VueComponent
  $refs: {
    servicesList: {
      onServiceAdded: (serviceType: string, facilityCode: string, wardCode: string) => null
    }
  }
  onServiceAdded: (serviceType: string, facilityCode: string, wardCode: string) => null
}
