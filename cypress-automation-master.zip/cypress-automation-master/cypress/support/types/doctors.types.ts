export interface DoctorDetails {
  fullName: string
  prescriberNumber: string
  practiceName: string
  providerNumber: string
}

export interface SearchForDoctorOptions {
  searchMethodSelector: string
  searchTerm: string
}
