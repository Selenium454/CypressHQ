import { GeneratedAddress } from './general.types'
import { PatientLatest } from '@schemas/api/models/patient.cloud.models.core'
import { ContactLatest } from '@schemas/api/models/contact.cloud.models.core'
import { RegistrationModelLatest } from '@schemas/api/models/registrationModel.models.webApi.cloudServices'
import {
  RepatCardTypeValues,
  RelationshipValues,
  AustralianSouthSeaIslanderStatusValues,
  EthnicGroupValues,
  IndigenousStatusValues,
  MaritalStatusValues,
  SexValues,
} from '@schemas/api/types'

export interface GeneratedPatient extends PatientLatest {
  activeInHub: boolean
  medicationInstructions: string
  allergies: string
  concessionNumber: string
  concessionType: string
  concessionValidToDate: string
  ctg: boolean
  medicareFirstName: string
  medicareNumber: string
  medicareSurName: string
  medicareValidDate: string
  repatCardType: typeof RepatCardTypeValues[number]
  repatNumber: string
  safetyNetNumber: string
}

export interface GeneratedContact extends ContactLatest {
  address: GeneratedAddress
  email: string
  isMainContact: boolean
  phoneNumber: string
  mobileNumber: string
  relationship: typeof RelationshipValues[number]
}

export enum CustomerSex {
  unknown = 0,
  male,
  female,
  other,
}

export interface PatientPersonalDetailsFormVue {
  setPatientAddress: () => null
  setPatientDetails: () => null
}

/**
 * Typing for a generic intervention object.
 */
export interface Intervention {
  consequenceImpact: string
  content: string
  drugNames: string[]
  drugProblem: string
  drugProblemDetails: string
  facilityCode: string
  facilityName: string
  fromDate: string
  id: string
  interventionDate: string
  likelihood: string
  pharmacyId: string
  pharmacyName: string
  recommendation: string
  recommendationDetails: string
  roundCode: string
  roundName: string
  urNumber: string
  userReference: string
  writtenBy: string
}

export interface GeneratedRegistrationModel extends RegistrationModelLatest {
  address: GeneratedAddress
  australianSouthSeaIslanderStatus: typeof AustralianSouthSeaIslanderStatusValues[number]
  countryOfBirth: string
  dateOfBirth: string
  email: string
  employmentStatus: string
  ethnicGroup: typeof EthnicGroupValues[number]
  title: string
  middleName: string
  preferredName: string
  indigenousStatus: typeof IndigenousStatusValues[number]
  language: string
  maritalStatus: typeof MaritalStatusValues[number]
  mobileNumber: string
  phoneNumber: string
  nationality: string
  sex: typeof SexValues[number]
  timeZoneId: string
  patient: GeneratedPatient
}
