import { DeliveryTypeValues, OrderContextValues } from '@schemas/api/types/models.types'
import * as moment from 'moment'

export interface Customs {
  orderFor: string
  comment: string
  deliveryType?: typeof DeliveryTypeValues[number] | null
  dueTime?: moment.Moment
  tags?: string | null
  wardCode?: string
  urn?: string
  numberOfPhotos?: number
}

export interface CreateChartJob {
  context: typeof OrderContextValues[number]
  orderFor: string
  comment?: string
  deliveryType?: typeof DeliveryTypeValues[number] | null
  dueTime?: moment.Moment
  tags?: string | null
  wardCode?: string
  urn?: string
  numberOfPhotos?: number
  snapshotName: string
}

/**
 * Object containing the current due time options in health director.
 */
export const dueTimes = Object.freeze({
  hour: 'hour',
  today: 'today',
  tomorrow: 'tomorrow',
  other: 'other',
})

/**
 * A dictionary of values associated to each chart job type.
 */
export const chartJobTypes: ChartJobTypes = Object.freeze({
  regular: { chartJobType: 'regular', deliveryType: 'regular', tags: null, tagArray: [] },
  urgent: { chartJobType: 'urgent', deliveryType: 'express', tags: null, tagArray: ['#urgentJob'] },
  discharge: {
    chartJobType: 'discharge',
    deliveryType: 'regular',
    tags: 'discharged',
    tagArray: ['#dischargeJob'],
  },
  urgentDischarge: {
    chartJobType: 'urgentDischarge',
    deliveryType: 'express',
    tags: 'discharged',
    tagArray: ['#urgentJob', '#dischargeJob'],
  },
})

/**
 * Dictionary of displayed names and the values used for the chartflow statuses.
 */
export const chartJobStatus = Object.freeze({
  pick: { status: 'Pick', displayName: 'Picked', value: 'picked' },
  label: { status: 'Label', displayName: 'Labeled', value: 'dispensed' },
  check: { status: 'Check', displayName: 'Checked', value: 'dispatched' },
  completed: { status: 'Completed', displayName: 'Completed', value: 'dispatched' },
  hold: { status: 'Hold', displayName: 'On Hold', value: 'onHold' },
  cancel: { status: 'Cancel', displayName: 'Cancel', value: 'notSupplied' },
})

export interface ChartJobType {
  chartJobType: string
  deliveryType: typeof DeliveryTypeValues[number]
  tags: string | null
  tagArray: string[]
}

export interface ChartJobTypes {
  regular: ChartJobType
  urgent: ChartJobType
  discharge: ChartJobType
  urgentDischarge: ChartJobType
}
