export const searchTypeList = Object.freeze({
  Surname: 'surname',
  Medicare: 'medicare',
  Urn: 'urn',
  CustomerId: 'customerId',
})

export const searchTypes: SearchTypes = Object.freeze({
  [searchTypeList.Surname]: { autoSearch: true, name: 'name', searchTypeSelector: '#patientSearchByname' },
  [searchTypeList.Medicare]: {
    autoSearch: false,
    name: 'medicare',
    searchTypeSelector: '#patientSearchBymedicare',
  },
  [searchTypeList.Urn]: { autoSearch: false, name: 'URN', searchTypeSelector: '#patientSearchByurn' },
  [searchTypeList.CustomerId]: {
    autoSearch: false,
    name: 'customer ID',
    searchTypeSelector: '#patientSearchByhubId',
  },
})

export interface SearchResult {
  data: {
    activeInHub: boolean
    dateOfBirth: string
    fullName: string
    medicareNumber: string
    nonActiveReason: string
    roles: string
    score: number
    services: []
    userId: string
  }[]
}

export interface SearchType {
  autoSearch: boolean
  name: string
  searchTypeSelector: string
}

export interface SearchTypes {
  [searchType: string]: SearchType
}
