export const UsersRoutes = Object.freeze({
  GetUsersDetails: {
    method: 'GET',
    url: '**/user/details',
    alias: 'getUsersDetails',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add schema checks.
        }
        return { response }
      })
    },
  },
  GetUsersLogin: {
    method: 'GET',
    url: '**/users/login',
    alias: 'getUsersLogin',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add schema checks.
        }
        return { response }
      })
    },
  },
  GetUsersPrincipalName: {
    method: 'GET',
    url: '**/users/principalName',
    alias: 'getUsersPrincipalName',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add schema checks.
        }
        return { response }
      })
    },
  },
  PostUsersHubId: {
    method: 'POST',
    url: '**/users/hubId',
    alias: 'postUsersHubId',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add schema checks.
        }
        return { request, response }
      })
    },
  },
  GetUsersPreferences: {
    method: 'GET',
    url: '**/user/preferences',
    alias: 'getUsersPreferences',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add schema checks.
        }
        return { response }
      })
    },
  },
  PutUsersPreferences: {
    method: 'PUT',
    url: '**/users/preferences',
    alias: 'putUsersPreferences',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add schema checks.
        }
        return { request, response }
      })
    },
  },
  CheckUserSessionValid: {
    method: 'GET',
    url: '**/auth/isUserSessionStillValid',
    alias: 'checkUserSessionValid',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add schema checks.
        }
        return { response }
      })
    },
  },
})
