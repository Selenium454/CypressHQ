export const AuditRoutes = Object.freeze({
  GetAudit: {
    method: 'GET',
    url: '**/audit',
    alias: 'getAudit',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  PostAudit: {
    method: 'POST',
    url: '**/audit',
    alias: 'postAudit',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
  },
})
