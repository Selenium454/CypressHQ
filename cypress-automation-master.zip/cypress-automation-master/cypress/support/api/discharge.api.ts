export const DischargeRoutes = Object.freeze({
  PostDischargeReport: {
    method: 'POST',
    url: '**/discharge/report',
    alias: 'postDischargeReport',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
  },
})
