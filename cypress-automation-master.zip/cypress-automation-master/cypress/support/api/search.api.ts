export const SearchRoutes = Object.freeze({
  GetSearchByName: {
    method: 'GET',
    url: '**/search/hub?searchBy=name*', //ENDPOINT: '**/search/byName
    alias: 'getSearchByName',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add schema checks.
        }
        return { response }
      })
    },
    request: function(textToSearch: string) {
      let counter: number = 0

      const maxCounter: number = 60,
        url: string = encodeURI(Cypress.env('ENV_URL') + '/Search/ByName?textToSearch=' + textToSearch)

      const requestBody: Partial<Cypress.RequestOptions> = {
        method: 'GET',
        form: true,
        url,
        headers: {
          Authorization: 'Bearer ' + Cypress.env('ACCESS_TOKEN'),
        },
      }

      return cy.request(requestBody).then(response => {
        //TODO: Change this to polling
        if (response.body.model.length === 0 && counter < maxCounter) {
          counter += 1
          this.request(textToSearch)
        } else {
          return response.body
        }
      })
    },
  },
  GetSearchByEmail: {
    method: 'GET',
    url: '**/search/byEmail',
    alias: 'getSearchByEmail',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add schema checks.
        }
        return { response }
      })
    },
  },
  GetSearchByMedicare: {
    method: 'GET',
    url: '**/search/hub?searchBy=medicare*', //ENDPOINT: '**/search/byMedicare'
    alias: 'getSearchByMedicare',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add schema checks.
        }
        return { response }
      })
    },
  },
  PostSearchByUrn: {
    method: 'GET', //ENDPOINT: 'POST'
    url: '**/search/hub?searchBy=urn*', //ENDPOINT: '**/search/byUrn'
    alias: 'postSearchByUrn',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add schema checks.
        }
        return { request, response }
      })
    },
  },
  GetSearchById: {
    method: 'GET',
    url: '**/search/hub?searchBy=hubId*', //ENDPOINT: '**/search/byID'
    alias: 'getSearchById',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add schema checks.
        }
        return { response }
      })
    },
  },
})
