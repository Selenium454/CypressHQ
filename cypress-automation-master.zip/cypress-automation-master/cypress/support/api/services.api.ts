import { PostServicesAddRequestLatest, PostServicesAddResponseLatest } from '@schemas/api/endpoints/services/add.post'
import {
  PutServicesUpdateRequestLatest,
  PutServicesUpdateResponseLatest,
} from '@schemas/api/endpoints/services/update.put'
import {
  DeleteServicesDeleteRequestLatest,
  DeleteServicesDeleteResponseLatest,
} from '@schemas/api/endpoints/services/delete.delete'
import { GetServicesAllResponseLatest } from '@schemas/api/endpoints/services/all.get'
import { pollRequest } from './general.api'

export const ServicesRoutes = Object.freeze({
  PostServicesByUserIdAdd: {
    method: 'POST',
    url: '**/services/*/add',
    alias: 'postServicesByUserIdAdd',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody as PostServicesAddRequestLatest
        const response = $xhrRequest.responseBody as PostServicesAddResponseLatest
        if (snapshotName) {
          //TODO: Add schema checks.
        }
        return { request, response }
      })
    },
    request: function(params: { customerId: string; body: PostServicesAddRequestLatest }) {
      const { customerId, body } = params
      const bearer = Cypress.env('ACCESS_TOKEN') ? Cypress.env('ACCESS_TOKEN') : Cypress.env('GA_ACCESS_TOKEN')
      const url = encodeURI(`${Cypress.env('ENV_URL')}/Services/${customerId}/Add`)
      const requestBody: Partial<Cypress.RequestOptions> = {
        method: 'POST',
        url,
        headers: {
          Authorization: `Bearer ${bearer}`,
        },
        body,
      }

      const maxRetries: number = 5
      let tries: number = 0

      return cy.request(requestBody).then(response => {
        if (response.status === 200) {
          return response
        } else {
          tries += 1
          pollRequest({
            callbackFunction: this.request,
            callbackParams: { customerId, body },
            tries: tries,
            maxRetries: maxRetries,
          })
        }
      })
    },
  },
  DeleteServicesByUserIdDelete: {
    method: 'DELETE',
    url: '**/services/*/delete',
    alias: 'deleteServicesByUserIdDelete',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody as DeleteServicesDeleteResponseLatest
        if (snapshotName) {
          //TODO: Add schema checks.
        }
        return { response }
      })
    },
    request: function(params: { customerId: string; body: DeleteServicesDeleteRequestLatest }) {
      const { customerId, body } = params
      const bearer = Cypress.env('ACCESS_TOKEN') ? Cypress.env('ACCESS_TOKEN') : Cypress.env('GA_ACCESS_TOKEN')
      const url = encodeURI(`${Cypress.env('ENV_URL')}/Services/${customerId}/Delete`)
      const requestBody: Partial<Cypress.RequestOptions> = {
        method: 'DELETE',
        url,
        headers: {
          Authorization: `Bearer ${bearer}`,
        },
        body,
        retryOnStatusCodeFailure: true,
      }

      return cy.request(requestBody).then(response => {
        return response
      })
    },
  },
  GetServicesByUserIdAll: {
    method: 'GET',
    url: '**/customer/profile/*/all', //ENDPOINT: '**/services/*/all'
    alias: 'getServicesByUserIdAll',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody as GetServicesAllResponseLatest
        if (snapshotName) {
          //TODO: Add schema checks.
        }
        return { response }
      })
    },
    request: function(params: { customerId: string }) {
      const { customerId } = params
      const bearer = Cypress.env('ACCESS_TOKEN') ? Cypress.env('ACCESS_TOKEN') : Cypress.env('GA_ACCESS_TOKEN')
      const url = encodeURI(`${Cypress.env('ENV_URL')}/Services/${customerId}/All`)
      const requestBody: Partial<Cypress.RequestOptions> = {
        method: 'GET',
        url,
        headers: {
          Authorization: `Bearer ${bearer}`,
        },
        retryOnStatusCodeFailure: true,
      }

      return cy.request(requestBody).then(response => {
        return response
      })
    },
  },
  PutServicesByUserIdUpdate: {
    method: 'POST',
    url: '**/profile/*/update', //ENDPOINT: '**/services/*/update'
    alias: 'putServicesByUserIdUpdate',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody as PutServicesUpdateRequestLatest
        const response = $xhrRequest.responseBody as PutServicesUpdateResponseLatest
        if (snapshotName) {
          //TODO: Add schema checks.
        }
        return { request, response }
      })
    },
    request: function(params: { customerId: string; body: PutServicesUpdateRequestLatest }) {
      const { customerId, body } = params
      const bearer = Cypress.env('ACCESS_TOKEN') ? Cypress.env('ACCESS_TOKEN') : Cypress.env('GA_ACCESS_TOKEN')
      const url = encodeURI(`${Cypress.env('ENV_URL')}/Services/${customerId}/Update`)
      const requestBody: Partial<Cypress.RequestOptions> = {
        method: 'PUT',
        url,
        headers: {
          Authorization: `Bearer ${bearer}`,
        },
        body,
        retryOnStatusCodeFailure: true,
      }

      const maxRetries: number = 5
      let tries: number = 0

      return cy.request(requestBody).then(response => {
        if (response.status === 200) {
          return response
        } else {
          tries += 1
          pollRequest({
            callbackFunction: this.request,
            callbackParams: { customerId, body },
            tries: tries,
            maxRetries: maxRetries,
          })
        }
      })
    },
  },

  //Only used on profile
  ProfilePostServicesByUserIdAdd: {
    method: 'POST',
    url: '**/customer/profile/*/add',
    alias: 'postServicesByUserIdAdd',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody as PostServicesAddRequestLatest
        const response = $xhrRequest.responseBody as PostServicesAddResponseLatest
        if (snapshotName) {
          //TODO: Add schema checks.
        }
        return { request, response }
      })
    },
  },
})
