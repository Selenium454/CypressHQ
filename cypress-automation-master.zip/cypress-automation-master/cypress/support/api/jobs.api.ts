export const JobsRoutes = Object.freeze({
  GetJobsDischarge: {
    method: 'GET',
    url: '**/jobs/discharge',
    alias: 'getJobsDischarge',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  PostJobsDischarge: {
    method: 'POST',
    url: '**/jobs/discharge',
    alias: 'postJobsDischarge',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
  },
  GetJobsFacility: {
    method: 'GET',
    url: '**/jobs/facility',
    alias: 'getJobsFacility',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  GetJobsPharmacy: {
    method: 'GET',
    url: '**/jobs/pharmacy',
    alias: 'getJobsPharmacy',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  GetJobsOrders: {
    method: 'GET',
    url: '**/jobs/orders',
    alias: 'getJobsOrders',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  PostJobsOrders: {
    method: 'POST',
    url: '**/pharmacy/update-chart-job', //ENDPOINT: '**/jobs/orders'
    alias: 'postJobsOrders',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
  },
  PostJobsLockByType: {
    method: 'POST',
    url: '**/jobs/lock/*',
    alias: 'postJobsLockByType',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
  },
  PostJobsUnlockByType: {
    method: 'POST',
    url: '**/jobs/unlock/*',
    alias: 'postJobsUnlockByType',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
  },
})
