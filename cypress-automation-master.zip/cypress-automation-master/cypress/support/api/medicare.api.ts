export const MedicareRoutes = Object.freeze({
  GetMedicareJobs: {
    method: 'GET',
    url: '**/medicare/jobs',
    alias: 'getMedicareJobs',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  GetMedicarePage: {
    method: 'GET',
    url: '**/medicare/page',
    alias: 'getMedicarePage',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  GetMedicareSearch: {
    method: 'GET',
    url: '**/medicare/search',
    alias: 'getMedicareSearch',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  PostMedicareSearch: {
    method: 'POST',
    url: '**/medicare/search',
    alias: 'postMedicareSearch',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
  },
  PutMedicareHide: {
    method: 'PUT',
    url: '**/medicare/hide',
    alias: 'putMedicareHide',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
  },
  PutMedicareRestore: {
    method: 'PUT',
    url: '**/medicare/restore',
    alias: 'putMedicareRestore',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
  },
  PutMedicareUpdate: {
    method: 'PUT',
    url: '**/medicare/update',
    alias: 'putMedicareUpdate',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
  },
  PostMedicareValidate: {
    method: 'POST',
    url: '**/medicare/validate',
    alias: 'postMedicareValidate',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
  },
  PostMedicareValidateMedicare: {
    method: 'POST',
    url: '**/medicare/validateMedicare',
    alias: 'postMedicareValidateMedicare',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
  },
  PostMedicareValidateRepat: {
    method: 'POST',
    url: '**/repat-validate?repatNumber=**', //TODO: /medicare/validateRepat
    alias: 'postMedicareValidateRepat',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
  },
})
