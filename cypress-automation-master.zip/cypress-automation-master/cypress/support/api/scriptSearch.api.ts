export const ScriptSearchRoutes = Object.freeze({
  PostScriptSearch: {
    method: 'POST',
    url: '**/script/search',
    alias: 'postScriptSearch',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add schema checks.
        }
        return { request, response }
      })
    },
  },
})
