export const VisitsRoutes = Object.freeze({
  DeleteVisits: {
    method: 'DELETE',
    url: '**/visits',
    alias: 'deleteVisits',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add schema checks.
        }
        return { response }
      })
    },
  },
  PostVisits: {
    method: 'POST',
    url: '**/visits',
    alias: 'postVisits',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add schema checks.
        }
        return { request, response }
      })
    },
  },
  PutVisits: {
    method: 'PUT',
    url: '**/visit/*', //ENDPOINT: **/visits',
    alias: 'putVisits',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add schema checks.
        }
        return { request, response }
      })
    },
  },
  PostVisitsSearch: {
    method: 'POST',
    url: '**/visits/search',
    alias: 'postVisitsSearch',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add schema checks.
        }
        return { request, response }
      })
    },
  },
  GetVisitsById: {
    method: 'GET',
    url: '**/visit/*', //ENDPOINT: '**/visits/*',
    alias: 'getVisitsById',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add schema checks.
        }
        return { response }
      })
    },
  },
  GetVisitsCodes: {
    method: 'GET',
    url: '**/visits/codes',
    alias: 'getVisitsCodes',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add schema checks.
        }
        return { response }
      })
    },
  },
})
