export const CorporateRoutes = Object.freeze({
  DeleteCorporate: {
    method: 'DELETE',
    url: '**/corporate',
    alias: 'deleteCorporate',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  PostCorporate: {
    method: 'POST',
    url: '**/corporate',
    alias: 'postCorporate',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
  },
  PutCorporate: {
    method: 'PUT',
    url: '**/corporate',
    alias: 'putCorporate',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
  },
  GetCorporateBusinessUnits: {
    method: 'GET',
    url: '**/corporate/businessUnits',
    alias: 'getCorporateBusinessUnits',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  GetCorporateDomain: {
    method: 'GET',
    url: '**/corporate/domain',
    alias: 'getCorporateDomain',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  GetCorporateAll: {
    method: 'GET',
    url: '**/corporate/all',
    alias: 'getCorporateAll',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  GetCorporateEmployees: {
    method: 'GET',
    url: '**/corporate/employees',
    alias: 'getCorporateEmployees',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
})
