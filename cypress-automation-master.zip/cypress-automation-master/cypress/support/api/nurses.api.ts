export const NursesRoutes = Object.freeze({
  GetMedicationsFutureView: {
    method: 'GET',
    url: '**/medications/futureView',
    alias: 'getMedicationsFutureView',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  GetMedicationsDetails: {
    method: 'GET',
    url: '**/medications/details',
    alias: 'getMedicationsDetails',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  GetMedicationsDetailsFacility: {
    method: 'GET',
    url: '**/medications/detailsFacility',
    alias: 'getMedicationsDetailsFacility',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
})
