export const setupAdmissionRoutes = () => {}

export const AdmissionsRoutes = Object.freeze({
  GetAdmissionGenerateAdmissionNumber: {
    method: 'GET',
    url: '**/admission/generateAdmissionNumber',
    alias: 'getAdmissionGenerateAdmissionNumber',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  GetAdmissionDocument: {
    method: 'GET',
    url: '**/admission/document',
    alias: 'getAdmissionDocument',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  GetAdmissionCurrent: {
    method: 'GET',
    url: '**/admission/current',
    alias: 'getAdmissionCurrent',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  GetAdmissionRecentFacility: {
    method: 'GET',
    url: '**/admission/recentFacility',
    alias: 'getAdmissionRecentFacility',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  GetAdmissionRecent: {
    method: 'GET',
    url: '**/admission/recent',
    alias: 'getAdmissionRecent',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  PutAdmissionUpdate: {
    method: 'PUT',
    url: '**/admission/update',
    alias: 'putAdmissionUpdate',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
  },
})
