export const BusinessUnitRoutes = Object.freeze({
  DeleteBusinessUnit: {
    method: 'DELETE',
    url: '**/businessUnit',
    alias: 'deleteBusinessUnit',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  PostBusinessUnit: {
    method: 'POST',
    url: '**/businessUnit',
    alias: 'postBusinessUnit',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
  },
  PutBusinessUnit: {
    method: 'PUT',
    url: '**/businessUnit',
    alias: 'putBusinessUnit',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
  },
  GetBusinessUnitAll: {
    method: 'GET',
    url: '**/businessUnit',
    alias: 'getBusinessUnitAll',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  DeleteBusinessUnitEmployee: {
    method: 'DELETE',
    url: '**/businessUnit/employee',
    alias: 'deleteBusinessUnitEmployee',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  GetBusinessUnitEmployee: {
    method: 'GET',
    url: '**/businessUnit/employee',
    alias: 'getBusinessUnitEmployee',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  PutBusinessUnitEmployee: {
    method: 'PUT',
    url: '**/businessUnit/employee',
    alias: 'putBusinessUnitEmployee',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
  },
  GetBusinessUnitAssociatedBusinessUnits: {
    method: 'GET',
    url: '**/businessUnit/associatedBusinessUnits',
    alias: 'getBusinessUnitAssociatedBusinessUnits',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  GetBusinessUnitById: {
    method: 'GET',
    url: '**/businessUnit/*',
    alias: 'getBusinessUnitById',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
})
