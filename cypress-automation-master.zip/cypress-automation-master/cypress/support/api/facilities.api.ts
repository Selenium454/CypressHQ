export const FacilitiesRoutes = Object.freeze({
  DeleteFacilities: {
    method: 'DELETE',
    url: '**/facilities',
    alias: 'deleteFacilities',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
    request: function(facilityCode: string) {
      const bearer = Cypress.env('GA_ACCESS_TOKEN')
      const url: string = encodeURI(`${Cypress.env('ENV_URL')}/Facilities?facilityCode=${facilityCode}`)
      const requestBody: Partial<Cypress.RequestOptions> = {
        method: 'DELETE',
        form: false,
        url,
        headers: {
          Authorization: `Bearer ${bearer}`,
          'Content-Type': 'application/json',
        },
      }

      return cy.request(requestBody).then(response => {
        return response.body
      })
    },
  },
  GetFacilities: {
    method: 'GET',
    url: '**/facilities/facilities',
    alias: 'getFacilities',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  PostFacilities: {
    method: 'POST',
    url: '**/facilities',
    alias: 'postFacilities',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
  },
  PutFacilities: {
    method: 'PUT',
    url: '**/facilities',
    alias: 'putFacilities',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
  },
  PostFacilitiesOfPharmacies: {
    method: 'POST',
    url: '**/facilities/ofPharmacies',
    alias: 'postFacilitiesOfPharmacies',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
  },
  GetFacilitiesCodeByFacilityCode: {
    method: 'GET',
    url: '**/facilities/code/*',
    alias: 'getFacilitiesCodeByFacilityCode',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  GetFacilitiesTenantByTenantId: {
    method: 'GET',
    url: '**/facilities/tenant/*',
    alias: 'getFacilitiesTenantByTenantId',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  GetFacilitiesPatientsInWards: {
    method: 'GET',
    url: '**/facilities/patientsInWards',
    alias: 'getFacilitiesPatientsInWards',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  GetFacilitiesWards: {
    method: 'GET',
    url: '**/facilities/wards',
    alias: 'getFacilitiesWards',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
})
