import {
  PostDoctorsSearchRequestLatest,
  PostDoctorsSearchResponseLatest,
} from '@schemas/api/endpoints/doctors/search.post'

import { pollRequest } from './general.api'

export const DoctorsRoutes = Object.freeze({
  PostDoctors: {
    method: 'POST',
    url: '**/doctors',
    alias: 'postDoctors',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
  },
  PutDoctors: {
    method: 'PUT',
    url: '**/doctors',
    alias: 'putDoctors',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
  },
  GetDoctorsAll: {
    method: 'GET',
    url: '**/doctors/all',
    alias: 'getDoctorsAll',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  GetDoctorsById: {
    method: 'GET',
    url: '**/doctors/*',
    alias: 'getDoctorsById',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  GetDoctorsAvailabilityEmail: {
    method: 'GET',
    url: '**/doctors/availability/email',
    alias: 'getDoctorsAvailabilityEmail',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  GetDoctorsAvailabilityPrescriber: {
    method: 'GET',
    url: '**/doctors/availability/prescriber',
    alias: 'getDoctorsAvailabilityPrescriber',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  GetDoctorsAvailabilityProvider: {
    method: 'GET',
    url: '**/doctors/availability/provider',
    alias: 'getDoctorsAvailabilityProvider',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  PostDoctorsSearch: {
    method: 'POST',
    url: '**/doctor/search', //ENDPOINT: '**/doctors/search'
    alias: 'postDoctorsSearch',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody as PostDoctorsSearchRequestLatest
        const response = $xhrRequest.responseBody as PostDoctorsSearchResponseLatest
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
    request: function(params: { filter: PostDoctorsSearchRequestLatest; tries?: number }) {
      const { filter } = params
      const bearer = Cypress.env('ACCESS_TOKEN') ? Cypress.env('ACCESS_TOKEN') : Cypress.env('GA_ACCESS_TOKEN')
      const url = encodeURI(`${Cypress.env('ENV_URL')}/Dcotors/Search`)
      const requestBody: Partial<Cypress.RequestOptions> = {
        method: 'POST',
        form: true,
        url,
        headers: {
          Authorization: `Bearer ${bearer}`,
        },
        body: filter,
      }

      const maxRetries: number = 5
      let { tries = 0 } = params

      return cy.request(requestBody).then(response => {
        if (response.status === 200) {
          return response
        } else {
          tries += 1
          pollRequest({
            callbackFunction: this.request,
            callbackParams: { filter },
            tries: tries,
            maxRetries: maxRetries,
          })
        }
      })
    },
  },
  GetDoctorsSearchPracticesByDoctorName: {
    method: 'GET',
    url: '**/doctors/searchPracticesByDoctorName',
    alias: 'getDoctorsSearchPracticesByDoctorName',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  DeleteDoctorDoctor: {
    method: 'DELETE',
    url: '**/doctors/doctor',
    alias: 'deleteDoctorDoctor',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
})
