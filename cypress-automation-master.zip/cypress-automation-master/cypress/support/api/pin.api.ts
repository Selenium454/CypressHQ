export const PinRoutes = Object.freeze({
  PostPinCreate: {
    method: 'POST',
    url: '**/PIN/create',
    alias: 'postPinCreate',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add schema checks.
        }
        return { request, response }
      })
    },
  },
  PutPinChange: {
    method: 'PUT',
    url: '**/PIN/change',
    alias: 'putPinChange',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add schema checks.
        }
        return { request, response }
      })
    },
  },
  GetPinReset: {
    method: 'GET',
    url: '**/PIN/reset',
    alias: 'getPinReset',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add schema checks.
        }
        return { response }
      })
    },
  },
  GetPinAuthenticate: {
    method: 'GET',
    url: '**/PIN/authenticate',
    alias: 'getPinAuthenticate',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add schema checks.
        }
        return { response }
      })
    },
  },
})
