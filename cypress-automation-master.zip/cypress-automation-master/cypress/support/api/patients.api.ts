import { SearchPatientFilterLatest } from '@schemas/api/models/searchPatientFilter.search.core'
import { RegistrationModelLatest } from '@schemas/api/models/registrationModel.models.webApi.cloudServices'
import {
  PutPatientsDetailsRequestLatest,
  PutPatientsDetailsResponseLatest,
  PutPatientsDetailsRequestSchema,
  PutPatientsDetailsResponseSchema,
} from '@schemas/api/endpoints/patients/details.put'
import { ContactLatest } from '@schemas/api/models/contact.cloud.models.core'
import {
  PostPatientsSearchRequestLatest,
  PostPatientsSearchResponseLatest,
} from '@schemas/api/endpoints/patients/search.post'
import {
  PostPatientsRegisterRequestLatest,
  PostPatientsRegisterResponseLatest,
} from '@schemas/api/endpoints/patients/register.post'
import { GetPatientsInterventionsResponseLatest } from '@schemas/api/endpoints/patients/interventions.get'
import {
  PostPatientsInterventionsRequestLatest,
  PostPatientsInterventionsResponseLatest,
} from '@schemas/api/endpoints/patients/interventions.post'
import {
  PutPatientsInterventionsRequestLatest,
  PutPatientsInterventionsResponseLatest,
} from '@schemas/api/endpoints/patients/interventions.put'
import { GetPatientsDetailsResponseLatest } from '@schemas/api/endpoints/patients/details.get'
import { GetPatientsBillingResponseLatest } from '@schemas/api/endpoints/patients/billing.get'
import {
  PutPatientsBillingRequestLatest,
  PutPatientsBillingResponseLatest,
} from '@schemas/api/endpoints/patients/billing.put'
import { GetPatientsContactsResponseLatest } from '@schemas/api/endpoints/patients/contacts.get'
import {
  PostPatientsContactsRequestLatest,
  PostPatientsContactsResponseLatest,
} from '@schemas/api/endpoints/patients/contacts.post'
import {
  PostPatientsCreditCardDetailsRequestLatest,
  PostPatientsCreditCardDetailsResponseLatest,
} from '@schemas/api/endpoints/patients/creditCardDetails.post'
import {
  PostPatientsBankDetailsRequestLatest,
  PostPatientsBankDetailsResponseLatest,
} from '@schemas/api/endpoints/patients/bankDetails.post'
import { checkResponse, checkRequest } from './general.api'

export const PatientsRoutes = Object.freeze({
  PostPatientsSearch: {
    method: 'GET', //METHOD: 'POST'
    url: '**/search/hub?*', //ENDPOINT: '**/patients/search'
    alias: 'postPatientsSearch',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
    request: (params: { body: SearchPatientFilterLatest }) => {
      const { body } = params
      const bearer = Cypress.env('ACCESS_TOKEN') ? Cypress.env('ACCESS_TOKEN') : Cypress.env('GA_ACCESS_TOKEN')
      const url: string = encodeURI(`${Cypress.env('ENV_URL')}/Patients/Search`)
      const requestBody: Partial<Cypress.RequestOptions> = {
        method: 'POST',
        form: true,
        url,
        headers: {
          Authorization: `Bearer ${bearer}`,
        },
        body,
      }

      return cy.request(requestBody).then(response => {
        return response
      })
    },
  },
  PostPatientsRegister: {
    method: 'POST',
    url: '**/customer/create', //ENDPOINT: '**/customer/register'
    alias: 'postPatientsRegister',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody as PostPatientsRegisterRequestLatest
        const response = $xhrRequest.responseBody as PostPatientsRegisterResponseLatest
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
    request: (params: { model: RegistrationModelLatest }) => {
      const { model } = params
      const body = JSON.stringify(model)
      const bearer = Cypress.env('ACCESS_TOKEN') ? Cypress.env('ACCESS_TOKEN') : Cypress.env('GA_ACCESS_TOKEN')
      const url = encodeURI(`${Cypress.env('ENV_URL')}/Patients/Register`)
      const requestBody: Partial<Cypress.RequestOptions> = {
        method: 'POST',
        url,
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${bearer}`,
        },
        body,
      }

      return cy.request(requestBody).then(response => {
        cy.task('storeUserIdForDeletion', response.body.model)
        return cy.wrap(response)
      })
    },
  },
  DeletePatientsByUserIdInterventions: {
    method: 'DELETE',
    url: '**/patients/*/interventions',
    alias: 'deletePatientsByUserIdInterventions',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
  },
  GetPatientByUserIdInterventions: {
    method: 'GET',
    url: '**/patients/*/interventions',
    alias: 'getPatientByUserIdInterventions',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody as GetPatientsInterventionsResponseLatest
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  PostPatientByUserIdInterventions: {
    method: 'POST',
    url: '**/patients/*/interventions',
    alias: 'postPatientByUserIdInterventions',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody as PostPatientsInterventionsRequestLatest
        const response = $xhrRequest.responseBody as PostPatientsInterventionsResponseLatest
        if (snapshotName) {
          //TODO: Add schema checks.
        }
        return { request, response }
      })
    },
  },
  PutPatientByUserIdInterventions: {
    method: 'PUT',
    url: '**/patients/*/interventions',
    alias: 'putPatientByUserIdInterventions',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody as PutPatientsInterventionsRequestLatest
        const response = $xhrRequest.responseBody as PutPatientsInterventionsResponseLatest
        if (snapshotName) {
          //TODO: Add schema checks.
        }
        return { request, response }
      })
    },
  },
  GetPatientsByUserIdDetails: {
    method: 'GET',
    url: '**/profile/details/*', //ENDPOINT: '**/patients/*/details'
    alias: 'getPatientsByUserIdDetails',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody as GetPatientsDetailsResponseLatest
        if (snapshotName) {
          //TODO: Add schema checks.
        }
        return { response }
      })
    },
    request: (params: { userId: number }) => {
      const { userId } = params
      const bearer = Cypress.env('ACCESS_TOKEN') ? Cypress.env('ACCESS_TOKEN') : Cypress.env('GA_ACCESS_TOKEN')
      const url: string = encodeURI(`${Cypress.env('ENV_URL')}/Patients/${userId}/Details`)
      const requestBody: Partial<Cypress.RequestOptions> = {
        method: 'GET',
        form: true,
        url,
        headers: {
          Authorization: `Bearer ${bearer}`,
        },
      }

      return cy.request(requestBody).then(response => {
        return response
      })
    },
  },
  PutPatientsByUserIdDetails: {
    method: 'POST', //PUT
    url: '**/customer/profile/*/all', //ENDPOINT: '**/patients/*/details'
    alias: 'putPatientsByUserIdDetails',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody as PutPatientsDetailsRequestLatest
        const response = $xhrRequest.responseBody as PutPatientsDetailsResponseLatest

        if (snapshotName) {
          checkRequest<PutPatientsDetailsRequestLatest>({
            schemaName: PutPatientsDetailsRequestSchema,
            request,
            snapshotName,
          })

          checkResponse<PutPatientsDetailsResponseLatest>({
            schemaName: PutPatientsDetailsResponseSchema,
            response,
            snapshotName,
          })
        }

        return { request, response }
      })
    },
    request: (params: { userId: number; body: PutPatientsDetailsRequestLatest }) => {
      const { userId, body } = params
      const bearer = Cypress.env('ACCESS_TOKEN') ? Cypress.env('ACCESS_TOKEN') : Cypress.env('GA_ACCESS_TOKEN')
      const url: string = encodeURI(`${Cypress.env('ENV_URL')}/Patients/${userId}/Details`)
      const requestBody: Partial<Cypress.RequestOptions> = {
        method: 'PUT',
        form: true,
        url,
        headers: {
          Authorization: `Bearer ${bearer}`,
        },
        body,
      }

      return cy.request(requestBody).then(response => {
        return response
      })
    },
  },
  GetPatientsByUserIdBilling: {
    method: 'GET',
    url: '**/patients/*/billing',
    alias: 'getPatientsByUserIdBilling',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody as GetPatientsBillingResponseLatest
        if (snapshotName) {
          //TODO: Add schema checks.
        }
        return { response }
      })
    },
  },
  PutPatientsByUserIdBilling: {
    method: 'PUT',
    url: '**/patients/*/billing',
    alias: 'putPatientsByUserIdBilling',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody as PutPatientsBillingRequestLatest
        const response = $xhrRequest.responseBody as PutPatientsBillingResponseLatest
        if (snapshotName) {
          //TODO: Add schema checks.
        }
        return { request, response }
      })
    },
  },
  GetPatientsByUserIdContacts: {
    method: 'GET',
    url: '**/profile/*/contacts', //ENDPOINT: '**/patients/*/contacts'
    alias: 'getPatientsByUserIdContacts',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody as GetPatientsContactsResponseLatest
        if (snapshotName) {
          //TODO: Add schema checks.
        }
        return { response }
      })
    },
  },
  PostPatientsByUserIdContacts: {
    method: 'POST',
    url: '**/profile/*/contacts', //ENDPOINT: '**/patients/*/contacts'
    alias: 'postPatientsByUserIdContacts',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody as PostPatientsContactsRequestLatest
        const response = $xhrRequest.responseBody as PostPatientsContactsResponseLatest
        if (snapshotName) {
          //TODO: Add schema checks.
        }
        return { request, response }
      })
    },
    request: (params: { userId: string; body: ContactLatest[] }) => {
      const { userId, body } = params
      const bearer = Cypress.env('ACCESS_TOKEN') ? Cypress.env('ACCESS_TOKEN') : Cypress.env('GA_ACCESS_TOKEN')
      const url: string = encodeURI(`${Cypress.env('ENV_URL')}/Patients/${userId}/contacts`)
      const requestBody: Partial<Cypress.RequestOptions> = {
        method: 'POST',
        url,
        headers: {
          Authorization: `Bearer ${bearer}`,
        },
        body,
      }

      return cy.request(requestBody).then(response => {
        return response
      })
    },
  },
  PostPatientsByUserIdCreditCardDetails: {
    method: 'POST',
    url: '**/patients/*/creditCardDetails', //ENDPOINT: '**/patients/*/creditCardDetails'
    alias: 'postPatientsByUserIdCreditCardDetails',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody as PostPatientsCreditCardDetailsRequestLatest
        const response = $xhrRequest.responseBody as PostPatientsCreditCardDetailsResponseLatest
        if (snapshotName) {
          //TODO: Add schema checks.
        }
        return { request, response }
      })
    },
  },
  PostPatientsByUserIdBankDetails: {
    method: 'POST',
    url: '**/patients/*/bankDetails',
    alias: 'postPatientsByUserIdBankDetails',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody as PostPatientsBankDetailsRequestLatest
        const response = $xhrRequest.responseBody as PostPatientsBankDetailsResponseLatest
        if (snapshotName) {
          //TODO: Add schema checks.
        }
        return { request, response }
      })
    },
  },
  DeletePatientsPatient: {
    method: 'DELETE',
    url: '**/patients/patient',
    alias: 'deletePatientsPatient',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add schema checks.
        }
        return { response }
      })
    },
    request: (params: { userIds: string[] }) => {
      const { userIds } = params
      const bearer = Cypress.env('GA_ACCESS_TOKEN')
      const url: string = encodeURI(`${Cypress.env('ENV_URL')}/Patients/Patient`)
      const requestBody: Partial<Cypress.RequestOptions> = {
        method: 'DELETE',
        form: false,
        url,
        headers: {
          Authorization: `Bearer ${bearer}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(userIds),
      }

      return cy.request(requestBody).then(response => {
        return response
      })
    },
  },

  //Fake endpoint using the patient search to check for email
  SearchForEmail: {
    method: 'POST', //METHOD: 'POST'
    url: '**/search/searchPatient', //ENDPOINT: '**/patients/search'
    alias: 'postPatientsSearchEmail',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody as PostPatientsSearchRequestLatest
        const response = $xhrRequest.responseBody as PostPatientsSearchResponseLatest
        if (snapshotName) {
          //TODO: Add schema checks.
        }
        return { request, response }
      })
    },
  },
})
