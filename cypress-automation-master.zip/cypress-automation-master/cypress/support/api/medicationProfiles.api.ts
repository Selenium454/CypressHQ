export const MedicationProfilesRoutes = Object.freeze({
  GetNursesByUserId: {
    method: 'GET',
    url: '**/nurses/*',
    alias: 'getNursesByUserId',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  PutNursesByUserId: {
    method: 'PUT',
    url: '**/nurses/*',
    alias: 'putNursesByUserId',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
  },
  PostNursesSearch: {
    method: 'POST',
    url: '**/nurses/search',
    alias: 'postNursesSearch',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
  },
})
