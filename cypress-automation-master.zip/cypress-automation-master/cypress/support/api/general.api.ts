export const AddressFinderRoutes = Object.freeze({
  GetAddressFinderAddressInfo: {
    method: 'GET',
    url: '**/api/au/address/info?**',
    alias: 'getAddressFinderAddressInfo',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  GetAddressFinderAutoComplete: {
    method: 'GET',
    url: '**/api/au/address/autocomplete?**',
    alias: 'getAddressFinderAutocomplete',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
})
/**
 * Checks a given response from a REST request is correct against a givne schema.
 */
export const checkResponse = <T>(params: { schemaName: any; response: T; snapshotName: string }) => {
  const { schemaName, response, snapshotName } = params

  const schema = new schemaName()

  schema
    .check(response)
    .sanitize(response)
    .snapshot({
      name: `${snapshotName} -  ${schema.snapshotSubtitle}`,
    })
}

/**
 * Checks a given REST request is correct against a given schema.
 */
export const checkRequest = <T>(params: { schemaName: any; request: T; snapshotName: string }) => {
  const { schemaName, request, snapshotName } = params

  const schema = new schemaName()

  schema
    .check(request)
    .sanitize(request)
    .snapshot({
      name: `${snapshotName} -  ${schemaName.snapshotSubtitle}`,
    })
}

/**
 * Authenticates login with Microsoft and returns a valid access token.
 */
export const authenticateWithMicrosoft = (userEmail: string, password: string): Cypress.Chainable => {
  return cy
    .request({
      method: 'POST',
      url: 'https://login.microsoftonline.com/common/oauth2/token',
      form: true,
      body: {
        grant_type: 'password',
        resource: Cypress.env('API_ENV_URL'),
        client_id: Cypress.env('API_CLIENT_ID'),
        username: userEmail,
        password: password,
      },
    })
    .then(response => {
      return response.body.access_token
    })
}

export const pollRequest = (params: {
  callbackFunction: Function
  callbackParams: object
  tries: number
  maxRetries: number
}) => {
  let { tries } = params
  const { callbackFunction, callbackParams, maxRetries } = params

  tries += 1
  if (tries <= maxRetries) {
    cy.wait(1000) //Stagger retries
    callbackFunction({ ...callbackParams })
  } else {
    throw new Error(`Unable to successfully retrieve valid response after ${maxRetries} attempts.`)
  }
}
