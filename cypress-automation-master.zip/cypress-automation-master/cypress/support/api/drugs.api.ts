export const DrugsRoutes = Object.freeze({
  GetDrugsGetAllByName: {
    method: 'GET',
    url: '**/drugs/getAllByName',
    alias: 'getDrugsGetAllByName',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  GetDrugsGetAllSigs: {
    method: 'GET',
    url: '**/drugs/getAllSigs',
    alias: 'getDrugsGetAllSigs',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  GetDrugsFormByAbreviation: {
    method: 'GET',
    url: '**/drugs/form/*',
    alias: 'getDrugsFormByAbreviation',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  GetDrugsSearch: {
    method: 'GET',
    url: '**/drugs/search',
    alias: 'getDrugsSearch',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  PostDrugsSearchScripts: {
    method: 'POST',
    url: '**/drugs/search/scripts',
    alias: 'postDrugsSearchScripts',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
  },
})
