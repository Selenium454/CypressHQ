import { PostOrdersNewRequestLatest } from '@schemas/api/endpoints/orders/new.post'
import { pollRequest } from './general.api'

export const OrdersRoutes = Object.freeze({
  GetOrdersCompletedByPharmacyId: {
    method: 'GET',
    url: '**/orders/completed/*',
    alias: 'getOrdersCompletedByPharmacyId',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  GetOrdersHistory: {
    method: 'GET',
    url: '**/orders/history',
    alias: 'getOrdersHistory',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
    request: function(params: { orderFor: number | string; from: string; till: string; tries?: number }) {
      const { orderFor, from, till } = params
      const bearer = Cypress.env('ACCESS_TOKEN') ? Cypress.env('ACCESS_TOKEN') : Cypress.env('GA_ACCESS_TOKEN')
      const url = encodeURI(`${Cypress.env('ENV_URL')}/Orders/History?orderFor=${orderFor}&from=${from}&till=${till}`)
      const requestBody: Partial<Cypress.RequestOptions> = {
        method: 'GET',
        form: true,
        url,
        headers: {
          Authorization: `Bearer ${bearer}`,
        },
      }

      const maxRetries: number = 5
      let { tries = 0 } = params

      return cy.request(requestBody).then(response => {
        if (response.status === 200 && response.body['model'].length > 0) {
          return response
        } else {
          tries += 1
          pollRequest({
            callbackFunction: this.request,
            callbackParams: { orderFor, from, till },
            tries: tries,
            maxRetries: maxRetries,
          })
        }
      })
    },
  },
  GetOrders: {
    method: 'GET',
    url: '**/orders',
    alias: 'getOrders',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
    request: function(params: { orderId: string }) {
      const { orderId } = params
      const bearer = Cypress.env('ACCESS_TOKEN') ? Cypress.env('ACCESS_TOKEN') : Cypress.env('GA_ACCESS_TOKEN')
      const url = encodeURI(`${Cypress.env('ENV_URL')}/Orders?orderId=${orderId}`)
      const requestBody: Partial<Cypress.RequestOptions> = {
        method: 'GET',
        form: true,
        url,
        headers: {
          Authorization: `Bearer ${bearer}`,
        },
      }

      return cy.request(requestBody).then(response => {
        return response
      })
    },
  },
  GetOrdersBatch: {
    method: 'GET',
    url: '**/orders/batch',
    alias: 'getOrdersBatch',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
    request: function(params: { batchId: string; tries?: number }) {
      const { batchId } = params
      const bearer = Cypress.env('ACCESS_TOKEN') ? Cypress.env('ACCESS_TOKEN') : Cypress.env('GA_ACCESS_TOKEN')
      const url = encodeURI(`${Cypress.env('ENV_URL')}/Orders/Batch?batchId=${batchId}`)
      const requestBody: Partial<Cypress.RequestOptions> = {
        method: 'GET',
        form: true,
        url,
        headers: {
          Authorization: `Bearer ${bearer}`,
        },
      }

      const maxRetries: number = 5
      let { tries = 0 } = params

      return cy.request(requestBody).then(response => {
        if (response.status === 200) {
          return response
        } else {
          tries += 1
          pollRequest({
            callbackFunction: this.request,
            callbackParams: { batchId, tries },
            tries: tries,
            maxRetries: maxRetries,
          })
        }
      })
    },
  },
  PostOrdersNew: {
    method: 'POST',
    url: '**/chartflow/create', //ENDPOINT: '**/orders/new'
    alias: 'postOrdersNew',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
    request: function(params: { order: PostOrdersNewRequestLatest }) {
      const { order } = params
      const bearer = Cypress.env('ACCESS_TOKEN') ? Cypress.env('ACCESS_TOKEN') : Cypress.env('GA_ACCESS_TOKEN')
      const url = encodeURI(Cypress.env('ENV_URL') + '/Orders/New')
      const requestBody: Partial<Cypress.RequestOptions> = {
        method: 'POST',
        url,
        headers: {
          Authorization: `Bearer ${bearer}`,
        },
        body: order,
      }

      return cy.request(requestBody).then(response => {
        return response
      })
    },
  },
  PostOrdersSearch: {
    method: 'POST',
    url: '**/orders/search',
    alias: 'postOrdersSearch',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
  },
  PutOrdersLock: {
    method: 'PUT',
    url: '**/Orders/Lock', //ENDPOINT: '**/orders/lock'
    alias: 'putOrdersLock',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
  },
  PutOrdersUnlock: {
    method: 'PUT',
    url: '**/orders/unlock',
    alias: 'putOrdersUnlock',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
  },
  UploadImageToBlob: {
    method: 'POST',
    url: '**/upload/images/*',
    alias: 'uploadImageToBlob',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
  },
})
