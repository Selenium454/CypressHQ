import {
  PostAdministrationAddFacilityRequestLatest,
  PostAdministrationAddFacilityResponseLatest,
  PostAdministrationAddFacilityRequestSchema,
  PostAdministrationAddFacilityResponseSchema,
} from '@schemas/api/endpoints/administration/addFacility.post'

import { checkRequest, checkResponse } from './general.api'

export const setupAdministrationRoutes = () => {
  cy.route({ method: 'PUT', url: '**/administration/removeEmployee' }).as('puAdministrationRemoveEmployee')
}

export const AdministrationRoutes = Object.freeze({
  GetAdministrationAllBusinessUnits: {
    method: 'GET',
    url: '**/administration/allBusinessUnits',
    alias: 'getAdministrationAllBusinessUnits',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  GetAdministrationAllBusinessUnitEmployees: {
    method: 'GET',
    url: '**/administration/allBusinessUnitEmployees/*',
    alias: 'getAdministrationAllBusinessUnitEmployees',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  PostAdministrationAddCorporate: {
    method: 'POST',
    url: '**/administration/addCorporate',
    alias: 'postAdministrationAddCorporate',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
  },
  PutAdministrationEditCorporate: {
    method: 'PUT',
    url: '**/administration/editCorporate',
    alias: 'putAdministrationEditCorporate',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
  },
  PostAdministrationAddBusinessUnit: {
    method: 'POST',
    url: '**/administration/addBusinessUnit',
    alias: 'postAdministrationAddBusinessUnit',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
  },
  PutAdministrationEditBusinessUnit: {
    method: 'PUT',
    url: '**/administration/editBusinessUnit',
    alias: 'putAdministrationEditBusinessUnit',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
  },
  PostAdministrationAddFacility: {
    method: 'POST',
    url: '**/administration/addFacility',
    alias: 'postAdministrationAddFacility',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody as PostAdministrationAddFacilityRequestLatest
        const response = $xhrRequest.responseBody as PostAdministrationAddFacilityResponseLatest
        if (snapshotName) {
          checkRequest<PostAdministrationAddFacilityRequestLatest>({
            schemaName: PostAdministrationAddFacilityRequestSchema,
            request,
            snapshotName,
          })

          checkResponse<PostAdministrationAddFacilityResponseLatest>({
            schemaName: PostAdministrationAddFacilityResponseSchema,
            response,
            snapshotName,
          })
        }
        return { request, response }
      })
    },
    request: (params: { body: PostAdministrationAddFacilityRequestLatest }) => {
      const { body } = params
      const bearer = Cypress.env('GA_ACCESS_TOKEN')
      const url: string = encodeURI(`${Cypress.env('ENV_URL')}/Administration/AddFacility`)
      const requestBody: Partial<Cypress.RequestOptions> = {
        method: 'POST',
        form: true,
        url,
        headers: {
          Authorization: `Bearer ${bearer}`,
        },
        body,
      }

      return cy.request(requestBody).then(response => {
        return response
      })
    },
  },
  PutAdministrationEditFacility: {
    method: 'PUT',
    url: '**/administration/editFacility',
    alias: 'putAdministrationEditFacility',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
  },
  PutAdministrationAssociateEmployee: {
    method: 'PUT',
    url: '**/administration/allBusinessUnitEmployees/*',
    alias: 'putAdministrationAssociateEmployee',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
  },
  PutAdministrationRemoveEmployee: {
    method: 'PUT',
    url: '**/administration/removeEmployee',
    alias: 'putAdministrationRemoveEmployee',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
  },
})
