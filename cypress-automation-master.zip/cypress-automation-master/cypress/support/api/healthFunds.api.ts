export const HealthFundsRoutes = Object.freeze({
  GetHealthfundsByHealthFundCodeInsurer: {
    method: 'GET',
    url: '**/healthfunds/*/insurer?*',
    alias: 'getHealthfundsByHealthFundCodeInsurer',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { response }
      })
    },
  },
  PostHealthFundsInsurers: {
    method: 'POST',
    url: '**/healthfunds/insurer/search', //ENDPOINT: '**/healthFunds/insurer'
    alias: 'postHealthFundsInsurers',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add scheam checks
        }
        return { request, response }
      })
    },
  },
})
