export const RegistrationRoutes = Object.freeze({
  PostRegisterPatient: {
    method: 'POST',
    url: '**/register/patient',
    alias: 'postRegisterPatient',
    check: function(snapshotName?: string) {
      return cy.wait(`@${this.alias}`).then($xhrRequest => {
        const request = $xhrRequest.requestBody
        const response = $xhrRequest.responseBody
        if (snapshotName) {
          //TODO: Add schema checks.
        }
        return { request, response }
      })
    },
  },
})
