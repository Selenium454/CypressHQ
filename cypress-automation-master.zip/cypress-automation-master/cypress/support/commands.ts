import { authenticateWithMicrosoft, PatientsRoutes, FacilitiesRoutes } from './api'
import { VueComponent, StoredData } from './types'
import { ApiSchemaLibrary } from '@schemas/api'

// ***********************************************
// This example commands.js shows you how to
// create letious custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
// Cypress.Commands.add("login", (email, password) => { ... })
//
//
// -- This is a child command --
// Cypress.Commands.add("drag", { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add("dismiss", { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This is will overwrite an existing command --
// Cypress.Commands.overwrite("visit", (originalFn, url, options) => { ... })

export const setupSnapshots = (snapshotFileName: string) => {
  //@ts-ignore
  Cypress.config('snapshotFileName', `${snapshotFileName}.snapshots.js`)
  require('@cypress/snapshot').register()
}

/**
 * Logs into Health Director with the given email and password.
 */

const login = (email: string, password: string) => {
  cy.getCookie('logged_role').then(cookie => {
    if (cookie && cookie.value === email) {
      cy.visit('/', {
        onBeforeLoad: win => {
          cy.spy(win.console, `error`).as('console-error')
        },
      })

      return
    } else {
      cy.logout()
    }

    cy.get('#email')
      .clear()
      .type(email)
      .should('have.value', email)

    cy.get('#password')
      .clear()
      .type(password)
      .should('have.value', password)

    cy.get('.btn-primary').click()

    authenticateWithMicrosoft(email, password).then((response: any) => {
      Cypress.env('ACCESS_TOKEN', response)
    })

    cy.setCookie('logged_role', email)

    // Close timezone selection popup
    cy.get('body').then($body => {
      if ($body.find('.btn-warning').length) {
        cy.get('.btn-warning')
          .click()
          .should('not.exist')
      }

      // Close php debug bar if open
      if ($body.find('.phpdebugbar').length) {
        if (!$body.find('.phpdebugbar-closed').length) {
          cy.get('.phpdebugbar-close-btn').click()
        }
      }
    })
  })
}

/**
 * Logs out of Health Director.
 */
const logout = () => {
  cy.clearCookie('ACCESS-TOKEN')
    .visit('/auth/logout')
    .url()
    .should('contain', 'auth/login')
    .clearCookie('logged_role')
}

const findVueComponent = (vueComponent: VueComponent, componentName: string) => {
  if (vueComponent.$options._componentTag === componentName) {
    return vueComponent
  }
  let result: VueComponent | {} = {}
  vueComponent.$children.forEach(component => {
    let possibleMatch: VueComponent | {} = {}
    possibleMatch = findVueComponent(component, componentName)
    if (Object.entries(possibleMatch).length > 0) {
      result = possibleMatch
      return result
    }
  })
  return result
}

const cleanCreatedData = () => {
  cy.task('getDataForDeletion').then(dataForDeletion => {
    const data = (dataForDeletion as unknown) as StoredData
    const { userIds, facilities } = data
    if (userIds.length > 0) {
      PatientsRoutes.DeletePatientsPatient.request({ userIds: userIds })
    }

    if (facilities.length > 0) {
      facilities.forEach(facilityCode => {
        FacilitiesRoutes.DeleteFacilities.request(facilityCode)
      })
    }
  })

  cy.task('resetDataForDeletion')
}

declare global {
  namespace Cypress {
    interface Chainable<Subject> {
      login: (email: string, password: string) => Chainable
      logout: () => Chainable
      setupSnapshots: (snapshotFileName: string) => void
      snapshot: (options?: object) => Chainable
      sanitize: (schemaName: string, schemaVersion: string) => Chainable
      getVueComponent: (componentName: string) => Chainable
      cleanCreatedData: () => Chainable
    }
  }
}

Cypress.Commands.add('login', login)
Cypress.Commands.add('logout', logout)
Cypress.Commands.add('setupSnapshots', setupSnapshots)
Cypress.Commands.add(
  'sanitize',
  {
    prevSubject: true,
  },
  (subject, schemaName, schemaVersion) => {
    const sanitized = ApiSchemaLibrary.sanitize(schemaName, schemaVersion)(subject)
    return sanitized
  }
)

Cypress.Commands.add('getVueComponent', { prevSubject: true }, (subject, componentName) => {
  let result: VueComponent | {} = {}
  subject.app.$children.forEach((component: VueComponent) => {
    let possibleMatch: VueComponent | {} = {}
    possibleMatch = findVueComponent(component, componentName)
    if (Object.entries(possibleMatch).length > 0) {
      result = possibleMatch
      return result
    }
  })
  return result
})

Cypress.Commands.add('cleanCreatedData', cleanCreatedData)
