/* tslint:disable */

import * as gulp from 'gulp'
import { argv } from 'yargs'
var run = require('gulp-run-command').default
import { EnumLiteralsOf } from '@support/types'

type Environments = EnumLiteralsOf<typeof Environments>
const Environments = Object.freeze({
  dev: '--env configFile=dev' as 'dev',
  qa: '--env configFile=qa' as 'qa',
})

type Suites = EnumLiteralsOf<typeof Suites>
const Suites = Object.freeze({
  regression: 'regression' as 'regression',
  scenario: 'scenario' as 'scenario',
  integration: 'integration' as 'integration',
  ui: 'ui' as 'ui',
})

type Priorities = EnumLiteralsOf<typeof Priorities>
const Priorities = {
  p1: '1' as 'p1',
  p2: '2' as 'p2',
  p3: '3' as 'p3',
  p4: '4' as 'p4',
}

type UserRoles = EnumLiteralsOf<typeof UserRoles>
const UserRoles = {
  cancerCareAdmin: 'cancerCareAdmin' as 'cancerCareAdmin',
  corporateAdmin: 'corporateAdmin' as 'corporateAdmin',
  nurse: 'nurse' as 'nurse',
  pharmacist: 'pharmacist' as 'pharmacist',
  pharmacyAdmin: 'pharmacyAdmin' as 'pharmacyAdmin',
  pharmacyTechnician: 'pharmacyTechnician' as 'pharmacyTechnician',
  doctor: 'doctor' as 'doctor',
  globalAdmin: 'globalAdmin' as 'globalAdmin',
}

let cypressFunction = 'open'
let baseExec = 'npx'
let spec: string | null

gulp.task('cypress', _cb => {
  const environment: Environments = argv.env as Environments
  let options: string = Environments[environment] || '--env configFile=dev'

  if (argv.run != null) {
    cypressFunction = 'run'
  }

  if (argv.role != null) {
    const chosenRole: UserRoles = argv.suite as UserRoles
    const role = UserRoles[chosenRole] || null
    options = `${options},role=${role}`
  }

  if (argv.priority != null) {
    const chosenPriority: Priorities = argv.priority as Priorities
    const priority = Priorities[chosenPriority] || Priorities.p4
    options = `${options},priority=${priority}`
  }

  if (argv.suite != null) {
    const chosenSuite: Suites = argv.suite as Suites
    const suite = Suites[chosenSuite] || null
    options = `${options},suite=${suite}`
  }

  if (argv.spec != null) {
    const glob: string = argv.spec as string
    spec = `--spec ${glob}`
  }

  //Only use this command when cypress is running as a submodule of HealthDirector
  if (argv.coverage != null) {
    options = `${options},coverage=true`
    baseExec = `npx nyc -x '**/plugins/**' -x '**/all.js' -x '**/*.spec.js' -x '**/*.min.js' --all`
  }

  let cmd = `${baseExec} cypress ${cypressFunction} ${options}`

  //Only use these if used with --run
  if (argv.spec != null) {
    cmd = `${cmd} ${spec}`
  }
  if (argv.record != null) {
    cmd = `${cmd} --record --key 70b0f6d9-9293-401e-9624-8c350b34e795`
  }
  run(cmd)()
})
