import { CustomFormat } from '@cypress/schema-tools'

export const syncAddress: CustomFormat = {
  name: 'syncAddress',
  description: 'Paddress for patient syncing',
  detect: /^[0-9]{2,3} [a-zA-Z ]*$/,
  defaultValue: '25 PAINT ST',
}

export const syncAdmission: CustomFormat = {
  name: 'syncAdmission',
  description: 'Padmission for patient syncing',
  detect: /^(?:[0-9]{8}|'')$/,
  defaultValue: '12345678',
}

export const syncPastDate: CustomFormat = {
  name: 'syncPastDate',
  description: 'Pbirthdate for patient syncing',
  detect: /^{\^[0-9]{4}\/[0-9]{2}\/[0-9]{2}}$/,
  defaultValue: '{^1993/11/22}',
}

export const syncConcessionNumber: CustomFormat = {
  name: 'syncConcessionNumber',
  description: 'Pconcno for patient syncing',
  detect: /^(?:'CN[0-9]{9}'|'')$/,
  defaultValue: "'CN998908321'",
}

export const syncFutureDate: CustomFormat = {
  name: 'syncFutureDate',
  description: 'Pconcvdate, Pinsvdate for patient syncing',
  detect: /^(?:{\^2[0-9]{3}\/[0-9]{2}\/[0-9]{2}}|^{\^\/\/})$/,
  defaultValue: '{^2025/11/22}',
}

export const syncEmailAddress: CustomFormat = {
  name: 'syncEmailAddress',
  description: 'Pemail for patient syncing',
  detect: /^(?:[A-Z0-9_.]*@[A-Z0-9]*.COM|'')$/,
  defaultValue: 'BEN_SPINKS@YAHOO.COM',
}

export const syncFirstName: CustomFormat = {
  name: 'syncFirstName',
  description: 'Pfirstname for patient syncing',
  detect: /[A-Z-]*/,
  defaultValue: 'BENJAMIN',
}

export const syncHealthFundId: CustomFormat = {
  name: 'syncHealthFundId',
  description: 'Phfundid for patient syncing',
  detect: /^'[A-Z]*'$/,
  defaultValue: "'HCF'",
}

export const syncHealthFundNumber: CustomFormat = {
  name: 'syncHealthFundNumber',
  description: 'Phfundmno for patient syncing',
  detect: /^(?:[0-9]{6}|0000|)$/,
  defaultValue: '123456',
}

export const syncMedicareNumber: CustomFormat = {
  name: 'syncMedicareNumber',
  description: 'Pmedicare for patient syncing',
  detect: /^(?:'[0-9]{11}'|'')$/,
  defaultValue: '12345678901',
}

export const syncPatientNotes: CustomFormat = {
  name: 'syncPatientNotes',
  description: 'Pnotes for patient syncing',
  detect: /[a-zA-Z0-9 =\\!{},]*/,
  defaultValue:
    'HCF TOP =80691584\r\n\r\n{\r\nTry to synthesize the AGP pixel, maybe it will reboot the virtual sensor!\r\n}',
}

export const syncPhoneNumber: CustomFormat = {
  name: 'syncPhoneNumber',
  description: 'Pphoneno for patient syncing',
  detect: /^(?:'[0-9]{8}'|'')$/,
  defaultValue: '66286345',
}

export const syncPostCode: CustomFormat = {
  name: 'syncPostCode',
  description: 'Ppostcode for patient syncing',
  detect: /[0-9]{4}/,
  defaultValue: '4000',
}

export const syncRepatNumber: CustomFormat = {
  name: 'syncRepatNumber',
  description: 'Prepatno for patient syncing',
  detect: /^(?:'QSM[0-9]{5}'|'')$/,
  defaultValue: "'QSM12345'",
}

export const syncSafetyNetNumber: CustomFormat = {
  name: 'syncSafetyNetNumber',
  description: 'Psafentno for patient syncing',
  detect: /^(?:'SN[0-9]{9}'|'')$/,
  defaultValue: "'SN920899878'",
}

export const syncSuburb: CustomFormat = {
  name: 'syncSuburb',
  description: 'Psuburb for patient syncing',
  detect: /[A-Z ]*/,
  defaultValue: 'WEST COOPER',
}

export const syncSurname: CustomFormat = {
  name: 'syncSurname',
  description: 'Psurname for patient syncing',
  detect: /QA[A-Z]{13}/,
  defaultValue: 'QAABCDEFGHIJ',
}

export const syncTitle: CustomFormat = {
  name: 'syncTitle',
  description: 'Ptitle for patient syncing',
  detect: /[A-Z]*/,
  defaultValue: 'MRS',
}

export const syncURNumber: CustomFormat = {
  name: 'syncURNumber',
  description: 'Purnumber for patient syncing',
  detect: /^[0-9]{8}$/,
  defaultValue: '91234567',
}

export const syncRepatColour: CustomFormat = {
  name: 'syncRepatColour',
  description: 'Prepatcol for patient syncing',
  detect: /^(?:'[A-Z]{1}'|'')$/,
  defaultValue: "'W'",
}

export const syncSex: CustomFormat = {
  name: 'syncSex',
  description: 'Psex for patient syncing',
  detect: /^(?:'M'|'F')$/,
  defaultValue: 'F',
}
