import { CustomFormat } from '@cypress/schema-tools'

export const admissionNumber: CustomFormat = {
  name: 'admissionNumber',
  description: 'Admission id number.',
  detect: /^([0-9]{8})$/,
  defaultValue: '12345678',
}
