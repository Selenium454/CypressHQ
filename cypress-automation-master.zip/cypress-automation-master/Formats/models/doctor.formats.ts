import { CustomFormat } from '@cypress/schema-tools'

export const providerNumber: CustomFormat = {
  name: 'providerNumber',
  description: '',
  detect: /^[0-9A-Za-z]{8}$/,
  defaultValue: '1194579W',
}
