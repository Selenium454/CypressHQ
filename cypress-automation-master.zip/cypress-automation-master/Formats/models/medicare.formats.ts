import { CustomFormat } from '@cypress/schema-tools'

export const medicareNumber: CustomFormat = {
  name: 'medicareNumber',
  description: 'Patient medicare number',
  detect: /^(?:[0-9]{11}|)$/,
  defaultValue: '64472026003',
}

export const concessionNumber: CustomFormat = {
  name: 'concessionNumber',
  description: 'Patient concession number',
  detect: /^(?:CN[0-9]{9}|)$/,
  defaultValue: 'CN986991521',
}

export const concessionType: CustomFormat = {
  name: 'concessionType',
  description: '',
  detect: /^(?:S|)$/,
}

export const repatNumber: CustomFormat = {
  name: 'repatNumber',
  description: 'Patient repat number',
  detect: /^(?:QSM[0-9]{5}|QX[0-9]{6}[A-Z]{1}|)$/,
  defaultValue: 'QSM12345',
}

export const repatCardType: CustomFormat = {
  name: 'repatCardType',
  description: 'Patient repat card type',
  detect: /^(?:none|white|gold|orange)$/,
  defaultValue: 'white',
}

export const safetyNetNumber: CustomFormat = {
  name: 'safetyNetNumber',
  description: 'Patient safety net number',
  detect: /^(?:SN[0-9]{9}|'')$/,
  defaultValue: 'SN920899878',
}

export const elapsedTime: CustomFormat = {
  name: 'elapsedTime',
  description: 'Elapsed time used in medicare validation',
  detect: /^[0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]*$/,
  defaultValue: '00:00:00.123456',
}
