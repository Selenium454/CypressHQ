import { CustomFormat } from '@cypress/schema-tools/src/formats'

export const healthFund: CustomFormat = {
  name: 'healthFund',
  description: 'Health fund ID',
  detect: /^(?:[A-Z]{3,4}|)$/,
  defaultValue: 'HCF',
}
