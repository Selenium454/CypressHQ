import { CustomFormat, oneOfRegex } from '@cypress/schema-tools'

const roleRegex = oneOfRegex(
  'pharmacist',
  'pharmacyAdmin',
  'cancerCareAdmin',
  'technician',
  'nurse',
  'corporateAdmin',
  'doctor',
  'epicAccounts',
  'doctorInternal'
)

export const name: CustomFormat = {
  name: 'name',
  description: 'NAME',
  detect: /[A-Za-z]{1,}/,
  defaultValue: 'Ruby',
}

export const fullName: CustomFormat = {
  name: 'fullName',
  description: 'Full name',
  detect: /([A-Za-z]{1,}\s{1}){2,3}/,
  defaultValue: 'Ruby Qabcdefg',
}

export const userId: CustomFormat = {
  name: 'userId',
  description: 'Format for user Ids',
  detect: /^[0-9]{10}$/,
  defaultValue: '0000206402',
}

export const trackId: CustomFormat = {
  name: 'trackId',
  description: 'Format for user Ids',
  detect: /^[0-9a-z]{32}$/,
  defaultValue: '86d4f1dfc6ac4636b7bdd33c23c81868',
}

export const userRole: CustomFormat = {
  name: 'userRole',
  description: 'Role of HD user',
  detect: roleRegex,
  defaultValue: 'pharmacyAdmin',
}

export const pharmacyId: CustomFormat = {
  name: 'pharmacyId',
  description: '',
  detect: /^[0-9]{1,5}$/,
  defaultValue: '9001',
}

export const facilityCode: CustomFormat = {
  name: 'facilityCode',
  description: '',
  detect: /^[A-z]{1,}$/,
  defaultValue: 'QAabcdef',
}

export const paginationPages: CustomFormat = {
  name: 'paginationPages',
  description: '',
  detect: /^[0-9]{1,5}$/,
  defaultValue: 1,
}

export const notes: CustomFormat = {
  name: 'notes',
  description: 'Any length of notes.',
  detect: /^[A-z0-9]{1,}$/,
  defaultValue: 'These were replaced by cypress.',
}
