import { CustomFormat } from '@cypress/schema-tools'

export const mobileNumber: CustomFormat = {
  name: 'mobileNumber',
  description: '10 digit mobile number',
  detect: /^(?:[0-9]{10}|)$/,
  defaultValue: '0412345678',
}

export const patientSex: CustomFormat = {
  name: 'patientSex',
  description: 'Patient sex string',
  detect: /^(?:male|female)$/,
  defaultValue: 'female',
}

export const title: CustomFormat = {
  name: 'title',
  description: 'Patient title',
  detect: /[A-Za-z]{2,4}/,
  defaultValue: 'mr',
}

export const emailAddress: CustomFormat = {
  name: 'emailAddress',
  description: 'email address',
  detect: /^(?:[A-Za-z0-9_.]*@[a-zA-Z0-9]*.com|)$/i,
  defaultValue: 'BEN_SPINKS@YAHOO.COM',
}

export const patientTitle: CustomFormat = {
  name: 'patientTitle',
  description: "Patient's title",
  detect: /^(?:[A-Za-z]{2,4}|)$/,
  defaultValue: 'mr',
}

export const phoneNumber: CustomFormat = {
  name: 'phoneNumber',
  description: "Patient's phone number",
  detect: /^(?:[0-9]{8}|)$/,
  defaultValue: '66288494',
}

export const mobilePhoneNumber: CustomFormat = {
  name: 'mobilePhoneNumber',
  description: "Patient's mobile phone number",
  detect: /^(?:[0-9]{10}|)$/,
  defaultValue: '0416676743',
}

export const urNumber: CustomFormat = {
  name: 'urNumber',
  description: '',
  detect: /^[0-9]{1,}$/,
  defaultValue: '91234567',
}

export const serviceIdentifier: CustomFormat = {
  name: 'serviceIdentifier',
  description: '',
  detect: /^[0-9]{1,}$/,
  defaultValue: '12345',
}

export const healthFundexpiryDate: CustomFormat = {
  name: 'healthFundexpiryDate',
  description: '',
  detect: /^(?:[1,2][0-9]{3}-[0-9]{2}-[0-9]{2}|[1,2][0-9]{3}-[0-9]{2}-[0-9]{2}T00:00:00|)$/,
  defaultValue: '2020/06/20',
}

export const healthFundMembership: CustomFormat = {
  name: 'healthFundMembership',
  description: '',
  detect: /^(?:[0-9]{4,10}|)$/,
  defaultValue: '1539983909',
}
