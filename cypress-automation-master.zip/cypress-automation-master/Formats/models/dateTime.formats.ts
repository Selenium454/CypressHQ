import { CustomFormat } from '@cypress/schema-tools'

const dateTimeRegexWithTimezone = new RegExp(`[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(.[0-9]{1,})?Z`)

const dateTimeRegex = new RegExp(`[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}|`)

export const dateTimeWithTimezone: CustomFormat = {
  name: 'dateTimeWithTimezone',
  description: 'General regex for a due time with timezone',
  detect: dateTimeRegexWithTimezone,
  defaultValue: `2020-12-24T09:00:50.756Z`,
}

export const dateWithPlusTimezone: CustomFormat = {
  name: 'dateWithPlusTimezone',
  description: 'General regex for a due time with +10 timezone',
  detect: /^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(.[0-9]{1,})?\+[0-2]{2}:00$/,
  defaultValue: `2019-09-07T14:24:59.0450+10:00`,
}

export const dateTime: CustomFormat = {
  name: 'dateTime',
  description: 'General regex for a due time',
  detect: dateTimeRegex,
  defaultValue: `2020-12-24T09:00:50`,
}

export const dateString: CustomFormat = {
  name: 'dateString',
  description: '',
  detect: /^(?:[0-9]{2}\/[0-9]{2}\/[1,2][0-9]{3}|)$/,
  defaultValue: '22/11/2020',
}
