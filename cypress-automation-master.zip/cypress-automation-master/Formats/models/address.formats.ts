import { CustomFormat } from '@cypress/schema-tools'

export const street: CustomFormat = {
  name: 'street',
  description: 'Address street code',
  detect: /^([0-9]{1,3})?[a-zA-Z ']*$/,
  defaultValue: '25 Paint St',
}

export const suburb: CustomFormat = {
  name: 'suburb',
  description: 'Address suburb',
  detect: /[A-Z ]*/,
  defaultValue: 'West Cooper',
}

export const postCode: CustomFormat = {
  name: 'postCode',
  description: 'Address post code',
  detect: /[0-9]{4}/,
  defaultValue: '4000',
}
