import { CustomFormat } from '@cypress/schema-tools'

const generalDateRegex = '[0-9]{4}-[0-9]{2}-[0-9]{2}'
const encodedDateTimeRegex = `[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}%3A[0-9]{2}%3A[0-9]{2}Z`
const blobPath = 'https://[a-z0-9]{1,}.blob.core.windows.net'
const blobImageFolderName = '[a-zA-Z-]{1,}'
const blobImageExtension = 'jpg|jpeg'

const generateFacilityChartOrderPathRegex = (): RegExp => {
  const hospitalPharmacyId = '[0-9]{1,}'
  const hospitalFacilityCode = '[a-z]{1,}'
  const sigRegex = `[0-9a-zA-Z%]{43,}%3D`
  const pidRegex = `pid-${hospitalPharmacyId}-fcode-${hospitalFacilityCode}`
  const finishedRegex = new RegExp(
    `${blobPath}/${pidRegex}/${blobImageFolderName}/[0-9a-z]{14}.[0-9]{8}-${pidRegex}.${blobImageExtension}\\?sv=${generalDateRegex}&sr=b&sig=${sigRegex}&st=${encodedDateTimeRegex}&se=${encodedDateTimeRegex}&sp=r`
  )

  return finishedRegex
}

const generatePatientChartOrderPathRegex = (): RegExp => {
  const sigRegex = `[0-9a-zA-Z%].*`

  const finishedRegex = new RegExp(
    `${blobPath}/[0-9]{10}/${blobImageFolderName}/[0-9a-z]{14}.[0-9]{8}-[0-9]{10}.${blobImageExtension}\\?sv=${generalDateRegex}&sr=b&sig=${sigRegex}&st=${encodedDateTimeRegex}&se=${encodedDateTimeRegex}&sp=r`
  )

  return finishedRegex
}

export const patientChartJobPath: CustomFormat = {
  name: 'patientChartJobPath',
  description: 'Basic structure of the path to a chart job image',
  detect: /chart-images\/[0-9a-z]{14}.[0-9]{8}-[0-9]{10}.jpeg/,
  defaultValue: 'chart-images/5c0f536ecea2d7.01705180-0000206402.jpeg',
}

export const facilityChartJobPath: CustomFormat = {
  name: 'facilityChartJobPath',
  description: 'Basic structure of the path to a facility chart job image',
  detect: /chart-images\/[0-9a-z]{14}.[0-9]{8}-pid-[0-9]{2,}-fcode-[a-z]{3,8}.jpeg/,
  defaultValue: 'chart-images/5c0df5dc2091f0.35981256-pid-44-fcode-sjgm.jpeg',
}

export const chartOrderPath: CustomFormat = {
  name: 'chartOrderPath',
  description: "Basic path structure to a chart job's images",
  detect: /^(https:\/\/[a-z0-9]{1,}.blob.core.windows.net.*)|(chart-images\/[0-9a-z]{14}.*)$/,
  defaultValue: `Order path removed in sanitize`,
}

export const patientChartOrderPath: CustomFormat = {
  name: 'patientChartOrderPath',
  description: "Full path structure to a patient chart job's images",
  detect: generatePatientChartOrderPathRegex(),
  defaultValue: `https://hubnonprodqacustomers01.blob.core.windows.net/0000206402/chart-images/5c20d13caf6de8.24731045-0000206402.jpeg?sv=2017-04-17&sr=b&sig=RXH2i1IqCdbABB15TCCvarDFPHUWfHjEDn7eiS5w7aU%3D&st=2018-12-24T12%3A25%3A30Z&se=2018-12-24T18%3A30%3A30Z&sp=r`,
}

export const facilityChartOrderPath: CustomFormat = {
  name: 'facilityChartOrderPath',
  description: "Full path structure to a patient chart job's images",
  detect: generateFacilityChartOrderPathRegex(),
  defaultValue: `https://hubnonprodqacustomers01.blob.core.windows.net/pid-44-fcode-sjgm/chart-images/5c369b2ac36d56.82921185-pid-44-fcode-sjgm.jpeg?sv=2017-04-17&sr=b&sig=4sJ8rL0OiXEWqH1iXuCHMFNzPPA05XN%2BaUIhDrL99W8%3D&st=2019-01-10T01%3A04%3A31Z&se=2019-01-10T07%3A09%3A31Z&sp=r`,
}

export const chartJobComment: CustomFormat = {
  name: 'chartJobComment',
  description: 'Chart Job Comment',
  detect: /[\s\S]*/,
  defaultValue: `Chart Job Comment`,
}

export const orderId: CustomFormat = {
  name: 'orderId',
  description: 'Job order Id',
  detect: /^[0-9]{12}$|^1$/,
  defaultValue: '000000007744',
}

export const orderFor: CustomFormat = {
  name: 'orderFor',
  description: '',
  detect: /^QA[a-z]{1,6}$|^[0-9]{10}$/,
  defaultValue: 'QAabcdef',
}

export const dailyChartOrderId: CustomFormat = {
  name: 'dailyChartOrderId',
  description: '',
  detect: /^[0-9]{6}$/,
  defaultValue: '000001',
}
