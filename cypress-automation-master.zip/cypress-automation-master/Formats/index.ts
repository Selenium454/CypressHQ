import { CustomFormats, getDefaults } from '@cypress/schema-tools'

import * as AddressFormats from './models/address.formats'
import * as ChartFlowFormats from './models/chartFlow.formats'
import * as CommonFormats from './models/common.formats'
import * as DateTimeFormats from './models/dateTime.formats'
import * as DoctorFormats from './models/doctor.formats'
import * as MedicareFormats from './models/medicare.formats'
import * as PatientFormats from './models/patient.formats'
import * as ServicesFormats from './models/services.formats'

import * as SyncFormats from './sync.formats'

export const formats: CustomFormats = {
  ...AddressFormats,
  ...ChartFlowFormats,
  ...CommonFormats,
  ...DateTimeFormats,
  ...DoctorFormats,
  ...MedicareFormats,
  ...PatientFormats,
  ...ServicesFormats,

  ...SyncFormats,
}

export const formatDefaults = getDefaults(formats)
