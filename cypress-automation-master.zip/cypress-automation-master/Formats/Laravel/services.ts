import { CustomFormat } from '@cypress/schema-tools'

const dueTimeTodayRegex = new RegExp(
  `${Cypress.moment()
    .utc()
    .format('YYYY-MM-DD')}T[0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{1,}Z`
)

export const serviceId: CustomFormat = {
  name: 'serviceId',
  description: 'Format for service Ids',
  detect: /^[0-9a-z]{32}$/i,
  defaultValue: '9e8d7754092c4c91bd0a12453f3f1aba',
}

export const serviceAdded: CustomFormat = {
  name: 'serviceAdded',
  description: 'Format for service added date',
  detect: dueTimeTodayRegex,
  defaultValue: '2019-01-28T23:13:05.9247732Z',
}
