import { documentSchemas } from '@cypress/schema-tools'
import { ApiPatientSchemas } from '../schemas'
import { formats } from '../formats'
console.log(documentSchemas(ApiPatientSchemas, formats))
