export * from './add.post'
export * from './delete.delete'
export * from './all.get'
export * from './update.put'

import { SchemaCollection, combineSchemas } from '@cypress/schema-tools/src'
import { DeleteServicesDeleteRequestSchema, DeleteServicesDeleteResponseSchema } from './delete.delete'
import { PostServicesAddRequestSchema, PostServicesAddResponseSchema } from './add.post'
import { GetServicesAllResponseSchema } from './all.get'
import { PutServicesUpdateRequestSchema, PutServicesUpdateResponseSchema } from './update.put'

export const servicesSchemas: SchemaCollection = combineSchemas(
  PostServicesAddRequestSchema.versionedSchemas,
  PostServicesAddResponseSchema.versionedSchemas,

  DeleteServicesDeleteRequestSchema.versionedSchemas,
  DeleteServicesDeleteResponseSchema.versionedSchemas,

  GetServicesAllResponseSchema.versionedSchemas,

  PutServicesUpdateRequestSchema.versionedSchemas,
  PutServicesUpdateResponseSchema.versionedSchemas
)
