import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import {
  SuccessResponseSchema,
  SuccessResponse440,
} from '@schemas/api/models/successResponse.modelResponseAttribute.filters.web.core.cloud'

import { MedicalServiceSchema, MedicalService440 } from '@schemas/api/models/medicalService.cloud.models.core'
import { generateSanitizeFunction } from '@schemas/api/shared'

const medicalServiceSchema = new MedicalServiceSchema()
const successResponseSchema = new SuccessResponseSchema()

/**
 * Request
 */
interface DeleteServicesDeleteRequest440 extends MedicalService440 {}
export interface DeleteServicesDeleteRequestLatest extends DeleteServicesDeleteRequest440 {}

export class DeleteServicesDeleteRequestSchema {
  latestVersion: string = '4.4.0'

  public static request440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'deleteServicesDeleteRequest',
      type: 'object',
      description: '',
      properties: {
        ...MedicalServiceSchema.medicalService440.schema.properties,
      },
      additionalProperties: true,
    },
    example: (({
      ...((MedicalServiceSchema.medicalService440.example as unknown) as MedicalService440),
    } as DeleteServicesDeleteRequest440) as unknown) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(DeleteServicesDeleteRequestSchema.request440)

  public static snapshotSubtitle = 'Delete Servives Delete Request'

  public check = (object: DeleteServicesDeleteRequestLatest, version: string = this.latestVersion) => {
    cy.wrap(object).should('followSchema', 'deleteServicesDeleteRequest', version)
    return this
  }

  public sanitize = (object: DeleteServicesDeleteRequestLatest, version: string = this.latestVersion) => {
    return medicalServiceSchema.sanitize(object, version)
  }
}

/**
 * Response
 */
interface DeleteServicesDeleteResponse440 extends SuccessResponse440 {}
export interface DeleteServicesDeleteResponseLatest extends DeleteServicesDeleteResponse440 {}

export class DeleteServicesDeleteResponseSchema {
  latestVersion: string = '4.4.0'

  public static response440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'deleteServicesDeleteResponse',
      type: 'object',
      description: '',
      properties: {
        ...SuccessResponseSchema.successResponse440.schema.properties,
      },
      additionalProperties: true,
    },
    example: ({
      ...SuccessResponseSchema.successResponse440.example,
    } as DeleteServicesDeleteResponse440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(DeleteServicesDeleteResponseSchema.response440)

  public static snapshotSubtitle = 'Delete Servives Delete Response'

  public check = (object: DeleteServicesDeleteResponseLatest, version: string = this.latestVersion) => {
    cy.wrap(object).should('followSchema', 'deleteServicesDeleteResponse', version)
    return this
  }

  public sanitize = (object: DeleteServicesDeleteResponseLatest, version: string = this.latestVersion) => {
    return successResponseSchema.sanitize(object, version).then(sanitized => {
      return generateSanitizeFunction(
        DeleteServicesDeleteResponseSchema.versionedSchemas,
        'deleteServicesDeleteResponse',
        version
      )(sanitized as PlainObject) as DeleteServicesDeleteResponseLatest
    })
  }
}
