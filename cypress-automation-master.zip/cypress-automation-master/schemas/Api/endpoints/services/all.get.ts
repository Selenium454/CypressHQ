import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'

import {
  MedicalServiceResponse440,
  MedicalServiceResponseSchema,
  MedicalServiceResponseLatest,
} from '@schemas/api/models/medicalServiceResponse.cloud.models.core'
import {
  SuccessResponseSchema,
  SuccessResponse440,
} from '@schemas/api/models/successResponse.modelResponseAttribute.filters.web.core.cloud'
import { generateSanitizeFunction } from '@schemas/api/shared'

const medicalServiceResponseSchema = new MedicalServiceResponseSchema()
const successResponseSchema = new SuccessResponseSchema()

/**
 * Response
 */
interface GetServicesAllResponse440 extends SuccessResponse440 {
  model?: MedicalServiceResponse440[] | null
}
export interface GetServicesAllResponseLatest extends GetServicesAllResponse440 {}

export class GetServicesAllResponseSchema {
  latestVersion: string = '4.4.0'

  public static response440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'getServicesAllResponse',
      type: 'object',
      description: '',
      properties: {
        ...SuccessResponseSchema.successResponse440.schema.properties,
        model: {
          type: ['array', 'null'],
          description: '',
          items: {
            ...MedicalServiceResponseSchema.medicalServiceResponse440.schema,
          },
        },
      },
      additionalProperties: true,
    },
    example: ({
      ...SuccessResponseSchema.successResponse440.example,
      model: [(MedicalServiceResponseSchema.medicalServiceResponse440.example as unknown) as MedicalServiceResponse440],
    } as GetServicesAllResponse440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(GetServicesAllResponseSchema.response440)

  public static snapshotSubtitle = 'Get Servives All Response'

  public check = (object: GetServicesAllResponseLatest, version: string = this.latestVersion) => {
    cy.wrap(object).should('followSchema', 'getServicesAllResponse', version)
    return this
  }

  public sanitize = (object: GetServicesAllResponseLatest, version: string = this.latestVersion) => {
    if (object.model) {
      let services = object.model as MedicalServiceResponseLatest[]
      services.forEach((service, index) => {
        medicalServiceResponseSchema.sanitize(service, version).then(sanitizedService => {
          object.model![index] = sanitizedService
        })
      })
    }

    return successResponseSchema.sanitize(object, version).then(sanitized => {
      return generateSanitizeFunction(GetServicesAllResponseSchema.versionedSchemas, 'getServicesAllResponse', version)(
        sanitized as PlainObject
      ) as GetServicesAllResponseLatest
    })
  }
}
