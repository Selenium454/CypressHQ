import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import {
  SuccessResponseSchema,
  SuccessResponse440,
} from '@schemas/api/models/successResponse.modelResponseAttribute.filters.web.core.cloud'

import { MedicalServiceSchema, MedicalService440 } from '@schemas/api/models/medicalService.cloud.models.core'
import { generateSanitizeFunction } from '@schemas/api/shared'

const medicalServiceSchema = new MedicalServiceSchema()
const successResponseSchema = new SuccessResponseSchema()

/**
 * Request
 */
interface PostServicesAddRequest440 extends MedicalService440 {}
export interface PostServicesAddRequestLatest extends PostServicesAddRequest440 {}

export class PostServicesAddRequestSchema {
  latestVersion: string = '4.4.0'

  public static request440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'postServicesAddRequest',
      type: 'object',
      description: '',
      properties: {
        ...MedicalServiceSchema.medicalService440.schema.properties,
      },
      additionalProperties: true,
    },
    example: (({
      ...((MedicalServiceSchema.medicalService440.example as unknown) as MedicalService440),
    } as PostServicesAddRequest440) as unknown) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(PostServicesAddRequestSchema.request440)

  public static snapshotSubtitle = 'Post Servives Add Request'

  public check = (object: PostServicesAddRequestLatest, version: string = this.latestVersion) => {
    cy.wrap(object).should('followSchema', 'postServicesAddRequest', version)
    return this
  }

  public sanitize = (object: PostServicesAddRequestLatest, version: string = this.latestVersion) => {
    return medicalServiceSchema.sanitize(object, version)
  }
}

/**
 * Response
 */
interface PostServicesAddResponse440 extends SuccessResponse440 {
  model?: string | null
}
export interface PostServicesAddResponseLatest extends PostServicesAddResponse440 {}

export class PostServicesAddResponseSchema {
  latestVersion: string = '4.4.0'

  public static response440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'postServicesAddResponse',
      type: 'object',
      description: '',
      properties: {
        ...SuccessResponseSchema.successResponse440.schema.properties,
        model: {
          type: ['string', 'null'],
          description: '',
          format: 'trackId',
          required: false,
        },
      },
      additionalProperties: true,
    },
    example: ({
      ...SuccessResponseSchema.successResponse440.example,
    } as PostServicesAddResponse440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(PostServicesAddResponseSchema.response440)

  public static snapshotSubtitle = 'Post Servives Add Response'

  public check = (object: PostServicesAddResponseLatest, version: string = this.latestVersion) => {
    cy.wrap(object).should('followSchema', 'postServicesAddResponse', version)
    return this
  }

  public sanitize = (object: PostServicesAddResponseLatest, version: string = this.latestVersion) => {
    return successResponseSchema.sanitize(object, version).then(sanitized => {
      return generateSanitizeFunction(
        PostServicesAddResponseSchema.versionedSchemas,
        'postServicesAddResponse',
        version
      )(sanitized as PlainObject) as PostServicesAddResponseLatest
    })
  }
}
