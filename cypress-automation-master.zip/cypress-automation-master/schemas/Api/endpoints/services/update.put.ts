import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import {
  SuccessResponseSchema,
  SuccessResponse440,
} from '@schemas/api/models/successResponse.modelResponseAttribute.filters.web.core.cloud'

import { MedicalServiceSchema, MedicalService440 } from '@schemas/api/models/medicalService.cloud.models.core'
import { generateSanitizeFunction } from '@schemas/api/shared'

const medicalServiceSchema = new MedicalServiceSchema()
const successResponseSchema = new SuccessResponseSchema()

/**
 * Request
 */
interface PutServicesUpdateRequest440 extends MedicalService440 {}
export interface PutServicesUpdateRequestLatest extends PutServicesUpdateRequest440 {}

export class PutServicesUpdateRequestSchema {
  latestVersion: string = '4.4.0'

  public static request440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'putServicesUpdateRequest',
      type: 'object',
      description: '',
      properties: {
        ...MedicalServiceSchema.medicalService440.schema.properties,
      },
      additionalProperties: true,
    },
    example: (({
      ...((MedicalServiceSchema.medicalService440.example as unknown) as MedicalService440),
    } as PutServicesUpdateRequest440) as unknown) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(PutServicesUpdateRequestSchema.request440)

  public static snapshotSubtitle = 'Put Servives Update Request'

  public check = (object: PutServicesUpdateRequestLatest, version: string = this.latestVersion) => {
    cy.wrap(object).should('followSchema', 'putServicesUpdateRequest', version)
    return this
  }

  public sanitize = (object: PutServicesUpdateRequestLatest, version: string = this.latestVersion) => {
    return medicalServiceSchema.sanitize(object, version)
  }
}

/**
 * Response
 */
interface PutServicesUpdateResponse440 extends SuccessResponse440 {}
export interface PutServicesUpdateResponseLatest extends PutServicesUpdateResponse440 {}

export class PutServicesUpdateResponseSchema {
  latestVersion: string = '4.4.0'

  public static response440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'putServicesUpdateResponse',
      type: 'object',
      description: '',
      properties: {
        ...SuccessResponseSchema.successResponse440.schema.properties,
      },
      additionalProperties: true,
    },
    example: ({
      ...SuccessResponseSchema.successResponse440.example,
    } as PutServicesUpdateResponse440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(PutServicesUpdateResponseSchema.response440)

  public static snapshotSubtitle = 'Put Servives Update Response'

  public check = (object: PutServicesUpdateResponseLatest, version: string = this.latestVersion) => {
    cy.wrap(object).should('followSchema', 'putServicesUpdateResponse', version)
    return this
  }

  public sanitize = (object: PutServicesUpdateResponseLatest, version: string = this.latestVersion) => {
    return successResponseSchema.sanitize(object, version).then(sanitized => {
      return generateSanitizeFunction(
        PutServicesUpdateResponseSchema.versionedSchemas,
        'putServicesUpdateResponse',
        version
      )(sanitized as PlainObject) as PutServicesUpdateResponseLatest
    })
  }
}
