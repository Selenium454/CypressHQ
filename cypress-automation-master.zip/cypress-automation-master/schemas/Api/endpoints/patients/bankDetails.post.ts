import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { BankAccount440, BankAccountSchema } from '@schemas/api/models/bankAccount.cloud.models.core'
import {
  SuccessResponse440,
  SuccessResponseSchema,
} from '@schemas/api/models/successResponse.modelResponseAttribute.filters.web.core.cloud'
import { generateSanitizeFunction } from '@schemas/api/shared'

const bankAccountSchema = new BankAccountSchema()
const successResponseSchema = new SuccessResponseSchema()

/**
 * Request
 */
interface PostPatientsBankDetailsRequest440 extends BankAccount440 {}
export interface PostPatientsBankDetailsRequestLatest extends PostPatientsBankDetailsRequest440 {}

export class PostPatientsBankDetailsRequestSchema {
  latestVersion: string = '4.4.0'

  public static request440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'postPatientsBankDetailsRequest',
      type: 'object',
      description: '',
      properties: {
        ...BankAccountSchema.bankAccount440.schema.properties,
      },
      additionalProperties: true,
    },
    example: ({
      ...BankAccountSchema.bankAccount440.example,
    } as PostPatientsBankDetailsRequest440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(PostPatientsBankDetailsRequestSchema.request440)

  public static snapshotSubtitle = 'Post Patients Bank Details Request'

  public check = (object: PostPatientsBankDetailsRequestLatest, version: string = this.latestVersion) => {
    cy.wrap(object).should('followSchema', 'postPatientsBankDetailsRequest', version)
    return this
  }

  public sanitize = (object: PostPatientsBankDetailsRequestLatest, version: string = this.latestVersion) => {
    return bankAccountSchema.sanitize(object, version)
  }
}

/**
 * Response
 */
interface PostPatientsBankDetailsResponse440 extends SuccessResponse440 {}
export interface PostPatientsBankDetailsResponseLatest extends PostPatientsBankDetailsResponse440 {}

export class PostPatientsBankDetailsResponseSchema {
  latestVersion: string = '4.4.0'

  public static response440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'postPatientsBankDetailsResponse',
      type: 'object',
      description: '',
      properties: {
        ...SuccessResponseSchema.successResponse440.schema.properties,
      },
      additionalProperties: true,
    },
    example: ({
      ...SuccessResponseSchema.successResponse440.example,
    } as PostPatientsBankDetailsResponse440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(PostPatientsBankDetailsResponseSchema.response440)

  public static snapshotSubtitle = 'Post Patients Bank Details Response'

  public check = (object: PostPatientsBankDetailsResponseLatest, version: string = this.latestVersion) => {
    cy.wrap(object).should('followSchema', 'postPatientsBankDetailsResponse', version)
    return this
  }

  public sanitize = (object: PostPatientsBankDetailsResponseLatest, version: string = this.latestVersion) => {
    return successResponseSchema.sanitize(object, version).then(sanitized => {
      return generateSanitizeFunction(
        PostPatientsBankDetailsResponseSchema.versionedSchemas,
        'postPatientsBankDetailsResponse',
        version
      )(sanitized as PlainObject) as PostPatientsBankDetailsResponseLatest
    })
  }
}
