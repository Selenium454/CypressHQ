import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { ContactSchema, Contact440 } from '@schemas/api/models/contact.cloud.models.core'
import {
  SuccessResponseSchema,
  SuccessResponse440,
} from '@schemas/api/models/successResponse.modelResponseAttribute.filters.web.core.cloud'
import { generateSanitizeFunction } from '@schemas/api/shared'

const contactSchema = new ContactSchema()
const successResponseSchema = new SuccessResponseSchema()

/**
 * Request
 */
interface PostPatientsContactsRequest440 extends Contact440 {}
export interface PostPatientsContactsRequestLatest extends PostPatientsContactsRequest440 {}

export class PostPatientsContactsRequestSchema {
  latestVersion: string = '4.4.0'

  public static request440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'postPatientsContactsRequest',
      type: 'object',
      description: '',
      properties: {
        ...ContactSchema.contact440.schema.properties,
      },
      additionalProperties: true,
    },
    example: (({
      ...((ContactSchema.contact440.example as unknown) as Contact440),
    } as PostPatientsContactsRequest440) as unknown) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(PostPatientsContactsRequestSchema.request440)

  public static snapshotSubtitle = 'Post Patients Contacts Request'

  public check = (object: PostPatientsContactsRequestLatest[], version: string = this.latestVersion) => {
    object.forEach(contact => {
      cy.wrap(contact).should('followSchema', 'postPatientsContactsRequest', version)
    })
    return this
  }

  public sanitize = (object: PostPatientsContactsRequestLatest[], version: string = this.latestVersion) => {
    object.forEach((contact, index) => {
      contactSchema.sanitize(contact, version).then(sanitizedContact => {
        object[index] = sanitizedContact
      })
    })
    return cy.wrap(object)
  }
}

/**
 * Response
 */
interface PostPatientsContactsResponse440 extends SuccessResponse440 {}
export interface PostPatientsContactsResponseLatest extends PostPatientsContactsResponse440 {}

export class PostPatientsContactsResponseSchema {
  latestVersion: string = '4.4.0'

  public static response440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'postPatientsContactsResponse',
      type: 'object',
      description: '',
      properties: {
        ...SuccessResponseSchema.successResponse440.schema.properties,
      },
      additionalProperties: true,
    },
    example: ({
      ...SuccessResponseSchema.successResponse440.example,
    } as PostPatientsContactsResponse440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(PostPatientsContactsResponseSchema.response440)

  public static snapshotSubtitle = 'Post Patients Contacts Response'

  public check = (object: PostPatientsContactsResponseLatest, version: string = this.latestVersion) => {
    cy.wrap(object).should('followSchema', 'postPatientsContactsResponse', version)
    return this
  }

  public sanitize = (object: PostPatientsContactsResponseLatest, version: string = this.latestVersion) => {
    return successResponseSchema.sanitize(object, version).then(sanitized => {
      return generateSanitizeFunction(
        PostPatientsContactsResponseSchema.versionedSchemas,
        'postPatientsContactsResponse',
        version
      )(sanitized as PlainObject) as PostPatientsContactsResponseLatest
    })
  }
}
