import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import {
  RegistrationModelSchema,
  RegistrationModel440,
} from '@schemas/api/models/registrationModel.models.webApi.cloudServices'
import {
  SuccessResponseSchema,
  SuccessResponse440,
} from '@schemas/api/models/successResponse.modelResponseAttribute.filters.web.core.cloud'
import { generateSanitizeFunction } from '@schemas/api/shared'

const registrationModelSchema = new RegistrationModelSchema()
const successResponseSchema = new SuccessResponseSchema()

/**
 * Request
 */
interface PostPatientsRegisterRequest440 extends RegistrationModel440 {}
export interface PostPatientsRegisterRequestLatest extends PostPatientsRegisterRequest440 {}

export class PostPatientsRegisterRequestSchema {
  latestVersion: string = '4.4.0'

  public static request440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'postPatientsRegisterRequest',
      type: 'object',
      description: '',
      properties: {
        ...RegistrationModelSchema.registrationModel440.schema.properties,
      },
      required: true,
      additionalProperties: false,
    },
    example: (({
      ...((RegistrationModelSchema.registrationModel440.example as unknown) as RegistrationModel440),
    } as PostPatientsRegisterRequest440) as unknown) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(PostPatientsRegisterRequestSchema.request440)

  public static snapshotSubtitle = 'Post Patients Register Request'

  public check = (object: PostPatientsRegisterRequestLatest, version: string = this.latestVersion) => {
    cy.wrap(object).should('followSchema', 'postPatientsRegisterRequest', version)
    return this
  }

  public sanitize = (object: PostPatientsRegisterRequestLatest, version: string = this.latestVersion) => {
    return registrationModelSchema.sanitize(object, version)
  }
}

/**
 * Response
 */
interface PostPatientsRegisterResponse440 extends SuccessResponse440 {
  model?: string
}
export interface PostPatientsRegisterResponseLatest extends PostPatientsRegisterResponse440 {}

export class PostPatientsRegisterResponseSchema {
  latestVersion: string = '4.4.0'

  public static response440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'postPatientsRegisterResponse',
      type: 'object',
      description: '',
      properties: {
        ...SuccessResponseSchema.successResponse440.schema.properties,
        model: {
          type: ['string', 'null'],
          description: '',
          format: 'userId',
          required: false,
        },
      },
      additionalProperties: true,
    },
    example: ({
      ...SuccessResponseSchema.successResponse440.example,
    } as PostPatientsRegisterResponse440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(PostPatientsRegisterResponseSchema.response440)

  public static snapshotSubtitle = 'Post Patients Register Response'

  public check = (object: PostPatientsRegisterResponseLatest, version: string = this.latestVersion) => {
    cy.wrap(object).should('followSchema', 'postPatientsRegisterResponse', version)
    return this
  }

  public sanitize = (object: PostPatientsRegisterResponseLatest, version: string = this.latestVersion) => {
    return successResponseSchema.sanitize(object, version).then(sanitized => {
      return generateSanitizeFunction(
        PostPatientsRegisterResponseSchema.versionedSchemas,
        'postPatientsRegisterResponse',
        version
      )(sanitized as PlainObject) as PostPatientsRegisterResponseLatest
    })
  }
}
