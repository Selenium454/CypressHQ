import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { InterventionSchema, Intervention440 } from '@schemas/api/models/intervention.cloud.models.core'
import {
  SuccessResponseSchema,
  SuccessResponse440,
} from '@schemas/api/models/successResponse.modelResponseAttribute.filters.web.core.cloud'
import { generateSanitizeFunction } from '@schemas/api/shared'

const sanitizeInterventionSchema = new InterventionSchema()
const successResponseSchema = new SuccessResponseSchema()

/**
 * Request
 */
interface PutPatientsInterventionsRequest440 extends Intervention440 {}
export interface PutPatientsInterventionsRequestLatest extends PutPatientsInterventionsRequest440 {}

export class PutPatientsInterventionsRequestSchema {
  latestVersion: string = '4.4.0'

  public static request440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'putPatientsInterventionsRequest',
      type: 'object',
      description: '',
      properties: {
        ...InterventionSchema.intervention440.schema.properties,
      },
      additionalProperties: true,
    },
    example: ({
      ...InterventionSchema.intervention440.example,
    } as PutPatientsInterventionsRequest440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(PutPatientsInterventionsRequestSchema.request440)

  public static snapshotSubtitle = 'Put Patients Interventions Request'

  public check = (object: PutPatientsInterventionsRequestLatest, version: string = this.latestVersion) => {
    cy.wrap(object).should('followSchema', 'putPatientsInterventionsRequest', version)
    return this
  }

  public sanitize = (object: PutPatientsInterventionsRequestLatest, version: string = this.latestVersion) => {
    return sanitizeInterventionSchema.sanitize(object, version)
  }
}

/**
 * Response
 */
interface PutPatientsInterventionsResponse440 extends SuccessResponse440 {}
export interface PutPatientsInterventionsResponseLatest extends PutPatientsInterventionsResponse440 {}

export class PutPatientsInterventionsResponseSchema {
  latestVersion: string = '4.4.0'

  public static response440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'putPatientsInterventionsResponse',
      type: 'object',
      description: '',
      properties: {
        ...SuccessResponseSchema.successResponse440.schema.properties,
      },
      additionalProperties: true,
    },
    example: ({
      ...SuccessResponseSchema.successResponse440.example,
    } as PutPatientsInterventionsResponse440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(PutPatientsInterventionsResponseSchema.response440)

  public static snapshotSubtitle = 'Put Patients Interventions Response'

  public check = (object: PutPatientsInterventionsResponseLatest, version: string = this.latestVersion) => {
    cy.wrap(object).should('followSchema', 'putPatientsInterventionsResponse', version)
    return this
  }

  public sanitize = (object: PutPatientsInterventionsResponseLatest, version: string = this.latestVersion) => {
    return successResponseSchema.sanitize(object, version).then(sanitized => {
      return generateSanitizeFunction(
        PutPatientsInterventionsResponseSchema.versionedSchemas,
        'putPatientsInterventionsResponse',
        version
      )(sanitized as PlainObject) as PutPatientsInterventionsResponseLatest
    })
  }
}
