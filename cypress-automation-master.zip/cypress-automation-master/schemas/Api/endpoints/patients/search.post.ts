import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { SearchPatientFilterSchema, SearchPatientFilter440 } from '@schemas/api/models/searchPatientFilter.search.core'
import {
  SuccessResponseSchema,
  SuccessResponse440,
} from '@schemas/api/models/successResponse.modelResponseAttribute.filters.web.core.cloud'
import { IResultPageSchema, IResultPage440 } from '@schemas/api/models/iResultPage.paging.models.core'
import {
  SearchPatientResultsSchema,
  SearchPatientResults440,
} from '@schemas/api/models/searchPatientResults.cloud.models.core'
import { generateSanitizeFunction } from '@schemas/api/shared'

const searchPatientFilterSchema = new SearchPatientFilterSchema()
const iResultPageSchema = new IResultPageSchema()
const successResponseSchema = new SuccessResponseSchema()

/**
 * Request
 */
interface PostPatientsSearchRequest440 extends SearchPatientFilter440 {}
export interface PostPatientsSearchRequestLatest extends PostPatientsSearchRequest440 {}

export class PostPatientsSearchRequestSchema {
  latestVersion: string = '4.4.0'

  public static request440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'postPatientsSearchRequest',
      type: 'object',
      description: '',
      properties: {
        ...SearchPatientFilterSchema.searchPatientFilter440.schema.properties,
      },
      required: true,
      additionalProperties: false,
    },
    example: {
      ...(SearchPatientFilterSchema.searchPatientFilter440.example as PostPatientsSearchRequest440),
    },
  }

  public static versionedSchemas = versionSchemas(PostPatientsSearchRequestSchema.request440)

  public static snapshotSubtitle = 'Post Patients Search Request'

  public check = (object: PostPatientsSearchRequestLatest, version: string = this.latestVersion) => {
    cy.wrap(object).should('followSchema', 'postPatientsSearchRequest', version)
    return this
  }

  public sanitize = (object: PostPatientsSearchRequestLatest, version: string = this.latestVersion) => {
    return searchPatientFilterSchema.sanitize(object, version)
  }
}

/**
 * Response
 */
interface SearchPatientResults extends IResultPage440 {
  items?: SearchPatientResults440[] | null
}
interface PostPatientsSearchResponse440 extends SuccessResponse440 {
  model?: SearchPatientResults | null
}
export interface PostPatientsSearchResponseLatest extends PostPatientsSearchResponse440 {}

export class PostPatientsSearchResponseSchema {
  latestVersion: string = '4.4.0'

  public static response440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'postPatientsSearchResponse',
      type: 'object',
      description: '',
      properties: {
        ...SuccessResponseSchema.successResponse440.schema.properties,
        model: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...IResultPageSchema.iResultPage440.schema.properties,
            items: {
              type: ['array', 'null'],
              description: '',
              items: {
                ...SearchPatientResultsSchema.searchPatientResults440.schema,
              },
              see: SearchPatientResultsSchema.searchPatientResults440,
            },
          },
          see: IResultPageSchema.iResultPage440,
          required: false,
        },
      },
      additionalProperties: true,
    },
    example: ({
      ...SuccessResponseSchema.successResponse440.example,
      model: {
        ...IResultPageSchema.iResultPage440.example,
        items: [{ ...SearchPatientResultsSchema.searchPatientResults440.example }],
      },
    } as PostPatientsSearchResponse440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(PostPatientsSearchResponseSchema.response440)

  public static snapshotSubtitle = 'Post Patients Search Response'

  public check = (object: PostPatientsSearchResponseLatest, version: string = this.latestVersion) => {
    cy.wrap(object).should('followSchema', 'postPatientsSearchResponse', version)
    return this
  }

  public sanitize = (object: PostPatientsSearchResponseLatest, version: string = this.latestVersion) => {
    if (object.model) {
      iResultPageSchema.sanitize(object.model).then(sanitizedModel => {
        object.model = sanitizedModel
      })
    }

    return successResponseSchema.sanitize(object, version).then(sanitized => {
      return generateSanitizeFunction(
        PostPatientsSearchResponseSchema.versionedSchemas,
        'postPatientsSearchResponse',
        version
      )(sanitized as PlainObject) as PostPatientsSearchResponseLatest
    })
  }
}
