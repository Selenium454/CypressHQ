import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import {
  SuccessResponseSchema,
  SuccessResponse440,
} from '@schemas/api/models/successResponse.modelResponseAttribute.filters.web.core.cloud'
import { ContactSchema, Contact440 } from '@schemas/api/models/contact.cloud.models.core'
import { generateSanitizeFunction } from '@schemas/api/shared'

const contactsSchema = new ContactSchema()
const successResponseSchema = new SuccessResponseSchema()

/**
 * Response
 */
interface GetPatientsContactsResponse440 extends SuccessResponse440 {
  model?: Contact440[] | null
}
export interface GetPatientsContactsResponseLatest extends GetPatientsContactsResponse440 {}

export class GetPatientsContactsResponseSchema {
  latestVersion: string = '4.4.0'

  public static response440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'getPatientsContactsResponse',
      type: 'object',
      description: '',
      properties: {
        ...SuccessResponseSchema.successResponse440.schema.properties,
        model: {
          type: ['array', 'null'],
          items: {
            ...ContactSchema.contact440.schema,
          },
          see: ContactSchema.contact440,
        },
      },
      additionalProperties: true,
    },
    example: ({
      ...SuccessResponseSchema.successResponse440.example,
      model: [(ContactSchema.contact440.example as unknown) as Contact440],
    } as GetPatientsContactsResponse440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(GetPatientsContactsResponseSchema.response440)

  public static snapshotSubtitle = 'Get Patients Contacts Response'

  public check = (object: GetPatientsContactsResponseLatest, version: string = this.latestVersion) => {
    cy.wrap(object).should('followSchema', 'getPatientsContactsResponse', version)
    return this
  }

  public sanitize = (object: GetPatientsContactsResponseLatest, version: string = this.latestVersion) => {
    if (object.model) {
      object.model.forEach((contact, index: number) => {
        contactsSchema.sanitize(contact).then(sanitizedContact => {
          object.model![index] = sanitizedContact
        })
      })
    }

    return successResponseSchema.sanitize(object, version).then(sanitized => {
      return generateSanitizeFunction(
        GetPatientsContactsResponseSchema.versionedSchemas,
        'getPatientsContactsResponse',
        version
      )(sanitized as PlainObject) as GetPatientsContactsResponseLatest
    })
  }
}
