import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import {
  SuccessResponseSchema,
  SuccessResponse440,
} from '@schemas/api/models/successResponse.modelResponseAttribute.filters.web.core.cloud'
import {
  PatientDetailsCommandSchema,
  PatientDetailsCommand440,
} from '@schemas/api/models/patientDetailsCommand.cloud.models.core'
import { generateSanitizeFunction } from '@schemas/api/shared'

const patientDetailsCommandSchema = new PatientDetailsCommandSchema()
const successResponseSchema = new SuccessResponseSchema()

/**
 * Request
 */
interface PutPatientsDetailsRequest440 extends PatientDetailsCommand440 {}
export interface PutPatientsDetailsRequestLatest extends PutPatientsDetailsRequest440 {}

export class PutPatientsDetailsRequestSchema {
  latestVersion: string = '4.4.0'

  public static request440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'putPatientsDetailsRequest',
      type: 'object',
      description: '',
      properties: {
        ...PatientDetailsCommandSchema.patientDetailsCommand440.schema.properties,
      },
      additionalProperties: true,
    },
    example: ({
      ...PatientDetailsCommandSchema.patientDetailsCommand440.example,
    } as PutPatientsDetailsRequest440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(PutPatientsDetailsRequestSchema.request440)

  public static snapshotSubtitle = 'Put Patients Details Request'

  public check = (object: PutPatientsDetailsRequestLatest, version: string = this.latestVersion) => {
    cy.wrap(object).should('followSchema', 'putPatientsDetailsRequest', version)
    return this
  }

  public sanitize = (object: PutPatientsDetailsRequestLatest, version: string = this.latestVersion) => {
    return patientDetailsCommandSchema.sanitize(object, version)
  }
}

/**
 * Response
 */
interface PutPatientsDetailsResponse440 extends SuccessResponse440 {}
export interface PutPatientsDetailsResponseLatest extends PutPatientsDetailsResponse440 {}

export class PutPatientsDetailsResponseSchema {
  latestVersion: string = '4.4.0'

  public static response440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'putPatientsDetailsResponse',
      type: 'object',
      description: '',
      properties: {
        ...SuccessResponseSchema.successResponse440.schema.properties,
      },
      additionalProperties: true,
    },
    example: ({
      ...SuccessResponseSchema.successResponse440.example,
    } as PutPatientsDetailsResponse440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(PutPatientsDetailsResponseSchema.response440)

  public static snapshotSubtitle = 'Put Patients Details Response'

  public check = (object: PutPatientsDetailsResponseLatest, version: string = this.latestVersion) => {
    cy.wrap(object).should('followSchema', 'putPatientsDetailsResponse', version)
    return this
  }

  public sanitize = (object: PutPatientsDetailsResponseLatest, version: string = this.latestVersion) => {
    return successResponseSchema.sanitize(object, version).then(sanitized => {
      return generateSanitizeFunction(
        PutPatientsDetailsResponseSchema.versionedSchemas,
        'putPatientsDetailsResponse',
        version
      )(sanitized as PlainObject) as PutPatientsDetailsResponseLatest
    })
  }
}
