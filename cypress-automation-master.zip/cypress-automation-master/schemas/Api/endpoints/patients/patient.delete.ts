import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import {
  SuccessResponseSchema,
  SuccessResponse440,
} from '@schemas/api/models/successResponse.modelResponseAttribute.filters.web.core.cloud'
import { EntityDeleteResultSchema, EntityDeleteResult440 } from '@schemas/api/models/entityDeleteResult.removers.core'
import { generateSanitizeFunction } from '@schemas/api/shared'

const entityDeleteResultSchema = new EntityDeleteResultSchema()
const successResponseSchema = new SuccessResponseSchema()

/**
 * Response
 */
interface DeletePatientsPatientResponse440 extends SuccessResponse440 {
  model: EntityDeleteResult440[] | null
}
export interface DeletePatientsPatientResponseLatest extends DeletePatientsPatientResponse440 {}

export class DeletePatientsPatientResponseSchema {
  latestVersion: string = '4.4.0'

  public static response440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'deletePatientsPatientResponse',
      type: 'object',
      description: '',
      properties: {
        ...SuccessResponseSchema.successResponse440.schema.properties,
        model: {
          type: ['array', 'null'],
          items: {
            ...EntityDeleteResultSchema.entityDeleteResult440.schema,
          },
          see: EntityDeleteResultSchema.entityDeleteResult440,
        },
      },
      additionalProperties: false,
    },
    example: (({
      ...SuccessResponseSchema.successResponse440.example,
      model: [EntityDeleteResultSchema.entityDeleteResult440.example],
    } as DeletePatientsPatientResponse440) as unknown) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(DeletePatientsPatientResponseSchema.response440)

  public static snapshotSubtitle = 'Delete Patients Patient Response'

  public check = (object: DeletePatientsPatientResponseLatest, version: string = this.latestVersion) => {
    cy.wrap(object).should('followSchema', 'deletePatientsPatientResponse', version)
    return this
  }

  public sanitize = (object: DeletePatientsPatientResponseLatest, version: string = this.latestVersion) => {
    if (object.model) {
      object.model.forEach((deletedEntity: EntityDeleteResult440, index: number) => {
        entityDeleteResultSchema.sanitize(deletedEntity).then(sanitizedEntity => {
          object.model![index] = sanitizedEntity
        })
      })
    }

    return successResponseSchema.sanitize(object, version).then(sanitized => {
      return generateSanitizeFunction(
        DeletePatientsPatientResponseSchema.versionedSchemas,
        'deletePatientsPatientResponse',
        version
      )(sanitized as PlainObject) as DeletePatientsPatientResponseLatest
    })
  }
}
