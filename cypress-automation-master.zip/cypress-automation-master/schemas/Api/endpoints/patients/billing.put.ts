import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { BillingDetailsCloudSchema, BillingDetailsCloud440 } from '@schemas/api/models/billingDetails.cloud.models.core'
import {
  SuccessResponseSchema,
  SuccessResponse440,
} from '@schemas/api/models/successResponse.modelResponseAttribute.filters.web.core.cloud'
import { generateSanitizeFunction } from '@schemas/api/shared'

const billingDetailsCloudSchema = new BillingDetailsCloudSchema()
const successResponseSchema = new SuccessResponseSchema()

/**
 * Request
 */
interface PutPatientsBillingRequest440 extends BillingDetailsCloud440 {}
export interface PutPatientsBillingRequestLatest extends PutPatientsBillingRequest440 {}

export class PutPatientsBillingRequestSchema {
  latestVersion: string = '4.4.0'

  public static request440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'putPatientsBillingRequest',
      type: 'object',
      description: '',
      properties: {
        ...BillingDetailsCloudSchema.billingDetailsCloud440.schema.properties,
      },
      additionalProperties: true,
    },
    example: ({
      ...BillingDetailsCloudSchema.billingDetailsCloud440.example,
    } as PutPatientsBillingRequest440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(PutPatientsBillingRequestSchema.request440)

  public static snapshotSubtitle = 'Put Patients Billing Request'

  public check = (object: PutPatientsBillingRequestLatest, version: string = this.latestVersion) => {
    cy.wrap(object).should('followSchema', 'putPatientsBillingRequest', version)
    return this
  }

  public sanitize = (object: PutPatientsBillingRequestLatest, version: string = this.latestVersion) => {
    return billingDetailsCloudSchema.sanitize(object, version)
  }
}

/**
 * Response
 */
interface PutPatientsBillingResponse440 extends SuccessResponse440 {}
export interface PutPatientsBillingResponseLatest extends PutPatientsBillingResponse440 {}

export class PutPatientsBillingResponseSchema {
  latestVersion: string = '4.4.0'

  public static response440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'putPatientsBillingResponse',
      type: 'object',
      description: '',
      properties: {
        ...SuccessResponseSchema.successResponse440.schema.properties,
      },
      additionalProperties: true,
    },
    example: ({
      ...SuccessResponseSchema.successResponse440.example,
    } as PutPatientsBillingResponse440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(PutPatientsBillingResponseSchema.response440)

  public static snapshotSubtitle = 'Put Patients Billing Response'

  public check = (object: PutPatientsBillingResponseLatest, version: string = this.latestVersion) => {
    cy.wrap(object).should('followSchema', 'putPatientsBillingResponse', version)
    return this
  }

  public sanitize = (object: PutPatientsBillingResponseLatest, version: string = this.latestVersion) => {
    return successResponseSchema.sanitize(object, version).then(sanitized => {
      return generateSanitizeFunction(
        PutPatientsBillingResponseSchema.versionedSchemas,
        'putPatientsBillingResponse',
        version
      )(sanitized as PlainObject) as PutPatientsBillingResponseLatest
    })
  }
}
