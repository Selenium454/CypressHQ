export * from './bankDetails.post'
export * from './billing.get'
export * from './billing.put'
export * from './contacts.get'
export * from './contacts.post'
export * from './creditCardDetails.post'
export * from './details.get'
export * from './details.put'
export * from './interventions.delete'
export * from './interventions.get'
export * from './interventions.post'
export * from './interventions.put'
export * from './patient.delete'
export * from './register.post'
export * from './search.post'

import { SchemaCollection, combineSchemas } from '@cypress/schema-tools/src'
import { PostPatientsBankDetailsRequestSchema, PostPatientsBankDetailsResponseSchema } from './bankDetails.post'
import { GetPatientsBillingResponseSchema } from './billing.get'
import { PutPatientsBillingRequestSchema, PutPatientsBillingResponseSchema } from './billing.put'
import { GetPatientsContactsResponseSchema } from './contacts.get'
import { PostPatientsContactsRequestSchema, PostPatientsContactsResponseSchema } from './contacts.post'
import {
  PostPatientsCreditCardDetailsRequestSchema,
  PostPatientsCreditCardDetailsResponseSchema,
} from './creditCardDetails.post'
import { GetPatientsDetailsResponseSchema } from './details.get'
import { PutPatientsDetailsRequestSchema, PutPatientsDetailsResponseSchema } from './details.put'
import { DeletePatientsInterventionsResponseSchema } from './interventions.delete'
import { GetPatientsInterventionsResponseSchema } from './interventions.get'
import { PostPatientsInterventionsRequestSchema, PostPatientsInterventionsResponseSchema } from './interventions.post'
import { PutPatientsInterventionsRequestSchema, PutPatientsInterventionsResponseSchema } from './interventions.put'
import { DeletePatientsPatientResponseSchema } from './patient.delete'
import { PostPatientsRegisterRequestSchema, PostPatientsRegisterResponseSchema } from './register.post'
import { PostPatientsSearchRequestSchema, PostPatientsSearchResponseSchema } from './search.post'

export const patientSchemas: SchemaCollection = combineSchemas(
  PostPatientsBankDetailsRequestSchema.versionedSchemas,
  PostPatientsBankDetailsResponseSchema.versionedSchemas,

  GetPatientsBillingResponseSchema.versionedSchemas,

  PutPatientsBillingRequestSchema.versionedSchemas,
  PutPatientsBillingResponseSchema.versionedSchemas,

  GetPatientsContactsResponseSchema.versionedSchemas,

  PostPatientsContactsRequestSchema.versionedSchemas,
  PostPatientsContactsResponseSchema.versionedSchemas,

  PostPatientsCreditCardDetailsRequestSchema.versionedSchemas,
  PostPatientsCreditCardDetailsResponseSchema.versionedSchemas,

  GetPatientsDetailsResponseSchema.versionedSchemas,

  PutPatientsDetailsRequestSchema.versionedSchemas,
  PutPatientsDetailsResponseSchema.versionedSchemas,

  DeletePatientsInterventionsResponseSchema.versionedSchemas,

  GetPatientsInterventionsResponseSchema.versionedSchemas,

  PostPatientsInterventionsRequestSchema.versionedSchemas,
  PostPatientsInterventionsResponseSchema.versionedSchemas,

  PutPatientsInterventionsRequestSchema.versionedSchemas,
  PutPatientsInterventionsResponseSchema.versionedSchemas,

  DeletePatientsPatientResponseSchema.versionedSchemas,

  PostPatientsRegisterRequestSchema.versionedSchemas,
  PostPatientsRegisterResponseSchema.versionedSchemas,

  PostPatientsSearchRequestSchema.versionedSchemas,
  PostPatientsSearchResponseSchema.versionedSchemas
)
