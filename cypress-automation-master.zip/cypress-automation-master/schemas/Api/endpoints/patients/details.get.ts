import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import {
  SuccessResponseSchema,
  SuccessResponse440,
} from '@schemas/api/models/successResponse.modelResponseAttribute.filters.web.core.cloud'
import {
  PatientDetailsCloudSchema,
  PatientDetailsCloud430,
  PatientDetailsCloud440,
} from '@schemas/api/models/patientDetails.cloud.models.core'
import { generateSanitizeFunction } from '@schemas/api/shared'

const patientDetailsSchema = new PatientDetailsCloudSchema()
const successResponseSchema = new SuccessResponseSchema()

/**
 * Response
 */
interface GetPatientsDetailsResponse430 extends SuccessResponse440 {
  model: PatientDetailsCloud430
}
interface GetPatientsDetailsResponse440 extends SuccessResponse440 {
  model: PatientDetailsCloud440
}
export interface GetPatientsDetailsResponseLatest extends GetPatientsDetailsResponse440 {}

export class GetPatientsDetailsResponseSchema {
  latestVersion: string = '4.4.0'

  public static request430: ObjectSchema = {
    version: {
      major: 4,
      minor: 3,
      patch: 0,
    },
    schema: {
      title: 'getPatientsDetailsResponse',
      type: 'object',
      description: '',
      properties: {
        ...SuccessResponseSchema.successResponse440.schema.properties,
        model: {
          ...PatientDetailsCloudSchema.patientDetailsCloud430.schema,
        },
      },
      additionalProperties: true,
    },
    example: (({
      ...SuccessResponseSchema.successResponse440.example,
      model: {
        ...PatientDetailsCloudSchema.patientDetailsCloud430.example,
      },
    } as GetPatientsDetailsResponse430) as unknown) as PlainObject,
  }

  public static request440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'getPatientsDetailsResponse',
      type: 'object',
      description: '',
      properties: {
        ...SuccessResponseSchema.successResponse440.schema.properties,
        model: {
          ...PatientDetailsCloudSchema.patientDetailsCloud440.schema,
        },
      },
      additionalProperties: true,
    },
    example: (({
      ...SuccessResponseSchema.successResponse440.example,
      model: {
        ...PatientDetailsCloudSchema.patientDetailsCloud440.example,
      },
    } as GetPatientsDetailsResponse440) as unknown) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(
    GetPatientsDetailsResponseSchema.request430,
    GetPatientsDetailsResponseSchema.request440
  )

  public static snapshotSubtitle = 'Get Patients Details Response'

  public check = (object: GetPatientsDetailsResponseLatest, version: string = this.latestVersion) => {
    cy.wrap(object).should('followSchema', 'getPatientsDetailsResponse', version)
    return this
  }

  public sanitize = (object: GetPatientsDetailsResponseLatest, version: string = this.latestVersion) => {
    patientDetailsSchema.sanitize(object.model).then(sanitizedModel => {
      object.model = sanitizedModel
    })

    return successResponseSchema.sanitize(object, version).then(sanitized => {
      return generateSanitizeFunction(
        GetPatientsDetailsResponseSchema.versionedSchemas,
        'getPatientsDetailsResponse',
        version
      )(sanitized as PlainObject) as GetPatientsDetailsResponseLatest
    })
  }
}
