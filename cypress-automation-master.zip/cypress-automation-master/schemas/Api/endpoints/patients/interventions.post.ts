import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { InterventionApiSchema, InterventionApi440 } from '@schemas/api/models/interventionApi.api.models.core.cloud'
import {
  SuccessResponseSchema,
  SuccessResponse440,
} from '@schemas/api/models/successResponse.modelResponseAttribute.filters.web.core.cloud'
import { generateSanitizeFunction } from '@schemas/api/shared'

const interventionApiSchema = new InterventionApiSchema()
const successResponseSchema = new SuccessResponseSchema()

/**
 * Request
 */
interface PostPatientsInterventionsRequest440 extends InterventionApi440 {}
export interface PostPatientsInterventionsRequestLatest extends PostPatientsInterventionsRequest440 {}

export class PostPatientsInterventionsRequestSchema {
  latestVersion: string = '4.4.0'

  public static request440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'postPatientsInterventionsRequest',
      type: 'object',
      description: '',
      properties: {
        ...InterventionApiSchema.interventionApi440.schema.properties,
      },
      additionalProperties: true,
    },
    example: ({
      ...InterventionApiSchema.interventionApi440.example,
    } as PostPatientsInterventionsRequest440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(PostPatientsInterventionsRequestSchema.request440)

  public static snapshotSubtitle = 'Post Patients Interventions Request'

  public check = (object: PostPatientsInterventionsRequestLatest, version: string = this.latestVersion) => {
    cy.wrap(object).should('followSchema', 'postPatientsInterventionsRequest', version)
    return this
  }

  public sanitize = (object: PostPatientsInterventionsRequestLatest, version: string = this.latestVersion) => {
    return interventionApiSchema.sanitize(object, version)
  }
}

/**
 * Response
 */
interface PostPatientsInterventionsResponse440 extends SuccessResponse440 {}
export interface PostPatientsInterventionsResponseLatest extends PostPatientsInterventionsResponse440 {}

export class PostPatientsInterventionsResponseSchema {
  latestVersion: string = '4.4.0'

  public static response440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'postPatientsInterventionsResponse',
      type: 'object',
      description: '',
      properties: {
        ...SuccessResponseSchema.successResponse440.schema.properties,
      },
      additionalProperties: true,
    },
    example: ({
      ...SuccessResponseSchema.successResponse440.example,
    } as PostPatientsInterventionsResponse440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(PostPatientsInterventionsResponseSchema.response440)

  public static snapshotSubtitle = 'Post Patients Interventions Response'

  public check = (object: PostPatientsInterventionsResponseLatest, version: string = this.latestVersion) => {
    cy.wrap(object).should('followSchema', 'postPatientsInterventionsResponse', version)
    return this
  }

  public sanitize = (object: PostPatientsInterventionsResponseLatest, version: string = this.latestVersion) => {
    return successResponseSchema.sanitize(object, version).then(sanitized => {
      return generateSanitizeFunction(
        PostPatientsInterventionsResponseSchema.versionedSchemas,
        'postPatientsInterventionsResponse',
        version
      )(sanitized as PlainObject) as PostPatientsInterventionsResponseLatest
    })
  }
}
