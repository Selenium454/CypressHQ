import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import {
  SuccessResponseSchema,
  SuccessResponse440,
} from '@schemas/api/models/successResponse.modelResponseAttribute.filters.web.core.cloud'
import {
  BillingDetailsModelsSchema,
  BillingDetailsModels440,
} from '@schemas/api/models/billingDetails.models.webApi.cloudServices'
import { generateSanitizeFunction } from '@schemas/api/shared'

const billingDetailsModelSchema = new BillingDetailsModelsSchema()
const successResponseSchema = new SuccessResponseSchema()

/**
 * Response
 */
interface GetPatientsBillingResponse440 extends SuccessResponse440 {
  model: BillingDetailsModels440
}
export interface GetPatientsBillingResponseLatest extends GetPatientsBillingResponse440 {}

export class GetPatientsBillingResponseSchema {
  latestVersion: string = '4.4.0'

  public static response440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'getPatientsBillingResponse',
      type: 'object',
      description: '',
      properties: {
        ...SuccessResponseSchema.successResponse440.schema.properties,
        model: {
          ...BillingDetailsModelsSchema.billingDetailsModels440.schema,
        },
      },
      additionalProperties: true,
    },
    example: (({
      ...SuccessResponseSchema.successResponse440.example,
      model: BillingDetailsModelsSchema.billingDetailsModels440.example,
    } as GetPatientsBillingResponse440) as unknown) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(GetPatientsBillingResponseSchema.response440)

  public static snapshotSubtitle = 'Get Patients Billing Response'

  public check = (object: GetPatientsBillingResponseLatest, version: string = this.latestVersion) => {
    cy.wrap(object).should('followSchema', 'getPatientsBillingResponse', version)
    return this
  }

  public sanitize = (object: GetPatientsBillingResponseLatest, version: string = this.latestVersion) => {
    billingDetailsModelSchema.sanitize(object.model).then(sanitizedModel => {
      object.model = sanitizedModel
    })

    return successResponseSchema.sanitize(object, version).then(sanitized => {
      return generateSanitizeFunction(
        GetPatientsBillingResponseSchema.versionedSchemas,
        'getPatientsBillingResponse',
        version
      )(sanitized as PlainObject) as GetPatientsBillingResponseLatest
    })
  }
}
