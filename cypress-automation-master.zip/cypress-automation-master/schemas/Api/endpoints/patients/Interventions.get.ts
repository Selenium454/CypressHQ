import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import {
  SuccessResponseSchema,
  SuccessResponse440,
} from '@schemas/api/models/successResponse.modelResponseAttribute.filters.web.core.cloud'
import {
  InterventionListItemSchema,
  InterventionListItem440,
} from '@schemas/api/models/interventionListItem.api.models.core.cloud'
import { generateSanitizeFunction } from '@schemas/api/shared'

const successResponseSchema = new SuccessResponseSchema()
const interventionListItemSchema = new InterventionListItemSchema()

/**
 * Response
 */
interface GetPatientsInterventionsResponse440 extends SuccessResponse440 {
  model?: InterventionListItem440[] | null
}
export interface GetPatientsInterventionsResponseLatest extends GetPatientsInterventionsResponse440 {}

export class GetPatientsInterventionsResponseSchema {
  latestVersion: string = '4.4.0'

  public static response440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'getPatientsInterventionsResponse',
      type: 'object',
      description: '',
      properties: {
        ...SuccessResponseSchema.successResponse440.schema.properties,
        model: {
          type: ['array', 'null'],
          description: '',
          items: {
            ...InterventionListItemSchema.interventionListItem440.schema,
          },
          see: InterventionListItemSchema.interventionListItem440,
          required: false,
        },
      },
      additionalProperties: true,
    },
    example: ({
      ...SuccessResponseSchema.successResponse440.example,
      model: [(InterventionListItemSchema.interventionListItem440.example as unknown) as InterventionListItem440],
    } as GetPatientsInterventionsResponse440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(GetPatientsInterventionsResponseSchema.response440)

  public static snapshotSubtitle = 'Get Patients Interventions Response'

  public check = (object: GetPatientsInterventionsResponseLatest, version: string = this.latestVersion) => {
    cy.wrap(object).should('followSchema', 'getPatientsInterventionsResponse', version)
    return this
  }

  public sanitize = (object: GetPatientsInterventionsResponseLatest, version: string = this.latestVersion) => {
    if (object.model) {
      object.model.forEach((interventionListItem, index) => {
        interventionListItemSchema.sanitize(interventionListItem, version).then(sanitizedInterventionListItem => {
          object.model![index] = sanitizedInterventionListItem
        })
      })
    }

    return successResponseSchema.sanitize(object, version).then(sanitized => {
      return generateSanitizeFunction(
        GetPatientsInterventionsResponseSchema.versionedSchemas,
        'getPatientsInterventionsResponse',
        version
      )(sanitized as PlainObject) as GetPatientsInterventionsResponseLatest
    })
  }
}
