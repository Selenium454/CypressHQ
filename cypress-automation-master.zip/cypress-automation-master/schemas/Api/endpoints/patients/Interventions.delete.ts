import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import {
  SuccessResponseSchema,
  SuccessResponse440,
} from '@schemas/api/models/successResponse.modelResponseAttribute.filters.web.core.cloud'
import { generateSanitizeFunction } from '@schemas/api/shared'

const successResponseSchema = new SuccessResponseSchema()

/**
 * Response
 */
interface DeletePatientsInterventionsResponse440 extends SuccessResponse440 {}
export interface DeletePatientsInterventionsResponseLatest extends DeletePatientsInterventionsResponse440 {}

export class DeletePatientsInterventionsResponseSchema {
  latestVersion: string = '4.4.0'

  public static response440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'deletePatientsInterventionsResponse',
      type: 'object',
      description: '',
      properties: {
        ...SuccessResponseSchema.successResponse440.schema.properties,
      },
      additionalProperties: true,
    },
    example: ({
      ...SuccessResponseSchema.successResponse440.example,
    } as DeletePatientsInterventionsResponse440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(DeletePatientsInterventionsResponseSchema.response440)

  public static snapshotSubtitle = 'Delete Patients Interventions Response'

  public check = (object: DeletePatientsInterventionsResponseLatest, version: string = this.latestVersion) => {
    cy.wrap(object).should('followSchema', 'deletePatientsInterventionsResponse', version)
    return this
  }

  public sanitize = (object: DeletePatientsInterventionsResponseLatest, version: string = this.latestVersion) => {
    return successResponseSchema.sanitize(object, version).then(sanitized => {
      return generateSanitizeFunction(
        DeletePatientsInterventionsResponseSchema.versionedSchemas,
        'deletePatientsInterventionsResponse',
        version
      )(sanitized as PlainObject) as DeletePatientsInterventionsResponseLatest
    })
  }
}
