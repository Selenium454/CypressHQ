import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import {
  SuccessResponseSchema,
  SuccessResponse440,
} from '@schemas/api/models/successResponse.modelResponseAttribute.filters.web.core.cloud'
import { OrderMetadataSchema, OrderMetadata440 } from '@schemas/api/models/orderMetadata.orders.cloud.models.core'
import { generateSanitizeFunction } from '@schemas/api/shared'

const orderMetadataSchema = new OrderMetadataSchema()
const successResponseSchema = new SuccessResponseSchema()

/**
 * Response
 */
interface GetOrdersCompletedResponse440 extends SuccessResponse440 {
  model?: OrderMetadata440[] | null
}
export interface GetOrdersCompletedResponseLatest extends GetOrdersCompletedResponse440 {}

export class GetOrdersCompletedResponseSchema {
  latestVersion: string = '4.4.0'

  public static response440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'getOrdersCompletedResponse',
      type: 'object',
      description: '',
      properties: {
        ...SuccessResponseSchema.successResponse440.schema.properties,
        model: {
          type: ['array', 'null'],
          description: '',
          items: {
            ...OrderMetadataSchema.orderMetadata440.schema,
          },
        },
      },
      additionalProperties: true,
    },
    example: ({
      ...SuccessResponseSchema.successResponse440.example,
      model: [OrderMetadataSchema.orderMetadata440.example],
    } as GetOrdersCompletedResponse440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(GetOrdersCompletedResponseSchema.response440)

  public static snapshotSubtitle = 'Get Orders Completed Response'

  public check = (object: GetOrdersCompletedResponseLatest, version: string = this.latestVersion) => {
    cy.wrap(object).should('followSchema', 'getOrdersCompletedResponse', version)
    return this
  }

  public sanitize = (object: GetOrdersCompletedResponseLatest, version: string = this.latestVersion) => {
    if (object.model) {
      object.model.forEach((orderMetadata: OrderMetadata440, index: number) => {
        orderMetadataSchema.sanitize(orderMetadata).then(sanitizedOrderMetadata => {
          object.model![index] = sanitizedOrderMetadata
        })
      })
    }

    return successResponseSchema.sanitize(object, version).then(sanitized => {
      return generateSanitizeFunction(
        GetOrdersCompletedResponseSchema.versionedSchemas,
        'getOrdersCompletedResponse',
        version
      )(sanitized as PlainObject) as GetOrdersCompletedResponseLatest
    })
  }
}
