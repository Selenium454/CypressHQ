import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import {
  SuccessResponse440,
  SuccessResponseSchema,
} from '@schemas/api/models/successResponse.modelResponseAttribute.filters.web.core.cloud'
import { Order440, OrderSchema, OrderLatest } from '@schemas/api/models/order.orders.cloud.models.core'
import { generateSanitizeFunction } from '@schemas/api/shared'

const successResponseSchema = new SuccessResponseSchema()
const orderSchema = new OrderSchema()

/**
 * Response
 */
interface GetOrdersBatchResponse440 extends SuccessResponse440 {
  model?: Order440[] | null
}
export interface GetOrdersBatchResponseLatest extends GetOrdersBatchResponse440 {}

export class GetOrdersBatchResponseSchema {
  latestVersion: string = '4.4.0'

  public static response440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'getOrdersBatchResponse',
      type: 'object',
      description: '',
      properties: {
        ...SuccessResponseSchema.successResponse440.schema.properties,
        model: {
          type: ['array', 'null'],
          description: '',
          items: {
            ...OrderSchema.order440.schema,
          },
        },
      },
      additionalProperties: true,
    },
    example: ({
      ...SuccessResponseSchema.successResponse440.example,
      model: [OrderSchema.order440.example],
    } as GetOrdersBatchResponse440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(GetOrdersBatchResponseSchema.response440)

  public static snapshotSubtitle = 'Get Orders Batch Response'

  public check = (object: GetOrdersBatchResponseLatest, version: string = this.latestVersion) => {
    cy.wrap(object).should('followSchema', 'getOrdersBatchResponse', version)
    return this
  }

  public sanitize = (object: GetOrdersBatchResponseLatest, version: string = this.latestVersion) => {
    if (object.model) {
      object.model.forEach((order: OrderLatest, index: number) => {
        orderSchema.sanitize(order).then(sanitizedOrder => {
          object.model![index] = sanitizedOrder
        })
      })
    }

    return successResponseSchema.sanitize(object, version).then(sanitized => {
      return generateSanitizeFunction(GetOrdersBatchResponseSchema.versionedSchemas, 'getOrdersBatchResponse', version)(
        sanitized as PlainObject
      ) as GetOrdersBatchResponseLatest
    })
  }
}
