import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import {
  SuccessResponseSchema,
  SuccessResponse440,
} from '@schemas/api/models/successResponse.modelResponseAttribute.filters.web.core.cloud'
import { OrderSchema, Order440 } from '@schemas/api/models/order.orders.cloud.models.core'
import { generateSanitizeFunction } from '@schemas/api/shared'

const orderSchema = new OrderSchema()
const successResponseSchema = new SuccessResponseSchema()

/**
 * Response
 */
interface GetOrdersResponse440 extends SuccessResponse440 {
  model?: Order440 | null
}
export interface GetOrdersResponseLatest extends GetOrdersResponse440 {}

export class GetOrdersResponseSchema {
  latestVersion: string = '4.4.0'

  public static response440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'getOrdersResponse',
      type: 'object',
      description: '',
      properties: {
        ...SuccessResponseSchema.successResponse440.schema.properties,
        model: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...OrderSchema.order440.schema.properties,
          },
        },
      },
      additionalProperties: true,
    },
    example: ({
      ...SuccessResponseSchema.successResponse440.example,
      model: OrderSchema.order440.example,
    } as GetOrdersResponse440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(GetOrdersResponseSchema.response440)

  public static snapshotSubtitle = 'Get Orders Response'

  public check = (object: GetOrdersResponseLatest, version: string = this.latestVersion) => {
    cy.wrap(object).should('followSchema', 'getOrdersResponse', version)
    return this
  }

  public sanitize = (object: GetOrdersResponseLatest, version: string = this.latestVersion) => {
    if (object.model) {
      orderSchema.sanitize(object.model).then(sanitizedModel => {
        object.model = sanitizedModel
      })
    }

    return successResponseSchema.sanitize(object, version).then(sanitized => {
      return generateSanitizeFunction(GetOrdersResponseSchema.versionedSchemas, 'getOrdersResponse', version)(
        sanitized as PlainObject
      ) as GetOrdersResponseLatest
    })
  }
}
