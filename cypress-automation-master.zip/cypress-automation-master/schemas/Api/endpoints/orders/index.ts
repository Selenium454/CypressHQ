export * from './batch.get'
export * from './completed.get'
export * from './history.get'
export * from './lock.put'
export * from './new.post'
export * from './orders.get'
export * from './search.post'
export * from './unlock.put'

import { SchemaCollection, combineSchemas } from '@cypress/schema-tools/src'
import { GetOrdersBatchResponseSchema } from './batch.get'
import { GetOrdersCompletedResponseSchema } from './completed.get'
import { GetOrdersHistoryResponseSchema } from './history.get'
import { PutOrdersLockResponseSchema } from './lock.put'
import { PostOrdersNewRequestSchema, PostOrdersNewResponseSchema } from './new.post'
import { GetOrdersResponseSchema } from './orders.get'
import { PostOrdersSearchRequestSchema, PostOrdersSearchResponseSchema } from './search.post'
import { PutOrdersUnlockResponseSchema } from './unlock.put'

export const ordersSchemas: SchemaCollection = combineSchemas(
  GetOrdersBatchResponseSchema.versionedSchemas,

  GetOrdersCompletedResponseSchema.versionedSchemas,

  GetOrdersHistoryResponseSchema.versionedSchemas,

  PutOrdersLockResponseSchema.versionedSchemas,

  PostOrdersNewRequestSchema.versionedSchemas,
  PostOrdersNewResponseSchema.versionedSchemas,

  GetOrdersResponseSchema.versionedSchemas,

  PostOrdersSearchRequestSchema.versionedSchemas,
  PostOrdersSearchResponseSchema.versionedSchemas,

  PutOrdersUnlockResponseSchema.versionedSchemas
)
