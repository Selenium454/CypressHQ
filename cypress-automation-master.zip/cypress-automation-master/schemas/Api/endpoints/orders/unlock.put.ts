import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import {
  SuccessResponseSchema,
  SuccessResponse440,
} from '@schemas/api/models/successResponse.modelResponseAttribute.filters.web.core.cloud'
import { generateSanitizeFunction } from '@schemas/api/shared'

const successResponseSchema = new SuccessResponseSchema()

/**
 * Response
 */
interface PutOrdersUnlockResponse440 extends SuccessResponse440 {}
export interface PutOrdersUnlockResponseLatest extends PutOrdersUnlockResponse440 {}

export class PutOrdersUnlockResponseSchema {
  latestVersion: string = '4.4.0'

  public static response440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'putOrdersUnlockResponse',
      type: 'object',
      description: '',
      properties: {
        ...SuccessResponseSchema.successResponse440.schema.properties,
      },
      additionalProperties: true,
    },
    example: ({
      ...SuccessResponseSchema.successResponse440.example,
    } as PutOrdersUnlockResponse440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(PutOrdersUnlockResponseSchema.response440)

  public static snapshotSubtitle = 'Put Orders Unlock Response'

  public check = (object: PutOrdersUnlockResponseLatest, version: string = this.latestVersion) => {
    cy.wrap(object).should('followSchema', 'putOrdersUnlockResponse', version)
    return this
  }

  public sanitize = (object: PutOrdersUnlockResponseLatest, version: string = this.latestVersion) => {
    return successResponseSchema.sanitize(object, version).then(sanitized => {
      return generateSanitizeFunction(
        PutOrdersUnlockResponseSchema.versionedSchemas,
        'putOrdersUnlockResponse',
        version
      )(sanitized as PlainObject) as PutOrdersUnlockResponseLatest
    })
  }
}
