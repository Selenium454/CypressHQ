import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import {
  SuccessResponseSchema,
  SuccessResponse440,
} from '@schemas/api/models/successResponse.modelResponseAttribute.filters.web.core.cloud'
import { OrderFilterSchema, OrderFilter440 } from '@schemas/api/models/orderFilter.search.core'
import {
  OrderSearchResultSchema,
  OrderSearchResult440,
} from '@schemas/api/models/orderSearchResult.models.webApi.cloudServices'
import { generateSanitizeFunction } from '@schemas/api/shared'

const orderFilterSchema = new OrderFilterSchema()
const orderSearchResultSchema = new OrderSearchResultSchema()
const successResponseSchema = new SuccessResponseSchema()

/**
 * Request
 */
interface PostOrdersSearchRequest440 extends OrderFilter440 {}
export interface PostOrdersSearchRequestLatest extends PostOrdersSearchRequest440 {}

export class PostOrdersSearchRequestSchema {
  latestVersion: string = '4.4.0'
  public static request440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'postOrdersSearchRequest',
      type: 'object',
      description: '',
      properties: {
        ...OrderFilterSchema.orderFilter440.schema.properties,
      },
      additionalProperties: true,
    },
    example: ({
      ...OrderFilterSchema.orderFilter440.example,
    } as PostOrdersSearchRequest440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(PostOrdersSearchRequestSchema.request440)

  public static snapshotSubtitle = 'Post Orders Search Request'

  public check = (object: PostOrdersSearchRequestLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'postOrdersSearchRequest', version)
  }

  public sanitize = (object: PostOrdersSearchRequestLatest, version: string = this.latestVersion) => {
    return orderFilterSchema.sanitize(object, version)
  }
}

/**
 * Response
 */
interface PostOrdersSearchResponse440 extends SuccessResponse440 {
  model?: OrderSearchResult440 | null
}
export interface PostOrdersSearchResponseLatest extends PostOrdersSearchResponse440 {}

export class PostOrdersSearchResponseSchema {
  latestVersion: string = '4.4.0'

  public static response440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'postOrdersSearchResponse',
      type: 'object',
      description: '',
      properties: {
        ...SuccessResponseSchema.successResponse440.schema.properties,
        model: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...OrderSearchResultSchema.orderSearchResult440.schema.properties,
          },
        },
      },
      additionalProperties: true,
    },
    example: ({
      ...SuccessResponseSchema.successResponse440.example,
      model: {
        ...OrderSearchResultSchema.orderSearchResult440.example,
      },
    } as PostOrdersSearchResponse440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(PostOrdersSearchResponseSchema.response440)

  public static snapshotSubtitle = 'Post Orders Search Response'

  public check = (object: PostOrdersSearchResponseLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'postOrdersSearchResponse', version)
  }

  public sanitize = (object: PostOrdersSearchResponseLatest, version: string = this.latestVersion) => {
    if (object.model) {
      orderSearchResultSchema.sanitize(object.model).then(sanitizedModel => {
        object.model = sanitizedModel
      })
    }

    return successResponseSchema.sanitize(object, version).then(sanitized => {
      return generateSanitizeFunction(
        PostOrdersSearchResponseSchema.versionedSchemas,
        'postOrdersSearchResponse',
        version
      )(sanitized as PlainObject) as PostOrdersSearchResponseLatest
    })
  }
}
