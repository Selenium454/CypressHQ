import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import {
  SuccessResponseSchema,
  SuccessResponse440,
} from '@schemas/api/models/successResponse.modelResponseAttribute.filters.web.core.cloud'
import { OrdersRequestSchema, OrdersRequest440 } from '@schemas/api/models/ordersRequest.api.models.core.cloud'
import { OrdersResponseSchema, OrdersResponse440 } from '@schemas/api/models/ordersResponse.api.models.core.cloud'
import { generateSanitizeFunction } from '@schemas/api/shared'

const ordersRequestSchema = new OrdersRequestSchema()
const ordersResponseSchema = new OrdersResponseSchema()
const successResponseSchema = new SuccessResponseSchema()

/**
 * Request
 */
interface PostOrdersNewRequest440 extends OrdersRequest440 {}
export interface PostOrdersNewRequestLatest extends PostOrdersNewRequest440 {}

export class PostOrdersNewRequestSchema {
  latestVersion: string = '4.4.0'

  public static request440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'postOrdersNewRequest',
      type: 'object',
      description: '',
      properties: {
        ...OrdersRequestSchema.ordersRequest440.schema.properties,
      },
      additionalProperties: true,
    },
    example: (({
      ...((OrdersRequestSchema.ordersRequest440.example as unknown) as OrdersRequest440),
    } as PostOrdersNewRequest440) as unknown) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(PostOrdersNewRequestSchema.request440)

  public static snapshotSubtitle = 'Post Orders New Request'

  public check = (object: PostOrdersNewRequestLatest, version: string = this.latestVersion) => {
    cy.wrap(object).should('followSchema', 'postOrdersNewRequest', version)
    return this
  }

  public sanitize = (object: PostOrdersNewRequestLatest, version: string = this.latestVersion) => {
    return ordersRequestSchema.sanitize(object, version)
  }
}

/**
 * Response
 */
interface PostOrdersNewResponse440 extends SuccessResponse440 {
  model?: OrdersResponse440 | null
}
export interface PostOrdersNewResponseLatest extends PostOrdersNewResponse440 {}

export class PostOrdersNewResponseSchema {
  latestVersion: string = '4.4.0'

  public static response440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'postOrdersNewResponse',
      type: 'object',
      description: '',
      properties: {
        ...SuccessResponseSchema.successResponse440.schema.properties,
        model: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...OrdersResponseSchema.ordersResponse440.schema.properties,
            successful: {
              type: ['array', 'null'],
              description: '',
              items: {
                type: ['string', 'null'],
                format: 'orderFor',
                description: '',
                required: false,
              },
              required: false,
            },
          },
        },
      },
      additionalProperties: true,
    },
    example: ({
      ...SuccessResponseSchema.successResponse440.example,
      model: OrdersResponseSchema.ordersResponse440.example,
    } as PostOrdersNewResponse440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(PostOrdersNewResponseSchema.response440)

  public static snapshotSubtitle = 'Post Orders New Response'

  public check = (object: PostOrdersNewResponseLatest, version: string = this.latestVersion) => {
    cy.wrap(object).should('followSchema', 'postOrdersNewResponse', version)
    return this
  }

  public sanitize = (object: PostOrdersNewResponseLatest, version: string = this.latestVersion) => {
    if (object.model) {
      ordersResponseSchema.sanitize(object.model).then(sanitizedModel => {
        object.model = sanitizedModel
      })
    }

    return successResponseSchema.sanitize(object, version).then(sanitized => {
      return generateSanitizeFunction(PostOrdersNewResponseSchema.versionedSchemas, 'postOrdersNewResponse', version)(
        sanitized as PlainObject
      ) as PostOrdersNewResponseLatest
    })
  }
}
