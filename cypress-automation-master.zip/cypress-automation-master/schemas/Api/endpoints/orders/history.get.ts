import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import {
  SuccessResponseSchema,
  SuccessResponse440,
} from '@schemas/api/models/successResponse.modelResponseAttribute.filters.web.core.cloud'
import {
  PatientOrderMetadataSchema,
  PatientOrderMetadata440,
} from '@schemas/api/models/patientOrderMetadata.orders.cloud.models.core'
import { generateSanitizeFunction } from '@schemas/api/shared'

const successResponseSchema = new SuccessResponseSchema()
const patientOrderMetadataSchema = new PatientOrderMetadataSchema()

/**
 * Response
 */
interface GetOrdersHistoryResponse440 extends SuccessResponse440 {
  model?: PatientOrderMetadata440[] | null
}
export interface GetOrdersHistoryResponseLatest extends GetOrdersHistoryResponse440 {}

export class GetOrdersHistoryResponseSchema {
  latestVersion: string = '4.4.0'

  public static response440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'getOrdersHistoryResponse',
      type: 'object',
      description: '',
      properties: {
        ...SuccessResponseSchema.successResponse440.schema.properties,
        model: {
          type: ['array', 'null'],
          description: '',
          items: {
            ...PatientOrderMetadataSchema.patientOrderMetadata440.schema,
          },
        },
      },
      additionalProperties: true,
    },
    example: ({
      ...SuccessResponseSchema.successResponse440.example,
      model: [PatientOrderMetadataSchema.patientOrderMetadata440.example],
    } as GetOrdersHistoryResponse440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(GetOrdersHistoryResponseSchema.response440)

  public static snapshotSubtitle = 'Get Orders History Response'

  public check = (object: GetOrdersHistoryResponseLatest, version: string = this.latestVersion) => {
    cy.wrap(object).should('followSchema', 'getOrdersHistoryResponse', version)
    return this
  }

  public sanitize = (object: GetOrdersHistoryResponseLatest, version: string = this.latestVersion) => {
    if (object.model) {
      patientOrderMetadataSchema.sanitize(object.model[object.model.length - 1]).then(sanitizedPatientOrderMetadata => {
        object.model = [sanitizedPatientOrderMetadata]
      })
    }

    return successResponseSchema.sanitize(object, version).then(sanitized => {
      return generateSanitizeFunction(
        GetOrdersHistoryResponseSchema.versionedSchemas,
        'getOrdersHistoryResponse',
        version
      )(sanitized as PlainObject) as GetOrdersHistoryResponseLatest
    })
  }
}
