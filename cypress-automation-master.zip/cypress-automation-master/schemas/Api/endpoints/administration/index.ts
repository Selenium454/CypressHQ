export * from './addFacility.post'

import { SchemaCollection, combineSchemas } from '@cypress/schema-tools/src'
import {
  PostAdministrationAddFacilityRequestSchema,
  PostAdministrationAddFacilityResponseSchema,
} from './addFacility.post'

export const administrationSchemas: SchemaCollection = combineSchemas(
  PostAdministrationAddFacilityRequestSchema.versionedSchemas,
  PostAdministrationAddFacilityResponseSchema.versionedSchemas
)
