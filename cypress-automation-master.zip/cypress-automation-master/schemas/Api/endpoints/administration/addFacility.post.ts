import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import {
  SuccessResponseSchema,
  SuccessResponse440,
} from '@schemas/api/models/successResponse.modelResponseAttribute.filters.web.core.cloud'
import { generateSanitizeFunction } from '@schemas/api/shared'
import { FacilitySchema, Facility440 } from '@schemas/api/models/facility.cloud.models.core'

const successResponseSchema = new SuccessResponseSchema()
const facilityRequestSchema = new FacilitySchema()

/**
 * Request
 */
interface PostAdministrationAddFacilityRequest440 extends Facility440 {}
export interface PostAdministrationAddFacilityRequestLatest extends PostAdministrationAddFacilityRequest440 {}

export class PostAdministrationAddFacilityRequestSchema {
  latestVersion: string = '4.4.0'

  public static request440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'postAdministrationAddFacilityRequest',
      type: 'object',
      description: '',
      properties: {
        ...FacilitySchema.facility440.schema.properties,
      },
      additionalProperties: true,
    },
    example: {
      ...((FacilitySchema.facility440.example as unknown) as PlainObject),
    },
  }

  public static versionedSchemas = versionSchemas(PostAdministrationAddFacilityRequestSchema.request440)

  public static snapshotSubtitle = 'Post Administration Add Facility Request'

  public check = (object: PostAdministrationAddFacilityRequestLatest, version: string = this.latestVersion) => {
    cy.wrap(object).should('followSchema', 'postAdministrationAddFacilityRequest', version)
    return this
  }

  public sanitize = (object: PostAdministrationAddFacilityRequestLatest, version: string = this.latestVersion) => {
    return facilityRequestSchema.sanitize(object, version)
  }
}

/**
 * Response
 */
interface PostAdministrationAddFacilityResponse440 extends SuccessResponse440 {
  model?: string | null
}
export interface PostAdministrationAddFacilityResponseLatest extends PostAdministrationAddFacilityResponse440 {}

export class PostAdministrationAddFacilityResponseSchema {
  latestVersion: string = '4.4.0'

  public static response440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'postAdministrationAddFacility',
      type: 'object',
      description: '',
      properties: {
        ...SuccessResponseSchema.successResponse440.schema.properties,
        model: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: true,
    },
    example: ({
      ...SuccessResponseSchema.successResponse440.example,
    } as PostAdministrationAddFacilityResponse440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(PostAdministrationAddFacilityResponseSchema.response440)

  public static snapshotSubtitle = 'Post Administration Add Facility Response'

  public check = (object: PostAdministrationAddFacilityResponseLatest, version: string = this.latestVersion) => {
    cy.wrap(object).should('followSchema', 'postAdministrationAddFacility', version)
    return this
  }

  public sanitize = (object: PostAdministrationAddFacilityResponseLatest, version: string = this.latestVersion) => {
    return successResponseSchema.sanitize(object, version).then(sanitized => {
      return generateSanitizeFunction(
        PostAdministrationAddFacilityResponseSchema.versionedSchemas,
        'postAdministrationAddFacility',
        version
      )(sanitized as PlainObject) as PostAdministrationAddFacilityResponseLatest
    })
  }
}
