import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import {
  SuccessResponseSchema,
  SuccessResponse440,
} from '@schemas/api/models/successResponse.modelResponseAttribute.filters.web.core.cloud'
import { generateSanitizeFunction } from '@schemas/api/shared'
import { DoctorFilter440, DoctorFilterSchema } from '@schemas/api/models/doctorFilter.search.core'
import { IResultPageSchema, IResultPage440 } from '@schemas/api/models/iResultPage.paging.models.core'
import {
  DoctorSearchResultSchema,
  DoctorSearchResultLatest,
  DoctorSearchResult440,
} from '@schemas/api/models/doctorSearchResult.search.core'

const successResponseSchema = new SuccessResponseSchema()
const doctorFilterSchema = new DoctorFilterSchema()
const doctorSearchResultSchema = new DoctorSearchResultSchema()

/**
 * Request
 */
interface PostDoctorsSearchRequest440 extends DoctorFilter440 {}
export interface PostDoctorsSearchRequestLatest extends PostDoctorsSearchRequest440 {}

export class PostDoctorsSearchRequestSchema {
  latestVersion: string = '4.4.0'

  public static request440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'postDoctorsSearchRequest',
      type: 'object',
      description: '',
      properties: {
        ...DoctorFilterSchema.doctorFilter440.schema.properties,
      },
      additionalProperties: true,
    },
    example: DoctorFilterSchema.doctorFilter440.example,
  }

  public static versionedSchemas = versionSchemas(PostDoctorsSearchRequestSchema.request440)

  public static snapshotSubtitle = 'Post Doctors Search Request'

  public check = (object: PostDoctorsSearchRequestLatest, version: string = this.latestVersion) => {
    cy.wrap(object).should('followSchema', 'postDoctorsSearchRequest', version)
    return this
  }

  public sanitize = (object: PostDoctorsSearchRequestLatest, version: string = this.latestVersion) => {
    return doctorFilterSchema.sanitize(object, version)
  }
}

/**
 * Response
 */
interface PostDoctorsSearchResponseModel440 extends IResultPage440 {
  items?: DoctorSearchResult440[] | null
}
interface PostDoctorsSearchResponse440 extends SuccessResponse440 {
  model?: PostDoctorsSearchResponseModel440 | null
}
export interface PostDoctorsSearchResponseLatest extends PostDoctorsSearchResponse440 {}

export class PostDoctorsSearchResponseSchema {
  latestVersion: string = '4.4.0'

  public static response440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'postDoctorsSearch',
      type: 'object',
      description: '',
      properties: {
        ...SuccessResponseSchema.successResponse440.schema.properties,
        model: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...IResultPageSchema.iResultPage440.schema.properties,
            items: {
              type: ['array', 'null'],
              description: '',
              items: {
                type: ['object', 'null'],
                description: '',
                properties: {
                  ...DoctorSearchResultSchema.doctorSearchResult440.schema.properties,
                },
                see: DoctorSearchResultSchema.doctorSearchResult440,
              },
            },
          },
          see: IResultPageSchema.iResultPage440,
          required: false,
        },
      },
      additionalProperties: true,
    },
    example: ({
      ...SuccessResponseSchema.successResponse440.example,
      model: {
        ...IResultPageSchema.iResultPage440.example,
        items: [{ ...DoctorSearchResultSchema.doctorSearchResult440.example }],
      },
    } as PostDoctorsSearchResponse440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(PostDoctorsSearchResponseSchema.response440)

  public static snapshotSubtitle = 'Post Doctors Search Response'

  public check = (object: PostDoctorsSearchResponseLatest, version: string = this.latestVersion) => {
    cy.wrap(object).should('followSchema', 'postDoctorsSearch', version)
    return this
  }

  public sanitize = (object: PostDoctorsSearchResponseLatest, version: string = this.latestVersion) => {
    if (object.model && object.model.items) {
      object.model.items.forEach((searchResult: DoctorSearchResultLatest, index: number) => {
        doctorSearchResultSchema.sanitize(searchResult).then(sanitizedSearchResult => {
          object.model!.items![index] = sanitizedSearchResult
        })
      })
    }

    return successResponseSchema.sanitize(object, version).then(sanitized => {
      return generateSanitizeFunction(PostDoctorsSearchResponseSchema.versionedSchemas, 'postDoctorsSearch', version)(
        sanitized as PlainObject
      ) as PostDoctorsSearchResponseLatest
    })
  }
}
