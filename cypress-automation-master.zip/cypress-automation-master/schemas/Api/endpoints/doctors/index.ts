export * from './search.post'

import { SchemaCollection, combineSchemas } from '@cypress/schema-tools/src'
import { PostDoctorsSearchRequestSchema, PostDoctorsSearchResponseSchema } from './search.post'

export const doctorsSchemas: SchemaCollection = combineSchemas(
  PostDoctorsSearchRequestSchema.versionedSchemas,
  PostDoctorsSearchResponseSchema.versionedSchemas
)
