import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'

import { generateSanitizeFunction } from '../shared'

export interface OrdersResponse440 {
  successful?: string[] | null
  faulted?: string[] | null
}
export interface OrdersResponseLatest extends OrdersResponse440 {}

export class OrdersResponseSchema {
  latestVersion: string = '4.4.0'

  public static ordersResponse440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'ordersResponseSchema',
      type: 'object',
      description: 'Time slots model for medication time slots.',
      properties: {
        successful: {
          type: ['array', 'null'],
          description: '',
          items: {
            type: ['string', 'null'],
            format: 'userId',
            description: '',
            required: false,
          },
          required: false,
        },
        faulted: {
          type: ['array', 'null'],
          description: '',
          items: {
            type: ['string', 'null'],
            description: '',
            required: false,
          },
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({} as OrdersResponse440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(OrdersResponseSchema.ordersResponse440)

  public static snapshotSubtitle = 'Order Response Model'

  public check = (object: OrdersResponseLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'ordersResponseSchema', version)
  }

  public sanitize = (object: OrdersResponseLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(OrdersResponseSchema.versionedSchemas, 'ordersResponseSchema', version)(
        object as PlainObject
      ) as OrdersResponseLatest
    })
  }
}
