import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { UserReference440, UserReferenceSchema } from './userReference.cloud.models.core'

import { generateSanitizeFunction } from '../shared'

const userReferenceSchema = new UserReferenceSchema()

export interface Lock440 {
  lockedBy?: UserReference440 | null
  lockedUntil?: string | null
  lockId?: string | null
}
export interface LockLatest extends Lock440 {}

export class LockSchema {
  latestVersion: string = '4.4.0'

  public static lock440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'lockSchema',
      type: 'object',
      description: '',
      properties: {
        lockedBy: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...UserReferenceSchema.userReference440.schema.properties,
          },
          see: UserReferenceSchema.userReference440,
          required: false,
        },
        lockedUntil: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        lockId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({
      lockedBy: UserReferenceSchema.userReference440.example,
      lockedUntil: '2020-08-22T06:00:00.000Z',
      lockId: 'QA134567',
    } as Lock440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(LockSchema.lock440)

  public static snapshotSubtitle = 'Lock Model'

  public check = (object: LockLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'lockSchema', version)
  }

  public sanitize = (object: LockLatest, version: string = this.latestVersion) => {
    if (object.lockedBy) {
      userReferenceSchema.sanitize(object.lockedBy).then(sanitizedUserReference => {
        object.lockedBy = sanitizedUserReference
      })
    }

    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(LockSchema.versionedSchemas, 'lockSchema', version)(
        object as PlainObject
      ) as LockLatest
    })
  }
}
