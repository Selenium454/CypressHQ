import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { Address440, AddressSchema } from './address.cloud.models.core'
import { RelationshipValues } from '../types'

import { generateSanitizeFunction } from '../shared'

const addressSchema = new AddressSchema()

export interface Contact440 {
  address?: Address440
  email?: string | null
  firstName: string
  isMainContact?: boolean
  mobileNumber?: string | null
  phoneNumber?: string | null
  relationship?: typeof RelationshipValues[number] | null
  surName: string
}
export interface ContactLatest extends Contact440 {}

export class ContactSchema {
  latestVersion: string = '4.4.0'

  public static contact440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'contactSchema',
      type: 'object',
      description: 'Patient contact model.',
      properties: {
        address: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...AddressSchema.address440.schema.properties,
          },
          see: AddressSchema.address440,
          required: false,
        },
        firstName: {
          type: ['null', 'string'],
          description: "Contact's first name.",
          required: true,
        },
        isMainContact: {
          type: 'boolean',
          description: 'Is the contact currently the main contact for the patient?',
          required: false,
        },
        surName: {
          type: ['null', 'string'],
          description: "Contact's surname.",
          required: true,
        },
        email: {
          type: ['null', 'string'],
          format: 'emailAddress',
          description: "Contact's current email address.",
          required: false,
        },
        mobileNumber: {
          type: ['null', 'string'],
          description: "Contact's current mobile number.",
          required: false,
        },
        phoneNumber: {
          type: ['null', 'string'],
          description: "Contact's current phone number.",
          required: false,
        },
        relationship: {
          type: ['null', 'string'],
          description: "Contact's relationship with the customer.",
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: (({
      address: AddressSchema.address440.example as Address440,
      firstName: 'Ben',
      isMainContact: false,
      surName: 'Spinks',
      email: 'ben.spinks@epicdigitalau.com',
      mobileNumber: '0400921423',
      phoneNumber: '662841231',
      relationship: 'spouse',
    } as Contact440) as unknown) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(ContactSchema.contact440)

  public static snapshotSubtitle = 'Contact Model'

  public check = (object: ContactLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'contactSchema', version)
  }

  public sanitize = (object: ContactLatest, version: string = this.latestVersion) => {
    if (object.address) {
      addressSchema.sanitize(object.address).then(sanitizedAddress => {
        object.address = sanitizedAddress
      })
    }

    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(ContactSchema.versionedSchemas, 'contactSchema', version)(
        (object as unknown) as PlainObject
      ) as ContactLatest
    })
  }
}
