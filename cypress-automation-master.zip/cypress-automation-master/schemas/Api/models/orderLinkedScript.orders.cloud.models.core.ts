import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'

import { generateSanitizeFunction } from '../shared'

export interface OrderLinkedScript440 {
  siteId?: number | null
  scriptNumber?: number | null
  dispensingDate?: string | null
}
export interface OrderLinkedScriptLatest extends OrderLinkedScript440 {}

export class OrderLinkedScriptSchema {
  latestVersion: string = '4.4.0'

  public static orderLinkedScript440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'orderLinkedScriptSchema',
      type: 'object',
      description: 'Time slots model for medication time slots.',
      properties: {
        siteId: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        scriptNumber: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        dispensingDate: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({} as OrderLinkedScript440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(OrderLinkedScriptSchema.orderLinkedScript440)

  public static snapshotSubtitle = 'Order Linked Script Model'

  public check = (object: OrderLinkedScriptLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'notationSchema', version)
  }

  public sanitize = (object: OrderLinkedScriptLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(OrderLinkedScriptSchema.versionedSchemas, 'orderLinkedScriptSchema', version)(
        object as PlainObject
      ) as OrderLinkedScriptLatest
    })
  }
}
