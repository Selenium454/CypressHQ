import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { OrderContextValues, ClassificationValues } from '../types/models.types'
import { OrderRequest440, OrderRequestSchema } from './orderRequest.api.models.core.cloud'

import { generateSanitizeFunction } from '../shared'

export interface OrdersRequest440 {
  context: typeof OrderContextValues[number]
  roundCode?: string | null
  facilityCode?: string | null
  classification: typeof ClassificationValues[number]
  orders: OrderRequest440[]
}
export interface OrdersRequestLatest extends OrdersRequest440 {}

export class OrdersRequestSchema {
  latestVersion: string = '4.4.0'

  public static ordersRequest440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'ordersRequestSchema',
      type: 'object',
      description: '',
      properties: {
        context: {
          type: ['string', 'null'],
          description: '',
          enum: (OrderContextValues as unknown) as string[],
          required: false,
        },
        roundCode: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        facilityCode: {
          type: ['string', 'null'],
          format: 'facilityCode',
          description: '',
          required: false,
        },
        classification: {
          type: ['string', 'null'],
          description: '',
          enum: (ClassificationValues as unknown) as string[],
          required: false,
        },
        orders: {
          type: 'array',
          description: '',
          items: {
            ...OrderRequestSchema.orderRequest440.schema,
          },
          see: OrderRequestSchema.orderRequest440,
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: (({
      context: 'personal',
      classification: 'personal',
      orders: [(OrderRequestSchema.orderRequest440.example as unknown) as OrderRequest440],
    } as OrdersRequest440) as unknown) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(OrdersRequestSchema.ordersRequest440)

  public static snapshotSubtitle = 'ORder Request Model'

  public check = (object: OrdersRequestLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'ordersRequestSchema', version)
  }

  public sanitize = (object: OrdersRequestLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(OrdersRequestSchema.versionedSchemas, 'ordersRequestSchema', version)(
        (object as unknown) as PlainObject
      ) as OrdersRequestLatest
    })
  }
}
