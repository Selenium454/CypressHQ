import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'

import { generateSanitizeFunction } from '../shared'

export interface UserReference440 {
  id?: string | null
  name?: string | null
}
export interface UserReferenceLatest extends UserReference440 {}

export class UserReferenceSchema {
  latestVersion: string = '4.4.0'

  public static userReference440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'userReferenceSchema',
      type: 'object',
      description: '',
      properties: {
        id: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        name: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({
      id: '0001780094',
      name: 'John PharmacyAdmin',
    } as UserReference440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(UserReferenceSchema.userReference440)

  public static snapshotSubtitle = 'User Reference Model'

  public check = (object: UserReferenceLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'userReferenceSchema', version)
  }

  public sanitize = (object: UserReferenceLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(UserReferenceSchema.versionedSchemas, 'userReferenceSchema', version)(
        object as PlainObject
      ) as UserReferenceLatest
    })
  }
}
