import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { ConcessionEntitledValues, NonActiveReasonValues, RepatCardTypeValues } from '../types'
import { MedicalServiceResponse440, MedicalServiceResponseSchema } from './medicalServiceResponse.cloud.models.core'

import { generateSanitizeFunction } from '../shared'

export interface PatientInnerDetails440 {
  activeInHub?: boolean | null
  allergies?: string | null
  concessionEntitled?: typeof ConcessionEntitledValues[number] | null
  concessionNumber?: string | null
  concessionType?: string | null
  concessionValidToDate?: string | null
  ctg?: boolean | null
  medicationInstructions?: string | null
  medicareFirstName?: string | null
  medicareNumber?: string | null
  medicareSurName?: string | null
  medicareValidDate?: string | null
  nonActiveReason?: typeof NonActiveReasonValues[number] | null
  repatCardType?: typeof RepatCardTypeValues[number] | null
  repatNumber?: string | null
  safetyNetNumber?: string | null
  services?: MedicalServiceResponse440[] | null
}
export interface PatientInnerDetailsLatest extends PatientInnerDetails440 {}

export class PatientInnerDetailsSchema {
  latestVersion: string = '4.4.0'

  public static patientInnerDetails440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'patientInnerDetailsSchema',
      type: 'object',
      description: '',
      properties: {
        activeInHub: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        allergies: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        concessionEntitled: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        concessionNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        concessionType: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        concessionValidToDate: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        ctg: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        medicationInstructions: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        medicareFirstName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        medicareNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        medicareSurName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        medicareValidDate: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        nonActiveReason: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        repatCardType: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        repatNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        safetyNetNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        services: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...MedicalServiceResponseSchema.medicalServiceResponse440.schema.properties,
          },
          see: MedicalServiceResponseSchema.medicalServiceResponse440,
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({
      activeInHub: true,
      allergies: null,
      ctg: false,
      medicationInstructions: null,
      services: [
        (MedicalServiceResponseSchema.medicalServiceResponse440.example as unknown) as MedicalServiceResponse440,
      ],
    } as PatientInnerDetails440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(PatientInnerDetailsSchema.patientInnerDetails440)

  public static snapshotSubtitle = 'Patient Inner Details Model'

  public check = (object: PatientInnerDetailsLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'patientInnerDetailsSchema', version)
  }

  public sanitize = (object: PatientInnerDetailsLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(PatientInnerDetailsSchema.versionedSchemas, 'patientInnerDetailsSchema', version)(
        object as PlainObject
      ) as PatientInnerDetailsLatest
    })
  }
}
