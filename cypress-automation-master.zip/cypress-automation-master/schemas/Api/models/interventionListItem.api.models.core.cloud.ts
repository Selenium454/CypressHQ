import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { UserReference440, UserReferenceSchema } from './userReference.cloud.models.core'
import {
  ConsequenceImpactValues,
  DrugProblemValues,
  DrugProblemDetailsValues,
  LikelihoodValues,
  RecommendationValues,
  RecommendationDetailsValues,
} from '../types'

import { generateSanitizeFunction } from '../shared'

const userReferenceSchema = new UserReferenceSchema()

export interface InterventionListItem440 {
  userReference?: UserReference440
  pharmacyName?: string | null
  facilityName?: string | null
  roundName?: string | null
  consequenceImpact?: typeof ConsequenceImpactValues[number]
  content?: string | null
  drugNames?: string[] | null
  drugProblem?: typeof DrugProblemValues[number]
  drugProblemDetails?: typeof DrugProblemDetailsValues[number]
  facilityCode?: string | null
  fromDate?: string | null
  id?: string | null
  interventionDate?: string | null
  likelihood?: typeof LikelihoodValues[number]
  pharmacyId?: string | null
  recommendation?: typeof RecommendationValues[number]
  recommendationDetails?: typeof RecommendationDetailsValues[number]
  roundCode?: string | null
  urNumber?: string | null
  writtenBy?: string | null
}
export interface InterventionListItemLatest extends InterventionListItem440 {}

export class InterventionListItemSchema {
  latestVersion: string = '4.4.0'

  public static interventionListItem440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'interventionListItemSchema',
      type: 'object',
      description: '',
      properties: {
        userReference: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...UserReferenceSchema.userReference440.schema.properties,
          },
          see: UserReferenceSchema.userReference440,
          required: false,
        },
        pharmacyName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        facilityName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        roundName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        consequenceImpact: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        content: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        drugNames: {
          type: ['array', 'null'],
          description: '',
          required: false,
        },
        drugProblem: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        drugProblemDetails: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        facilityCode: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        fromDate: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        id: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        interventionDate: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        likelihood: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        pharmacyId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        recommendation: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        recommendationDetails: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        roundCode: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        urNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        writtenBy: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({
      userReference: UserReferenceSchema.userReference440.example,
      pharmacyName: 'Epic Pharmacy Sunshine Coast',
      facilityName: 'Buderim Private Hospital',
      roundName: 'BD 4B Ward',
      consequenceImpact: 'moderate',
      content: 'test',
      drugNames: ['test'],
      drugProblem: 'overOrUnderDose',
      drugProblemDetails: 'prescribedDoseTooHigh',
      facilityCode: 'TSCP',
      fromDate: '2019-08-24T12:46:06',
      id: '9b2a78b5-882c-4bc7-b095-32087de3818e',
      interventionDate: '2019-08-24T12:46:06',
      likelihood: 'almostCertain',
      pharmacyId: '78',
      recommendation: 'referralRequired',
      recommendationDetails: 'referToPrescriber',
      roundCode: 'B4B',
      urNumber: '159560',
      writtenBy: '0001780094',
    } as InterventionListItem440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(InterventionListItemSchema.interventionListItem440)

  public static snapshotSubtitle = 'Intervention List Item Model'

  public check = (object: InterventionListItemLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'interventionListItemSchema', version)
  }

  public sanitize = (object: InterventionListItemLatest, version: string = this.latestVersion) => {
    if (object.userReference) {
      userReferenceSchema.sanitize(object.userReference).then(sanitizedUserReference => {
        object.userReference = sanitizedUserReference
      })
    }

    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(
        InterventionListItemSchema.versionedSchemas,
        'interventionListItemSchema',
        version
      )(object as PlainObject) as InterventionListItemLatest
    })
  }
}
