import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { DoctorReference440, DoctorReferenceSchema } from './doctorReference.cloud.models.core'
import { FacilityTypeValues, InactiveServiceOtherReasonValues, ServiceStatusValues, ServiceTypeValues } from '../types'
import { HealthFund440, HealthFundSchema } from './healthFund.cloud.models.core'
import { ExternalIdentifier440, ExternalIdentifierSchema } from './externalIdentifier.cloud.models.core'
import { TimeSlots440, TimeSlotsSchema } from './timeSlots.cloud.models.core'

import { generateSanitizeFunction } from '../shared'

const healthFundSchema = new HealthFundSchema()

export interface MedicalService440 {
  added?: string | null
  authorizationFormUrl?: string | null
  bedNumber?: string | null
  businessUnitId: string
  doctors?: DoctorReference440[]
  facilityCode: string
  facilityName?: string | null
  facilityType: typeof FacilityTypeValues[number]
  healthFund?: HealthFund440
  id?: string | null
  identifiers?: ExternalIdentifier440[]
  inactiveServiceOtherReason?: string | null
  inactiveServiceReason?: typeof InactiveServiceOtherReasonValues[number]
  patientNumber?: string | null
  roomNumber?: string | null
  serviceStatus?: typeof ServiceStatusValues[number]
  serviceType: typeof ServiceTypeValues[number]
  statusChangedToInactive: boolean
  synced?: string | null
  timeSlots?: TimeSlots440[]
  updated?: string | null
  urNumber?: string | null
  wardCode?: string | null
  wardName?: string | null
}
export interface MedicalServiceLatest extends MedicalService440 {}

export class MedicalServiceSchema {
  latestVersion: string = '4.4.0'

  public static medicalService440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'medicalServiceSchema',
      type: 'object',
      description: 'Generic services model for use on patients.',
      properties: {
        added: {
          type: ['string', 'null'],
          format: 'dateTimeWithTimezone',
          description: '',
          required: false,
        },
        authorizationFormUrl: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        bedNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        businessUnitId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        doctors: {
          type: ['array', 'null'],
          description: '',
          items: {
            ...DoctorReferenceSchema.doctorReference440.schema,
          },
          see: DoctorReferenceSchema.doctorReference440,
          required: false,
        },
        facilityCode: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        facilityName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        facilityType: {
          type: 'string',
          description: '',
          required: false,
        },
        healthFund: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...HealthFundSchema.healthFund440.schema.properties,
          },
          see: HealthFundSchema.healthFund440,
          required: false,
        },
        id: {
          type: 'string',
          format: 'trackId',
          description: '',
          required: false,
        },
        identifiers: {
          type: ['array', 'null'],
          description: '',
          items: {
            ...ExternalIdentifierSchema.externalIdentifier440.schema,
          },
          see: ExternalIdentifierSchema.externalIdentifier440,
          required: false,
        },
        inactiveServiceOtherReason: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        inactiveServiceReason: {
          type: 'string',
          description: '',
          required: false,
        },
        patientNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        roomNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        serviceStatus: {
          type: 'string',
          description: '',
          required: false,
        },
        serviceType: {
          type: 'string',
          description: '',
          required: false,
        },
        statusChangedToInactive: {
          type: 'boolean',
          description: '',
          required: false,
        },
        synced: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        timeSlots: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...TimeSlotsSchema.timeSlots440.schema.properties,
          },
          see: TimeSlotsSchema.timeSlots440,
          required: false,
        },
        updated: {
          type: ['string', 'null'],
          format: 'dateTime',
          description: '',
          required: false,
        },
        urNumber: {
          type: ['string', 'null'],
          format: 'urNumber',
          description: '',
          required: false,
        },
        wardCode: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        wardName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: (({
      added: null,
      authorizationFormUrl: '',
      bedNumber: '2',
      businessUnitId: '72',
      doctors: [(DoctorReferenceSchema.doctorReference440.example as unknown) as DoctorReference440],
      facilityCode: 'GRAN',
      facilityName: 'Regis Birkdale',
      facilityType: 'agedCare',
      healthFund: HealthFundSchema.healthFund440.example as HealthFund440,
      id: 'GRAN_agedCare',
      identifiers: [(ExternalIdentifierSchema.externalIdentifier440.example as unknown) as ExternalIdentifier440],
      inactiveServiceOtherReason: '',
      inactiveServiceReason: 'none',
      patientNumber: '1234',
      roomNumber: '1',
      serviceStatus: 'active',
      serviceType: 'agedCare',
      statusChangedToInactive: true,
      synced: null,
      timeSlots: [TimeSlotsSchema.timeSlots440.example as TimeSlots440],
      updated: null,
      urNumber: '0000584892',
      wardCode: 'GRHM',
      wardName: 'Hunter & Mclaren',
    } as MedicalService440) as unknown) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(MedicalServiceSchema.medicalService440)

  public static snapshotSubtitle = 'Medical Service Model'

  public check = (object: MedicalServiceLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'medicalServiceSchema', version)
  }

  public sanitize = (object: MedicalServiceLatest, version: string = this.latestVersion) => {
    if (object.healthFund) {
      healthFundSchema.sanitize(object.healthFund).then(sanitizedHealthFund => {
        object.healthFund = sanitizedHealthFund
      })
    }

    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(MedicalServiceSchema.versionedSchemas, 'medicalServiceSchema', version)(
        (object as unknown) as PlainObject
      ) as MedicalServiceLatest
    })
  }
}
