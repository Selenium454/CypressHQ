import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { ReferenceTypeValues } from '../types'
import { Referral440, ReferralSchema } from './referral.cloud.models.core'

import { generateSanitizeFunction } from '../shared'

export interface DoctorReference440 {
  practiceId?: string
  referenceType: typeof ReferenceTypeValues[number]
  referrals?: Referral440[]
  userId: string
}
export interface DoctorReferenceLatest extends DoctorReference440 {}

export class DoctorReferenceSchema {
  latestVersion: string = '4.4.0'

  public static doctorReference440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'doctorReferenceSchema',
      type: 'object',
      description: 'Doctor reference model used inside patient services.',
      properties: {
        practiceId: {
          type: ['string', 'null'],
          description: 'ID of the practice the doctor belongs to.',
          required: false,
        },
        referenceType: {
          type: 'string',
          description: "The doctor's reference type.",
          required: true,
        },
        referrals: {
          type: ['array', 'null'],
          description: '',
          items: {
            ...ReferralSchema.referral440.schema,
          },
          see: ReferralSchema.referral440,
          required: false,
        },
        userId: {
          type: ['string', 'null'],
          description: 'The user ID of the doctor.',
          required: true,
        },
      },
      additionalProperties: false,
    },
    example: (({
      practiceId: 'b75831574c234ec896106dc0176c83c9',
      referenceType: 'surgeon',
      referrals: [ReferralSchema.referral440.example as Referral440],
      userId: '0000016547',
    } as DoctorReference440) as unknown) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(DoctorReferenceSchema.doctorReference440)

  public static snapshotSubtitle = 'Doctor Reference Model'

  public check = (object: DoctorReferenceLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'doctorReferenceSchema', version)
  }

  public sanitize = (object: DoctorReferenceLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(DoctorReferenceSchema.versionedSchemas, 'doctorReferenceSchema', version)(
        (object as unknown) as PlainObject
      ) as DoctorReferenceLatest
    })
  }
}
