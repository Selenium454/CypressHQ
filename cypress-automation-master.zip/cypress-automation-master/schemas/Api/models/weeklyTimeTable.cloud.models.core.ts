import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'

import { generateSanitizeFunction } from '../shared'

export interface WeeklyTimeTable440 {
  sunday?: string[] | null
  monday?: string[] | null
  tuesday?: string[] | null
  wednesday?: string[] | null
  thursday?: string[] | null
  friday?: string[] | null
  saturday?: string[] | null
}
export interface WeeklyTimeTableLatest extends WeeklyTimeTable440 {}

export class WeeklyTimeTableSchema {
  latestVersion: string = '4.4.0'

  public static weeklyTimeTable440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'weeklyTimeTableSchema',
      type: 'object',
      description: '',
      properties: {
        sunday: {
          type: ['array', 'null'],
          description: '',
          items: {
            type: ['string', 'null'],
            required: false,
          },
          required: false,
        },
        monday: {
          type: ['array', 'null'],
          description: '',
          items: {
            type: ['string', 'null'],
            required: false,
          },
          required: false,
        },
        tuesday: {
          type: ['array', 'null'],
          description: '',
          items: {
            type: ['string', 'null'],
            required: false,
          },
          required: false,
        },
        wednesday: {
          type: ['array', 'null'],
          description: '',
          items: {
            type: ['string', 'null'],
            required: false,
          },
          required: false,
        },
        thursday: {
          type: ['array', 'null'],
          description: '',
          items: {
            type: ['string', 'null'],
            required: false,
          },
          required: false,
        },
        friday: {
          type: ['array', 'null'],
          description: '',
          items: {
            type: ['string', 'null'],
            required: false,
          },
          required: false,
        },
        saturday: {
          type: ['array', 'null'],
          description: '',
          items: {
            type: ['string', 'null'],
            required: false,
          },
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: (({
      userId: '12345678',
      referenceType: 'treating',
    } as WeeklyTimeTable440) as unknown) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(WeeklyTimeTableSchema.weeklyTimeTable440)

  public static snapshotSubtitle = 'Weekly Time Table Model'

  public check = (object: WeeklyTimeTableLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'weeklyTimeTableSchema', version)
  }

  public sanitize = (object: WeeklyTimeTableLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(WeeklyTimeTableSchema.versionedSchemas, 'weeklyTimeTableSchema', version)(
        (object as unknown) as PlainObject
      ) as WeeklyTimeTableLatest
    })
  }
}
