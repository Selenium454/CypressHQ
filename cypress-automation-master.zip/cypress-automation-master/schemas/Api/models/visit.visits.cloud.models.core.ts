import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { VisitAppointment440, VisitAppointmentSchema } from './visitAppointment.visits.cloud.models.core'
import { VisitBilling440, VisitBillingSchema } from './visitBilling.visits.cloud.models.core'
import { HealthFund440, HealthFundSchema } from './healthFund.cloud.models.core'
import { VisitDoctorReference440, VisitDoctorReferenceSchema } from './visitDoctorReference.cloud.models.core'
import { VisitStatusValues } from '../types'

import { generateSanitizeFunction } from '../shared'

const healthFundSchema = new HealthFundSchema()
const visitAppointmentSchema = new VisitAppointmentSchema()
const visitBillingSchema = new VisitBillingSchema()
const visitDoctorReferenceSchema = new VisitDoctorReferenceSchema()

export interface Visit440 {
  appointment?: VisitAppointment440 | null
  billedInformation?: VisitBilling440 | null
  facilityCode: string
  healthFund?: HealthFund440 | null
  patientId: string
  patientName?: string | null
  patientDateOfBirth?: string | null
  rules?: [{}] | null
  serviceId: string
  status?: typeof VisitStatusValues[number] | null
  treatingDoctor: VisitDoctorReference440
  totalCareId?: string | null
  visitId?: string | null
  externalId?: string | null
  visitInformation?: VisitBilling440 | null
  wardCode: string
  created?: string | null
  synced?: string | null
  updated?: string | null
  documentType?: string | null
}
export interface VisitLatest extends Visit440 {}

export class VisitSchema {
  latestVersion: string = '4.4.0'

  public static visit440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'visitSchema',
      type: 'object',
      description: '',
      properties: {
        appointment: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...VisitAppointmentSchema.visitAppointment440.schema.properties,
          },
          see: VisitAppointmentSchema.visitAppointment440,
          required: false,
        },
        billedInformation: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...VisitBillingSchema.visitBilling440.schema.properties,
          },
          see: VisitBillingSchema.visitBilling440,
          required: false,
        },
        facilityCode: {
          type: 'string',
          description: '',
          required: true,
        },
        healthFund: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...HealthFundSchema.healthFund440.schema.properties,
          },
          see: HealthFundSchema.healthFund440,
          required: false,
        },
        patientId: {
          type: 'string',
          description: '',
          required: true,
        },
        patientName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        patientDateOfBirth: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        rules: {
          type: ['array', 'null'],
          description: '',
          required: false,
        },
        serviceId: {
          type: 'string',
          description: '',
          required: true,
        },
        status: {
          type: ['string', 'null'],
          description: '',
          enum: (VisitStatusValues as unknown) as string[],
          required: false,
        },
        treatingDoctor: {
          type: 'object',
          description: '',
          properties: {
            ...VisitDoctorReferenceSchema.visitDoctorReference440.schema.properties,
          },
          see: VisitDoctorReferenceSchema.visitDoctorReference440,
          required: true,
        },
        totalCareId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        visitId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        externalId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        visitInformation: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...VisitBillingSchema.visitBilling440.schema.properties,
          },
          see: VisitBillingSchema.visitBilling440,
          required: false,
        },
        wardCode: {
          type: 'string',
          description: '',
          required: true,
        },
        created: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        synced: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        updated: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        documentType: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: (({
      facilityCode: 'SJGM',
      patientId: '123',
      serviceId: '1234',
      treatingDoctor: (VisitDoctorReferenceSchema.visitDoctorReference440
        .example as unknown) as VisitDoctorReference440,
      wardCode: 'CATH',
    } as Visit440) as unknown) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(VisitSchema.visit440)

  public static snapshotSubtitle = 'Visit Model'

  public check = (object: VisitLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'visitSchema', version)
  }

  public sanitize = (object: VisitLatest, version: string = this.latestVersion) => {
    if (object.appointment) {
      visitAppointmentSchema.sanitize(object.appointment).then(sanitizedAppointment => {
        object.appointment = sanitizedAppointment
      })
    }

    if (object.billedInformation) {
      visitBillingSchema.sanitize(object.billedInformation).then(sanitizedBilledInformation => {
        object.billedInformation = sanitizedBilledInformation
      })
    }

    if (object.healthFund) {
      healthFundSchema.sanitize(object.healthFund).then(sanitizedHealthFund => {
        object.healthFund = sanitizedHealthFund
      })
    }

    if (object.treatingDoctor) {
      visitDoctorReferenceSchema.sanitize(object.treatingDoctor).then(sanitizedTreatingDoctor => {
        object.treatingDoctor = sanitizedTreatingDoctor
      })
    }

    if (object.visitInformation) {
      visitBillingSchema.sanitize(object.visitInformation).then(sanitizedVisitInformation => {
        object.visitInformation = sanitizedVisitInformation
      })
    }

    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(VisitSchema.versionedSchemas, 'visitSchema', version)(
        (object as unknown) as PlainObject
      ) as VisitLatest
    })
  }
}
