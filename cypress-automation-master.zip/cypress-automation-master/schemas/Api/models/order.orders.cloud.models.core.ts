import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { PharmacyOrderStatus440, PharmacyOrderStatusSchema } from './pharmacyOrderStatus.orders.cloud.models.core'
import { DeliveryOptions440, DeliveryOptionsSchema } from './deliveryOptions.orders.cloud.models.core'
import { Lock440, LockSchema } from './lock.models.core'
import { OrderLinkedScript440, OrderLinkedScriptSchema } from './orderLinkedScript.orders.cloud.models.core'
import { ChartItem440, ChartItemSchema } from './chartItem.orders.cloud.models.core'
import { ShopItem440, ShopItemSchema } from './shopItem.orders.cloud.models.core'
import { ScriptItem440, ScriptItemSchema } from './scriptItem.orders.cloud.models.core'
import { OrderStatistics440, OrderStatisticsSchema } from './orderStatistics.orders.cloud.models.core'
import {
  ChartStatusValues,
  RolesValues,
  OrderContextValues,
  OrderTypeValues,
  ScriptTypeValues,
  OrderStateValues,
  ChartSourceValues,
} from '../types'

import { generateSanitizeFunction } from '../shared'

const deliveryOptionsSchema = new DeliveryOptionsSchema()
const lockSchema = new LockSchema()
const orderStatisticsSchema = new OrderStatisticsSchema()
const pharmacyOrderStatusSchema = new PharmacyOrderStatusSchema()

export interface Order440 {
  statistics?: OrderStatistics440 | null
  orderType?: typeof OrderTypeValues[number] | null
  scriptType?: typeof ScriptTypeValues[number] | null
  orderId?: string | null
  batchId?: string | null
  groupId?: string | null
  alias?: string | null
  orderedBy?: string | null
  orderedFor?: string | null
  context?: typeof OrderContextValues[number] | null
  round?: string | null
  roundName?: string | null
  orderByRole?: typeof RolesValues[number] | null
  orderForName?: string | null
  orderByName?: string | null
  pharmacyId?: string | null
  created?: string | null
  scriptDate?: string | null
  state?: typeof OrderStateValues[number] | null
  pharmacyStatus?: PharmacyOrderStatus440 | null
  deliveryOptions?: DeliveryOptions440 | null
  deliveryTime?: string | null
  endTime?: string | null
  isExpress?: boolean | null
  tags?: string | null
  dispatched?: boolean | null
  facilityCode?: string | null
  urn?: string | null
  scriptItems?: ScriptItem440[] | null
  imageName?: string | null
  shopItems?: ShopItem440[] | null
  chartSource?: typeof ChartSourceValues[number] | null
  chartItems?: ChartItem440[] | null
  dailyChartOrderId?: string | null
  dueTime?: string | null
  scriptLinking?: boolean | null
  linkedScripts?: OrderLinkedScript440[] | null
  comment?: string | null
  chartStatus?: typeof ChartStatusValues[number] | null
  isLockable?: boolean | null
  lock?: Lock440 | null
  documentType?: string | null
}
export interface OrderLatest extends Order440 {}

export class OrderSchema {
  latestVersion: string = '4.4.0'

  public static order440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'orderSchema',
      type: 'object',
      description: '',
      properties: {
        statistics: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...OrderStatisticsSchema.orderStatistics440.schema.properties,
          },
          see: OrderStatisticsSchema.orderStatistics440,
          required: false,
        },
        orderType: {
          type: ['string', 'null'],
          description: '',
          enum: (OrderTypeValues as unknown) as string[],
          required: false,
        },
        scriptType: {
          type: ['string', 'null'],
          description: '',
          enum: (ScriptTypeValues as unknown) as string[],
          required: false,
        },
        orderId: {
          type: ['string', 'null'],
          format: 'orderId',
          description: '',
          required: false,
        },
        batchId: {
          type: ['string', 'null'],
          format: 'orderId',
          description: '',
          required: false,
        },
        groupId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        alias: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        orderedBy: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        orderedFor: {
          type: ['string', 'null'],
          format: 'orderFor',
          description: '',
          required: false,
        },
        context: {
          type: ['string', 'null'],
          description: '',
          enum: (OrderContextValues as unknown) as string[],
          required: false,
        },
        round: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        roundName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        orderByRole: {
          type: ['string', 'null'],
          format: 'userRole',
          description: '',
          enum: (RolesValues as unknown) as string[],
          required: false,
        },
        orderForName: {
          type: ['string', 'null'],
          format: 'fullName',
          description: '',
          required: false,
        },
        orderByName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        pharmacyId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        created: {
          type: ['string', 'null'],
          format: 'dateTimeWithTimezone',
          description: '',
          required: false,
        },
        scriptDate: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        state: {
          type: ['string', 'null'],
          description: '',
          enum: (OrderStateValues as unknown) as string[],
          required: false,
        },
        pharmacyStatus: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...PharmacyOrderStatusSchema.pharmacyOrderStatus440.schema.properties,
          },
          see: PharmacyOrderStatusSchema.pharmacyOrderStatus440,
          required: false,
        },
        deliveryOptions: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...DeliveryOptionsSchema.deliveryOptions440.schema.properties,
          },
          see: DeliveryOptionsSchema.deliveryOptions440,
          required: false,
        },
        deliveryTime: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        endTime: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        isExpress: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        tags: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        dispatched: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        facilityCode: {
          type: ['string', 'null'],
          format: 'facilityCode',
          description: '',
          required: false,
        },
        urn: {
          type: ['string', 'null'],
          format: 'urNumber',
          description: '',
          required: false,
        },
        scriptItems: {
          type: ['array', 'null'],
          description: '',
          items: {
            ...ScriptItemSchema.scriptItem440.schema,
          },
          see: ScriptItemSchema.scriptItem440,
          required: false,
        },
        imageName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        shopItems: {
          type: ['array', 'null'],
          description: '',
          items: {
            ...ShopItemSchema.shopItem440.schema,
          },
          see: ShopItemSchema.shopItem440,
          required: false,
        },
        chartSource: {
          type: ['string', 'null'],
          description: '',
          enum: (ChartSourceValues as unknown) as string[],
          required: false,
        },
        chartItems: {
          type: ['array', 'null'],
          description: '',
          items: {
            ...ChartItemSchema.chartItem440.schema,
          },
          see: ChartItemSchema.chartItem440,
          required: false,
        },
        dailyChartOrderId: {
          type: ['string', 'null'],
          format: 'dailyChartOrderId',
          description: '',
          required: false,
        },
        dueTime: {
          type: ['string', 'null'],
          format: 'dateTimeWithTimezone',
          description: '',
          required: false,
        },
        scriptLinking: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        linkedScripts: {
          type: ['array', 'null'],
          description: '',
          items: {
            ...OrderLinkedScriptSchema.orderLinkedScript440.schema,
          },
          see: OrderLinkedScriptSchema.orderLinkedScript440,
          required: false,
        },
        comment: {
          type: ['string', 'null'],
          format: 'chartJobComment',
          description: '',
          required: false,
        },
        chartStatus: {
          type: ['string', 'null'],
          description: '',
          enum: (ChartStatusValues as unknown) as string[],
          required: false,
        },
        isLockable: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        lock: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...LockSchema.lock440.schema.properties,
          },
          see: LockSchema.lock440,
          required: false,
        },
        documentType: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({} as Order440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(OrderSchema.order440)

  public static snapshotSubtitle = 'Order Model'

  public check = (object: OrderLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'orderSchema', version)
  }

  public sanitize = (object: OrderLatest, version: string = this.latestVersion) => {
    if (object.statistics) {
      orderStatisticsSchema.sanitize(object.statistics).then(sanitizedStatistics => {
        object.statistics = sanitizedStatistics
      })
    }

    if (object.pharmacyStatus) {
      pharmacyOrderStatusSchema.sanitize(object.pharmacyStatus).then(sanitizedPharmacyStatus => {
        object.pharmacyStatus = sanitizedPharmacyStatus
      })
    }

    if (object.deliveryOptions) {
      deliveryOptionsSchema.sanitize(object.deliveryOptions).then(sanitizedDeliveryOptions => {
        object.deliveryOptions = sanitizedDeliveryOptions
      })
    }

    if (object.lock) {
      lockSchema.sanitize(object.lock).then(sanitizedLock => {
        object.lock = sanitizedLock
      })
    }

    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(OrderSchema.versionedSchemas, 'orderSchema', version)(
        object as PlainObject
      ) as OrderLatest
    })
  }
}
