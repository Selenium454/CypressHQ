import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { RolesValues, OrderStateValues } from '../types'
import { UserReference440, UserReferenceSchema } from './userReference.cloud.models.core'

import { generateSanitizeFunction } from '../shared'

const userReferenceSchema = new UserReferenceSchema()

export interface PharmacyOrderProcess440 {
  pharmacyRole?: typeof RolesValues[number] | null
  notes?: string | null
  state?: typeof OrderStateValues[number] | null
  notSuppliedReason?: string | null
  replacement?: string | null
  requested?: string | null
  updated?: string | null
  userReference?: UserReference440 | null
}
export interface PharmacyOrderProcessLatest extends PharmacyOrderProcess440 {}

export class PharmacyOrderProcessSchema {
  latestVersion: string = '4.4.0'

  public static pharmacyOrderProcess440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'pharmacyOrderProcessSchema',
      type: 'object',
      description: '',
      properties: {
        pharmacyRole: {
          type: ['string', 'null'],
          description: '',
          enum: (RolesValues as unknown) as string[],
          required: false,
        },
        notes: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        state: {
          type: ['string', 'null'],
          description: '',
          enum: (OrderStateValues as unknown) as string[],
          required: false,
        },
        notSuppliedReason: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        pharmacyOrderProcessOrder: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        replacement: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        requested: {
          type: ['string', 'null'],
          format: 'dateTimeWithTimezone',
          description: '',
          required: false,
        },
        updated: {
          type: ['string', 'null'],
          format: 'dateTimeWithTimezone',
          description: '',
          required: false,
        },
        userReference: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...UserReferenceSchema.userReference440.schema.properties,
          },
          see: UserReferenceSchema.userReference440,
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({} as PharmacyOrderProcess440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(PharmacyOrderProcessSchema.pharmacyOrderProcess440)

  public static snapshotSubtitle = 'Pharmacy Order Process Model'

  public check = (object: PharmacyOrderProcessLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'pharmacyOrderProcessSchema', version)
  }

  public sanitize = (object: PharmacyOrderProcessLatest, version: string = this.latestVersion) => {
    if (object.userReference) {
      userReferenceSchema.sanitize(object.userReference).then(sanitizedUserReference => {
        object.userReference = sanitizedUserReference
      })
    }

    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(
        PharmacyOrderProcessSchema.versionedSchemas,
        'pharmacyOrderProcessSchema',
        version
      )(object as PlainObject) as PharmacyOrderProcessLatest
    })
  }
}
