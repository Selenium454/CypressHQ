import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { AuditTypeValues } from '../types'

import { generateSanitizeFunction } from '../shared'

export interface Audit440 {
  id?: string | null
  userId?: string | null
  userName?: string | null
  createdByUserId?: string | null
  createdByUserName?: string | null
  facilityCode?: string | null
  facilityName?: string | null
  businessUnitId?: string | null
  businessUnitName?: string | null
  date?: string | null
  description?: string | null
  trackId?: string | null
  type?: typeof AuditTypeValues[number] | null
  details?: object | null
  documentType?: string | null
}
export interface AuditLatest extends Audit440 {}

export class AuditSchema {
  latestVersion: string = '4.4.0'

  public static audit440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'auditSchema',
      type: 'object',
      description: '',
      properties: {
        id: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        userId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        userName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        createdByUserId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        createdByUserName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        facilityCode: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        facilityName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        businessUnitId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        businessUnitName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        date: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        description: {
          type: ['string', 'null'],
          description: '',
          format: 'audit',
          required: false,
        },
        trackId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        type: {
          type: ['string', 'null'],
          description: '',
          enum: (AuditTypeValues as unknown) as string[],
          required: false,
        },
        details: {
          type: ['object', 'null'],
          description: '',
          format: 'audit',
          required: false,
        },
        documentType: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({} as Audit440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(AuditSchema.audit440)

  public static snapshotSubtitle = 'Audit Model'

  public check = (object: AuditLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'auditSchema', version)
  }

  public sanitize = (object: AuditLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(AuditSchema.versionedSchemas, 'auditSchema', version)(
        object as PlainObject
      ) as AuditLatest
    })
  }
}
