import { ObjectSchema, versionSchemas, PlainObject, extend } from '@cypress/schema-tools'
import { Address440, AddressSchema } from './address.cloud.models.core'
import { AdmissionDetails440, AdmissionDetailsSchema } from './admissionDetails.cloud.models.core'
import {
  AustralianSouthSeaIslanderStatusValues,
  IndigenousStatusValues,
  MaritalStatusValues,
  NonActiveReasonValues,
  SexValues,
  EthnicGroupValues,
} from '../types'
import { MedicalServiceResponse440, MedicalServiceResponseSchema } from './medicalServiceResponse.cloud.models.core'
import {
  SupportingInformationDetails440,
  SupportingInformationDetailsSchema,
} from './supportingInformationDetails.schema'
import {
  PatientInnerDetails440,
  PatientInnerDetailsSchema,
} from './patientInnerDetails.patientDetails.cloud.models.core'

import { generateSanitizeFunction } from '../shared'

const addressSchema = new AddressSchema()
const admissionDetailsSchema = new AdmissionDetailsSchema()
const patientInnerDetailsSchema = new PatientInnerDetailsSchema()

export interface PatientDetailsCloud430 {
  activeInHub?: boolean | null
  address?: Address440
  admission?: AdmissionDetails440
  allergies?: string | null
  australianSouthSeaIslanderStatus?: typeof AustralianSouthSeaIslanderStatusValues[number] | null
  countryOfBirth?: string | null
  ctg?: boolean | null
  dateOfBirth?: string | null
  dateOfDeceased?: string | null
  email?: string | null
  employmentStatus?: string | null
  ethnicGroup?: typeof EthnicGroupValues[number] | null
  firstName?: string | null
  indigenousStatus?: typeof IndigenousStatusValues[number] | null
  language?: string | null
  maritalStatus?: typeof MaritalStatusValues[number] | null
  medicationInstructions?: string | null
  middleName?: string | null
  mobileNumber?: string | null
  nationality?: string | null
  nonActiveReason?: typeof NonActiveReasonValues[number] | null
  notificationsEmail?: string | null
  phoneNumber?: string | null
  photoUrl?: string | null
  services?: MedicalServiceResponse440[] | null
  sex?: typeof SexValues[number] | null
  status?: string | null
  supportingInformation?: SupportingInformationDetails440
  surName?: string | null
  timeZoneId?: string | null
  title?: string | null
  userId?: string | null
  preferredName?: string | null
}
export interface PatientDetailsCloud440 extends PatientDetailsCloud430 {
  activeInHub?: never
  ctg?: never
  nonActiveReason?: never
  services?: never
  supportingInformation?: never
  patient?: PatientInnerDetails440 | null
}
export interface PatientDetailsCloudLatest extends PatientDetailsCloud440 {}

export class PatientDetailsCloudSchema {
  latestVersion: string = '4.4.0'

  public static patientDetailsCloud430: ObjectSchema = {
    version: {
      major: 4,
      minor: 3,
      patch: 0,
    },
    schema: {
      title: 'patientDetailsSchema',
      type: 'object',
      description: '',
      properties: {
        activeInHub: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        address: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...AddressSchema.address440.schema.properties,
          },
          see: AddressSchema.address440,
          required: false,
        },
        admission: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...AdmissionDetailsSchema.admissionDetails440.schema.properties,
          },
          see: AdmissionDetailsSchema.admissionDetails440,
          required: false,
        },
        allergies: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        australianSouthSeaIslanderStatus: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        ctg: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        countryOfBirth: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        dateOfDeceased: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        email: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        employmentStatus: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        ethnicGroup: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        firstName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        indigenousStatus: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        language: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        maritalStatus: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        medicationInstructions: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        middleName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        mobileNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        nationality: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        nonActiveReason: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        notificationsEmail: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        phoneNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        photoUrl: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        services: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...MedicalServiceResponseSchema.medicalServiceResponse440.schema.properties,
          },
          see: MedicalServiceResponseSchema.medicalServiceResponse440,
          required: false,
        },
        sex: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        status: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        supportingInformation: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...SupportingInformationDetailsSchema.supportingInformationDetails440.schema.properties,
          },
          see: SupportingInformationDetailsSchema.supportingInformationDetails440,
          required: false,
        },
        surName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        timeZoneId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        title: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        userId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        preferredName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({
      activeInHub: true,
      address: AddressSchema.address440.example as Address440,
      admission: AdmissionDetailsSchema.admissionDetails440.example as AdmissionDetails440,
      allergies: null,
      countryOfBirth: null,
      ctg: false,
      dateOfBirth: '1923-01-14T00:00:00',
      dateOfDeceased: null,
      email: 'Matilda_West@gmail.com',
      employmentStatus: null,
      firstName: 'Ellie',
      indigenousStatus: 'none',
      language: 'English',
      maritalStatus: 'widowed',
      medicationInstructions: null,
      middleName: null,
      mobileNumber: null,
      nationality: null,
      nonActiveReason: 'none',
      notificationsEmail: null,
      phoneNumber: '66282135',
      photoUrl: null,
      services: [
        (MedicalServiceResponseSchema.medicalServiceResponse440.example as unknown) as MedicalServiceResponse440,
      ],
      sex: 'female',
      status: null,
      supportingInformation: SupportingInformationDetailsSchema.supportingInformationDetails440
        .example as SupportingInformationDetails440,
      surName: 'qaaanwoybdxwmij',
      timeZoneId: 'E. Australia Standard Time',
      title: 'Mr',
      userId: '0000542618',
      preferredName: null,
    } as PatientDetailsCloud430) as PlainObject,
  }

  public static patientDetailsCloud440: ObjectSchema = extend(PatientDetailsCloudSchema.patientDetailsCloud430, {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'patientDetailsSchema',
      type: 'object',
      description: '',
      properties: {
        activeInHub: {
          type: ['boolean', 'null'],
          required: false,
          deprecated: 'Now found in patient object.',
        },
        ctg: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
          deprecated: 'Now found in patient object.',
        },
        nonActiveReason: {
          type: ['string', 'null'],
          description: '',
          required: false,
          deprecated: 'Now found in patient object.',
        },
        services: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...MedicalServiceResponseSchema.medicalServiceResponse440.schema.properties,
          },
          see: MedicalServiceResponseSchema.medicalServiceResponse440,
          required: false,
          deprecated: 'Now found in patient object.',
        },
        supportingInformation: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...SupportingInformationDetailsSchema.supportingInformationDetails440.schema.properties,
          },
          see: SupportingInformationDetailsSchema.supportingInformationDetails440,
          required: false,
          deprecated: 'Now found in patient object.',
        },
        patient: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...PatientInnerDetailsSchema.patientInnerDetails440.schema.properties,
          },
          see: PatientInnerDetailsSchema.patientInnerDetails440,
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({
      address: AddressSchema.address440.example as Address440,
      admission: AdmissionDetailsSchema.admissionDetails440.example as AdmissionDetails440,
      countryOfBirth: null,
      dateOfBirth: '1923-01-14T00:00:00',
      dateOfDeceased: null,
      email: 'Matilda_West@gmail.com',
      employmentStatus: null,
      firstName: 'Ellie',
      indigenousStatus: 'none',
      language: 'English',
      maritalStatus: 'widowed',
      middleName: null,
      mobileNumber: null,
      nationality: null,
      notificationsEmail: null,
      phoneNumber: '66282135',
      photoUrl: null,
      sex: 'female',
      status: 'none',
      surName: 'qaaanwoybdxwmij',
      timeZoneId: 'E. Australia Standard Time',
      title: 'Mr',
      userId: '0000542618',
      preferredName: null,
      patient: PatientInnerDetailsSchema.patientInnerDetails440.example as PatientInnerDetails440,
    } as PatientDetailsCloud440) as PlainObject,
  })

  public static versionedSchemas = versionSchemas(PatientDetailsCloudSchema.patientDetailsCloud440)

  public static snapshotSubtitle = 'Patient Details Model'

  public check = (object: PatientDetailsCloudLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'patientDetailsCloudSchema', version)
  }

  public sanitize = (object: PatientDetailsCloudLatest, version: string = this.latestVersion) => {
    if (object.address) {
      addressSchema.sanitize(object.address).then(sanitizedAddress => {
        object.address = sanitizedAddress
      })
    }

    if (object.admission) {
      admissionDetailsSchema.sanitize(object.admission).then(sanitizedAdmission => {
        object.admission = sanitizedAdmission
      })
    }

    if (object.patient) {
      patientInnerDetailsSchema.sanitize(object.patient).then(sanitizedPatient => {
        object.patient = sanitizedPatient
      })
    }

    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(PatientDetailsCloudSchema.versionedSchemas, 'patientDetailsSchema', version)(
        object as PlainObject
      ) as PatientDetailsCloudLatest
    })
  }
}
