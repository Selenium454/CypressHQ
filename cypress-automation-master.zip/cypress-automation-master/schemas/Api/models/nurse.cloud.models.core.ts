import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import {
  ExtendedFacilityReference440,
  ExtendedFacilityReferenceSchema,
} from './extendedFacilityReference.cloud.models.core'

import { generateSanitizeFunction } from '../shared'

const extendedFacilityReference = new ExtendedFacilityReferenceSchema()

export interface Nurse440 {
  facility?: ExtendedFacilityReference440 | null
  externalId?: string | null
  isHospitalNurse?: boolean | null
  pharmacyId?: string | null
}
export interface NurseLatest extends Nurse440 {}

export class NurseSchema {
  latestVersion: string = '4.4.0'

  public static nurse440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'nurseSchema',
      type: 'object',
      description: 'Time slots model for medication time slots.',
      properties: {
        facility: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...ExtendedFacilityReferenceSchema.extendedFacilityReference440.schema.properties,
          },
          see: ExtendedFacilityReferenceSchema.extendedFacilityReference440,
          required: false,
        },
        externalId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        isHospitalNurse: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        pharmacyId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({} as Nurse440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(NurseSchema.nurse440)

  public static snapshotSubtitle = 'Nurse Model'

  public check = (object: NurseLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'notationSchema', version)
  }

  public sanitize = (object: NurseLatest, version: string = this.latestVersion) => {
    if (object.facility) {
      extendedFacilityReference.sanitize(object.facility).then(sanitizedFacility => {
        object.facility = sanitizedFacility
      })
    }

    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(NurseSchema.versionedSchemas, 'nurseSchema', version)(
        object as PlainObject
      ) as NurseLatest
    })
  }
}
