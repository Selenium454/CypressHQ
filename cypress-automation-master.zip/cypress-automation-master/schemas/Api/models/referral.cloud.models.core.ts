import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { ReferralTypeValues } from '../types'

import { generateSanitizeFunction } from '../shared'

export interface Referral440 {
  referralType?: typeof ReferralTypeValues[number] | null
  letterDate?: string | null
  startDate?: string | null
  expiryDate?: string | null
}
export interface ReferralLatest extends Referral440 {}

export class ReferralSchema {
  latestVersion: string = '4.4.0'

  public static referral440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'referralSchema',
      type: 'object',
      description: "Doctor's referral model.",
      properties: {
        expiryDate: {
          type: ['string', 'null'],
          description: 'Date that the referral expires on.',
          format: 'dateTime',
          required: false,
        },
        letterDate: {
          type: ['string', 'null'],
          description: 'Date the referral was created.',
          required: false,
        },
        referralType: {
          type: ['string', 'null'],
          description: 'Type of referral.',
          required: false,
        },
        startDate: {
          type: ['string', 'null'],
          description: 'Date the referral is valid from.',
          format: 'dateTime',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({
      referralType: 'hospital',
      letterDate: '2019-04-25',
      startDate: '2019-04-26',
      expiryDate: '2020-04-25',
    } as Referral440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(ReferralSchema.referral440)

  public static snapshotSubtitle = 'Referral Model'

  public check = (object: ReferralLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'referralSchema', version)
  }

  public sanitize = (object: ReferralLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(ReferralSchema.versionedSchemas, 'referralSchema', version)(
        object as PlainObject
      ) as ReferralLatest
    })
  }
}
