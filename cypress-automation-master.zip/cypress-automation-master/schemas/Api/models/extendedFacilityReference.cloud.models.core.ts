import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'

import { generateSanitizeFunction } from '../shared'

export interface ExtendedFacilityReference440 {
  wardCodes?: string[] | null
  code?: string | null
  name?: string | null
  tenantId?: string | null
}
export interface ExtendedFacilityReferenceLatest extends ExtendedFacilityReference440 {}

export class ExtendedFacilityReferenceSchema {
  latestVersion: string = '4.4.0'

  public static extendedFacilityReference440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'extendedFacilityReferenceSchema',
      type: 'object',
      description: '',
      properties: {
        wardCodes: {
          type: ['array', 'null'],
          description: '',
          items: {
            type: 'string',
            required: false,
          },
          required: false,
        },
        code: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        name: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        tenantId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({
      wardCodes: ['CATH'],
      code: 'SJGM',
      name: 'St John of God Hospital Murdoch',
      tenantId: '44',
    } as ExtendedFacilityReference440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(ExtendedFacilityReferenceSchema.extendedFacilityReference440)

  public static snapshotSubtitle = 'Extended Facility Reference Model'

  public check = (object: ExtendedFacilityReferenceLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'extendedFacilityReferenceSchema', version)
  }

  public sanitize = (object: ExtendedFacilityReferenceLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(
        ExtendedFacilityReferenceSchema.versionedSchemas,
        'extendedFacilityReferenceSchema',
        version
      )(object as PlainObject) as ExtendedFacilityReferenceLatest
    })
  }
}
