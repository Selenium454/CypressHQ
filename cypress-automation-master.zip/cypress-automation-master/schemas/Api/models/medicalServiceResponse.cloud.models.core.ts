import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { Admission440, AdmissionSchema } from './admission.cloud.models.core'
import { DoctorReferenceApi440, DoctorReferenceApiSchema } from './doctorReferenceApi.cloud.models.core'
import { FacilityTypeValues, InactiveServiceOtherReasonValues, ServiceStatusValues, ServiceTypeValues } from '../types'
import { HealthFund440, HealthFundSchema } from './healthFund.cloud.models.core'
import { ExternalIdentifier440, ExternalIdentifierSchema } from './externalIdentifier.cloud.models.core'
import { TimeSlots440, TimeSlotsSchema } from './timeSlots.cloud.models.core'

import { generateSanitizeFunction } from '../shared'

const admissionSchema = new AdmissionSchema()
const healthFundSchema = new HealthFundSchema()

export interface MedicalServiceResponse440 {
  admission: Admission440
  authorizationFormUrlToken?: string | null
  doctors?: DoctorReferenceApi440[]
  added?: string | null
  authorizationFormUrl?: string | null
  bedNumber?: string | null
  businessUnitId: string
  facilityCode: string
  facilityName?: string | null
  facilityType: typeof FacilityTypeValues[number]
  healthFund?: HealthFund440
  id?: string | null
  identifiers?: ExternalIdentifier440[]
  inactiveServiceOtherReason?: string | null
  inactiveServiceReason?: typeof InactiveServiceOtherReasonValues[number]
  patientNumber?: string | null
  roomNumber?: string | null
  serviceStatus?: typeof ServiceStatusValues[number]
  serviceType: typeof ServiceTypeValues[number]
  statusChangedToInactive: boolean
  synced?: string | null
  timeSlots?: TimeSlots440[]
  updated?: string | null
  urNumber?: string | null
  wardCode?: string | null
  wardName?: string | null
}
export interface MedicalServiceResponseLatest extends MedicalServiceResponse440 {}

export class MedicalServiceResponseSchema {
  latestVersion: string = '4.4.0'

  public static medicalServiceResponse440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'medicalServiceResponseSchema',
      type: 'object',
      description: 'Generic services model for use on patients.',
      properties: {
        admission: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...AdmissionSchema.admission440.schema.properties,
          },
          see: AdmissionSchema.admission440,
          required: false,
        },
        authorizationFormUrlToken: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        added: {
          type: ['string', 'null'],
          format: 'dateTimeWithTimezone',
          description: '',
          required: false,
        },
        authorizationFormUrl: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        bedNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        businessUnitId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        doctors: {
          type: 'array',
          description: '',
          items: {
            ...DoctorReferenceApiSchema.doctorReferenceApi440.schema,
          },
          see: DoctorReferenceApiSchema.doctorReferenceApi440,
          required: false,
        },
        facilityCode: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        facilityName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        facilityType: {
          type: 'string',
          description: '',
          required: false,
        },
        healthFund: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...HealthFundSchema.healthFund440.schema.properties,
          },
          see: HealthFundSchema.healthFund440,
          required: false,
        },
        id: {
          type: 'string',
          format: 'trackId',
          description: '',
          required: false,
        },
        identifiers: {
          type: ['array', 'null'],
          description: '',
          items: {
            ...ExternalIdentifierSchema.externalIdentifier440.schema,
          },
          see: ExternalIdentifierSchema.externalIdentifier440,
          required: false,
        },
        inactiveServiceOtherReason: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        inactiveServiceReason: {
          type: 'string',
          description: '',
          required: false,
        },
        patientNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        roomNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        serviceStatus: {
          type: 'string',
          description: '',
          required: false,
        },
        serviceType: {
          type: 'string',
          description: '',
          required: false,
        },
        statusChangedToInactive: {
          type: 'boolean',
          description: '',
          required: false,
        },
        synced: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        timeSlots: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...TimeSlotsSchema.timeSlots440.schema.properties,
          },
          see: TimeSlotsSchema.timeSlots440,
          required: false,
        },
        updated: {
          type: ['string', 'null'],
          format: 'dateTime',
          description: '',
          required: false,
        },
        urNumber: {
          type: ['string', 'null'],
          format: 'urNumber',
          description: '',
          required: false,
        },
        wardCode: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        wardName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: (({
      admission: (AdmissionSchema.admission440.example as unknown) as Admission440,
      doctors: [(DoctorReferenceApiSchema.doctorReferenceApi440.example as unknown) as DoctorReferenceApi440],
      added: '2018-12-19T00:34:43.8456831Z',
      authorizationFormUrl: '',
      bedNumber: '7',
      businessUnitId: '44',
      facilityCode: 'SJGM',
      facilityName: 'St John Of God Hospital Murdoch',
      facilityType: 'hospital',
      healthFund: HealthFundSchema.healthFund440.example as HealthFund440,
      id: 'a6fe17e9ea8146f2af4069146e3561c7',
      identifiers: [(ExternalIdentifierSchema.externalIdentifier440.example as unknown) as ExternalIdentifier440],
      inactiveServiceOtherReason: '',
      roomNumber: '42',
      serviceStatus: 'inactive',
      serviceType: 'admission',
      synced: '2018-12-19T00:34:43.8456831Z',
      updated: '2018-12-19T00:34:59.729047Z',
      urNumber: '90137349',
      wardCode: 'CATH',
      wardName: 'St Catherine',
      statusChangedToInactive: false,
    } as MedicalServiceResponse440) as unknown) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(MedicalServiceResponseSchema.medicalServiceResponse440)

  public static snapshotSubtitle = 'Medical Service Response Model'

  public check = (object: MedicalServiceResponseLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'medicalServiceResponseSchema', version)
  }

  public sanitize = (object: MedicalServiceResponseLatest, version: string = this.latestVersion) => {
    if (object.admission) {
      admissionSchema.sanitize(object.admission).then(sanitizedAdmission => {
        object.admission = sanitizedAdmission
      })
    }

    if (object.healthFund) {
      healthFundSchema.sanitize(object.healthFund).then(sanitizedHealthFund => {
        object.healthFund = sanitizedHealthFund
      })
    }

    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(
        MedicalServiceResponseSchema.versionedSchemas,
        'medicalServiceResponseSchema',
        version
      )((object as unknown) as PlainObject) as MedicalServiceResponseLatest
    })
  }
}
