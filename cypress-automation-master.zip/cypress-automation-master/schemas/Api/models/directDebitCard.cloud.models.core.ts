import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { BankAcountType } from '../types'

import { generateSanitizeFunction } from '../shared'

export interface DirectDebitCard440 {
  bankAccountName?: string | null
  bankAccountNumber?: string | null
  bankBsb?: string | null
  bankName?: string | null
  signedFormUrl?: string | null
  type?: typeof BankAcountType[number] | null
}
export interface DirectDebitCardLatest extends DirectDebitCard440 {}

export class DirectDebitCardSchema {
  latestVersion: string = '4.4.0'

  public static directDebitCard440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'directDebitCardSchema',
      type: 'object',
      description: '',
      properties: {
        description: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        genericName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        startDate: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        title: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        type: {
          type: ['string', 'null'],
          description: '',
          enum: (BankAcountType as unknown) as string[],
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({
      bankAccountName: 'Offshore',
      bankAccountNumber: '13456789',
      bankBsb: '123-456',
      bankName: 'Test Bank Ltd',
      signedFormUrl: null,
      type: 'directDebitCard',
    } as DirectDebitCard440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(DirectDebitCardSchema.directDebitCard440)

  public static snapshotSubtitle = 'Direct Debit Card Model'

  public check = (object: DirectDebitCardLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'directDebitCardSchema', version)
  }

  public sanitize = (object: DirectDebitCardLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(DirectDebitCardSchema.versionedSchemas, 'directDebitCardSchema', version)(
        object as PlainObject
      ) as DirectDebitCardLatest
    })
  }
}
