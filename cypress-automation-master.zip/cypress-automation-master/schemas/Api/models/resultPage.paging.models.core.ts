import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { OrderSearchResult440, OrderSearchResultSchema } from './orderSearchResult.models.webApi.cloudServices'

import { generateSanitizeFunction } from '../shared'

export interface ResultPage440 {
  total?: number | null
  itemsPerPage?: number | null
  pageNumber?: number | null
  itemsInCurrentPage?: number | null
  items?: OrderSearchResult440[] | null
  totalPages?: number | null
}
export interface ResultPageLatest extends ResultPage440 {}

export class ResultPageSchema {
  latestVersion: string = '4.4.0'

  public static resultPage440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'resultPageSchema',
      type: 'object',
      description: '',
      properties: {
        total: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        itemsPerPage: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        pageNumber: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        itemsInCurrentPage: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        items: {
          type: ['array', 'null'],
          description: '',
          items: {
            ...OrderSearchResultSchema.orderSearchResult440.schema,
          },
          see: OrderSearchResultSchema.orderSearchResult440,
          required: false,
        },
        totalPages: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({} as ResultPage440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(ResultPageSchema.resultPage440)

  public static snapshotSubtitle = 'Result Page Model'

  public check = (object: ResultPageLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'resultPageSchema', version)
  }

  public sanitize = (object: ResultPageLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(ResultPageSchema.versionedSchemas, 'resultPageSchema', version)(
        object as PlainObject
      ) as ResultPageLatest
    })
  }
}
