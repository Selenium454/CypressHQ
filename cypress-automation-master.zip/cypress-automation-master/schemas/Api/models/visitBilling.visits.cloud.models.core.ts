import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'

import { generateSanitizeFunction } from '../shared'

export interface VisitBilling440 {
  billingRate?: string | null
  consultationCodes?: string[] | null
  note?: string | null
}
export interface VisitBillingLatest extends VisitBilling440 {}

export class VisitBillingSchema {
  latestVersion: string = '4.4.0'

  public static visitBilling440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'visitBillingSchema',
      type: 'object',
      description: '',
      properties: {
        billingRate: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        consultationCodes: {
          type: ['array', 'null'],
          description: '',
          items: {
            type: ['string', 'null'],
            required: false,
          },
          required: false,
        },
        note: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({} as VisitBilling440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(VisitBillingSchema.visitBilling440)

  public static snapshotSubtitle = 'Visit Billing Model'

  public check = (object: VisitBillingLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'visitBillingSchema', version)
  }

  public sanitize = (object: VisitBillingLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(VisitBillingSchema.versionedSchemas, 'visitBillingSchema', version)(
        object as PlainObject
      ) as VisitBillingLatest
    })
  }
}
