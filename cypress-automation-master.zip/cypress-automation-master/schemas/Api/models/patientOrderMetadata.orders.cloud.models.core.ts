import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { OrderTypeValues, RolesValues, ScriptTypeValues } from '../types'
import { MedicationState440, MedicationStateSchema } from './medicationState.orders.cloud.models.core'

import { generateSanitizeFunction } from '../shared'

export interface PatientOrderMetadata440 {
  alias?: string | null
  batchId?: string | null
  created?: string | null
  dispatchDate?: string | null
  groupId?: string | null
  medicationNames?: MedicationState440[] | null
  orderByName?: string | null
  orderByRole?: typeof RolesValues[number] | null
  orderedBy?: string | null
  orderedFor?: string | null
  orderForName?: string | null
  orderType?: typeof OrderTypeValues[number] | null
  scriptType?: typeof ScriptTypeValues[number] | null
}
export interface PatientOrderMetadataLatest extends PatientOrderMetadata440 {}

export class PatientOrderMetadataSchema {
  latestVersion: string = '4.4.0'

  public static patientOrderMetadata440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'patientOrderMetadataSchema',
      type: 'object',
      description: '',
      properties: {
        alias: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        batchId: {
          type: ['string', 'null'],
          format: 'orderId',
          description: '',
          required: false,
        },
        created: {
          type: ['string', 'null'],
          format: 'dateTimeWithTimezone',
          description: '',
          required: false,
        },
        dispatchDate: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        groupId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        medicationNames: {
          type: ['array', 'null'],
          description: '',
          items: {
            ...MedicationStateSchema.medicationState440.schema,
          },
          see: MedicationStateSchema.medicationState440,
          required: false,
        },
        orderByName: {
          type: ['string', 'null'],
          description: '',
          required: true,
        },
        orderByRole: {
          type: ['string', 'null'],
          description: '',
          enum: (RolesValues as unknown) as string[],
          required: true,
        },
        orderedBy: {
          type: 'string',
          description: '',
          required: true,
        },
        orderedFor: {
          type: 'string',
          format: 'orderFor',
          description: '',
          required: true,
        },
        orderForName: {
          type: 'string',
          format: 'fullName',
          description: '',
          required: true,
        },
        orderType: {
          type: 'string',
          description: '',
          enum: (OrderTypeValues as unknown) as string[],
          required: true,
        },
        scriptType: {
          type: 'string',
          description: '',
          enum: (ScriptTypeValues as unknown) as string[],
          required: true,
        },
      },
      additionalProperties: false,
    },
    example: ({} as PatientOrderMetadata440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(PatientOrderMetadataSchema.patientOrderMetadata440)

  public static snapshotSubtitle = 'Patient Order Metadata Model'

  public check = (object: PatientOrderMetadataLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'patientOrderMetadataSchema', version)
  }

  public sanitize = (object: PatientOrderMetadataLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(
        PatientOrderMetadataSchema.versionedSchemas,
        'patientOrderMetadataSchema',
        version
      )(object as PlainObject) as PatientOrderMetadataLatest
    })
  }
}
