import { ObjectSchema, versionSchemas, PlainObject, combineSchemas, sanitize } from '@cypress/schema-tools'
import { BankAcountType } from '../types'
import { formatDefaults } from 'Formats/index.ts'
import { generateSanitizeFunction } from '../shared'

export interface BankAccount440 {
  bankAccountName?: string | null
  bankAccountNumber?: string | null
  bankBsb?: string | null
  bankName?: string | null
  signedFormUrl?: string | null
  type?: typeof BankAcountType[number] | null
}
export interface BankAccountLatest extends BankAccount440 {}

export class BankAccountSchema {
  latestVersion: string = '4.4.0'

  public static bankAccount440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'bankAccountSchema',
      type: 'object',
      description: '',
      properties: {
        bankAccountName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        bankAccountNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        bankBsb: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        bankName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        signedFormUrl: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        type: {
          type: ['string', 'null'],
          description: '',
          enum: (BankAcountType as unknown) as string[],
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({
      bankAccountName: 'Offshore',
      bankAccountNumber: '13456789',
      bankBsb: '123-456',
      bankName: 'Test Bank Ltd',
      signedFormUrl: null,
      type: 'bankDetails',
    } as BankAccount440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(BankAccountSchema.bankAccount440)

  public static snapshotSubtitle = 'Bank Account Model'

  public check = (object: BankAccountLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'bankAccountSchema', version)
  }

  public sanitize = (object: BankAccountLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(BankAccountSchema.versionedSchemas, 'bankAccountSchema', version)(
        object as PlainObject
      ) as BankAccountLatest
    })
  }
}
