import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { InternalEmployee440, InternalEmployeeSchema } from './internalEmployee.pharmacy.models.core'

import { generateSanitizeFunction } from '../shared'

const internalEmployeeSchema = new InternalEmployeeSchema()

export interface Corporate440 {
  corporateDomain?: string | null
  dispatcher?: InternalEmployee440 | null
  pharmacist?: InternalEmployee440 | null
  technician?: InternalEmployee440 | null
  pharmacyAdmin?: InternalEmployee440 | null
  epicEmployee?: InternalEmployee440 | null
  globalAdmin?: InternalEmployee440 | null
  corporateAdmin?: InternalEmployee440 | null
  cancerCareAdmin?: InternalEmployee440 | null
}
export interface CorporateLatest extends Corporate440 {}

export class CorporateSchema {
  latestVersion: string = '4.4.0'

  public static corporate440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'corporateSchema',
      type: 'object',
      description: 'Corporate reference model used inside patient services.',
      properties: {
        corporateDomain: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        dispatcher: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...InternalEmployeeSchema.internalEmployee440.schema.properties,
          },
          see: InternalEmployeeSchema.internalEmployee440,
          required: false,
        },
        pharmacist: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...InternalEmployeeSchema.internalEmployee440.schema.properties,
          },
          see: InternalEmployeeSchema.internalEmployee440,
          required: false,
        },
        technician: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...InternalEmployeeSchema.internalEmployee440.schema.properties,
          },
          see: InternalEmployeeSchema.internalEmployee440,
          required: false,
        },
        pharmacyAdmin: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...InternalEmployeeSchema.internalEmployee440.schema.properties,
          },
          see: InternalEmployeeSchema.internalEmployee440,
          required: false,
        },
        epicEmployee: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...InternalEmployeeSchema.internalEmployee440.schema.properties,
          },
          see: InternalEmployeeSchema.internalEmployee440,
          required: false,
        },
        globalAdmin: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...InternalEmployeeSchema.internalEmployee440.schema.properties,
          },
          see: InternalEmployeeSchema.internalEmployee440,
          required: false,
        },
        corporateAdmin: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...InternalEmployeeSchema.internalEmployee440.schema.properties,
          },
          see: InternalEmployeeSchema.internalEmployee440,
          required: false,
        },
        cancerCareAdmin: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...InternalEmployeeSchema.internalEmployee440.schema.properties,
          },
          see: InternalEmployeeSchema.internalEmployee440,
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({} as Corporate440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(CorporateSchema.corporate440)

  public static snapshotSubtitle = 'Corporate Model'

  public check = (object: CorporateLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'corporateSchema', version)
  }

  public sanitize = (object: CorporateLatest, version: string = this.latestVersion) => {
    if (object.dispatcher) {
      internalEmployeeSchema.sanitize(object.dispatcher).then(sanitizedDispatcher => {
        object.dispatcher = sanitizedDispatcher
      })
    }

    if (object.pharmacist) {
      internalEmployeeSchema.sanitize(object.pharmacist).then(sanitizedPharmacist => {
        object.pharmacist = sanitizedPharmacist
      })
    }

    if (object.technician) {
      internalEmployeeSchema.sanitize(object.technician).then(sanitizedTechnician => {
        object.technician = sanitizedTechnician
      })
    }

    if (object.pharmacyAdmin) {
      internalEmployeeSchema.sanitize(object.pharmacyAdmin).then(sanitizedPharmcyAdmin => {
        object.pharmacyAdmin = sanitizedPharmcyAdmin
      })
    }

    if (object.epicEmployee) {
      internalEmployeeSchema.sanitize(object.epicEmployee).then(sanitizedEpicEmployee => {
        object.epicEmployee = sanitizedEpicEmployee
      })
    }

    if (object.globalAdmin) {
      internalEmployeeSchema.sanitize(object.globalAdmin).then(sanitizedGlobalAdmin => {
        object.globalAdmin = sanitizedGlobalAdmin
      })
    }

    if (object.corporateAdmin) {
      internalEmployeeSchema.sanitize(object.corporateAdmin).then(sanitizedCorporateAdmin => {
        object.corporateAdmin = sanitizedCorporateAdmin
      })
    }

    if (object.cancerCareAdmin) {
      internalEmployeeSchema.sanitize(object.cancerCareAdmin).then(sanitizedCancerCareAdmin => {
        object.cancerCareAdmin = sanitizedCancerCareAdmin
      })
    }

    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(CorporateSchema.versionedSchemas, 'corporateSchema', version)(
        object as PlainObject
      ) as CorporateLatest
    })
  }
}
