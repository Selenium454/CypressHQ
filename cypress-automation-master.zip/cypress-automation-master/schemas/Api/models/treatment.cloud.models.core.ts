import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'

import { generateSanitizeFunction } from '../shared'

export interface Treatment440 {
  treatmentId: string
  userId: string
  businessUnitId: string
  facilityCode: string
  facilityName?: string | null
  wardCode: string
  wardName?: string | null
  checkedIn?: string | null
  checkInByUserId?: string | null
  checkedOut?: string | null
  checkOutByUserId?: string | null
  documentType?: string | null
}
export interface TreatmentLatest extends Treatment440 {}

export class TreatmentSchema {
  latestVersion: string = '4.4.0'

  public static treatment440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'treatmentSchema',
      type: 'object',
      description: '',
      properties: {
        treatmentId: {
          type: 'string',
          description: '',
          required: true,
        },
        userId: {
          type: 'string',
          description: '',
          required: true,
        },
        businessUnitId: {
          type: 'string',
          description: '',
          required: true,
        },
        facilityCode: {
          type: 'string',
          description: '',
          required: true,
        },
        facilityName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        wardCode: {
          type: 'string',
          description: '',
          required: true,
        },
        wardName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        checkedIn: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        checkInByUserId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        checkedOut: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        checkOutByUserId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        documentType: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: (({
      treatmentId: '123',
      userId: '123',
      businessUnitId: '123',
      facilityCode: 'SJGM',
      wardCode: 'CATH',
    } as Treatment440) as unknown) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(TreatmentSchema.treatment440)

  public static snapshotSubtitle = 'Treatment Model'

  public check = (object: TreatmentLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'treatmentSchema', version)
  }

  public sanitize = (object: TreatmentLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(TreatmentSchema.versionedSchemas, 'treatmentSchema', version)(
        (object as unknown) as PlainObject
      ) as TreatmentLatest
    })
  }
}
