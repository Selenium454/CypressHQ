import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { SystemTypeValues } from '../types'

import { generateSanitizeFunction } from '../shared'

export interface SystemIntegration440 {
  systemType?: typeof SystemTypeValues[number] | null
  enable?: boolean | null
  tags?: string | null
}
export interface SystemIntegrationLatest extends SystemIntegration440 {}

export class SystemIntegrationSchema {
  latestVersion: string = '4.4.0'

  public static systemIntegration440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'systemIntegrationSchema',
      type: 'object',
      description: '',
      properties: {
        systemType: {
          type: ['string', 'null'],
          description: '',
          enum: (SystemTypeValues as unknown) as string[],
          required: false,
        },
        enable: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        tags: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: (({
      userId: '12345678',
      referenceType: 'treating',
    } as SystemIntegration440) as unknown) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(SystemIntegrationSchema.systemIntegration440)

  public static snapshotSubtitle = 'System Integration Model'

  public check = (object: SystemIntegrationLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'systemIntegrationSchema', version)
  }

  public sanitize = (object: SystemIntegrationLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(SystemIntegrationSchema.versionedSchemas, 'systemIntegrationSchema', version)(
        (object as unknown) as PlainObject
      ) as SystemIntegrationLatest
    })
  }
}
