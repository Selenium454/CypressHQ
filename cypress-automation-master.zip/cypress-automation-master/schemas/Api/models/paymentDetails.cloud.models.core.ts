import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { CreditCard440, CreditCardSchema } from './creditCard.cloud.models.core'
import { DirectDebitCard440, DirectDebitCardSchema } from './DirectDebitCard.cloud.models.core'
import { BankAccount440, BankAccountSchema } from './bankAccount.cloud.models.core'

import { generateSanitizeFunction } from '../shared'

const creditCardSchema = new CreditCardSchema()
const directDebitCardSchema = new DirectDebitCardSchema()
const bankAccountSchema = new BankAccountSchema()

export interface PaymentDetails440 {
  creditCard?: CreditCard440 | null
  directDebitCard?: DirectDebitCard440 | null
  bankAccount?: BankAccount440 | null
}
export interface PaymentDetailsLatest extends PaymentDetails440 {}

export class PaymentDetailsSchema {
  latestVersion: string = '4.4.0'

  public static paymentDetails440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'paymentDetailsSchema',
      type: 'object',
      description: '',
      properties: {
        creditCard: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...CreditCardSchema.creditCard440.schema.properties,
          },
          see: CreditCardSchema.creditCard440,
          required: false,
        },
        directDebitCard: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...DirectDebitCardSchema.directDebitCard440.schema.properties,
          },
          see: DirectDebitCardSchema.directDebitCard440,
          required: false,
        },
        bankAccount: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...BankAccountSchema.bankAccount440.schema.properties,
          },
          see: BankAccountSchema.bankAccount440,
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({
      creditCard: CreditCardSchema.creditCard440.example,
      directDebitCard: DirectDebitCardSchema.directDebitCard440.example,
      bankAccount: BankAccountSchema.bankAccount440.example,
    } as PaymentDetails440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(PaymentDetailsSchema.paymentDetails440)

  public static snapshotSubtitle = 'Payment Details Model'

  public check = (object: PaymentDetailsLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'paymentDetailsSchema', version)
  }

  public sanitize = (object: PaymentDetailsLatest, version: string = this.latestVersion) => {
    if (object.creditCard) {
      creditCardSchema.sanitize(object.creditCard).then(sanitizedCreditCard => {
        object.creditCard = sanitizedCreditCard
      })
    }

    if (object.directDebitCard) {
      directDebitCardSchema.sanitize(object.directDebitCard).then(sanitizedDirectDebitCard => {
        object.directDebitCard = sanitizedDirectDebitCard
      })
    }

    if (object.bankAccount) {
      bankAccountSchema.sanitize(object.bankAccount).then(sanitizedBankAccount => {
        object.bankAccount = sanitizedBankAccount
      })
    }

    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(PaymentDetailsSchema.versionedSchemas, 'paymentDetailsSchema', version)(
        object as PlainObject
      ) as PaymentDetailsLatest
    })
  }
}
