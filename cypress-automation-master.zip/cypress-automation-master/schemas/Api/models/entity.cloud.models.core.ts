import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { Address440, AddressSchema } from './address.cloud.models.core'
import { Nurse440, NurseSchema } from './nurse.cloud.models.core'
import { Patient440, PatientSchema } from './patient.cloud.models.core'
import { Lock440, LockSchema } from './lock.models.core'
import { Corporate440, CorporateSchema } from './corporate.pharmacy.cloud.models.core'
import { BillingDetailsCloud440, BillingDetailsCloudSchema } from './billingDetails.cloud.models.core'
import {
  AustralianSouthSeaIslanderStatusValues,
  EthnicGroupValues,
  IndigenousStatusValues,
  MaritalStatusValues,
  RolesValues,
  UserStatusValues,
  SexValues,
} from '../types'
import { Doctor440, DoctorSchema } from './doctor.cloud.models.core'

import { generateSanitizeFunction } from '../shared'

const addressSchema = new AddressSchema()
const billingDetailsCloudSchema = new BillingDetailsCloudSchema()
const corporateSchema = new CorporateSchema()
const doctorSchema = new DoctorSchema()
const nurseSchema = new NurseSchema()
const patientSchema = new PatientSchema()
const lockSchema = new LockSchema()

export interface Entity440 {
  address?: Address440 | null
  australianSouthSeaIslanderStatus?: typeof AustralianSouthSeaIslanderStatusValues[number] | null
  billingDetails?: BillingDetailsCloud440 | null
  contactOf?: string[] | null
  corporate?: Corporate440 | null
  countryOfBirth?: string | null
  dateOfBirth?: string | null
  dateOfDeceased?: string | null
  deliveryAddress?: Address440 | null
  doctor?: Doctor440 | null
  email?: string | null
  employmentStatus?: string | null
  ethnicGroup?: typeof EthnicGroupValues[number] | null
  firstName: string
  preferredName?: string | null
  indigenousStatus?: typeof IndigenousStatusValues[number] | null
  language?: string | null
  maritalStatus?: typeof MaritalStatusValues[number] | null
  middleName?: string | null
  mobileNumber?: string | null
  namesPermutations?: string[] | null
  nationality?: string | null
  nurse?: Nurse440 | null
  objectId?: string | null
  patient?: Patient440 | null
  phoneNumber?: string | null
  photoUrl?: string | null
  pin?: string | null
  preferences?: object | null
  registeredBy?: string | null
  roles?: typeof RolesValues[number] | null
  sex?: typeof SexValues[number] | null
  surName: string
  timeZoneId?: string | null
  title?: string | null
  userId: string
  userPrincipalName?: string | null
  userStatus?: typeof UserStatusValues[number] | null
  isLockable?: boolean | null
  lock?: Lock440 | null
  documentType?: string | null
}
export interface EntityLatest extends Entity440 {}

export class EntitySchema {
  latestVersion: string = '4.4.0'

  public static entity440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'entitySchema',
      type: 'object',
      description: '',
      properties: {
        address: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...AddressSchema.address440.schema.properties,
          },
          see: AddressSchema.address440,
          required: false,
        },
        australianSouthSeaIslanderStatus: {
          type: ['string', 'null'],
          description: '',
          enum: (AustralianSouthSeaIslanderStatusValues as unknown) as string[],
          required: false,
        },
        billingDetails: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...BillingDetailsCloudSchema.billingDetailsCloud440.schema.properties,
          },
          see: BillingDetailsCloudSchema.billingDetailsCloud440,
          required: false,
        },
        contactOf: {
          type: ['array', 'null'],
          description: '',
          items: {
            type: ['string', 'null'],
            required: false,
          },
          required: false,
        },
        corporate: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...CorporateSchema.corporate440.schema.properties,
          },
          see: CorporateSchema.corporate440,
          required: false,
        },
        countryOfBirth: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        dateOfBirth: {
          type: ['string', 'null'],
          description: '',
          required: true,
        },
        dateOfDeceased: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        deliveryAddress: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...AddressSchema.address440.schema.properties,
          },
          see: AddressSchema.address440,
          required: false,
        },
        doctor: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...DoctorSchema.doctor440.schema.properties,
          },
          see: DoctorSchema.doctor440,
          required: false,
        },
        email: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        employmentStatus: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        ethnicGroup: {
          type: ['string', 'null'],
          description: '',
          enum: (EthnicGroupValues as unknown) as string[],
          required: false,
        },
        firstName: {
          type: 'string',
          description: '',
          required: true,
        },
        preferredName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        indigenousStatus: {
          type: ['string', 'null'],
          description: '',
          enum: (IndigenousStatusValues as unknown) as string[],
          required: false,
        },
        language: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        maritalStatus: {
          type: ['string', 'null'],
          description: '',
          enum: (MaritalStatusValues as unknown) as string[],
          required: false,
        },
        middleName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        mobileNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        namesPermutations: {
          type: ['array', 'null'],
          description: '',
          items: {
            type: ['string', 'null'],
            required: false,
          },
          required: false,
        },
        nationality: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        nurse: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...NurseSchema.nurse440.schema.properties,
          },
          see: NurseSchema.nurse440,
          required: false,
        },
        objectId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        patient: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...PatientSchema.patient440.schema.properties,
          },
          see: PatientSchema.patient440,
          required: false,
        },
        phoneNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        photoUrl: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        pin: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        preferences: {
          type: ['object', 'null'],
          description: '',
          required: false,
        },
        registeredBy: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        roles: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        sex: {
          type: ['string', 'null'],
          description: '',
          enum: (SexValues as unknown) as string[],
          required: false,
        },
        surName: {
          type: 'string',
          description: '',
          required: true,
        },
        timeZoneId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        title: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        userId: {
          type: 'string',
          description: '',
          required: true,
        },
        userPrincipalName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        userStatus: {
          type: ['string', 'null'],
          description: '',
          enum: (UserStatusValues as unknown) as string[],
          required: false,
        },
        isLockable: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        lock: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...LockSchema.lock440.schema.properties,
          },
          see: LockSchema.lock440,
          required: false,
        },
        documentType: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: (({
      userId: '12345',
      firstName: 'Bob',
      surName: 'Ross',
    } as Entity440) as unknown) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(EntitySchema.entity440)

  public static snapshotSubtitle = 'Entity Model'

  public check = (object: EntityLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'entitySchema', version)
  }

  public sanitize = (object: EntityLatest, version: string = this.latestVersion) => {
    if (object.address) {
      addressSchema.sanitize(object.address).then(sanitizedAddress => {
        object.address = sanitizedAddress
      })
    }

    if (object.billingDetails) {
      billingDetailsCloudSchema.sanitize(object.billingDetails).then(sanitizedBillingDetails => {
        object.billingDetails = sanitizedBillingDetails
      })
    }

    if (object.corporate) {
      corporateSchema.sanitize(object.corporate).then(sanitizedCorporate => {
        object.corporate = sanitizedCorporate
      })
    }

    if (object.deliveryAddress) {
      addressSchema.sanitize(object.deliveryAddress).then(sanitizedAddress => {
        object.deliveryAddress = sanitizedAddress
      })
    }

    if (object.doctor) {
      doctorSchema.sanitize(object.doctor).then(sanitizedDoctor => {
        object.doctor = sanitizedDoctor
      })
    }

    if (object.nurse) {
      nurseSchema.sanitize(object.nurse).then(sanitizedNurse => {
        object.nurse = sanitizedNurse
      })
    }

    if (object.patient) {
      patientSchema.sanitize(object.patient).then(sanitizedPatient => {
        object.patient = sanitizedPatient
      })
    }

    if (object.lock) {
      lockSchema.sanitize(object.lock).then(sanitizedLock => {
        object.lock = sanitizedLock
      })
    }

    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(EntitySchema.versionedSchemas, 'entitySchema', version)(
        (object as unknown) as PlainObject
      ) as EntityLatest
    })
  }
}
