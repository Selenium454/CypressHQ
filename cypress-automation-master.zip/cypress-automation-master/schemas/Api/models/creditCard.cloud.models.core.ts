import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { BankAcountType } from '../types'

import { generateSanitizeFunction } from '../shared'

export interface CreditCard440 {
  cardholderName?: string | null
  cardNumber?: string | null
  csvNumber?: string | null
  expiryDate?: string | null
  type?: typeof BankAcountType[number] | null
}
export interface CreditCardLatest extends CreditCard440 {}

export class CreditCardSchema {
  latestVersion: string = '4.4.0'

  public static creditCard440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'creditCardSchema',
      type: 'object',
      description: '',
      properties: {
        cardholderName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        cardNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        csvNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        expiryDate: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        type: {
          type: ['string', 'null'],
          description: '',
          enum: (BankAcountType as unknown) as string[],
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({
      cardholderName: 'Bob Ross',
      cardNumber: '13456789',
      csvNumber: '123',
      expiryDate: '2019-03-22',
      type: 'creditCard',
    } as CreditCard440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(CreditCardSchema.creditCard440)

  public static snapshotSubtitle = 'Credit Card Model'

  public check = (object: CreditCardLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'creditCardSchema', version)
  }

  public sanitize = (object: CreditCardLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(CreditCardSchema.versionedSchemas, 'creditCardSchema', version)(
        object as PlainObject
      ) as CreditCardLatest
    })
  }
}
