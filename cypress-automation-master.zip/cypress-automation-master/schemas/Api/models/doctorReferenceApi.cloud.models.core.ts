import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { Referral440, ReferralSchema } from './referral.cloud.models.core'
import { ReferenceTypeValues } from '../types'

import { generateSanitizeFunction } from '../shared'

export interface DoctorReferenceApi440 {
  fullName?: string | null
  practiceName?: string | null
  prescriberNumber?: string | null
  providerNumber?: string | null
  practiceId?: string | null
  referenceType: typeof ReferenceTypeValues[number]
  referrals?: Referral440[]
  userId: string
}
export interface DoctorReferenceApiLatest extends DoctorReferenceApi440 {}

export class DoctorReferenceApiSchema {
  latestVersion: string = '4.4.0'

  public static doctorReferenceApi440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'doctorReferenceApiSchema',
      type: 'object',
      description: 'Doctor reference model used inside patient services.',
      properties: {
        fullName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        practiceName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        prescriberNumber: {
          type: ['string', 'null'],
          description: '',
          required: true,
        },
        providerNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        practiceId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        referenceType: {
          type: 'string',
          description: '',
          required: true,
        },
        referrals: {
          type: ['array', 'null'],
          description: '',
          items: {
            ...ReferralSchema.referral440.schema,
          },
          see: ReferralSchema.referral440,
          required: false,
        },
        userId: {
          type: 'string',
          description: 'The user ID of the doctor.',
          required: true,
        },
      },
      additionalProperties: false,
    },
    example: (({
      fullName: 'Jerremy Smith',
      practiceName: 'Test',
      prescriberNumber: '123467',
      providerNumber: '144960AB',
      practiceId: 'b75831574c234ec896106dc0176c83c9',
      referenceType: 'referring',
      referrals: [ReferralSchema.referral440.example as Referral440],
      userId: '0000016547',
    } as DoctorReferenceApi440) as unknown) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(DoctorReferenceApiSchema.doctorReferenceApi440)

  public static snapshotSubtitle = 'Doctor Reference Api Model'

  public check = (object: DoctorReferenceApiLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'doctorReferenceApiSchema', version)
  }

  public sanitize = (object: DoctorReferenceApiLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(DoctorReferenceApiSchema.versionedSchemas, 'doctorReferenceApiSchema', version)(
        (object as unknown) as PlainObject
      ) as DoctorReferenceApiLatest
    })
  }
}
