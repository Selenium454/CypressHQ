import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { DoctorPrefixValues, DoctorTypeValues } from '../types'
import { Practice440, PracticeSchema } from './practice.cloud.models.core'

import { generateSanitizeFunction } from '../shared'

const practiceSchema = new PracticeSchema()

export interface Doctor440 {
  active?: boolean | null
  doctorPrefix?: typeof DoctorPrefixValues[number] | null
  doctorType?: typeof DoctorTypeValues[number] | null
  practices?: Practice440 | null
  prescriberNumber?: string | null
  registrationNumber?: string | null
  specializations?: string[] | null
}
export interface DoctorLatest extends Doctor440 {}

export class DoctorSchema {
  latestVersion: string = '4.4.0'

  public static doctor440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'doctorSchema',
      type: 'object',
      description: 'Doctor reference model used inside patient services.',
      properties: {
        active: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        doctorPrefix: {
          type: ['string', 'null'],
          description: '',
          enum: (DoctorPrefixValues as unknown) as string[],
          required: false,
        },
        doctorType: {
          type: ['string', 'null'],
          description: '',
          enum: (DoctorTypeValues as unknown) as string[],
          required: false,
        },
        practices: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...PracticeSchema.practice440.schema.properties,
          },
          see: PracticeSchema.practice440,
          required: false,
        },
        prescriberNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        registrationNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        specializations: {
          type: ['array', 'null'],
          description: '',
          items: {
            type: ['string', 'null'],
            required: false,
          },
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({} as Doctor440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(DoctorSchema.doctor440)

  public static snapshotSubtitle = 'Doctor Model'

  public check = (object: DoctorLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'doctorSchema', version)
  }

  public sanitize = (object: DoctorLatest, version: string = this.latestVersion) => {
    if (object.practices) {
      practiceSchema.sanitize(object.practices).then(sanitizedPractices => {
        object.practices = sanitizedPractices
      })
    }

    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(DoctorSchema.versionedSchemas, 'doctorSchema', version)(
        object as PlainObject
      ) as DoctorLatest
    })
  }
}
