import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { Notation440, NotationSchema } from './notation.orders.cloud.models.core'
import { SupplyAmountValues } from '../types'

import { generateSanitizeFunction } from '../shared'

export interface ChartItem440 {
  degree?: string | null
  emergencySupply?: boolean | null
  index?: number | null
  notations?: Notation440[] | null
  orderId?: string | null
  path?: string | null
  quantity?: number | null
  residentRequest?: boolean | null
  supplyAmount?: typeof SupplyAmountValues[number] | null
}
export interface ChartItemLatest extends ChartItem440 {}

export class ChartItemSchema {
  latestVersion: string = '4.4.0'

  public static chartItem440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'chartItemSchema',
      type: 'object',
      description: 'Time slots model for medication time slots.',
      properties: {
        degree: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        emergencySupply: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        index: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        notations: {
          type: ['array', 'null'],
          description: '',
          items: {
            ...NotationSchema.notation440.schema,
          },
          see: NotationSchema.notation440,
          required: false,
        },
        orderId: {
          type: ['string', 'null'],
          format: 'orderId',
          description: '',
          required: false,
        },
        path: {
          type: ['string', 'null'],
          format: 'chartOrderPath',
          description: '',
          required: false,
        },
        quantity: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        residentRequest: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        supplyAmount: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({} as ChartItem440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(ChartItemSchema.chartItem440)

  public static snapshotSubtitle = 'Chart Item Model'

  public check = (object: ChartItemLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'chartItemSchema', version)
  }

  public sanitize = (object: ChartItemLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(ChartItemSchema.versionedSchemas, 'chartItemSchema', version)(
        object as PlainObject
      ) as ChartItemLatest
    })
  }
}
