import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { generateSanitizeFunction } from '../shared'

export interface AdmissionAdministration440 {
  method?: string | null
  other?: string | null
  preferredMethod?: string | null
}
export interface AdmissionAdministrationLatest extends AdmissionAdministration440 {}

export class AdmissionAdministrationSchema {
  latestVersion: string = '4.4.0'

  public static admissionAdministration440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'admissionAdministrationSchema',
      type: 'object',
      description: '',
      properties: {
        method: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        other: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        preferredMethod: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({
      method: 'Method',
      other: 'Other',
      preferredMethod: 'Preferred Method',
    } as AdmissionAdministration440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(AdmissionAdministrationSchema.admissionAdministration440)

  public static snapshotSubtitle = 'Admission Administration Model'

  public check = (object: AdmissionAdministrationLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'admissionAdministrationSchema', version)
  }

  public sanitize = (object: AdmissionAdministrationLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(
        AdmissionAdministrationSchema.versionedSchemas,
        'admissionAdministrationSchema',
        version
      )(object as PlainObject) as AdmissionAdministrationLatest
    })
  }
}
