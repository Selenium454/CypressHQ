import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'

import { generateSanitizeFunction } from '../shared'

export interface HealthFund440 {
  id?: string | null
  coverLevel?: string | null
  expiryDate?: string | null
  membershipNumber?: string | null
}
export interface HealthFundLatest extends HealthFund440 {}

export class HealthFundSchema {
  latestVersion: string = '4.4.0'

  public static healthFund440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'healthFundSchema',
      type: 'object',
      description: 'Health fund model for use in patient services.',
      properties: {
        coverLevel: {
          type: ['string', 'null'],
          description: 'The level of cover the patient has under this health fund provider.',
          required: false,
        },
        expiryDate: {
          type: ['string', 'null'],
          format: 'dateWithPlusTimezone',
          description: 'The date that the health fund cover expires.',
          required: false,
        },
        id: {
          type: ['string', 'null'],
          format: 'healthFund',
          description: 'ID of the health fund.',
          required: false,
        },
        membershipNumber: {
          type: ['string', 'null'],
          format: 'healthFundMembership',
          description: "The patient's membership number.",
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({
      id: 'HCF',
      coverLevel: 'TOP',
      expiryDate: '2019-04-30',
      membershipNumber: '1235',
    } as HealthFund440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(HealthFundSchema.healthFund440)

  public static snapshotSubtitle = 'Health Fund Model'

  public check = (object: HealthFundLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'healthFundSchema', version)
  }

  public sanitize = (object: HealthFundLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(HealthFundSchema.versionedSchemas, 'healthFundSchema', version)(
        object as PlainObject
      ) as HealthFundLatest
    })
  }
}
