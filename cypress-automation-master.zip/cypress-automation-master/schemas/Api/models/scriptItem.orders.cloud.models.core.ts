import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { PackingTypeValues } from '../types'

import { generateSanitizeFunction } from '../shared'

export interface ScriptItem440 {
  form?: string | null
  greenDuplicateScriptFile?: string | null
  includeInRegularSachet?: boolean | null
  medicationEndDate?: string | null
  medicationName?: string | null
  medicationStartDate?: string | null
  orderId?: string | null
  packingType?: typeof PackingTypeValues[number] | null
  pharmacyAuthorizationFile?: string | null
  preferGenericBrand?: boolean | null
  repeatScript?: boolean | null
  strength?: string | null
  totalRepeats?: number | null
}
export interface ScriptItemLatest extends ScriptItem440 {}

export class ScriptItemSchema {
  latestVersion: string = '4.4.0'

  public static scriptItem440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'scriptItemSchema',
      type: 'object',
      description: '',
      properties: {
        form: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        greenDuplicateScriptFile: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        includeInRegularSachet: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        medicationEndDate: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        medicationName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        medicationStartDate: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        orderId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        packingType: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        pharmacyAuthorizationFile: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        preferGenericBrand: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        repeatScript: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        strength: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        totalRepeats: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({} as ScriptItem440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(ScriptItemSchema.scriptItem440)

  public static snapshotSubtitle = 'Script Item Model'

  public check = (object: ScriptItemLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'scriptItemSchema', version)
  }

  public sanitize = (object: ScriptItemLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(ScriptItemSchema.versionedSchemas, 'scriptItemSchema', version)(
        object as PlainObject
      ) as ScriptItemLatest
    })
  }
}
