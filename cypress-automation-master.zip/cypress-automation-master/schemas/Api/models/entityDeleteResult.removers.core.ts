import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { Entity440, EntitySchema } from './entity.cloud.models.core'
import { Audit440, AuditSchema } from './audit.audit.models.core'
import { Admission440, AdmissionSchema } from './admission.cloud.models.core'
import { Order440, OrderSchema } from './order.orders.cloud.models.core'
import { Visit440, VisitSchema } from './visit.visits.cloud.models.core'
import { Treatment440, TreatmentSchema } from './treatment.cloud.models.core'
import { MedicationProfile440, MedicationProfileSchema } from './medicationProfile.cloud.models.core'

import { generateSanitizeFunction } from '../shared'

const entitySchema = new EntitySchema()

export interface EntityDeleteResult440 {
  entity?: Entity440 | null
  audits?: Audit440[] | null
  admissions?: Admission440[] | null
  orders?: Order440[] | null
  visits?: Visit440[] | null
  treatments?: Treatment440[] | null
  medicationProfiles?: MedicationProfile440[] | null
}
export interface EntityDeleteResultLatest extends EntityDeleteResult440 {}

export class EntityDeleteResultSchema {
  latestVersion: string = '4.4.0'

  public static entityDeleteResult440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'entityDeleteResultSchema',
      type: 'object',
      description: '',
      properties: {
        entity: {
          type: ['object', 'null'],
          properties: {
            ...EntitySchema.entity440.schema.properties,
          },
          see: EntitySchema.entity440,
          required: false,
        },
        audits: {
          type: ['array', 'null'],
          description: '',
          items: {
            ...AuditSchema.audit440.schema,
          },
          see: AuditSchema.audit440,
          required: false,
        },
        admissions: {
          type: ['array', 'null'],
          description: '',
          items: {
            ...AdmissionSchema.admission440.schema,
          },
          see: AdmissionSchema.admission440,
          required: false,
        },
        orders: {
          type: ['array', 'null'],
          description: '',
          items: {
            ...OrderSchema.order440.schema,
          },
          see: OrderSchema.order440,
          required: false,
        },
        visits: {
          type: ['array', 'null'],
          description: '',
          items: {
            ...VisitSchema.visit440.schema,
          },
          see: VisitSchema.visit440,
          required: false,
        },
        treatments: {
          type: ['array', 'null'],
          description: '',
          items: {
            ...TreatmentSchema.treatment440.schema,
          },
          see: TreatmentSchema.treatment440,
          required: false,
        },
        medicationProfiles: {
          type: ['array', 'null'],
          description: '',
          items: {
            ...MedicationProfileSchema.medicationProfile440.schema,
          },
          see: MedicationProfileSchema.medicationProfile440,
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({} as EntityDeleteResult440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(EntityDeleteResultSchema.entityDeleteResult440)

  public static snapshotSubtitle = 'Entity Delete Result Model'

  public check = (object: EntityDeleteResultLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'entityDeleteResultSchema', version)
  }

  public sanitize = (object: EntityDeleteResultLatest, version: string = this.latestVersion) => {
    if (object.entity) {
      entitySchema.sanitize(object.entity).then(sanitizedEntity => {
        object.entity = sanitizedEntity
      })
    }

    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(EntityDeleteResultSchema.versionedSchemas, 'entityDeleteResultSchema', version)(
        object as PlainObject
      ) as EntityDeleteResultLatest
    })
  }
}
