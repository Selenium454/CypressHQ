import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import {
  ConsequenceImpactValues,
  DrugProblemValues,
  DrugProblemDetailsValues,
  LikelihoodValues,
  RecommendationValues,
  RecommendationDetailsValues,
} from '../types'

import { generateSanitizeFunction } from '../shared'

export interface InterventionApi440 {
  consequenceImpact?: typeof ConsequenceImpactValues[number] | null
  content?: string | null
  drugNames?: string[] | null
  drugProblem?: typeof DrugProblemValues[number] | null
  drugProblemDetails?: typeof DrugProblemDetailsValues[number] | null
  facilityCode?: string | null
  fromDate?: string | null
  interventionDate?: string | null
  likelihood?: typeof LikelihoodValues[number] | null
  pharmacyId?: string | null
  recommendation?: typeof RecommendationValues[number] | null
  recommendationDetails?: typeof RecommendationDetailsValues[number] | null
  roundCode?: string | null
  urNumber?: string | null
  writtenBy?: string | null
}
export interface InterventionApiLatest extends InterventionApi440 {}

export class InterventionApiSchema {
  latestVersion: string = '4.4.0'

  public static interventionApi440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'interventionApiSchema',
      type: 'object',
      description: 'Intervention model for patient interventions.',
      properties: {
        consequenceImpact: {
          type: ['string', 'null'],
          description: 'The impact of the event.',
          required: false,
        },
        content: {
          type: ['string', 'null'],
          description: "Contact's first name.",
          required: false,
        },
        drugNames: {
          type: 'array',
          description: 'Array of medications covered by the intervention.',
          items: {
            type: 'string',
            description: 'Medication name.',
          },
          required: false,
        },
        drugProblem: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        drugProblemDetails: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        facilityCode: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        fromDate: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        interventionDate: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        likelihood: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        pharmacyId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        recommendation: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        recommendationDetails: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        roundCode: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        urNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        writtenBy: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({
      consequenceImpact: 'insignificant',
      content: '',
      drugNames: ['Testicular Support'],
      drugProblem: 'drugSelection',
      drugProblemDetails: 'duplication',
      facilityCode: 'SJGM',
      fromDate: '14/12/2018',
      interventionDate: '14/12/2018',
      likelihood: 'almostCertain',
      pharmacyId: '44',
      recommendation: 'changeInTherapy',
      recommendationDetails: 'prescriptionNotDispensed',
      roundCode: 'CATH',
      urNumber: '0000504917',
      writtenBy: '0000000024',
    } as InterventionApi440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(InterventionApiSchema.interventionApi440)

  public static snapshotSubtitle = 'Intervention Api Model'

  public check = (object: InterventionApiLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'interventionApiSchema', version)
  }

  public sanitize = (object: InterventionApiLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(InterventionApiSchema.versionedSchemas, 'interventionApiSchema', version)(
        object as PlainObject
      ) as InterventionApiLatest
    })
  }
}
