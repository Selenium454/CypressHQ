import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'

import { generateSanitizeFunction } from '../shared'

export interface ExternalIdentifier440 {
  key: string
  value: string
}
export interface ExternalIdentifierLatest extends ExternalIdentifier440 {}

export class ExternalIdentifierSchema {
  latestVersion: string = '4.4.0'

  public static externalIdentifier440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'externalIdentifierSchema',
      type: 'object',
      description: 'Model for additional identifiers in patient services.',
      properties: {
        key: {
          type: ['string', 'null'],
          description: "The identifier's key value.",
          required: true,
        },
        value: {
          type: ['string', 'null'],
          format: 'serviceIdentifier',
          description: "The identifier's value.",
          required: true,
        },
      },
      additionalProperties: false,
    },
    example: (({
      key: 'TCID',
      value: '1234',
    } as ExternalIdentifier440) as unknown) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(ExternalIdentifierSchema.externalIdentifier440)

  public static snapshotSubtitle = 'External Identifier Model'

  public check = (object: ExternalIdentifierLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'externalIdentifierSchema', version)
  }

  public sanitize = (object: ExternalIdentifierLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(ExternalIdentifierSchema.versionedSchemas, 'externalIdentifierSchema', version)(
        (object as unknown) as PlainObject
      ) as ExternalIdentifierLatest
    })
  }
}
