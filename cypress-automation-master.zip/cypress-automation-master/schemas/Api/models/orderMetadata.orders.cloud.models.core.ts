import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { OrderContextValues, OrderTypeValues, OrderStateValues } from '../types'
import { PharmacyOrderStatus440, PharmacyOrderStatusSchema } from './pharmacyOrderStatus.orders.cloud.models.core'

import { generateSanitizeFunction } from '../shared'

const pharmacyOrderStatusSchema = new PharmacyOrderStatusSchema()

export interface OrderMetadata440 {
  orderType?: typeof OrderTypeValues[number] | null
  context?: typeof OrderContextValues[number] | null
  orderFor?: string | null
  name?: string | null
  pharmacyStatus?: PharmacyOrderStatus440 | null
  dueTime?: string | null
  received?: string | null
  deliveryTime?: string | null
  endTime?: string | null
  status?: typeof OrderStateValues[number] | null
  round?: string | null
  urn?: string | null
  orderByName?: string | null
  alias?: string | null
  tags?: string | null
  orderId?: string | null
  batchId?: string | null
  groupId?: string | null
  facilityCode?: string | null
}
export interface OrderMetadataLatest extends OrderMetadata440 {}

export class OrderMetadataSchema {
  latestVersion: string = '4.4.0'

  public static orderMetadata440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'orderMetadataSchema',
      type: 'object',
      description: '',
      properties: {
        orderType: {
          type: ['string', 'null'],
          description: '',
          enum: (OrderTypeValues as unknown) as string[],
          required: false,
        },
        context: {
          type: ['string', 'null'],
          description: '',
          enum: (OrderContextValues as unknown) as string[],
          required: false,
        },
        orderFor: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        name: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        pharmacyStatus: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...PharmacyOrderStatusSchema.pharmacyOrderStatus440.schema.properties,
          },
          see: PharmacyOrderStatusSchema.pharmacyOrderStatus440,
          required: false,
        },
        dueTime: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        received: {
          type: ['string', 'null'],
          description: '',
          required: true,
        },
        deliveryTime: {
          type: ['string', 'null'],
          description: '',
          required: true,
        },
        endTime: {
          type: 'string',
          description: '',
          required: true,
        },
        status: {
          type: 'string',
          description: '',
          enum: (OrderStateValues as unknown) as string[],
          required: true,
        },
        round: {
          type: 'string',
          description: '',
          required: true,
        },
        urn: {
          type: 'string',
          description: '',
          required: true,
        },
        orderByName: {
          type: 'string',
          description: '',
          required: true,
        },
        alias: {
          type: 'string',
          description: '',
          required: true,
        },
        tags: {
          type: 'string',
          description: '',
          required: true,
        },
        orderId: {
          type: 'string',
          description: '',
          required: true,
        },
        batchId: {
          type: 'string',
          description: '',
          required: true,
        },
        groupId: {
          type: 'string',
          description: '',
          required: true,
        },
        facilityCode: {
          type: 'string',
          description: '',
          required: true,
        },
      },
      additionalProperties: false,
    },
    example: ({} as OrderMetadata440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(OrderMetadataSchema.orderMetadata440)

  public static snapshotSubtitle = 'Order Metadata Model'

  public check = (object: OrderMetadataLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'orderMetadataSchema', version)
  }

  public sanitize = (object: OrderMetadataLatest, version: string = this.latestVersion) => {
    if (object.pharmacyStatus) {
      pharmacyOrderStatusSchema.sanitize(object.pharmacyStatus).then(sanitizedPharmacyStatus => {
        object.pharmacyStatus = sanitizedPharmacyStatus
      })
    }

    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(OrderMetadataSchema.versionedSchemas, 'orderMetadataSchema', version)(
        object as PlainObject
      ) as OrderMetadataLatest
    })
  }
}
