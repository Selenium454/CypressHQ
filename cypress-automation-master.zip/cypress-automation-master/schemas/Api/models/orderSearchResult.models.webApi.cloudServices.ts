import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { OrderTypeValues, OrderContextValues, OrderStateValues, ChartStatusValues } from '../types/models.types'

import { generateSanitizeFunction } from '../shared'

export interface OrderSearchResult440 {
  orderType?: typeof OrderTypeValues[number] | null
  context?: typeof OrderContextValues[number] | null
  orderById?: string | null
  orderByName?: string | null
  orderForId?: string | null
  orderForName?: string | null
  dueTime?: string | null
  created?: string | null
  deliveryTime?: string | null
  endTime?: string | null
  state?: typeof OrderStateValues[number] | null
  chartStatus?: typeof ChartStatusValues[number] | null
  urn?: string | null
  orderId?: string | null
  batchId?: string | null
  groupId?: string | null
  facilityCode?: string | null
  wardCode?: string | null
  tags?: string | null
}
export interface OrderSearchResultLatest extends OrderSearchResult440 {}

export class OrderSearchResultSchema {
  latestVersion: string = '4.4.0'

  public static orderSearchResult440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'orderSearchResultSchema',
      type: 'object',
      description: '',
      properties: {
        orderType: {
          type: ['string', 'null'],
          description: '',
          enum: (OrderTypeValues as unknown) as string[],
          required: false,
        },
        context: {
          type: ['string', 'null'],
          description: '',
          enum: (OrderTypeValues as unknown) as string[],
          required: false,
        },
        orderById: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        orderByName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        orderForId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        orderForName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        dueTime: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        created: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        deliveryTime: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        endTime: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        state: {
          type: ['string', 'null'],
          description: '',
          enum: (OrderStateValues as unknown) as string[],
          required: false,
        },
        chartStatus: {
          type: ['string', 'null'],
          description: '',
          enum: (ChartStatusValues as unknown) as string[],
          required: false,
        },
        urn: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        orderId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        batchId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        groupId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        facilityCode: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        wardCode: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        tags: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({} as OrderSearchResult440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(OrderSearchResultSchema.orderSearchResult440)

  public static snapshotSubtitle = 'Order Search Result Model'

  public check = (object: OrderSearchResultLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'orderSearchResultSchema', version)
  }

  public sanitize = (object: OrderSearchResultLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(OrderSearchResultSchema.versionedSchemas, 'orderSearchResultSchema', version)(
        object as PlainObject
      ) as OrderSearchResultLatest
    })
  }
}
