import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { ConcessionEntitledValues, NonActiveReasonValues, RepatCardTypeValues } from '../types'

import { generateSanitizeFunction } from '../shared'

export interface PatientDetailsPatientDetailsCommand440 {
  activeInHub?: boolean | null
  concessionEntitled?: typeof ConcessionEntitledValues[number] | null
  concessionNumber?: string | null
  concessionType?: string | null
  concessionValidToDate?: string | null
  ctg?: boolean | null
  medicareFirstName?: string | null
  medicareNumber?: string | null
  medicareSurName?: string | null
  medicareValidDate?: string | null
  medicationInstructions?: string | null
  nonActiveReason?: typeof NonActiveReasonValues[number] | null
  repatCardType?: typeof RepatCardTypeValues[number] | null
  repatNumber?: string | null
  safetyNetNumber?: string | null
}
export interface PatientDetailsPatientDetailsCommandLatest extends PatientDetailsPatientDetailsCommand440 {}

export class PatientDetailsPatientDetailsCommandSchema {
  latestVersion: string = '4.4.0'

  public static patientDetailsPatientDetailsCommand440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'patientDetailsPatientDetailsCommandSchema',
      type: 'object',
      description: '',
      properties: {
        activeInHub: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        concessionEntitled: {
          type: ['string', 'null'],
          description: '',
          enum: (ConcessionEntitledValues as unknown) as string[],
          required: false,
        },
        concessionNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        concessionType: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        concessionValidToDate: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        ctg: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        medicareFirstName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        medicareNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        medicareSurName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        medicareValidDate: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        medicationInstructions: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        nonActiveReason: {
          type: ['string', 'null'],
          description: '',
          enum: (NonActiveReasonValues as unknown) as string[],
          required: false,
        },
        repatCardType: {
          type: ['string', 'null'],
          description: '',
          enum: (RepatCardTypeValues as unknown) as string[],
          required: false,
        },
        repatNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        safetyNetNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({} as PatientDetailsPatientDetailsCommand440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(
    PatientDetailsPatientDetailsCommandSchema.patientDetailsPatientDetailsCommand440
  )

  public static snapshotSubtitle = 'Patient Details Model'

  public check = (object: PatientDetailsPatientDetailsCommandLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'patientDetailsPatientDetailsCommandSchema', version)
  }

  public sanitize = (object: PatientDetailsPatientDetailsCommandLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(
        PatientDetailsPatientDetailsCommandSchema.versionedSchemas,
        'patientDetailsPatientDetailsCommandSchema',
        version
      )(object as PlainObject) as PatientDetailsPatientDetailsCommandLatest
    })
  }
}
