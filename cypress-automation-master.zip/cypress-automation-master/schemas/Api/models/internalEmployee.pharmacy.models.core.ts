import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'

import { generateSanitizeFunction } from '../shared'

export interface InternalEmployee440 {
  pharmacyIds?: string[] | null
}
export interface InternalEmployeeLatest extends InternalEmployee440 {}

export class InternalEmployeeSchema {
  latestVersion: string = '4.4.0'

  public static internalEmployee440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'internalEmployeeSchema',
      type: 'object',
      description: '',
      properties: {
        pharmacyIds: {
          type: ['array', 'null'],
          description: '',
          items: {
            type: 'string',
            required: false,
          },
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({
      pharmacyIds: ['44', '72'],
    } as InternalEmployee440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(InternalEmployeeSchema.internalEmployee440)

  public static snapshotSubtitle = 'Internal Employee Model'

  public check = (object: InternalEmployeeLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'internalEmployeeSchema', version)
  }

  public sanitize = (object: InternalEmployeeLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(InternalEmployeeSchema.versionedSchemas, 'internalEmployeeSchema', version)(
        object as PlainObject
      ) as InternalEmployeeLatest
    })
  }
}
