import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { Address440, AddressSchema } from './address.cloud.models.core'

import { generateSanitizeFunction } from '../shared'

const addressSchema = new AddressSchema()

export interface Practice440 {
  address?: Address440 | null
  email?: string | null
  facilityCode?: string | null
  phoneNumber?: string | null
  practiceId?: string | null
  practiceName?: string | null
  providerNumber?: string | null
  wardCode?: string | null
}
export interface PracticeLatest extends Practice440 {}

export class PracticeSchema {
  latestVersion: string = '4.4.0'

  public static practice440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'practiceSchema',
      type: 'object',
      description: '',
      properties: {
        address: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...AddressSchema.address440.schema.properties,
          },
          see: AddressSchema.address440,
          required: false,
        },
        email: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        facilityCode: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        phoneNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        practiceId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        practiceName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        providerNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        wardCode: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({
      address: AddressSchema.address440.example as Address440,
      practiceId: null,
      practiceName: 'practice 1',
      providerNumber: '257898MH',
    } as Practice440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(PracticeSchema.practice440)

  public static snapshotSubtitle = 'Practice Model'

  public check = (object: PracticeLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'practiceSchema', version)
  }

  public sanitize = (object: PracticeLatest, version: string = this.latestVersion) => {
    if (object.address) {
      addressSchema.sanitize(object.address).then(sanitizedAddress => {
        object.address = sanitizedAddress
      })
    }

    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(PracticeSchema.versionedSchemas, 'practiceSchema', version)(
        object as PlainObject
      ) as PracticeLatest
    })
  }
}
