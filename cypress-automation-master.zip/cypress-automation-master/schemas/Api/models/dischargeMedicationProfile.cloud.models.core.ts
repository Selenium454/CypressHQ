import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { DischargeMedicationStatusValues } from '../types'

import { generateSanitizeFunction } from '../shared'

export interface DischargeMedicationProfile440 {
  additionalInformation?: string | null
  alternateName?: string | null
  bedtimeDose?: string | null
  dose?: number | null
  drugCode?: string | null
  drugForm?: string | null
  drugName?: string | null
  drugStrength?: string | null
  eveningDose?: string | null
  indication?: string | null
  medicationInstructions?: string | null
  translatedDirections?: string | null
  middayDose?: string | null
  morningDose?: string | null
  order?: number | null
  prn?: boolean | null
  purpose?: string | null
  reconcile?: boolean | null
  routeOfAdministration?: string | null
  sigCodesString?: string | null
  startDate?: string | null
  status?: typeof DischargeMedicationStatusValues[number] | null
  supplyAtHome?: boolean | null
}
export interface DischargeMedicationProfileLatest extends DischargeMedicationProfile440 {}

export class DischargeMedicationProfileSchema {
  latestVersion: string = '4.4.0'

  public static dischargeMedicationProfile440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'dischargeMedicationProfileSchema',
      type: 'object',
      description: '',
      properties: {
        additionalInformation: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        alternateName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        bedtimeDose: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        dose: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        drugCode: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        drugForm: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        drugName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        drugStrength: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        eveningDose: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        indication: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        medicationInstructions: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        translatedDirections: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        middayDose: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        morningDose: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        order: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        prn: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        purpose: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        reconcile: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        routeOfAdministration: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        sigCodesString: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        startDate: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        status: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        supplyAtHome: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({} as DischargeMedicationProfile440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(DischargeMedicationProfileSchema.dischargeMedicationProfile440)

  public static snapshotSubtitle = 'Discharge Medication Profile Model'

  public check = (object: DischargeMedicationProfileLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'dischargeMedicationProfileSchema', version)
  }

  public sanitize = (object: DischargeMedicationProfileLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(
        DischargeMedicationProfileSchema.versionedSchemas,
        'dischargeMedicationProfileSchema',
        version
      )(object as PlainObject) as DischargeMedicationProfileLatest
    })
  }
}
