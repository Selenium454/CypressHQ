import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'

import { generateSanitizeFunction } from '../shared'

export type statusValues = 'none' | 'draft' | 'completed' | 'approved'

export interface PracticeSearchResult440 {
  practiceId?: string | null
  practiceName?: string | null
  providerNumber?: string | null
}
export interface PracticeSearchResultLatest extends PracticeSearchResult440 {}

export class PracticeSearchResultSchema {
  latestVersion: string = '4.4.0'

  public static practiceSearchResult440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'practiceSearchResultSchema',
      type: 'object',
      description: '',
      properties: {
        practiceId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        practiceName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        providerNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: (({} as PracticeSearchResult440) as unknown) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(PracticeSearchResultSchema.practiceSearchResult440)

  public static snapshotSubtitle = 'Practice Search Results Model'

  public check = (object: PracticeSearchResultLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'practiceSearchResultSchema', version)
  }

  public sanitize = (object: PracticeSearchResultLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(
        PracticeSearchResultSchema.versionedSchemas,
        'practiceSearchResultSchema',
        version
      )(object as PlainObject) as PracticeSearchResultLatest
    })
  }
}
