import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { TypeValues } from '../types'

import { generateSanitizeFunction } from '../shared'

export interface Allergy440 {
  description?: string | null
  genericName?: string | null
  startDate?: string | null
  title?: string | null
  type?: typeof TypeValues[number] | null
}
export interface AllergyLatest extends Allergy440 {}

export class AllergySchema {
  latestVersion: string = '4.4.0'

  public static allergy440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'allergySchema',
      type: 'object',
      description: '',
      properties: {
        description: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        genericName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        startDate: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        title: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        type: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({
      description: 'Allergy description',
      genericName: 'Testosterone',
      startDate: '',
      title: '',
      type: 'none',
    } as Allergy440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(AllergySchema.allergy440)

  public static snapshotSubtitle = 'Allergy Model'

  public check = (object: AllergyLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'allergySchema', version)
  }

  public sanitize = (object: AllergyLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(AllergySchema.versionedSchemas, 'allergySchema', version)(
        object as PlainObject
      ) as AllergyLatest
    })
  }
}
