import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'

import { generateSanitizeFunction } from '../shared'

export interface AdmissionRiskIdentification440 {
  administrationAidDetails?: string | null
  assessmentOtherInformation?: string | null
  canMeasureLiquids?: string | null
  canOpenBottles?: boolean | null
  canReadComprehendLabels?: boolean | null
  canUnderstandEnglish?: boolean | null
  hasImpairedHearing?: boolean | null
  hasImpairedVision?: boolean | null
  languageSpoken?: string | null
  livesAlone?: boolean | null
  livesResidentialCare?: boolean | null
  recentHomeMedicineReview?: string | null
  riskOtherInformation?: string | null
  suspectedNonAdherence?: boolean | null
  swallowingIssues?: boolean | null
  usesAdministrationAid?: boolean | null
  usesDoseAdministrationDevice?: boolean | null
  usesMedicationList?: boolean | null
}
export interface AdmissionRiskIdentificationLatest extends AdmissionRiskIdentification440 {}

export class AdmissionRiskIdentificationSchema {
  latestVersion: string = '4.4.0'

  public static admissionRiskIdentification440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'admissionRiskIdentificationSchema',
      type: 'object',
      description: '',
      properties: {
        administrationAidDetails: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        assessmentOtherInformation: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        canMeasureLiquids: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        canOpenBottles: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        canReadComprehendLabels: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        canUnderstandEnglish: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        hasImpairedHearing: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        hasImpairedVision: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        languageSpoken: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        livesAlone: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        livesResidentialCare: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        recentHomeMedicineReview: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        riskOtherInformation: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        suspectedNonAdherence: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        swallowingIssues: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        usesAdministrationAid: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        usesDoseAdministrationDevice: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        usesMedicationList: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({
      administrationAidDetails: 'Admin Aid',
      assessmentOtherInformation: 'More Info',
      canMeasureLiquids: 'false',
      canOpenBottles: true,
      canReadComprehendLabels: true,
      canUnderstandEnglish: false,
      hasImpairedHearing: false,
      hasImpairedVision: true,
      languageSpoken: 'Language Spoken',
      livesAlone: false,
      livesResidentialCare: true,
      recentHomeMedicineReview: 'true',
      riskOtherInformation: 'Other Info',
      suspectedNonAdherence: false,
      swallowingIssues: true,
      usesAdministrationAid: true,
      usesDoseAdministrationDevice: false,
      usesMedicationList: false,
    } as AdmissionRiskIdentification440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(AdmissionRiskIdentificationSchema.admissionRiskIdentification440)

  public static snapshotSubtitle = 'Admission Risk Identificatiton Model'

  public check = (object: AdmissionRiskIdentificationLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'admissionRiskIdentificationSchema', version)
  }

  public sanitize = (object: AdmissionRiskIdentificationLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(
        AdmissionRiskIdentificationSchema.versionedSchemas,
        'admissionRiskIdentificationSchema',
        version
      )(object as PlainObject) as AdmissionRiskIdentificationLatest
    })
  }
}
