import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { NotationTypeValues } from '../types'

import { generateSanitizeFunction } from '../shared'

export interface Notation440 {
  color?: string | null
  comment?: string | null
  date?: string | null
  length?: number | null
  notationOrder?: number | null
  type?: typeof NotationTypeValues[number] | null
  userName?: string | null
  width?: number | null
  x?: number | null
  x1?: number | null
  y?: number | null
  y1?: number | null
}
export interface NotationLatest extends Notation440 {}

export class NotationSchema {
  latestVersion: string = '4.4.0'

  public static notation440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'notationSchema',
      type: 'object',
      description: 'Time slots model for medication time slots.',
      properties: {
        color: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        comment: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        date: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        length: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        notationOrder: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        type: {
          type: ['string', 'null'],
          description: '',
          enum: (NotationTypeValues as unknown) as string[],
          required: false,
        },
        userName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        width: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        x: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        x1: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        y: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        y1: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({} as Notation440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(NotationSchema.notation440)

  public static snapshotSubtitle = 'Notation Model'

  public check = (object: NotationLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'notationSchema', version)
  }

  public sanitize = (object: NotationLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(NotationSchema.versionedSchemas, 'notationSchema', version)(
        object as PlainObject
      ) as NotationLatest
    })
  }
}
