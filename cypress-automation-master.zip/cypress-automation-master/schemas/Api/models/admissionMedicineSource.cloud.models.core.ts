import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'

import { generateSanitizeFunction } from '../shared'

export interface AdmissionMedicineSource440 {
  confirmedBy?: string | null
  date?: string | null
  source?: string | null
}
export interface AdmissionMedicineSourceLatest extends AdmissionMedicineSource440 {}

export class AdmissionMedicineSourceSchema {
  latestVersion: string = '4.4.0'

  public static admissionMedicineSource440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'admissionMedicineSourceSchema',
      type: 'object',
      description: '',
      properties: {
        confirmedBy: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        date: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        source: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({
      confirmedBy: '0001780094',
      date: '2020-06-01T00:00:00.000Z',
      source: 'Test',
    } as AdmissionMedicineSource440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(AdmissionMedicineSourceSchema.admissionMedicineSource440)

  public static snapshotSubtitle = 'Admission Medicine Source Model'

  public check = (object: AdmissionMedicineSourceLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'admissionMedicineSourceSchema', version)
  }

  public sanitize = (object: AdmissionMedicineSourceLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(
        AdmissionMedicineSourceSchema.versionedSchemas,
        'admissionMedicineSourceSchema',
        version
      )(object as PlainObject) as AdmissionMedicineSourceLatest
    })
  }
}
