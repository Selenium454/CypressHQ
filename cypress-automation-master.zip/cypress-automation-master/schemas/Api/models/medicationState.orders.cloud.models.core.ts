import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { PackingTypeValues, OrderStateValues } from '../types'

import { generateSanitizeFunction } from '../shared'

export interface MedicationState440 {
  description?: string | null
  packingType?: typeof PackingTypeValues[number] | null
  state?: typeof OrderStateValues[number] | null
}
export interface MedicationStateLatest extends MedicationState440 {}

export class MedicationStateSchema {
  latestVersion: string = '4.4.0'

  public static medicationState440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'medicationStateSchema',
      type: 'object',
      description: '',
      properties: {
        description: {
          type: ['string', 'null'],
          format: 'chartOrderPath',
          description: '',
          required: false,
        },
        packingType: {
          type: ['number', 'null'],
          description: '',
          // enum: (PackingTypeValues as unknown) as string[], //TODO: Work out why this is coming back as a number
          required: false,
        },
        state: {
          type: ['string', 'null'],
          description: '',
          enum: (OrderStateValues as unknown) as string[],
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({} as MedicationState440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(MedicationStateSchema.medicationState440)

  public static snapshotSubtitle = 'Medication State Model'

  public check = (object: MedicationStateLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'medicationStateSchema', version)
  }

  public sanitize = (object: MedicationStateLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(MedicationStateSchema.versionedSchemas, 'medicationStateSchema', version)(
        object as PlainObject
      ) as MedicationStateLatest
    })
  }
}
