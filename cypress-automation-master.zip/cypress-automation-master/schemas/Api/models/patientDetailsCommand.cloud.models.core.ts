import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { Address440, AddressSchema } from './address.cloud.models.core'
import {
  AustralianSouthSeaIslanderStatusValues,
  EthnicGroupValues,
  IndigenousStatusValues,
  MaritalStatusValues,
  SexValues,
} from '../types'
import {
  PatientDetailsPatientDetailsCommand440,
  PatientDetailsPatientDetailsCommandSchema,
} from './patientDetails.patientDetailsCommand.cloud.models.core'

import { generateSanitizeFunction } from '../shared'

const addressSchema = new AddressSchema()
const patientDetailsPatientDetailsCommand = new PatientDetailsPatientDetailsCommandSchema()

export interface PatientDetailsCommand440 {
  address?: Address440 | null
  australianSouthSeaIslanderStatus?: typeof AustralianSouthSeaIslanderStatusValues[number] | null
  countryOfBirth?: string | null
  dateOfBirth?: string | null
  dateOfDeceased?: string | null
  email?: string | null
  employmentStatus?: string | null
  ethnicGroup?: typeof EthnicGroupValues[number] | null
  firstName?: string | null
  indigenousStatus?: typeof IndigenousStatusValues[number] | null
  language?: string | null
  maritalStatus?: typeof MaritalStatusValues[number] | null
  middleName?: string | null
  mobileNumber?: string | null
  nationality?: string | null
  phoneNumber?: string | null
  photoUrl?: string | null
  sex?: typeof SexValues[number] | null
  surName?: string | null
  timeZoneId?: string | null
  title?: string | null
  userId?: string | null
  preferredName?: string | null
  patient?: PatientDetailsPatientDetailsCommand440 | null
}
export interface PatientDetailsCommandLatest extends PatientDetailsCommand440 {}

export class PatientDetailsCommandSchema {
  latestVersion: string = '4.4.0'

  public static patientDetailsCommand440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'patientDetailsCommandSchema',
      type: 'object',
      description: '',
      properties: {
        address: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...AddressSchema.address440.schema.properties,
          },
          see: AddressSchema.address440,
          required: false,
        },
        australianSouthSeaIslanderStatus: {
          type: ['string', 'null'],
          description: '',
          enum: (AustralianSouthSeaIslanderStatusValues as unknown) as string[],
          required: false,
        },
        countryOfBirth: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        dateOfBirth: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        dateOfDeceased: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        email: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        employmentStatus: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        ethnicGroup: {
          type: ['string', 'null'],
          description: '',
          enum: (EthnicGroupValues as unknown) as string[],
          required: false,
        },
        firstName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        indigenousStatus: {
          type: ['string', 'null'],
          description: '',
          enum: (IndigenousStatusValues as unknown) as string[],
          required: false,
        },
        language: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        maritalStatus: {
          type: ['string', 'null'],
          description: '',
          enum: (MaritalStatusValues as unknown) as string[],
          required: false,
        },
        middleName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        mobileNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        nationality: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        phoneNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        photoUrl: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        sex: {
          type: ['string', 'null'],
          description: '',
          enum: (SexValues as unknown) as string[],
          required: false,
        },
        surName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        timeZoneId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        title: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        userId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        preferredName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        patient: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...PatientDetailsPatientDetailsCommandSchema.patientDetailsPatientDetailsCommand440.schema.properties,
          },
          see: PatientDetailsPatientDetailsCommandSchema.patientDetailsPatientDetailsCommand440,
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({
      address: AddressSchema.address440.example as Address440,
      countryOfBirth: null,
      dateOfBirth: '1923-01-14T00:00:00',
      dateOfDeceased: null,
      email: 'Matilda_West@gmail.com',
      employmentStatus: null,
      firstName: 'Ellie',
      indigenousStatus: 'none',
      language: 'English',
      maritalStatus: 'widowed',
      middleName: null,
      mobileNumber: null,
      nationality: null,
      phoneNumber: '66282135',
      photoUrl: null,
      sex: 'female',
      surName: 'qaaanwoybdxwmij',
      timeZoneId: 'E. Australia Standard Time',
      title: 'Mr',
      userId: '0000542618',
      preferredName: null,
      patient: PatientDetailsPatientDetailsCommandSchema.patientDetailsPatientDetailsCommand440
        .example as PatientDetailsPatientDetailsCommand440,
    } as PatientDetailsCommand440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(PatientDetailsCommandSchema.patientDetailsCommand440)

  public static snapshotSubtitle = 'Patient Details Command Model'

  public check = (object: PatientDetailsCommandLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'patientDetailsCommandSchema', version)
  }

  public sanitize = (object: PatientDetailsCommandLatest, version: string = this.latestVersion) => {
    if (object.address) {
      addressSchema.sanitize(object.address).then(sanitizedAddress => {
        object.address = sanitizedAddress
      })
    }

    if (object.patient) {
      patientDetailsPatientDetailsCommand.sanitize(object.patient).then(sanitizedPatient => {
        object.patient = sanitizedPatient
      })
    }

    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(
        PatientDetailsCommandSchema.versionedSchemas,
        'patientDetailsCommandSchema',
        version
      )(object as PlainObject) as PatientDetailsCommandLatest
    })
  }
}
