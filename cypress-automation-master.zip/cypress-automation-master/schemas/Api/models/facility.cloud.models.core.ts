import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'

import { generateSanitizeFunction } from '../shared'
import { Address440, AddressSchema } from './address.cloud.models.core'
import { WeeklyTimeTable440, WeeklyTimeTableSchema } from './weeklyTimetable.cloud.models.core'
import { SystemIntegration440, SystemIntegrationSchema } from './systemIntegration.cloud.models.core'
import { Ward440, WardSchema } from './ward.cloud.models.core'
import {
  FacilityTypeValues,
  WardFrequencyValues,
  PreferredSyncSourceValues,
  UrnTypeValues,
  VisitSourceValues,
} from '../types/models.types'
import { PracticingDoctor440, PracticingDoctorSchema } from './practicingDoctor.cloud.models.core'

export interface Facility440 {
  address?: Address440 | null
  businessUnitId: string
  pharmacyName?: string | null
  code: string
  corporateCompany?: string | null
  courierTimes?: WeeklyTimeTable440 | null
  cutOffCourierTime?: string | null
  doctors?: PracticingDoctor440[] | null
  domain?: string | null
  emails?: string[] | null
  externalCode?: string | null
  facilityLogoUrl?: string | null
  facilityType?: typeof FacilityTypeValues[number] | null
  faxNumbers?: string[] | null
  faxOrdersEnabled?: boolean | null
  frequency?: typeof WardFrequencyValues[number] | null
  identifiers?: object | null
  integrations?: SystemIntegration440[] | null
  mainContactName?: string | null
  name: string
  phoneNumber?: string | null
  preferedSyncSource?: typeof PreferredSyncSourceValues[number] | null
  syncMedications?: boolean | null
  serviceTypes?: string[] | null
  typeOfUrn?: typeof UrnTypeValues[number] | null
  visitSource?: typeof VisitSourceValues[number] | null
  startDate?: string | null
  tenantId?: string | null
  timeZoneId?: string | null
  rounds?: Ward440[] | null
  documentType?: string | null
}
export interface FacilityLatest extends Facility440 {}

export class FacilitySchema {
  latestVersion: string = '4.4.0'

  public static facility440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'facilitySchema',
      type: 'object',
      description: 'Health fund model for use in patient services.',
      properties: {
        address: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...AddressSchema.address440.schema.properties,
          },
          see: AddressSchema.address440,
          required: false,
        },
        businessUnitId: {
          type: 'string',
          description: '',
          required: false,
        },
        pharmacyName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        code: {
          type: 'string',
          description: '',
          required: true,
        },
        corporateCompany: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        courierTimes: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...WeeklyTimeTableSchema.weeklyTimeTable440.schema.properties,
          },
          see: WeeklyTimeTableSchema.weeklyTimeTable440,
          required: false,
        },
        cutOffCourierTime: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        doctors: {
          type: ['array', 'null'],
          description: '',
          items: {
            type: ['object', 'null'],
            description: '',
            properties: {
              ...PracticingDoctorSchema.practicingDoctor440.schema.properties,
            },
            see: PracticingDoctorSchema.practicingDoctor440,
          },
          required: false,
        },
        domain: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        emails: {
          type: ['array', 'null'],
          description: '',
          items: {
            type: ['string', 'null'],
            description: '',
            required: false,
          },
          required: false,
        },
        externalCode: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        facilityLogoUrl: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        facilityType: {
          type: ['string', 'null'],
          description: '',
          enum: (FacilityTypeValues as unknown) as string[],
          required: false,
        },
        faxNumbers: {
          type: ['array', 'null'],
          description: '',
          items: {
            type: ['string', 'null'],
            description: '',
            required: false,
          },
          required: false,
        },
        faxOrdersEnabled: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        frequency: {
          type: ['string', 'null'],
          description: '',
          enum: (WardFrequencyValues as unknown) as string[],
          required: false,
        },
        identifiers: {
          type: ['object', 'null'],
          description: '',
          required: false,
        },
        integrations: {
          type: ['array', 'null'],
          description: '',
          items: {
            type: ['object', 'null'],
            description: '',
            properties: {
              ...SystemIntegrationSchema.systemIntegration440.schema.properties,
            },
            see: SystemIntegrationSchema.systemIntegration440,
          },
          required: false,
        },
        mainContactName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        name: {
          type: 'string',
          description: '',
          required: true,
        },
        phoneNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        preferedSyncSource: {
          type: ['string', 'null'],
          description: '',
          enum: (PreferredSyncSourceValues as unknown) as string[],
          required: false,
        },
        syncMedications: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        serviceTypes: {
          type: ['array', 'null'],
          description: '',
          items: {
            type: ['string', 'null'],
            description: '',
            required: false,
          },
          required: false,
        },
        typeOfUrn: {
          type: ['string', 'null'],
          description: '',
          enum: (UrnTypeValues as unknown) as string[],
          required: false,
        },
        visitSource: {
          type: ['string', 'null'],
          description: '',
          enum: (VisitSourceValues as unknown) as string[],
          required: false,
        },
        startDate: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        tenantId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        timeZoneId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        rounds: {
          type: ['array', 'null'],
          description: '',
          items: {
            type: ['object', 'null'],
            description: '',
            properties: {
              ...WardSchema.ward440.schema.properties,
            },
            see: WardSchema.ward440,
          },
          required: false,
        },
        documentType: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: (({} as Facility440) as unknown) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(FacilitySchema.facility440)

  public static snapshotSubtitle = 'Facility Model'

  public check = (object: FacilityLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'facilitySchema', version)
  }

  public sanitize = (object: FacilityLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(FacilitySchema.versionedSchemas, 'facilitySchema', version)(
        (object as unknown) as PlainObject
      ) as FacilityLatest
    })
  }
}
