import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { Address440, AddressSchema } from './address.cloud.models.core'
import { BillingDetailsCloud440, BillingDetailsCloudSchema } from './billingDetails.cloud.models.core'
import {
  AustralianSouthSeaIslanderStatusValues,
  EthnicGroupValues,
  IndigenousStatusValues,
  MaritalStatusValues,
  SexValues,
} from '../types'
import { Patient440, PatientSchema } from './patient.cloud.models.core'
import { generateSanitizeFunction } from '../shared'

const addressSchema = new AddressSchema()
const billingDetailsCloudSchema = new BillingDetailsCloudSchema()
const patientSchema = new PatientSchema()

export interface RegistrationModel440 {
  userId?: string | null
  address?: Address440 | null
  billingDetails?: BillingDetailsCloud440 | null
  australianSouthSeaIslanderStatus?: typeof AustralianSouthSeaIslanderStatusValues[number]
  countryOfBirth?: string | null
  dateOfBirth?: string | null
  dateOfDeceased?: string | null
  deliveryAddress?: Address440 | null
  email?: string | null
  employmentStatus?: string | null
  ethnicGroup?: typeof EthnicGroupValues[number]
  title?: string | null
  firstName: string
  surName: string
  middleName?: string | null
  preferredName?: string | null
  indigenousStatus?: typeof IndigenousStatusValues[number]
  language?: string | null
  maritalStatus?: typeof MaritalStatusValues[number]
  mobileNumber?: string | null
  phoneNumber?: string | null
  photoUrl?: string | null
  nationality?: string | null
  sex?: typeof SexValues[number]
  timeZoneId?: string | null
  patient: Patient440
}
export interface RegistrationModelLatest extends RegistrationModel440 {}

export class RegistrationModelSchema {
  latestVersion: string = '4.4.0'

  public static registrationModel440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'registrationModelSchema',
      type: 'object',
      description: 'Registration model for creating a new patient.',
      properties: {
        userId: {
          type: ['string', 'null'],
          format: 'userId',
          description: '',
          required: false,
        },
        address: {
          type: ['object', 'null'],
          properties: {
            ...AddressSchema.address440.schema.properties,
          },
          see: AddressSchema.address440,
          required: false,
        },
        billingDetails: {
          type: ['object', 'null'],
          properties: {
            ...BillingDetailsCloudSchema.billingDetailsCloud440.schema.properties,
          },
          see: BillingDetailsCloudSchema.billingDetailsCloud440,
          required: false,
        },
        australianSouthSeaIslanderStatus: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        countryOfBirth: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        dateOfBirth: {
          type: ['string', 'null'],
          format: 'dateTime',
          description: '',
          required: false,
        },
        dateOfDeceased: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        deliveryAddress: {
          type: ['object', 'null'],
          properties: {
            ...AddressSchema.address440.schema.properties,
          },
          see: AddressSchema.address440,
          required: false,
        },
        email: {
          type: ['string', 'null'],
          format: 'emailAddress',
          description: '',
          required: false,
        },
        employmentStatus: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        ethnicGroup: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        title: {
          type: ['string', 'null'],
          format: 'title',
          description: '',
          required: false,
        },
        firstName: {
          type: 'string',
          format: 'name',
          description: '',
          required: true,
        },
        surName: {
          type: 'string',
          format: 'name',
          description: '',
          required: true,
        },
        middleName: {
          type: ['string', 'null'],
          format: 'name',
          description: '',
          required: false,
        },
        preferredName: {
          type: ['string', 'null'],
          format: 'name',
          description: '',
          required: false,
        },
        indigenousStatus: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        language: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        maritalStatus: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        mobileNumber: {
          type: ['string', 'null'],
          format: 'mobilePhoneNumber',
          description: '',
          required: false,
        },
        phoneNumber: {
          type: ['string', 'null'],
          format: 'phoneNumber',
          description: '',
          required: false,
        },
        photoUrl: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        nationality: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        sex: {
          type: ['string', 'null'],
          format: 'patientSex',
          description: '',
          required: false,
        },
        timeZoneId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        patient: {
          type: 'object',
          properties: {
            ...PatientSchema.patient440.schema.properties,
          },
          see: PatientSchema.patient440,
          required: true,
        },
      },
      additionalProperties: false,
    },
    example: (({
      userId: '0000618610',
      address: AddressSchema.address440.example as Address440,
      billingDetails: BillingDetailsCloudSchema.billingDetailsCloud440.example as BillingDetailsCloud440,
      australianSouthSeaIslanderStatus: 'no',
      countryOfBirth: 'Australia',
      dateOfBirth: '1993-11-22T00:00:00',
      email: 'BobbyTest@testtest.com',
      employmentStatus: 'Other',
      ethnicGroup: 'acehnese',
      title: 'mr',
      firstName: 'Bob',
      surName: 'Ross',
      middleName: 'Paint',
      preferredName: 'Bobby',
      indigenousStatus: 'aboriginal',
      language: 'Aboriginal English, so described',
      maritalStatus: 'single',
      mobileNumber: '0400921765',
      phoneNumber: '66287634',
      nationality: 'Overseas not specified',
      sex: 'male',
      timeZoneId: 'E. Australia Standard Time',
      patient: PatientSchema.patient440.example as Patient440,
    } as RegistrationModel440) as unknown) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(RegistrationModelSchema.registrationModel440)

  public static snapshotSubtitle = 'Registration Model Model'

  public check = (object: RegistrationModelLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'registrationModelSchema', version)
  }

  public sanitize = (object: RegistrationModelLatest, version: string = this.latestVersion) => {
    if (object.address) {
      addressSchema.sanitize(object.address).then(sanitizedAddress => {
        object.address = sanitizedAddress
      })
    }

    if (object.billingDetails) {
      billingDetailsCloudSchema.sanitize(object.billingDetails).then(sanitizedBillingDetails => {
        object.billingDetails = sanitizedBillingDetails
      })
    }

    if (object.deliveryAddress) {
      addressSchema.sanitize(object.deliveryAddress).then(sanitizedDeliveryAddress => {
        object.deliveryAddress = sanitizedDeliveryAddress
      })
    }

    patientSchema.sanitize(object.patient).then(sanitizedPatient => {
      object.patient = sanitizedPatient
    })

    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(RegistrationModelSchema.versionedSchemas, 'registrationModelSchema', version)(
        (object as unknown) as PlainObject
      ) as RegistrationModelLatest
    })
  }
}
