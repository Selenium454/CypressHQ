import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'

import { generateSanitizeFunction } from '../shared'

export interface OrderStatistics440 {
  completed?: boolean | null
  completedByUser?: string | null
  dispatchedOnTime?: boolean | null
  handlingMinutes?: number | null
}
export interface OrderStatisticsLatest extends OrderStatistics440 {}

export class OrderStatisticsSchema {
  latestVersion: string = '4.4.0'

  public static orderStatistics440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'orderStatisticsSchema',
      type: 'object',
      description: '',
      properties: {
        completed: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        completedByUser: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        dispatchedOnTime: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        handlingMinutes: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({} as OrderStatistics440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(OrderStatisticsSchema.orderStatistics440)

  public static snapshotSubtitle = 'Order Statistics Model'

  public check = (object: OrderStatisticsLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'orderStatisticsSchema', version)
  }

  public sanitize = (object: OrderStatisticsLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(OrderStatisticsSchema.versionedSchemas, 'orderStatisticsSchema', version)(
        object as PlainObject
      ) as OrderStatisticsLatest
    })
  }
}
