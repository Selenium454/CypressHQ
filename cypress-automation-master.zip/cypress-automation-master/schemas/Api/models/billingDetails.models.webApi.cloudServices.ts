import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { Address440, AddressSchema } from './address.cloud.models.core'

import { generateSanitizeFunction } from '../shared'

const addressSchema = new AddressSchema()

export interface BillingDetailsModels440 {
  attachmentUrl?: string | null
  billingAddress?: Address440
  email?: string | null
  firstName?: string | null
  mobileNumber?: string | null
  phoneNumber?: string | null
  surName?: string | null
}
export interface BillingDetailsModelsLatest extends BillingDetailsModels440 {}

export class BillingDetailsModelsSchema {
  latestVersion: string = '4.4.0'

  public static billingDetailsModels440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'billingDetailsSchemaModel',
      type: 'object',
      description: "Billing contact's details.",
      properties: {
        attachmentUrl: {
          type: ['string', 'null'],
          description: 'URL to the attached Customer Authorisation Form.',
          required: false,
        },
        billingAddress: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...AddressSchema.address440.schema.properties,
          },
          see: AddressSchema.address440,
          required: false,
        },
        email: {
          type: ['string', 'null'],
          format: 'emailAddress',
          description: "Billing contact's current email address.",
          required: false,
        },
        firstName: {
          type: ['string', 'null'],
          description: "Billing contact's first name.",
          format: 'name',
          required: false,
        },
        mobileNumber: {
          type: ['string', 'null'],
          description: "Billing contact's current mobile number.",
          required: false,
        },
        phoneNumber: {
          type: ['string', 'null'],
          format: 'phoneNumber',
          description: "Billing contact's current phone number.",
          required: false,
        },
        surName: {
          type: ['string', 'null'],
          format: 'name',
          description: "Billing contact's surname.",
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({
      attachmentUrl:
        'BillingAuthorization/customer_billing_authorization_Layla_qaaayeofurvyvku_90129272_21-08-2019-12_17_3.pdf',
      billingAddress: AddressSchema.address440.example as Address440,
      email: 'paulsmithsemail@yahoo.com.au',
      firstName: 'PAUL',
      mobileNumber: '0400921634',
      phoneNumber: '66286745',
      surName: 'SMITH',
    } as BillingDetailsModels440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(BillingDetailsModelsSchema.billingDetailsModels440)

  public static snapshotSubtitle = 'Billing Details Model Model'

  public check = (object: BillingDetailsModelsLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'billingDetailsModelsSchema', version)
  }

  public sanitize = (object: BillingDetailsModelsLatest, version: string = this.latestVersion) => {
    if (object.billingAddress) {
      addressSchema.sanitize(object.billingAddress).then(sanitizedAddress => {
        object.billingAddress = sanitizedAddress
      })
    }

    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(
        BillingDetailsModelsSchema.versionedSchemas,
        'billingDetailsSchemaModel',
        version
      )(object as PlainObject) as BillingDetailsModelsLatest
    })
  }
}
