import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'

import { generateSanitizeFunction } from '../shared'

export interface ShopItem440 {
  price?: number | null
  quantity?: number | null
  orderId?: string | null
  unitCost?: number | null
  barcode?: string | null
  costPerPack?: number | null
  costPerUnit?: number | null
  doseaidSachets?: boolean | null
  firstLevelAlternaeCategory?: string | null
  form?: string | null
  formConversion?: string | null
  gCode?: string | null
  gstStatus?: string | null
  markupPrecentage?: number | null
  packSize?: string | null
  secondLevelAlternaeCategory?: string | null
  description?: string | null
  firstLevelCategory?: string | null
  generic?: string | null
  itemNumber?: string | null
  itemsInPack?: number | null
  manufacturer?: string | null
  onSelling?: string | null
  retailPrice?: number | null
  secondLevelCategory?: string | null
  strength?: string | null
}
export interface ShopItemLatest extends ShopItem440 {}

export class ShopItemSchema {
  latestVersion: string = '4.4.0'

  public static shopItem440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'shopItemSchema',
      type: 'object',
      description: '',
      properties: {
        price: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        quantity: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        orderId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        unitCost: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        barcode: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        costPerPack: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        costPerUnit: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        doseaidSachets: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        firstLevelAlternaeCategory: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        form: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        formConversion: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        gCode: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        gstStatus: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        markupPrecentage: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        packSize: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        secondLevelAlternaeCategory: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        description: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        firstLevelCategory: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        generic: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        itemNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        itemsInPack: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        manufacturer: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        onSelling: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        retailPrice: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        secondLevelCategory: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        strength: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({} as ShopItem440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(ShopItemSchema.shopItem440)

  public static snapshotSubtitle = 'Shop Item Model'

  public check = (object: ShopItemLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'shopItemSchema', version)
  }

  public sanitize = (object: ShopItemLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(ShopItemSchema.versionedSchemas, 'shopItemSchema', version)(
        object as PlainObject
      ) as ShopItemLatest
    })
  }
}
