import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { OrderSortValues, OrderSortByValues } from '../types/models.types'

import { generateSanitizeFunction } from '../shared'

export interface OrderFilter440 {
  sort?: typeof OrderSortValues[number] | null
  sortBy?: typeof OrderSortByValues[number] | null
  batchId?: string | null
  urn?: string | null
  patientId?: string | null
  orderById?: string | null
  businessUnitIds?: string[] | null
  facilityCodes?: string[] | null
  wardCodes?: string[] | null
  from?: string | null
  to?: string | null
  statuses?: string[] | null
  chartStatuses?: string[] | null
  types?: string[] | null
  take?: number | null
  pageNumber?: number | null
}
export interface OrderFilterLatest extends OrderFilter440 {}

export class OrderFilterSchema {
  latestVersion: string = '4.4.0'

  public static orderFilter440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'orderFilterSchema',
      type: 'object',
      description: '',
      properties: {
        sort: {
          type: ['string', 'null'],
          description: '',
          enum: (OrderSortValues as unknown) as string[],
          required: false,
        },
        sortBy: {
          type: ['string', 'null'],
          description: '',
          enum: (OrderSortByValues as unknown) as string[],
          required: false,
        },
        batchId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        urn: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        patientId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        orderById: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        businessUnitIds: {
          type: ['array', 'null'],
          description: '',
          items: {
            type: ['string', 'null'],
            description: '',
            required: false,
          },
          required: false,
        },
        facilityCodes: {
          type: ['array', 'null'],
          description: '',
          items: {
            type: ['string', 'null'],
            description: '',
            required: false,
          },
          required: false,
        },
        wardCodes: {
          type: ['array', 'null'],
          description: '',
          items: {
            type: ['string', 'null'],
            description: '',
            required: false,
          },
          required: false,
        },
        from: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        to: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        statuses: {
          type: ['array', 'null'],
          description: '',
          items: {
            type: ['string', 'null'],
            description: '',
            required: false,
          },
          required: false,
        },
        chartStatuses: {
          type: ['array', 'null'],
          description: '',
          items: {
            type: ['string', 'null'],
            description: '',
            required: false,
          },
          required: false,
        },
        types: {
          type: ['array', 'null'],
          description: '',
          items: {
            type: ['string', 'null'],
            description: '',
            required: false,
          },
          required: false,
        },
        take: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        pageNumber: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({} as OrderFilter440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(OrderFilterSchema.orderFilter440)

  public static snapshotSubtitle = 'Order Filter Model'

  public check = (object: OrderFilterLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'orderFilterSchema', version)
  }

  public sanitize = (object: OrderFilterLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(OrderFilterSchema.versionedSchemas, 'orderFilterSchema', version)(
        object as PlainObject
      ) as OrderFilterLatest
    })
  }
}
