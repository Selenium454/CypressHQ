import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { UserReference440, UserReferenceSchema } from './userReference.cloud.models.core'
import { RolesValues } from '../types'

import { generateSanitizeFunction } from '../shared'

const userReferenceSchema = new UserReferenceSchema()

export interface ReconcileStatusHistory440 {
  date?: string | null
  status?: string | null
  userReference?: UserReference440 | null
  userRole?: typeof RolesValues[number] | null
}
export interface ReconcileStatusHistoryLatest extends ReconcileStatusHistory440 {}

export class ReconcileStatusHistorySchema {
  latestVersion: string = '4.4.0'

  public static reconcileStatusHistory440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'reconcileStatusHistorySchema',
      type: 'object',
      description: '',
      properties: {
        date: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        status: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        userReference: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...UserReferenceSchema.userReference440.schema.properties,
          },
          see: UserReferenceSchema.userReference440,
          required: false,
        },
        userRole: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({
      date: '2019-08-22T00:00:00',
      status: 'admitted',
      userReference: UserReferenceSchema.userReference440.example,
      userRole: 'patient',
    } as ReconcileStatusHistory440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(ReconcileStatusHistorySchema.reconcileStatusHistory440)

  public static snapshotSubtitle = 'Reconcile Status History Model'

  public check = (object: ReconcileStatusHistoryLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'reconcileStatusHistorySchema', version)
  }

  public sanitize = (object: ReconcileStatusHistoryLatest, version: string = this.latestVersion) => {
    if (object.userReference) {
      userReferenceSchema.sanitize(object.userReference).then(sanitizedUserReference => {
        object.userReference = sanitizedUserReference
      })
    }

    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(
        ReconcileStatusHistorySchema.versionedSchemas,
        'reconcileStatusHistorySchema',
        version
      )(object as PlainObject) as ReconcileStatusHistoryLatest
    })
  }
}
