import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'

import { generateSanitizeFunction } from '../shared'

export interface MedicationNotes440 {
  additionalNotes?: string | null
  otherSideEffects?: string | null
  seriousSideEffects?: string | null
  usedFor?: string | null
}
export interface MedicationNotesLatest extends MedicationNotes440 {}

export class MedicationNotesSchema {
  latestVersion: string = '4.4.0'

  public static medicationNotes440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'medicationNotesSchema',
      type: 'object',
      description: '',
      properties: {
        additionalNotes: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        otherSideEffects: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        seriousSideEffects: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        usedFor: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({
      additionalNotes: 'Additional Notes',
      otherSideEffects: 'Side effects',
      seriousSideEffects: 'Serious side effect',
      usedFor: 'Used for',
    } as MedicationNotes440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(MedicationNotesSchema.medicationNotes440)

  public static snapshotSubtitle = 'Medication Notes Model'

  public check = (object: MedicationNotesLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'medicationNotesSchema', version)
  }

  public sanitize = (object: MedicationNotesLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(MedicationNotesSchema.versionedSchemas, 'medicationNotesSchema', version)(
        object as PlainObject
      ) as MedicationNotesLatest
    })
  }
}
