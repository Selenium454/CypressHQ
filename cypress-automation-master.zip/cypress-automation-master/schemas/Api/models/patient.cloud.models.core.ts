import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { ConcessionEntitledValues, NonActiveReasonValues, RepatCardTypeValues } from '../types'
import { Contact440, ContactSchema } from './contact.cloud.models.core'
import { Intervention440, InterventionSchema } from './intervention.cloud.models.core'
import { MedicalService440, MedicalServiceSchema } from './medicalService.cloud.models.core'

import { generateSanitizeFunction } from '../shared'

export interface Patient440 {
  activeInHub?: boolean
  additionalPharmacistNotes?: string | null
  allergies?: string | null
  concessionEntitled?: typeof ConcessionEntitledValues[number]
  concessionNumber?: string | null
  concessionType?: string | null
  concessionValidToDate?: string | null
  contacts?: Contact440[]
  ctg?: boolean
  interventions?: Intervention440[]
  medicareFirstName?: string | null
  medicareNumber?: string | null
  medicareSurName?: string | null
  medicareValidDate?: string | null
  medicationInstructions?: string | null
  nonActiveReason?: typeof NonActiveReasonValues[number]
  ppns?: string[]
  repatCardType?: typeof RepatCardTypeValues[number]
  repatNumber?: string | null
  safetyNetNumber?: string | null
  services?: MedicalService440[]
}
export interface PatientLatest extends Patient440 {}

export class PatientSchema {
  latestVersion: string = '4.4.0'

  public static patient440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'patientSchema',
      type: 'object',
      description: '',
      properties: {
        activeInHub: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        additionalPharmacistNotes: {
          type: ['string', 'null'],
          format: 'postCode',
          description: '',
          required: false,
        },
        allergies: {
          type: ['string', 'null'],
          format: 'street',
          description: '',
          required: false,
        },
        concessionEntitled: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        concessionNumber: {
          type: ['string', 'null'],
          format: 'concessionNumber',
          description: '',
          required: false,
        },
        concessionType: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        concessionValidToDate: {
          type: ['string', 'null'],
          format: 'dateTime',
          description: '',
          required: false,
        },
        contacts: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...ContactSchema.contact440.schema.properties,
          },
          see: ContactSchema.contact440,
          required: false,
        },
        ctg: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        interventions: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...InterventionSchema.intervention440.schema.properties,
          },
          see: InterventionSchema.intervention440,
          required: false,
        },
        medicareFirstName: {
          type: ['string', 'null'],
          format: 'name',
          description: '',
          required: false,
        },
        medicareNumber: {
          type: ['string', 'null'],
          format: 'medicareNumber',
          description: '',
          required: false,
        },
        medicareSurName: {
          type: ['string', 'null'],
          format: 'name',
          description: '',
          required: false,
        },
        medicareValidDate: {
          type: ['string', 'null'],
          format: 'dateTime',
          description: '',
          required: false,
        },
        medicationInstructions: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        nonActiveReason: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        ppns: {
          type: 'array',
          description: '',
          items: {
            type: 'string',
            description: '',
          },
          required: false,
        },
        repatCardType: {
          type: ['string', 'null'],
          format: 'repatCardType',
          description: '',
          required: false,
        },
        repatNumber: {
          type: ['string', 'null'],
          format: 'repatNumber',
          description: '',
          required: false,
        },
        safetyNetNumber: {
          type: ['string', 'null'],
          format: 'safetyNetNumber',
          description: '',
          required: false,
        },
        services: {
          type: ['array', 'null'],
          description: '',
          items: {
            ...MedicalServiceSchema.medicalService440.schema,
          },
          see: MedicalServiceSchema.medicalService440,
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({
      activeInHub: true,
      medicationInstructions: 'These are some customer notes',
      allergies: 'Shellfish',
      concessionNumber: 'CN912345678',
      concessionType: 'S',
      concessionValidToDate: '2020-11-22T00:00:00',
      ctg: true,
      medicareFirstName: 'Bob',
      medicareNumber: '00000000000',
      medicareSurName: 'Ross',
      medicareValidDate: 'Invalid date',
      repatCardType: 'gold',
      repatNumber: 'QSM1',
      safetyNetNumber: 'SN912345678',
      services: [(MedicalServiceSchema.medicalService440.example as unknown) as MedicalService440],
    } as Patient440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(PatientSchema.patient440)

  public static snapshotSubtitle = 'Patient Model'

  public check = (object: PatientLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'patientSchema', version)
  }

  public sanitize = (object: PatientLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(PatientSchema.versionedSchemas, 'patientSchema', version)(
        object as PlainObject
      ) as PatientLatest
    })
  }
}
