import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { DeliveryTypeValues } from '../types'

import { generateSanitizeFunction } from '../shared'

export interface DeliveryOptions440 {
  deliveryInstructions?: string | null
  deliveryType?: typeof DeliveryTypeValues[number] | null
}
export interface DeliveryOptionsLatest extends DeliveryOptions440 {}

export class DeliveryOptionsSchema {
  latestVersion: string = '4.4.0'

  public static deliveryOptions440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'deliveryOptionsSchema',
      type: 'object',
      description: '',
      properties: {
        deliveryInstructions: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        deliveryType: {
          type: ['string', 'null'],
          description: '',
          enum: (DeliveryTypeValues as unknown) as string[],
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({} as DeliveryOptions440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(DeliveryOptionsSchema.deliveryOptions440)

  public static snapshotSubtitle = 'Delivery Options Model'

  public check = (object: DeliveryOptionsLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'deliveryOptionsSchema', version)
  }

  public sanitize = (object: DeliveryOptionsLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(DeliveryOptionsSchema.versionedSchemas, 'deliveryOptionsSchema', version)(
        object as PlainObject
      ) as DeliveryOptionsLatest
    })
  }
}
