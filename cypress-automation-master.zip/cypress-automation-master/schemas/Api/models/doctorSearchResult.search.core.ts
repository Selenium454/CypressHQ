import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'

import { generateSanitizeFunction } from '../shared'
import { PracticeSearchResult440, PracticeSearchResultSchema } from './practiceSearchResults.search.core'

export interface DoctorSearchResult440 {
  userId?: string | null
  firstName?: string | null
  surname?: string | null
  fullName?: string | null
  prescriberNumber?: string | null
  specializations?: string[] | null
  practices?: PracticeSearchResult440[] | null
}
export interface DoctorSearchResultLatest extends DoctorSearchResult440 {}

export class DoctorSearchResultSchema {
  latestVersion: string = '4.4.0'

  public static doctorSearchResult440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'doctorSearchResultSchema',
      type: 'object',
      description: '',
      properties: {
        userId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        firstName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        surname: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        fullName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        prescriberNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        specializations: {
          type: ['array', 'null'],
          description: '',
          items: {
            type: ['string', 'null'],
            description: '',
            required: false,
          },
          required: false,
        },
        practices: {
          type: ['array', 'null'],
          description: '',
          items: {
            type: ['object', 'null'],
            description: '',
            properties: {
              ...PracticeSearchResultSchema.practiceSearchResult440.schema.properties,
            },
            see: PracticeSearchResultSchema.practiceSearchResult440,
          },
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: (({} as DoctorSearchResult440) as unknown) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(DoctorSearchResultSchema.doctorSearchResult440)

  public static snapshotSubtitle = 'Doctor Search Results Model'

  public check = (object: DoctorSearchResultLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'practiceSearchResultSchema', version)
  }

  public sanitize = (object: DoctorSearchResultLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(DoctorSearchResultSchema.versionedSchemas, 'practiceSearchResultSchema', version)(
        object as PlainObject
      ) as DoctorSearchResultLatest
    })
  }
}
