import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { AdmissionStatusValues } from '../types'

import { generateSanitizeFunction } from '../shared'

export interface AdmissionDetails440 {
  admissionDate?: string | null
  admissionNumber?: string | null
  allergies?: string | null
  bedNumber?: string | null
  dischargeDate?: string | null
  facilityCode?: string | null
  facilityName?: string | null
  roomNumber?: string | null
  status?: typeof AdmissionStatusValues[number] | null
  urn?: string | null
  wardCode?: string | null
  wardName?: string | null
}
export interface AdmissionDetailsLatest extends AdmissionDetails440 {}

export class AdmissionDetailsSchema {
  latestVersion: string = '4.4.0'

  public static admissionDetails440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'admissionDetailsSchema',
      type: 'object',
      description: '',
      properties: {
        admissionDate: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        admissionNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        allergies: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        bedNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        dischargeDate: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        facilityCode: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        facilityName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        roomNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        status: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        name: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        wardCode: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        wardName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({
      admissionDate: '2018-12-19T10:34:42',
      admissionNumber: '62042921',
      allergies: '',
      bedNumber: '7',
      facilityCode: 'SJGM',
      facilityName: 'St John Of God Hospital Murdoch',
      roomNumber: '42',
      status: 'admitted',
      urn: '90137349',
      wardCode: 'CATH',
      wardName: 'St Catherine',
    } as AdmissionDetails440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(AdmissionDetailsSchema.admissionDetails440)

  public static snapshotSubtitle = 'Admission Details Model'

  public check = (object: AdmissionDetailsLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'admissionDetailsSchema', version)
  }

  public sanitize = (object: AdmissionDetailsLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(AdmissionDetailsSchema.versionedSchemas, 'admissionDetailsSchema', version)(
        object as PlainObject
      ) as AdmissionDetailsLatest
    })
  }
}
