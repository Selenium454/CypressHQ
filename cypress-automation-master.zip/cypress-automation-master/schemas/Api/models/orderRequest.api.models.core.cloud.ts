import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { DeliveryOptions440, DeliveryOptionsSchema } from './deliveryOptions.orders.cloud.models.core'
import { OrderTypeValues, ScriptTypeValues, ChartSourceValues, ChartStatusValues } from '../types/models.types'
import { ScriptItem440, ScriptItemSchema } from './scriptItem.orders.cloud.models.core'
import { ShopItem440, ShopItemSchema } from './shopItem.orders.cloud.models.core'
import { ChartItem440, ChartItemSchema } from './chartItem.orders.cloud.models.core'

import { generateSanitizeFunction } from '../shared'
import { OrderLatest } from './order.orders.cloud.models.core'

const deliveryOptionsSchema = new DeliveryOptionsSchema()
const chartItemSchema = new ChartItemSchema()

export interface OrderRequest440 {
  orderFor?: string | null
  orderType: typeof OrderTypeValues[number]
  deliveryOptions: DeliveryOptions440
  alias?: string | null
  tags?: string | null
  urn?: string | null
  scriptItems?: ScriptItem440[] | null
  scriptType?: typeof ScriptTypeValues[number] | null
  imageName?: string | null
  scriptDate?: string | null
  shopItems?: ShopItem440[] | null
  chartSource?: typeof ChartSourceValues[number] | null
  chartItems?: ChartItem440[] | null
  dailyChartOrderId?: string | null
  dueTime?: string | null
  scriptLinking?: boolean | null
  comment?: string | null
  chartStatus?: typeof ChartStatusValues[number] | null
}
export interface OrderRequestLatest extends OrderRequest440 {}

export class OrderRequestSchema {
  latestVersion: string = '4.4.0'

  public static orderRequest440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'orderRequestSchema',
      type: 'object',
      description: '',
      properties: {
        orderFor: {
          type: ['string', 'null'],
          format: 'userId',
          description: '',
          required: false,
        },
        orderType: {
          type: ['string', 'null'],
          description: '',
          enum: (OrderTypeValues as unknown) as string[],
          required: false,
        },
        deliveryOptions: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...DeliveryOptionsSchema.deliveryOptions440.schema.properties,
          },
          see: DeliveryOptionsSchema.deliveryOptions440,
          required: false,
        },
        alias: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        tags: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        urn: {
          type: ['string', 'null'],
          format: 'urNumber',
          description: '',
          required: false,
        },
        scriptItems: {
          type: ['array', 'null'],
          description: '',
          items: {
            ...ScriptItemSchema.scriptItem440.schema,
          },
          see: ScriptItemSchema.scriptItem440,
          required: false,
        },
        scriptType: {
          type: ['string', 'null'],
          description: '',
          enum: (ScriptTypeValues as unknown) as string[],
          required: false,
        },
        imageName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        scriptDate: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        shopItems: {
          type: ['array', 'null'],
          description: '',
          items: {
            ...ShopItemSchema.shopItem440.schema,
          },
          see: ShopItemSchema.shopItem440,
        },
        chartSource: {
          type: ['string', 'null'],
          description: '',
          enum: (ChartSourceValues as unknown) as string[],
          required: false,
        },
        chartItems: {
          type: ['array', 'null'],
          description: '',
          items: {
            ...ChartItemSchema.chartItem440.schema,
          },
          see: ChartItemSchema.chartItem440,
        },
        dailyChartOrderId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        dueTime: {
          type: ['string', 'null'],
          format: 'dateTimeWithTimezone',
          description: '',
          required: false,
        },
        scriptLinking: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        comment: {
          type: ['string', 'null'],
          format: 'chartJobComment',
          description: '',
          required: false,
        },
        chartStatus: {
          type: ['string', 'null'],
          description: '',
          enum: (ChartStatusValues as unknown) as string[],
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: (({
      orderType: 'script',
      deliveryOptions: DeliveryOptionsSchema.deliveryOptions440.example as DeliveryOptions440,
    } as OrderRequest440) as unknown) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(OrderRequestSchema.orderRequest440)

  public static snapshotSubtitle = 'Order Request Model'

  public check = (object: OrderRequestLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'orderRequestSchema', version)
  }

  public sanitize = (object: OrderRequestLatest, version: string = this.latestVersion) => {
    if (object.deliveryOptions) {
      deliveryOptionsSchema.sanitize(object.deliveryOptions).then(sanitizedDeliveryOptions => {
        object.deliveryOptions = sanitizedDeliveryOptions
      })
    }

    if (object.chartItems) {
      object.chartItems.forEach((chartItem: OrderLatest, index: number) => {
        chartItemSchema.sanitize(chartItem).then(sanitizedChartItem => {
          object.chartItems![index] = sanitizedChartItem
        })
      })
    }

    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(OrderRequestSchema.versionedSchemas, 'orderRequestSchema', version)(
        (object as unknown) as PlainObject
      ) as OrderRequestLatest
    })
  }
}
