import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import {
  DischargeMedicationProfile440,
  DischargeMedicationProfileSchema,
} from './dischargeMedicationProfile.cloud.models.core'
import { SigCodes440, SigCodesSchema } from './sigCodes.cloud.models.core'
import { DoseDaysValues, FrequencyValues, PackingTypeValues, ProfileTypeValues, MedicationStatusValues } from '../types'
import { MedicationNotes440, MedicationNotesSchema } from './medicationNotes.cloud.models.core'

import { generateSanitizeFunction } from '../shared'

const dischargeMedicationProfileSchema = new DischargeMedicationProfileSchema()
const medicationNotesSchema = new MedicationNotesSchema()
const sigCodesSchema = new SigCodesSchema()

export interface MedicationProfile440 {
  additionalInformation?: string | null
  admissionNumber?: string | null
  alternateName?: string | null
  doseDays?: typeof DoseDaysValues[number] | null
  drugCode?: string | null
  drugForm?: string | null
  drugName?: string | null
  drugPackSize?: number | null
  drugStrength?: string | null
  endDate: string
  facilityCode?: string | null
  frequency?: typeof FrequencyValues[number] | null
  lastAdherence?: string | null
  lastRepeat?: boolean | null
  medicationDescription?: string | null
  medicationInstructions?: string | null
  translatedDirections?: string | null
  otherRouteOfAdministration?: string | null
  packingReferenceNumber?: number | null
  packingType?: typeof PackingTypeValues[number] | null
  patientBalance?: number | null
  profileId?: string | null
  profileType?: typeof ProfileTypeValues[number] | null
  routeOfAdministration?: string | null
  s8?: string | null
  scriptNumber?: number | null
  sigCodes?: SigCodes440 | null
  sigCodesString?: string | null
  siteId: number
  startDate?: string | null
  timeslot1Dose?: number | null
  timeslot2Dose?: number | null
  timeslot3Dose?: number | null
  timeslot4Dose?: number | null
  timeslot5Dose?: number | null
  timeslot6Dose?: number | null
  timeslot7Dose?: number | null
  timeslot8Dose?: number | null
  updateDate?: string | null
  urNumber?: string | null
  userId: string
  alias?: string | null
  dischargeProfile?: DischargeMedicationProfile440 | null
  dischargeStatus?: string | null
  dose?: number | null
  indication?: string | null
  medicationSource?: string | null
  notes?: MedicationNotes440 | null
  reconcile?: boolean | null
  status?: typeof MedicationStatusValues[number] | null
  statusComments?: string | null
  supplyAtHome?: boolean | null
  documentType?: string | null
}
export interface MedicationProfileLatest extends MedicationProfile440 {}

export class MedicationProfileSchema {
  latestVersion: string = '4.4.0'

  public static medicationProfile440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'medicationProfileSchema',
      type: 'object',
      description: '',
      properties: {
        additionalInformation: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        admissionNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        alternateName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        doseDays: {
          type: ['string', 'null'],
          description: '',
          enum: (DoseDaysValues as unknown) as string[],
          required: false,
        },
        drugCode: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        drugForm: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        drugName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        drugPackSize: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        drugStrength: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        endDate: {
          type: 'string',
          description: '',
          required: true,
        },
        facilityCode: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        frequency: {
          type: ['string', 'null'],
          description: '',
          enum: (FrequencyValues as unknown) as string[],
          required: false,
        },
        lastAdherence: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        lastRepeat: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        medicationDescription: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        medicationInstructions: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        translatedDirections: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        otherRouteOfAdministration: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        packingReferenceNumber: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        packingType: {
          type: ['string', 'null'],
          description: '',
          enum: (PackingTypeValues as unknown) as string[],
          required: false,
        },
        patientBalance: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        profileId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        profileType: {
          type: ['number', 'null'],
          description: '',
          enum: (ProfileTypeValues as unknown) as string[],
          required: false,
        },
        routeOfAdministration: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        s8: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        scriptNumber: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        sigCodes: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...SigCodesSchema.sigCodes440.schema.properties,
          },
          see: SigCodesSchema.sigCodes440,
          required: false,
        },
        sigCodesString: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        siteId: {
          type: 'number',
          description: '',
          required: true,
        },
        startDate: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        timeslot1Dose: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        timeslot2Dose: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        timeslot3Dose: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        timeslot4Dose: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        timeslot5Dose: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        timeslot6Dose: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        timeslot7Dose: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        timeslot8Dose: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        updateDate: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        urNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        userId: {
          type: 'string',
          description: '',
          required: true,
        },
        alias: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        dischargeProfile: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...DischargeMedicationProfileSchema.dischargeMedicationProfile440.schema.properties,
          },
          see: DischargeMedicationProfileSchema.dischargeMedicationProfile440,
          required: false,
        },
        dischargeStatus: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        dose: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        indication: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        medicationSource: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        notes: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...MedicationNotesSchema.medicationNotes440.schema.properties,
          },
          see: MedicationNotesSchema.medicationNotes440,
          required: false,
        },
        reconcile: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        status: {
          type: ['string', 'null'],
          description: '',
          enum: (MedicationStatusValues as unknown) as string[],
          required: false,
        },
        statusComments: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        supplyAtHome: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        documentType: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: (({
      endDate: '2020-06-01',
      siteId: 44,
      userId: '123456',
    } as MedicationProfile440) as unknown) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(MedicationProfileSchema.medicationProfile440)

  public static snapshotSubtitle = 'Medication Profile Model'

  public check = (object: MedicationProfileLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'medicationProfileSchema', version)
  }

  public sanitize = (object: MedicationProfileLatest, version: string = this.latestVersion) => {
    if (object.sigCodes) {
      sigCodesSchema.sanitize(object.sigCodes).then(sanitizedSigCodes => {
        object.sigCodes = sanitizedSigCodes
      })
    }

    if (object.dischargeProfile) {
      dischargeMedicationProfileSchema.sanitize(object.dischargeProfile).then(sanitizedDischargeProfile => {
        object.dischargeProfile = sanitizedDischargeProfile
      })
    }

    if (object.notes) {
      medicationNotesSchema.sanitize(object.notes).then(sanitizedNotes => {
        object.notes = sanitizedNotes
      })
    }

    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(MedicationProfileSchema.versionedSchemas, 'medicationProfileSchema', version)(
        (object as unknown) as PlainObject
      ) as MedicationProfileLatest
    })
  }
}
