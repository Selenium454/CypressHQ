export * from './address.cloud.models.core'
export * from './admission.cloud.models.core'
export * from './admissionAdministration.cloud.models.core'
export * from './admissionDetails.cloud.models.core'
export * from './admissionGeneralInformation.cloud.models.core'
export * from './admissionHistoryChecklist.cloud.models.core'
export * from './admissionMedicineSource.cloud.models.core'
export * from './admissionRiskIdentification.cloud.models.core'
export * from './allergy.cloud.models.core'
export * from './audit.audit.models.core'
export * from './bankAccount.cloud.models.core'
export * from './billingDetails.cloud.models.core'
export * from './billingDetails.models.webApi.cloudServices'
export * from './chartItem.orders.cloud.models.core'
export * from './contact.cloud.models.core'
export * from './corporate.pharmacy.cloud.models.core'
export * from './creditCard.cloud.models.core'
export * from './deliveryOptions.orders.cloud.models.core'
export * from './directDebitCard.cloud.models.core'
export * from './dischargeMedicationProfile.cloud.models.core'
export * from './doctor.cloud.models.core'
export * from './doctorReference.cloud.models.core'
export * from './doctorReferenceApi.cloud.models.core'
export * from './entity.cloud.models.core'
export * from './entityDeleteResult.removers.core'
export * from './extendedFacilityReference.cloud.models.core'
export * from './externalDoctor.cloud.models.core'
export * from './externalIdentifier.cloud.models.core'
export * from './healthFund.cloud.models.core'
export * from './internalEmployee.pharmacy.models.core'
export * from './intervention.cloud.models.core'
export * from './interventionApi.api.models.core.cloud'
export * from './interventionListItem.api.models.core.cloud'
export * from './iResultPage.paging.models.core'
export * from './lock.models.core'
export * from './medicalService.cloud.models.core'
export * from './medicalServiceResponse.cloud.models.core'
export * from './medicationNotes.cloud.models.core'
export * from './medicationProfile.cloud.models.core'
export * from './notation.orders.cloud.models.core'
export * from './nurse.cloud.models.core'
export * from './order.orders.cloud.models.core'
export * from './orderLinkedScript.orders.cloud.models.core'
export * from './orderStatistics.orders.cloud.models.core'
export * from './orderMetadata.orders.cloud.models.core'
export * from './orderRequest.api.models.core.cloud'
export * from './ordersRequest.api.models.core.cloud'
export * from './orderStatistics.orders.cloud.models.core'
export * from './patient.cloud.models.core'
export * from './patientDetails.cloud.models.core'
export * from './patientDetails.patientDetailsCommand.cloud.models.core'
export * from './patientDetailsCommand.cloud.models.core'
export * from './patientInnerDetails.patientDetails.cloud.models.core'
export * from './patientOrderMetadata.orders.cloud.models.core'
export * from './paymentDetails.cloud.models.core'
export * from './pharmacyOrderProcess.orders.cloud.models.core'
export * from './pharmacyOrderStatus.orders.cloud.models.core'
export * from './practice.cloud.models.core'
export * from './reconcile.cloud.models.core'
export * from './reconcileStatusHistory.cloud.models.core'
export * from './referral.cloud.models.core'
export * from './registrationModel.models.webApi.cloudServices'
export * from './roleReference.cloud.models.core'
export * from './scriptItem.orders.cloud.models.core'
export * from './searchPatientFilter.search.core'
export * from './searchPatientResults.cloud.models.core'
export * from './shopItem.orders.cloud.models.core'
export * from './sigCodes.cloud.models.core'
export * from './successResponse.modelResponseAttribute.filters.web.core.cloud'
export * from './supportingInformationDetails.schema'
export * from './timeSlots.cloud.models.core'
export * from './treatment.cloud.models.core'
export * from './userReference.cloud.models.core'
export * from './visit.visits.cloud.models.core'
export * from './visitAppointment.visits.cloud.models.core'
export * from './visitBilling.visits.cloud.models.core'
export * from './visitDoctorReference.cloud.models.core'

import { SchemaCollection, combineSchemas } from '@cypress/schema-tools/src'
import { AddressSchema } from './address.cloud.models.core'
import { AdmissionSchema } from './admission.cloud.models.core'
import { AdmissionAdministrationSchema } from './admissionAdministration.cloud.models.core'
import { AdmissionDetailsSchema } from './admissionDetails.cloud.models.core'
import { AdmissionGeneralInformationSchema } from './admissionGeneralInformation.cloud.models.core'
import { AdmissionHistoryChecklistSchema } from './admissionHistoryChecklist.cloud.models.core'
import { AdmissionMedicineSourceSchema } from './admissionMedicineSource.cloud.models.core'
import { AdmissionRiskIdentificationSchema } from './admissionRiskIdentification.cloud.models.core'
import { AllergySchema } from './allergy.cloud.models.core'
import { AuditSchema } from './audit.audit.models.core'
import { BankAccountSchema } from './bankAccount.cloud.models.core'
import { BillingDetailsCloudSchema } from './billingDetails.cloud.models.core'
import { BillingDetailsModelsSchema } from './billingDetails.models.webApi.cloudServices'
import { ChartItemSchema } from './chartItem.orders.cloud.models.core'
import { ContactSchema } from './contact.cloud.models.core'
import { CorporateSchema } from './corporate.pharmacy.cloud.models.core'
import { CreditCardSchema } from './creditCard.cloud.models.core'
import { DeliveryOptionsSchema } from './deliveryOptions.orders.cloud.models.core'
import { DirectDebitCardSchema } from './directDebitCard.cloud.models.core'
import { DischargeMedicationProfileSchema } from './dischargeMedicationProfile.cloud.models.core'
import { DoctorSchema } from './doctor.cloud.models.core'
import { DoctorReferenceSchema } from './doctorReference.cloud.models.core'
import { DoctorReferenceApiSchema } from './doctorReferenceApi.cloud.models.core'
import { EntitySchema } from './entity.cloud.models.core'
import { EntityDeleteResultSchema } from './entityDeleteResult.removers.core'
import { ExtendedFacilityReferenceSchema } from './extendedFacilityReference.cloud.models.core'
import { ExternalDoctorSchema } from './externalDoctor.cloud.models.core'
import { ExternalIdentifierSchema } from './externalIdentifier.cloud.models.core'
import { HealthFundSchema } from './healthFund.cloud.models.core'
import { InternalEmployeeSchema } from './internalEmployee.pharmacy.models.core'
import { InterventionSchema } from './intervention.cloud.models.core'
import { InterventionApiSchema } from './interventionApi.api.models.core.cloud'
import { InterventionListItemSchema } from './interventionListItem.api.models.core.cloud'
import { IResultPageSchema } from './iResultPage.paging.models.core'
import { LockSchema } from './lock.models.core'
import { MedicalServiceSchema } from './medicalService.cloud.models.core'
import { MedicalServiceResponseSchema } from './medicalServiceResponse.cloud.models.core'
import { MedicationNotesSchema } from './medicationNotes.cloud.models.core'
import { MedicationProfileSchema } from './medicationProfile.cloud.models.core'
import { NotationSchema } from './notation.orders.cloud.models.core'
import { NurseSchema } from './nurse.cloud.models.core'
import { OrderSchema } from './order.orders.cloud.models.core'
import { OrderLinkedScriptSchema } from './orderLinkedScript.orders.cloud.models.core'
import { OrderStatisticsSchema } from './orderStatistics.orders.cloud.models.core'
import { PatientSchema } from './patient.cloud.models.core'
import { PatientDetailsCommandSchema } from './patientDetailsCommand.cloud.models.core'
import { PatientDetailsCloudSchema } from './patientDetails.cloud.models.core'
import { PatientInnerDetailsSchema } from './patientInnerDetails.patientDetails.cloud.models.core'
import { PaymentDetailsSchema } from './paymentDetails.cloud.models.core'
import { PharmacyOrderProcessSchema } from './pharmacyOrderProcess.orders.cloud.models.core'
import { PharmacyOrderStatusSchema } from './pharmacyOrderStatus.orders.cloud.models.core'
import { PracticeSchema } from './practice.cloud.models.core'
import { ReconcileSchema } from './reconcile.cloud.models.core'
import { ReconcileStatusHistorySchema } from './reconcileStatusHistory.cloud.models.core'
import { ReferralSchema } from './referral.cloud.models.core'
import { RegistrationModelSchema } from './registrationModel.models.webApi.cloudServices'
import { RoleReferenceSchema } from './roleReference.cloud.models.core'
import { ScriptItemSchema } from './scriptItem.orders.cloud.models.core'
import { SearchPatientFilterSchema } from './searchPatientFilter.search.core'
import { SearchPatientResultsSchema } from './searchPatientResults.cloud.models.core'
import { ShopItemSchema } from './shopItem.orders.cloud.models.core'
import { SigCodesSchema } from './sigCodes.cloud.models.core'
import { SuccessResponseSchema } from './successResponse.modelResponseAttribute.filters.web.core.cloud'
import { SupportingInformationDetailsSchema } from './supportingInformationDetails.schema'
import { TimeSlotsSchema } from './timeSlots.cloud.models.core'
import { TreatmentSchema } from './treatment.cloud.models.core'
import { UserReferenceSchema } from './userReference.cloud.models.core'
import { VisitSchema } from './visit.visits.cloud.models.core'
import { VisitAppointmentSchema } from './visitAppointment.visits.cloud.models.core'
import { VisitBillingSchema } from './visitBilling.visits.cloud.models.core'
import { VisitDoctorReferenceSchema } from './visitDoctorReference.cloud.models.core'

export const modelSchemas: SchemaCollection = combineSchemas(
  AddressSchema.versionedSchemas,
  AdmissionSchema.versionedSchemas,
  AdmissionAdministrationSchema.versionedSchemas,
  AdmissionDetailsSchema.versionedSchemas,
  AdmissionGeneralInformationSchema.versionedSchemas,
  AdmissionHistoryChecklistSchema.versionedSchemas,
  AdmissionMedicineSourceSchema.versionedSchemas,
  AdmissionRiskIdentificationSchema.versionedSchemas,
  AllergySchema.versionedSchemas,
  AuditSchema.versionedSchemas,
  BankAccountSchema.versionedSchemas,
  BillingDetailsCloudSchema.versionedSchemas,
  BillingDetailsModelsSchema.versionedSchemas,
  ChartItemSchema.versionedSchemas,
  ContactSchema.versionedSchemas,
  CorporateSchema.versionedSchemas,
  CreditCardSchema.versionedSchemas,
  DeliveryOptionsSchema.versionedSchemas,
  DirectDebitCardSchema.versionedSchemas,
  DischargeMedicationProfileSchema.versionedSchemas,
  DoctorSchema.versionedSchemas,
  DoctorReferenceSchema.versionedSchemas,
  DoctorReferenceApiSchema.versionedSchemas,
  EntitySchema.versionedSchemas,
  EntityDeleteResultSchema.versionedSchemas,
  ExtendedFacilityReferenceSchema.versionedSchemas,
  ExternalDoctorSchema.versionedSchemas,
  ExternalIdentifierSchema.versionedSchemas,
  HealthFundSchema.versionedSchemas,
  InternalEmployeeSchema.versionedSchemas,
  InterventionSchema.versionedSchemas,
  InterventionApiSchema.versionedSchemas,
  InterventionListItemSchema.versionedSchemas,
  IResultPageSchema.versionedSchemas,
  LockSchema.versionedSchemas,
  MedicalServiceSchema.versionedSchemas,
  MedicalServiceResponseSchema.versionedSchemas,
  MedicationNotesSchema.versionedSchemas,
  MedicationProfileSchema.versionedSchemas,
  NotationSchema.versionedSchemas,
  NurseSchema.versionedSchemas,
  OrderSchema.versionedSchemas,
  OrderLinkedScriptSchema.versionedSchemas,
  OrderStatisticsSchema.versionedSchemas,
  PatientSchema.versionedSchemas,
  PatientDetailsCloudSchema.versionedSchemas,
  PatientDetailsCommandSchema.versionedSchemas,
  PatientInnerDetailsSchema.versionedSchemas,
  PaymentDetailsSchema.versionedSchemas,
  PharmacyOrderProcessSchema.versionedSchemas,
  PharmacyOrderStatusSchema.versionedSchemas,
  PracticeSchema.versionedSchemas,
  ReconcileSchema.versionedSchemas,
  ReconcileStatusHistorySchema.versionedSchemas,
  ReferralSchema.versionedSchemas,
  RegistrationModelSchema.versionedSchemas,
  RoleReferenceSchema.versionedSchemas,
  ScriptItemSchema.versionedSchemas,
  SearchPatientFilterSchema.versionedSchemas,
  SearchPatientResultsSchema.versionedSchemas,
  ShopItemSchema.versionedSchemas,
  SigCodesSchema.versionedSchemas,
  SuccessResponseSchema.versionedSchemas,
  SupportingInformationDetailsSchema.versionedSchemas,
  TimeSlotsSchema.versionedSchemas,
  TreatmentSchema.versionedSchemas,
  UserReferenceSchema.versionedSchemas,
  VisitSchema.versionedSchemas,
  VisitAppointmentSchema.versionedSchemas,
  VisitBillingSchema.versionedSchemas,
  VisitDoctorReferenceSchema.versionedSchemas
)
