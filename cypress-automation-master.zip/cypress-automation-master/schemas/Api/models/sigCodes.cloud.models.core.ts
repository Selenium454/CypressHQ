import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'

import { generateSanitizeFunction } from '../shared'

export interface SigCodes440 {
  freeSigCode?: string | null
  systemSigCodes?: string[] | null
}
export interface SigCodesLatest extends SigCodes440 {}

export class SigCodesSchema {
  latestVersion: string = '4.4.0'

  public static sigCodes440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'sigCodesSchema',
      type: 'object',
      description: '',
      properties: {
        freeSigCode: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        systemSigCodes: {
          type: ['array', 'null'],
          description: '',
          items: {
            type: ['string', 'null'],
            required: false,
          },
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({} as SigCodes440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(SigCodesSchema.sigCodes440)

  public static snapshotSubtitle = 'Sig Codes Model'

  public check = (object: SigCodesLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'sigCodesSchema', version)
  }

  public sanitize = (object: SigCodesLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(SigCodesSchema.versionedSchemas, 'sigCodesSchema', version)(
        object as PlainObject
      ) as SigCodesLatest
    })
  }
}
