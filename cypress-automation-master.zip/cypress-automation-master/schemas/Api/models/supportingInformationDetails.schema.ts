import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { ConcessionEntitledValues, RepatCardTypeValues } from '../types/models.types'

import { generateSanitizeFunction } from '../shared'

export interface SupportingInformationDetails440 {
  concessionEntitled?: typeof ConcessionEntitledValues[number] | null
  concessionNumber?: string | null
  concessionType?: string | null
  concessionValidToDate?: string | null
  medicareFirstName?: string | null
  medicareNumber?: string | null
  medicareSurName?: string | null
  medicareValidDate?: string | null
  repatCardType?: typeof RepatCardTypeValues[number] | null
  repatNumber?: string | null
  safetyNetNumber?: string | null
}
export interface SupportingInformationDetailsLatest extends SupportingInformationDetails440 {}

export class SupportingInformationDetailsSchema {
  latestVersion: string = '4.4.0'

  public static supportingInformationDetails440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'supportingInformationDetailsSchema',
      type: 'object',
      description: '',
      properties: {
        concessionEntitled: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        concessionNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        concessionType: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        medicareFirstName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        medicareNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        medicareSurName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        medicareValidDate: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        repatCardType: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        repatNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        safetyNetNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({
      concessionEntitled: 'unknown',
      concessionType: 'S',
      concessionValidToDate: '2018-12-24T10:34:42',
      medicareNumber: '89769809553',
      medicareValidDate: '2018-12-31T23:59:59',
      repatCardType: 'orange',
      repatNumber: 'QSM29177',
    } as SupportingInformationDetails440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(SupportingInformationDetailsSchema.supportingInformationDetails440)

  public static snapshotSubtitle = 'Supporting Information Details Model'

  public check = (object: SupportingInformationDetailsLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'supportingInformationDetailsSchema', version)
  }

  public sanitize = (object: SupportingInformationDetailsLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(
        SupportingInformationDetailsSchema.versionedSchemas,
        'supportingInformationDetailsSchema',
        version
      )(object as PlainObject) as SupportingInformationDetailsLatest
    })
  }
}
