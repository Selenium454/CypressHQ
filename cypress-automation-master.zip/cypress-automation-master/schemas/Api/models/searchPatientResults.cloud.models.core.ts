import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { NonActiveReasonValues, RolesValues } from '../types'
import { MedicalService440, MedicalServiceSchema } from './medicalService.cloud.models.core'

import { generateSanitizeFunction } from '../shared'

export interface SearchPatientResults440 {
  activeInHub?: boolean | null
  medicareNumber?: string | null
  nonActiveReason?: typeof NonActiveReasonValues[number]
  services?: MedicalService440[]
  score?: number | null
  dateOfBirth?: string | null
  fullName?: string | null
  title?: string | null
  roles?: typeof RolesValues[number]
  userId?: string | null
  preferredName?: string | null
}
export interface SearchPatientResultsLatest extends SearchPatientResults440 {}

export class SearchPatientResultsSchema {
  latestVersion: string = '4.4.0'

  public static searchPatientResults440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'searchPatientResultsSchema',
      type: 'object',
      description: '',
      properties: {
        activeInHub: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        medicareNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        nonActiveReason: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        services: {
          type: ['array', 'null'],
          items: {
            ...MedicalServiceSchema.medicalService440.schema,
          },
          see: MedicalServiceSchema.medicalService440,
          required: false,
        },
        score: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        dateOfBirth: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        fullName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        title: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        roles: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        userId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        preferredName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({
      activeInHub: true,
      medicareNumber: '61483367661',
      nonActiveReason: 'none',
      services: [(MedicalServiceSchema.medicalService440.example as unknown) as MedicalService440],
      score: 0,
      dateOfBirth: '1977-07-14T00:00:00',
      fullName: 'NAOMI KIM MARTIN',
      title: 'MRS',
      roles: 'patient',
      userId: '0000670263',
    } as SearchPatientResults440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(SearchPatientResultsSchema.searchPatientResults440)

  public static snapshotSubtitle = 'Search Patient Results Model'

  public check = (object: SearchPatientResultsLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'searchPatientResultsSchema', version)
  }

  public sanitize = (object: SearchPatientResultsLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(
        SearchPatientResultsSchema.versionedSchemas,
        'searchPatientResultsSchema',
        version
      )(object as PlainObject) as SearchPatientResultsLatest
    })
  }
}
