import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { PharmacyOrderProcess440, PharmacyOrderProcessSchema } from './pharmacyOrderProcess.orders.cloud.models.core'

import { generateSanitizeFunction } from '../shared'

const pharmacyOrderProcess = new PharmacyOrderProcessSchema()

export interface PharmacyOrderStatus440 {
  technician?: PharmacyOrderProcess440 | null
  pharmacist?: PharmacyOrderProcess440 | null
  dispatcher?: PharmacyOrderProcess440 | null
}
export interface PharmacyOrderStatusLatest extends PharmacyOrderStatus440 {}

export class PharmacyOrderStatusSchema {
  latestVersion: string = '4.4.0'

  public static pharmacyOrderStatus440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'pharmacyOrderStatusSchema',
      type: 'object',
      description: '',
      properties: {
        technician: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...PharmacyOrderProcessSchema.pharmacyOrderProcess440.schema.properties,
          },
          see: PharmacyOrderProcessSchema.pharmacyOrderProcess440,
          required: false,
        },
        pharmacist: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...PharmacyOrderProcessSchema.pharmacyOrderProcess440.schema.properties,
          },
          see: PharmacyOrderProcessSchema.pharmacyOrderProcess440,
          required: false,
        },
        dispatcher: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...PharmacyOrderProcessSchema.pharmacyOrderProcess440.schema.properties,
          },
          see: PharmacyOrderProcessSchema.pharmacyOrderProcess440,
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({
      technician: PharmacyOrderProcessSchema.pharmacyOrderProcess440.example as PharmacyOrderProcess440,
      pharmacist: PharmacyOrderProcessSchema.pharmacyOrderProcess440.example as PharmacyOrderProcess440,
      dispatcher: PharmacyOrderProcessSchema.pharmacyOrderProcess440.example as PharmacyOrderProcess440,
    } as PharmacyOrderStatus440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(PharmacyOrderStatusSchema.pharmacyOrderStatus440)

  public static snapshotSubtitle = 'Pharmacy Order Status Model'

  public check = (object: PharmacyOrderStatusLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'pharmacyOrderStatusSchema', version)
  }

  public sanitize = (object: PharmacyOrderStatusLatest, version: string = this.latestVersion) => {
    if (object.technician) {
      pharmacyOrderProcess.sanitize(object.technician).then(sanitizedTechnician => {
        object.technician = sanitizedTechnician
      })
    }

    if (object.pharmacist) {
      pharmacyOrderProcess.sanitize(object.pharmacist).then(sanitizedPharmacist => {
        object.pharmacist = sanitizedPharmacist
      })
    }

    if (object.dispatcher) {
      pharmacyOrderProcess.sanitize(object.dispatcher).then(sanitizedDispatcher => {
        object.dispatcher = sanitizedDispatcher
      })
    }

    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(PharmacyOrderStatusSchema.versionedSchemas, 'pharmacyOrderStatusSchema', version)(
        object as PlainObject
      ) as PharmacyOrderStatusLatest
    })
  }
}
