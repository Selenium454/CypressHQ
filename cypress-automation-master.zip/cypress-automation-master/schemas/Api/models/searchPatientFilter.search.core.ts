import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'

import { generateSanitizeFunction } from '../shared'

export interface SearchPatientFilter440 {
  userId?: string | null
  from?: string | null
  to?: string | null
  name?: string | null
  urn?: string | null
  email?: string | null
  medicare?: string | null
  onlyActive?: boolean | null
  businessUnits?: string[] | null
  facilityCodes?: string[] | null
  wards?: string[] | null
  take?: number | null
  pageNumber?: number | null
}
export interface SearchPatientFilterLatest extends SearchPatientFilter440 {}

export class SearchPatientFilterSchema {
  latestVersion: string = '4.4.0'

  public static searchPatientFilter440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'searchPatientFilterSchema',
      type: 'object',
      description: '',
      properties: {
        userId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        from: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        to: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        urn: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        email: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        medicare: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        onlyActive: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        businessUnits: {
          type: ['array', 'null'],
          description: '',
          required: false,
        },
        facilityCodes: {
          type: ['array', 'null'],
          description: '',
          required: false,
        },
        wards: {
          type: ['array', 'null'],
          description: '',
          required: false,
        },
        take: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        pageNumber: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({
      userId: '0000670263',
      from: '2019-08-24T10:55:35.247Z',
      to: '2019-08-24T10:55:35.247Z',
      name: 'NAOMI KIM MARTIN',
      urn: '123456',
      email: 'test@test.com',
      medicare: '61483367661',
      onlyActive: true,
      businessUnits: ['44'],
      facilityCodes: ['SJGM'],
      wards: ['CATH'],
      take: 100,
      pageNumber: 1,
    } as SearchPatientFilter440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(SearchPatientFilterSchema.searchPatientFilter440)

  public static snapshotSubtitle = 'Search Patient Filter Model'

  public check = (object: SearchPatientFilterLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'searchPatientFilterSchema', version)
  }

  public sanitize = (object: SearchPatientFilterLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(SearchPatientFilterSchema.versionedSchemas, 'searchPatientFilterSchema', version)(
        object as PlainObject
      ) as SearchPatientFilterLatest
    })
  }
}
