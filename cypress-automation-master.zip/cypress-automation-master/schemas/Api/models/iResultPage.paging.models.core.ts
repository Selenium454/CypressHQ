import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'

import { generateSanitizeFunction } from '../shared'

export interface IResultPage440 {
  total?: number | null
  totalPages?: number | null
  itemsPerPage?: number | null
  pageNumber?: number | null
  itemsInCurrentPage?: number | null
  items?: any[] | null
}
export interface IResultPageLatest extends IResultPage440 {}

export class IResultPageSchema {
  latestVersion: string = '4.4.0'

  public static iResultPage440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'iResultPage',
      type: 'object',
      description: '',
      properties: {
        total: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        totalPages: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        itemsPerPage: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        pageNumber: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        itemsInCurrentPage: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        items: {
          type: ['array', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({
      total: 130771,
      itemsPerPage: 100,
      pageNumber: 1,
      itemsInCurrentPage: 100,
      items: [],
      totalPages: 1308,
    } as IResultPage440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(IResultPageSchema.iResultPage440)

  public static snapshotSubtitle = 'IResult Page Model'

  public check = (object: IResultPageLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'iResultPageSchema', version)
  }

  public sanitize = (object: IResultPageLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(IResultPageSchema.versionedSchemas, 'iResultPageSchema', version)(
        object as PlainObject
      ) as IResultPageLatest
    })
  }
}
