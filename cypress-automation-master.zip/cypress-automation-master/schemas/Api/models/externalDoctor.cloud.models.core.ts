import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'

import { generateSanitizeFunction } from '../shared'

export interface ExternalDoctor440 {
  firstName?: string | null
  prescriberNumber?: string | null
  providerNumber?: string | null
  surname?: string | null
  title?: string | null
}
export interface ExternalDoctorLatest extends ExternalDoctor440 {}

export class ExternalDoctorSchema {
  latestVersion: string = '4.4.0'

  public static externalDoctor440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'externalDoctorSchema',
      type: 'object',
      description: '',
      properties: {
        firstName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        prescriberNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        providerNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        surname: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        title: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({
      firstName: 'Bob',
      prescriberNumber: '2020-06-01T00:00:00.000Z',
      providerNumber: '1167639A',
      surname: 'Ross',
      title: 'Mr',
    } as ExternalDoctor440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(ExternalDoctorSchema.externalDoctor440)

  public static snapshotSubtitle = 'External Doctor Model'

  public check = (object: ExternalDoctorLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'externalDoctorSchema', version)
  }

  public sanitize = (object: ExternalDoctorLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(ExternalDoctorSchema.versionedSchemas, 'externalDoctorSchema', version)(
        object as PlainObject
      ) as ExternalDoctorLatest
    })
  }
}
