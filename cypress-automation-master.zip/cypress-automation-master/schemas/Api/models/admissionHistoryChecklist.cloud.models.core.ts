import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'

import { generateSanitizeFunction } from '../shared'

export interface AdmissionHistoryChecklist440 {
  analgesics?: boolean | null
  complementaryMedicines?: boolean | null
  gastrointestinalDrugs?: boolean | null
  inhalersPuffersSpraysSublingual?: boolean | null
  injectedMedicines?: boolean | null
  insertedMedicines?: boolean | null
  intermittentMedicines?: boolean | null
  oralContraceptivesHormoneReplacementTherapy?: boolean | null
  otherPeoplesMedicine?: boolean | null
  overTheCounterMedicines?: boolean | null
  prescriptionMedicines?: boolean | null
  recentlyCompletedCoursesMedicine?: boolean | null
  sleepingTablets?: boolean | null
  socialRecreationalDrugs?: boolean | null
  tropicalMedicines?: boolean | null
}
export interface AdmissionHistoryChecklistLatest extends AdmissionHistoryChecklist440 {}

export class AdmissionHistoryChecklistSchema {
  latestVersion: string = '4.4.0'

  public static admissionHistoryChecklist440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'admissionHistoryChecklistSchema',
      type: 'object',
      description: '',
      properties: {
        analgesics: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        complementaryMedicines: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        gastrointestinalDrugs: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        inhalersPuffersSpraysSublingual: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        injectedMedicines: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        insertedMedicines: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        intermittentMedicines: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        oralContraceptivesHormoneReplacementTherapy: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        otherPeoplesMedicine: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        overTheCounterMedicines: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        prescriptionMedicines: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        recentlyCompletedCoursesMedicine: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        sleepingTablets: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        socialRecreationalDrugs: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        tropicalMedicines: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({
      analgesics: false,
      complementaryMedicines: false,
      gastrointestinalDrugs: false,
      inhalersPuffersSpraysSublingual: false,
      injectedMedicines: false,
      insertedMedicines: false,
      oralContraceptivesHormoneReplacementTherapy: false,
      otherPeoplesMedicine: false,
      overTheCounterMedicines: false,
      prescriptionMedicines: false,
      recentlyCompletedCoursesMedicine: false,
      sleepingTablets: false,
      socialRecreationalDrugs: false,
      tropicalMedicines: false,
    } as AdmissionHistoryChecklist440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(AdmissionHistoryChecklistSchema.admissionHistoryChecklist440)

  public static snapshotSubtitle = 'Admission History Checklist Model'

  public check = (object: AdmissionHistoryChecklistLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'admissionHistoryChecklistSchema', version)
  }

  public sanitize = (object: AdmissionHistoryChecklistLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(
        AdmissionHistoryChecklistSchema.versionedSchemas,
        'admissionHistoryChecklistSchema',
        version
      )(object as PlainObject) as AdmissionHistoryChecklistLatest
    })
  }
}
