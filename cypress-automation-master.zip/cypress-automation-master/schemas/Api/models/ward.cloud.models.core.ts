import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { generateSanitizeFunction } from '../shared'
import { ServiceTypeValues, WardFrequencyValues, RoundTypeValues, UrnTypeValues } from '../types/models.types'
import { WeeklyTimeTable440, WeeklyTimeTableSchema } from './weeklyTimetable.cloud.models.core'
import { SystemIntegration440, SystemIntegrationSchema } from './systemIntegration.cloud.models.core'

export interface Ward440 {
  externalRoundCodes?: string[] | null
  roundId?: string | null
  serviceType?: typeof ServiceTypeValues[number] | null
  typeOfUrn?: typeof UrnTypeValues[number] | null
  courierTimes?: WeeklyTimeTable440 | null
  cutOffCourierTime?: string | null
  frequency?: typeof WardFrequencyValues[number] | null
  startDate?: string | null
  roundType?: typeof RoundTypeValues[number] | null
  integrations?: SystemIntegration440[] | null
  roundCode?: string | null
  roundName?: string | null
}
export interface WardLatest extends Ward440 {}

export class WardSchema {
  latestVersion: string = '4.4.0'

  public static ward440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'wardSchema',
      type: 'object',
      description: 'Generic ward model used across the project.',
      properties: {
        externalRoundCodes: {
          type: ['array', 'null'],
          description: '',
          items: {
            type: ['string', 'null'],
            description: '',
            required: false,
          },
          required: false,
        },
        roundId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        serviceType: {
          type: ['string', 'null'],
          description: '',
          enum: (ServiceTypeValues as unknown) as string[],
          required: false,
        },
        typeOfUrn: {
          type: ['string', 'null'],
          description: '',
          enum: (UrnTypeValues as unknown) as string[],
          required: false,
        },
        courierTimes: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...WeeklyTimeTableSchema.weeklyTimeTable440.schema.properties,
          },
          required: false,
        },
        roucutOffCourierTimendId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        frequency: {
          type: ['string', 'null'],
          description: '',
          enum: (WardFrequencyValues as unknown) as string[],
          required: false,
        },
        startDate: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        roundType: {
          type: ['string', 'null'],
          description: '',
          enum: (RoundTypeValues as unknown) as string[],
          required: false,
        },
        integrations: {
          type: ['array', 'null'],
          description: '',
          items: {
            type: ['object', 'null'],
            properties: {
              ...SystemIntegrationSchema.systemIntegration440.schema.properties,
            },
          },
          required: false,
        },
        roundCode: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        roundName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({} as Ward440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(WardSchema.ward440)

  public static snapshotSubtitle = 'Ward Model'

  public check = (object: WardLatest, version: string = this.latestVersion) => {
    cy.wrap(object).should('followSchema', 'wardSchema', version)
    return this
  }

  public sanitize = (object: WardLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(WardSchema.versionedSchemas, 'wardSchema', version)(
        (object as unknown) as PlainObject
      ) as WardLatest
    })
  }
}
