import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { RolesValues } from '../types'

import { generateSanitizeFunction } from '../shared'

export interface RoleReference440 {
  role?: typeof RolesValues[number] | null
  id?: string | null
  name?: string | null
}
export interface RoleReferenceLatest extends RoleReference440 {}

export class RoleReferenceSchema {
  latestVersion: string = '4.4.0'

  public static roleReference440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'roleReferenceSchema',
      type: 'object',
      description: '',
      properties: {
        role: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        id: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        name: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({
      role: 'none',
      id: '',
      name: 'Bob',
    } as RoleReference440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(RoleReferenceSchema.roleReference440)

  public static snapshotSubtitle = 'Role Reference Model'

  public check = (object: RoleReferenceLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'roleReferenceSchema', version)
  }

  public sanitize = (object: RoleReferenceLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(RoleReferenceSchema.versionedSchemas, 'roleReferenceSchema', version)(
        object as PlainObject
      ) as RoleReferenceLatest
    })
  }
}
