import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'

import { generateSanitizeFunction } from '../shared'

export interface VisitAppointment440 {
  duration?: string | null
  startDate?: string | null
}
export interface VisitAppointmentLatest extends VisitAppointment440 {}

export class VisitAppointmentSchema {
  latestVersion: string = '4.4.0'

  public static visitAppointment440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'visitAppointmentSchema',
      type: 'object',
      description: '',
      properties: {
        duration: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({} as VisitAppointment440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(VisitAppointmentSchema.visitAppointment440)

  public static snapshotSubtitle = 'Visit Appointment Model'

  public check = (object: VisitAppointmentLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'visitAppointmentSchema', version)
  }

  public sanitize = (object: VisitAppointmentLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(VisitAppointmentSchema.versionedSchemas, 'visitAppointmentSchema', version)(
        object as PlainObject
      ) as VisitAppointmentLatest
    })
  }
}
