import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { ReconcileStatusHistory440, ReconcileStatusHistorySchema } from './reconcileStatusHistory.cloud.models.core'

import { generateSanitizeFunction } from '../shared'

export type statusValues = 'none' | 'draft' | 'completed' | 'approved'

export interface Reconcile440 {
  reconcileStatusHistories?: ReconcileStatusHistory440[] | null
  status?: statusValues | null
}
export interface ReconcileLatest extends Reconcile440 {}

export class ReconcileSchema {
  latestVersion: string = '4.4.0'

  public static reconcile440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'reconcileSchema',
      type: 'object',
      description: '',
      properties: {
        reconcileStatusHistories: {
          type: ['array', 'null'],
          description: '',
          items: {
            ...ReconcileStatusHistorySchema.reconcileStatusHistory440.schema,
          },
          see: ReconcileStatusHistorySchema.reconcileStatusHistory440,
          required: false,
        },
        status: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({
      reconcileStatusHistories: [
        ReconcileStatusHistorySchema.reconcileStatusHistory440.example as ReconcileStatusHistory440,
      ],
      status: 'none',
    } as Reconcile440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(ReconcileSchema.reconcile440)

  public static snapshotSubtitle = 'Reconcile Model'

  public check = (object: ReconcileLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'reconcileSchema', version)
  }

  public sanitize = (object: ReconcileLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(ReconcileSchema.versionedSchemas, 'reconcileSchema', version)(
        object as PlainObject
      ) as ReconcileLatest
    })
  }
}
