import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { Referral440, ReferralSchema } from './referral.cloud.models.core'
import { ReferenceTypeValues } from '../types'

import { generateSanitizeFunction } from '../shared'

export interface VisitDoctorReference440 {
  providerNumber?: string | null
  practiceName?: string | null
  firstName?: string | null
  surname?: string | null
  fullName?: string | null
  practiceId?: string | null
  referenceType: typeof ReferenceTypeValues[number]
  referrals?: Referral440 | null
  userId: string
}
export interface VisitDoctorReferenceLatest extends VisitDoctorReference440 {}

export class VisitDoctorReferenceSchema {
  latestVersion: string = '4.4.0'

  public static visitDoctorReference440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'visitDoctorReferenceSchema',
      type: 'object',
      description: '',
      properties: {
        providerNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        practiceName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        firstName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        surname: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        fullName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        practiceId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        referenceType: {
          type: ['string', 'null'],
          description: '',
          enum: (ReferenceTypeValues as unknown) as string[],
          required: true,
        },
        referrals: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...ReferralSchema.referral440.schema.properties,
          },
          see: ReferralSchema.referral440,
          required: false,
        },
        userId: {
          type: 'string',
          description: '',
          required: true,
        },
      },
      additionalProperties: false,
    },
    example: (({
      userId: '12345678',
      referenceType: 'treating',
    } as VisitDoctorReference440) as unknown) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(VisitDoctorReferenceSchema.visitDoctorReference440)

  public static snapshotSubtitle = 'Visit Doctor Reference Model'

  public check = (object: VisitDoctorReferenceLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'visitDoctorReferenceSchema', version)
  }

  public sanitize = (object: VisitDoctorReferenceLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(
        VisitDoctorReferenceSchema.versionedSchemas,
        'visitDoctorReferenceSchema',
        version
      )((object as unknown) as PlainObject) as VisitDoctorReferenceLatest
    })
  }
}
