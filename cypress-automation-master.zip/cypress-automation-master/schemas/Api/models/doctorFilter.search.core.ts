import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'

import { generateSanitizeFunction } from '../shared'

export interface DoctorFilter440 {
  name?: string | null
  providerNumber?: string | null
  prescriberNumber?: string | null
  facilityCode?: string | null
  nonAssociatedPracticesOnly?: boolean | null
  take?: number | null
  pageNumber?: number | null
}
export interface DoctorFilterLatest extends DoctorFilter440 {}

export class DoctorFilterSchema {
  latestVersion: string = '4.4.0'

  public static doctorFilter440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'doctorFilterSchema',
      type: 'object',
      description: '',
      properties: {
        name: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        providerNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        prescriberNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        facilityCode: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        nonAssociatedPracticesOnly: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        take: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        pageNumber: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: (({} as DoctorFilter440) as unknown) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(DoctorFilterSchema.doctorFilter440)

  public static snapshotSubtitle = 'Doctor Filter Model'

  public check = (object: DoctorFilterLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'doctorFilterSchema', version)
  }

  public sanitize = (object: DoctorFilterLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(DoctorFilterSchema.versionedSchemas, 'doctorFilterSchema', version)(
        (object as unknown) as PlainObject
      ) as DoctorFilterLatest
    })
  }
}
