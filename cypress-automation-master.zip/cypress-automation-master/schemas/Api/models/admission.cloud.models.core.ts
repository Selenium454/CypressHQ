import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { Address440, AddressSchema } from './address.cloud.models.core'
import { AdmissionAdministration440, AdmissionAdministrationSchema } from './admissionAdministration.cloud.models.core'
import { Allergy440, AllergySchema } from './allergy.cloud.models.core'
import { RoleReference440, RoleReferenceSchema } from './roleReference.cloud.models.core'
import { ExternalDoctor440, ExternalDoctorSchema } from './externalDoctor.cloud.models.core'
import {
  AdmissionGeneralInformation440,
  AdmissionGeneralInformationSchema,
} from './admissionGeneralInformation.cloud.models.core'
import {
  AdmissionHistoryChecklist440,
  AdmissionHistoryChecklistSchema,
} from './admissionHistoryChecklist.cloud.models.core'
import { Reconcile440, ReconcileSchema } from './reconcile.cloud.models.core'
import {
  AdmissionRiskIdentification440,
  AdmissionRiskIdentificationSchema,
} from './admissionRiskIdentification.cloud.models.core'
import { AdmissionMedicineSource440, AdmissionMedicineSourceSchema } from './admissionMedicineSource.cloud.models.core'
import { Lock440, LockSchema } from './lock.models.core'
import {
  AdmissionStatusValues,
  FacilityTypeValues,
  ReconciliationPdfTypeValues,
  RepatCardTypeValues,
  SexValues,
  SourceValues,
  SourceTypeValues,
  StatusValues,
} from '../types'
import { generateSanitizeFunction } from '../shared'

const addressSchema = new AddressSchema()
const admissionAdministrationSchema = new AdmissionAdministrationSchema()
const roleReferenceSchema = new RoleReferenceSchema()
const admissionGeneralInformationSchema = new AdmissionGeneralInformationSchema()
const admissionHistoryChecklistSchema = new AdmissionHistoryChecklistSchema()
const reconcileSchema = new ReconcileSchema()
const admissionRiskIdentificationSchema = new AdmissionRiskIdentificationSchema()
const lockSchema = new LockSchema()

export interface Admission440 {
  accountType?: string | null
  additionalPharmacistNotes?: string | null
  address?: Address440 | null
  administration?: AdmissionAdministration440 | null
  admissionAllergies?: string | null
  admissionDate?: string | null
  admissionNumber: string
  admissionStatus?: typeof AdmissionStatusValues[number] | null
  alias?: string | null
  allergies?: Allergy440[] | null
  bedNumber?: string | null
  businessUnitId: string
  comments?: string | null
  concessionNumber?: string | null
  concessionValidToDate?: string | null
  createDate: string
  createdBy?: RoleReference440 | null
  dateOfBirth: string
  dischargeDate?: string | null
  dischargeSpecialInstructions?: string | null
  doctors?: ExternalDoctor440[] | null
  email?: string | null
  externalId?: string | null
  facilityCode: string
  facilityType?: typeof FacilityTypeValues[number] | null
  firstName: string
  generalInformation?: AdmissionGeneralInformation440
  healthFundCoverLevel?: string | null
  healthFundExpiry?: string | null
  healthFundId?: string | null
  healthFundMembershipNumber?: string | null
  height?: number
  historyChecklist?: AdmissionHistoryChecklist440 | null
  insuranceValidToDate?: string | null
  mailCategory?: string | null
  medicareFirstName?: string | null
  medicareNumber?: string | null
  medicareSurName?: string | null
  medicareValidToDate?: string | null
  oldAdmissionNumber?: string | null
  oldUrNumber?: string | null
  phoneNumber?: string | null
  reason?: string | null
  recentlyCeased?: string | null
  reconcileStatus?: Reconcile440 | null
  reconciliationPdfType?: typeof ReconciliationPdfTypeValues[number] | null
  repatCardType?: typeof RepatCardTypeValues[number] | null
  repatriationNumber?: string | null
  riskIdentification?: AdmissionRiskIdentification440 | null
  roomNumber?: string | null
  roundCode?: string | null
  safetyNetNumber?: string | null
  sex?: typeof SexValues[number] | null
  source: typeof SourceValues[number]
  sourcesMedicine?: AdmissionMedicineSource440[] | null
  sourceType: typeof SourceTypeValues[number]
  status?: typeof StatusValues[number] | null
  surName: string
  title?: string | null
  updateDate: string
  updatedBy?: RoleReference440 | null
  urNumber?: string | null
  userId: string
  weight?: number | null
  dischargeCounter?: number | null
  isLockable?: boolean | null
  lock?: Lock440 | null
  documentType?: string | null
}
export interface AdmissionLatest extends Admission440 {}

export class AdmissionSchema {
  latestVersion: string = '4.4.0'

  public static admission440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'admissionSchema',
      type: 'object',
      description: '',
      properties: {
        accountType: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        additionalPharmacistNotes: {
          type: ['string', 'null'],
          description: '',
          format: 'notes',
          required: false,
        },
        address: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...AddressSchema.address440.schema.properties,
          },
          see: AddressSchema.address440,
          required: false,
        },
        administration: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...AdmissionAdministrationSchema.admissionAdministration440.schema.properties,
          },
          see: AdmissionAdministrationSchema.admissionAdministration440,
          required: false,
        },
        admissionAllergies: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        admissionDate: {
          type: ['string', 'null'],
          description: '',
          format: 'dateTime',
          required: false,
        },
        admissionNumber: {
          type: 'string',
          description: '',
          format: 'admissionNumber',
          required: true,
        },
        admissionStatus: {
          type: ['string', 'null'],
          description: '',
          enum: (AdmissionStatusValues as unknown) as string[],
          required: false,
        },
        alias: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        allergies: {
          type: ['array', 'null'],
          description: '',
          items: {
            ...AllergySchema.allergy440.schema,
          },
          see: AllergySchema.allergy440,
          required: false,
        },
        bedNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        businessUnitId: {
          type: 'string',
          description: '',
          required: true,
        },
        comments: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        concessionNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        concessionValidToDate: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        createDate: {
          type: 'string',
          description: '',
          required: true,
        },
        createdBy: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...RoleReferenceSchema.roleReference440.schema.properties,
          },
          see: RoleReferenceSchema.roleReference440,
          required: false,
        },
        dateOfBirth: {
          type: 'string',
          description: '',
          required: true,
        },
        dischargeDate: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        dischargeSpecialInstructions: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        doctors: {
          type: ['array', 'null'],
          description: '',
          items: {
            ...ExternalDoctorSchema.externalDoctor440.schema,
          },
          see: ExternalDoctorSchema.externalDoctor440,
          required: false,
        },
        email: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        externalId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        facilityCode: {
          type: 'string',
          description: '',
          required: true,
        },
        facilityType: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        firstName: {
          type: 'string',
          description: '',
          required: true,
        },
        generalInformation: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...AdmissionGeneralInformationSchema.admissionGeneralInformation440.schema.properties,
          },
          see: AdmissionGeneralInformationSchema.admissionGeneralInformation440,
          required: false,
        },
        healthFundCoverLevel: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        healthFundExpiry: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        healthFundId: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        healthFundMembershipNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        height: {
          type: 'number',
          description: '',
          required: true,
        },
        historyChecklist: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...AdmissionHistoryChecklistSchema.admissionHistoryChecklist440.schema.properties,
          },
          see: AdmissionHistoryChecklistSchema.admissionHistoryChecklist440,
          required: false,
        },
        insuranceValidToDate: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        mailCategory: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        medicareFirstName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        medicareNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        medicareSurName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        medicareValidToDate: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        oldAdmissionNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        oldUrNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        phoneNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        reason: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        recentlyCeased: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        reconcileStatus: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...ReconcileSchema.reconcile440.schema.properties,
          },
          see: ReconcileSchema.reconcile440,
          required: false,
        },
        reconciliationPdfType: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        repatCardType: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        repatriationNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        riskIdentification: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...AdmissionRiskIdentificationSchema.admissionRiskIdentification440.schema.properties,
          },
          see: AdmissionRiskIdentificationSchema.admissionRiskIdentification440,
          required: false,
        },
        roomNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        roundCode: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        safetyNetNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        sex: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        source: {
          type: 'string',
          description: '',
          required: true,
        },
        sourcesMedicine: {
          type: ['array', 'null'],
          description: '',
          items: {
            ...AdmissionMedicineSourceSchema.admissionMedicineSource440.schema,
          },
          see: AdmissionMedicineSourceSchema.admissionMedicineSource440,
          required: false,
        },
        sourceType: {
          type: 'string',
          description: '',
          required: true,
        },
        status: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        surName: {
          type: 'string',
          description: '',
          required: true,
        },
        title: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        updateDate: {
          type: 'string',
          description: '',
          required: true,
        },
        updatedBy: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        urNumber: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        userId: {
          type: 'string',
          description: '',
          required: true,
        },
        weight: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        dischargeCounter: {
          type: ['number', 'null'],
          description: '',
          required: false,
        },
        isLockable: {
          type: ['boolean', 'null'],
          description: '',
          required: false,
        },
        lock: {
          type: ['object', 'null'],
          description: '',
          properties: {
            ...LockSchema.lock440.schema.properties,
          },
          see: LockSchema.lock440,
          required: false,
        },
        documentType: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: (({
      accountType: ' ',
      additionalPharmacistNotes: 'Use the wireless GB feed, then you can program the digital circuit!',
      address: AddressSchema.address440.example,
      administration: AdmissionAdministrationSchema.admissionAdministration440.example as PlainObject,
      admissionAllergies: '',
      admissionDate: '2018-12-19T10:34:42',
      admissionNumber: '62042921',
      admissionStatus: 'admitted',
      allergies: [],
      bedNumber: '7',
      businessUnitId: '44',
      concessionNumber: 'CN802459949',
      concessionValidToDate: '2018-12-24T10:34:42',
      createDate: '2018-12-19T00:34:42+00:00',
      createdBy: RoleReferenceSchema.roleReference440.example,
      dateOfBirth: '1923-01-14T00:00:00',
      doctors: [],
      email: 'Matilda_West@gmail.com',
      externalId: '0',
      facilityCode: 'SJGM',
      facilityType: 'hospital',
      firstName: 'Ellie',
      surName: 'Something',
      generalInformation: {},
      healthFundCoverLevel: 'TOP',
      healthFundExpiry: '2018-12-24T10:34:42',
      healthFundId: 'ESH',
      healthFundMembershipNumber: '987023',
      historyChecklist: AdmissionHistoryChecklistSchema.admissionHistoryChecklist440.example,
      insuranceValidToDate: '2018-12-24T10:34:42',
      mailCategory: '',
      medicareNumber: '89769809553',
      medicareValidToDate: '2018-12-31T23:59:59',
      oldAdmissionNumber: '',
      phoneNumber: '66282135',
      source: 'onPremiseSql',
      sourceType: 'patty',
      updateDate: '2018-12-31T23:59:59',
      userId: '0000542618',
      reconcileStatus: ReconcileSchema.reconcile440.example,
      reconciliationPdfType: 'simple',
      repatCardType: 'orange',
      repatriationNumber: 'QSM29177',
      riskIdentification: AdmissionRiskIdentificationSchema.admissionRiskIdentification440.example,
    } as Admission440) as unknown) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(AdmissionSchema.admission440)

  public static snapshotSubtitle = 'Admission Model'

  public check = (object: AdmissionLatest, version: string = this.latestVersion) => {
    if (object.address) {
      cy.wrap(object.address).should('followSchema', 'addressSchema', version)
    }

    if (object.administration) {
      cy.wrap(object.administration).should('followSchema', 'administrationSchema', version)
    }

    cy.wrap(object).should('followSchema', 'admissionSchema', version)
    return this
  }

  public sanitize = (object: AdmissionLatest, version: string = this.latestVersion) => {
    if (object.address) {
      addressSchema.sanitize(object.address).then(sanitizedAddress => {
        object.address = sanitizedAddress
      })
    }

    if (object.administration) {
      admissionAdministrationSchema.sanitize(object.administration).then(sanitizedAdministration => {
        object.administration = sanitizedAdministration
      })
    }

    if (object.createdBy) {
      roleReferenceSchema.sanitize(object.createdBy).then(sanitizedCreatedBy => {
        object.createdBy = sanitizedCreatedBy
      })
    }

    if (object.generalInformation) {
      admissionGeneralInformationSchema.sanitize(object.generalInformation).then(sanitizedGeneralInformation => {
        object.generalInformation = sanitizedGeneralInformation
      })
    }

    if (object.historyChecklist) {
      admissionHistoryChecklistSchema.sanitize(object.historyChecklist).then(sanitizedHistoryChecklist => {
        object.historyChecklist = sanitizedHistoryChecklist
      })
    }

    if (object.reconcileStatus) {
      reconcileSchema.sanitize(object.reconcileStatus).then(sanitizedReconcileStatus => {
        object.reconcileStatus = sanitizedReconcileStatus
      })
    }

    if (object.riskIdentification) {
      admissionRiskIdentificationSchema.sanitize(object.riskIdentification).then(sanitizedRiskIdentification => {
        object.riskIdentification = sanitizedRiskIdentification
      })
    }

    if (object.lock) {
      lockSchema.sanitize(object.lock).then(sanitizedLock => {
        object.lock = sanitizedLock
      })
    }

    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(AdmissionSchema.versionedSchemas, 'admissionSchema', version)(
        (object as unknown) as PlainObject
      ) as AdmissionLatest
    })
  }
}
