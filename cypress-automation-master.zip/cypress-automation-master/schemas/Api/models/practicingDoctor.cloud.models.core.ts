import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'

import { generateSanitizeFunction } from '../shared'
import { DoctorTypeValues } from '../types/models.types'

export interface PracticingDoctor440 {
  userId: string
  firstName: string
  surname: string
  providerNumber: string
  practiceName?: string | null
  type: typeof DoctorTypeValues[number]
}
export interface PracticingDoctorLatest extends PracticingDoctor440 {}

export class PracticingDoctorSchema {
  latestVersion: string = '4.4.0'

  public static practicingDoctor440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'practicingDoctorSchema',
      type: 'object',
      description: '',
      properties: {
        userId: {
          type: 'string',
          description: '',
          required: false,
        },
        firstName: {
          type: 'string',
          description: '',
          required: false,
        },
        surname: {
          type: 'string',
          description: '',
          required: false,
        },
        providerNumber: {
          type: 'string',
          description: '',
          required: false,
        },
        practiceName: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        type: {
          type: 'string',
          description: '',
          enum: (DoctorTypeValues as unknown) as string[],
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: (({
      userId: 'test',
      firstName: 'Bob',
      surname: 'ross',
      providerNumber: '123',
      type: 'none',
    } as PracticingDoctor440) as unknown) as PlainObject,
  }
  public static versionedSchemas = versionSchemas(PracticingDoctorSchema.practicingDoctor440)

  public static snapshotSubtitle = 'Practice Doctor Model'

  public check = (object: PracticingDoctorLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'practicingDoctorSchema', version)
  }

  public sanitize = (object: PracticingDoctorLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(PracticingDoctorSchema.versionedSchemas, 'practicingDoctorSchema', version)(
        (object as unknown) as PlainObject
      ) as PracticingDoctorLatest
    })
  }
}
