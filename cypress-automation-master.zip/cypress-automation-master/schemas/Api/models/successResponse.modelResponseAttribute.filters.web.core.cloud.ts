import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { ResponseStatusValues } from '../types'
import { generateSanitizeFunction } from '../shared'

export interface SuccessResponse440 {
  status?: typeof ResponseStatusValues[number]
  model?: any
  trackId?: string
}
export interface SuccessResponseLatest extends SuccessResponse440 {}

export class SuccessResponseSchema {
  latestVersion: string = '4.4.0'

  public static successResponse440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'successResponseSchema',
      type: 'object',
      description: 'Generic response model for successful requests.',
      properties: {
        model: {
          type: ['string', 'object', 'array', 'null'],
          description: '',
          required: false,
        },
        status: {
          type: ['string', 'null'],
          description: '',
          required: false,
        },
        trackId: {
          type: ['string', 'null'],
          format: 'trackId',
          description: '',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: {
      status: 'success',
      model: '[]',
      trackId: '86d4f1dfc6ac4636b7bdd33c23c81868',
    },
  }

  public static versionedSchemas = versionSchemas(SuccessResponseSchema.successResponse440)

  public static snapshotSubtitle = 'Success Response Model'

  public check = (object: SuccessResponseLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'successResponseSchema', version)
  }

  public sanitize = (object: SuccessResponseLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(SuccessResponseSchema.versionedSchemas, 'successResponseSchema', version)(
        object as PlainObject
      ) as SuccessResponseLatest
    })
  }
}
