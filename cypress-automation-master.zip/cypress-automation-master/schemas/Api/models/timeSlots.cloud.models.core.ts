import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'

import { generateSanitizeFunction } from '../shared'

export interface TimeSlots440 {
  timeslot1?: string | null
  timeslot2?: string | null
  timeslot3?: string | null
  timeslot4?: string | null
  timeslot5?: string | null
  timeslot6?: string | null
  timeslot7?: string | null
  timeslot8?: string | null
}
export interface TimeSlotsLatest extends TimeSlots440 {}

export class TimeSlotsSchema {
  latestVersion: string = '4.4.0'

  public static timeSlots440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'timeSlotsSchema',
      type: 'object',
      description: 'Time slots model for medication time slots.',
      properties: {
        timeslot1: {
          type: ['string', 'null'],
          description: 'Timeslot 1 time.',
          required: false,
        },
        timeslot2: {
          type: ['string', 'null'],
          description: 'Timeslot 2 time.',
          required: false,
        },
        timeslot3: {
          type: ['string', 'null'],
          description: 'Timeslot 3 time.',
          required: false,
        },
        timeslot4: {
          type: ['string', 'null'],
          description: 'Timeslot 4 time.',
          required: false,
        },
        timeslot5: {
          type: ['string', 'null'],
          description: 'Timeslot 5 time.',
          required: false,
        },
        timeslot6: {
          type: ['string', 'null'],
          description: 'Timeslot 6 time.',
          required: false,
        },
        timeslot7: {
          type: ['string', 'null'],
          description: 'Timeslot 7 time.',
          required: false,
        },
        timeslot8: {
          type: ['string', 'null'],
          description: 'Timeslot 8 time.',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({
      timeslot1: '2:00',
      timeslot2: '4:00',
      timeslot3: '6:00',
      timeslot4: '8:00',
      timeslot5: '10:00',
      timeslot6: '12:00',
      timeslot7: '14:00',
      timeslot8: '16:00',
    } as TimeSlots440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(TimeSlotsSchema.timeSlots440)

  public static snapshotSubtitle = 'Time Slots Model'

  public check = (object: TimeSlotsLatest, version: string = this.latestVersion) => {
    return cy.wrap(object).should('followSchema', 'timeSlotsSchema', version)
  }

  public sanitize = (object: TimeSlotsLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(TimeSlotsSchema.versionedSchemas, 'timeSlotsSchema', version)(
        object as PlainObject
      ) as TimeSlotsLatest
    })
  }
}
