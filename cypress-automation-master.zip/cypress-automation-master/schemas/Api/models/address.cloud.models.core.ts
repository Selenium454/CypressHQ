import { ObjectSchema, versionSchemas, PlainObject } from '@cypress/schema-tools'
import { generateSanitizeFunction } from '../shared'

export interface Address440 {
  country?: string | null
  postCode?: string | null
  secondaryStreet?: string | null
  state?: string | null
  street?: string | null
  suburb?: string | null
}
export interface AddressLatest extends Address440 {}

export class AddressSchema {
  latestVersion: string = '4.4.0'

  public static address440: ObjectSchema = {
    version: {
      major: 4,
      minor: 4,
      patch: 0,
    },
    schema: {
      title: 'addressSchema',
      type: 'object',
      description: 'Generic address model used across the project.',
      properties: {
        country: {
          type: ['string', 'null'],
          description: 'The current country of residence.',
          required: false,
        },
        postCode: {
          type: ['string', 'null'],
          format: 'postCode',
          description: 'The current postcode of residence.',
          required: false,
        },
        secondaryStreet: {
          type: ['string', 'null'],
          format: 'street',
          description: 'Secondary street of residence.',
          required: false,
        },
        state: {
          type: ['string', 'null'],
          description: 'State of residence.',
          required: false,
        },
        street: {
          type: ['string', 'null'],
          format: 'street',
          description: 'Street of residence.',
          required: false,
        },
        suburb: {
          type: ['string', 'null'],
          format: 'suburb',
          description: 'Suburb of  residence',
          required: false,
        },
      },
      additionalProperties: false,
    },
    example: ({
      country: 'Australia',
      postCode: '4051',
      secondaryStreet: '4/9 Huxley Ave, Alderley',
      state: 'QLD',
      street: '4/9 Huxley Ave, Alderley',
      suburb: 'Brisbane',
    } as Address440) as PlainObject,
  }

  public static versionedSchemas = versionSchemas(AddressSchema.address440)

  public static snapshotSubtitle = 'Address Model'

  public check = (object: AddressLatest, version: string = this.latestVersion) => {
    cy.wrap(object).should('followSchema', 'addressSchema', version)
    return this
  }

  public sanitize = (object: AddressLatest, version: string = this.latestVersion) => {
    return cy.wrap(object, { log: false }).then(object => {
      return generateSanitizeFunction(AddressSchema.versionedSchemas, 'addressSchema', version)(
        (object as unknown) as PlainObject
      ) as AddressLatest
    })
  }
}
