import { sanitize, combineSchemas, VersionedSchema } from '@cypress/schema-tools/src'
import { formatDefaults } from '@formats/index.ts'

export const generateSanitizeFunction = (schema: VersionedSchema, schemaName: string, schemaVersion: string) => {
  const combinedSchemas = combineSchemas(schema)
  return sanitize(combinedSchemas, formatDefaults)(schemaName, schemaVersion)
}
