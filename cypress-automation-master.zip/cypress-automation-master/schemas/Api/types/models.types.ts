/**
 * Ward
 */
export const WardFrequencyValues = ['none', 'daily', 'weeklySetDays', 'fortnightlySetDays'] as const

export const RoundTypeValues = [
  'notDefined',
  'general',
  'radiationOncology',
  'medicalOncology',
  'cardiology',
  'dialysis',
  'endocrinology',
  'gastroenterology',
  'hematology',
  'infectiousDisease',
  'medicalAssessmentUnit',
  'neurology',
  'renal',
  'respiratory',
  'rheumatology',
  'sleepDisorderUnit',
  'cardioThoracic',
  'dental',
  'ent',
  'gynaecology',
  'operatingTheater',
  'ophmatology',
  'orthopaedics',
  'plastic',
  'urology',
  'vascular',
] as const

/**
 * Facility
 */
export const PreferredSyncSourceValues = ['none', 'onPremiseSql', 'hL7'] as const

export const UrnTypeValues = ['hubId', 'urNumber', 'totalCareId'] as const

export const VisitSourceValues = ['none', 'totalCare'] as const

/**
 * System Integration
 */
export const SystemTypeValues = ['fred', 'ax', 'aria', 'charm', 'careRight'] as const

/**
 * Contact
 */
export const RelationshipValues = [
  'spouse',
  'sonOrDaughter',
  'motherOrFather',
  'friend',
  'otherFamily',
  'neighbour',
  'employedCarer',
  'nextOfKin',
  'other',
] as const

/**
 * Delivery Options
 */
export const DeliveryTypeValues = [
  'regular',
  'express',
  'threeBusinessDays',
  'nextBusinessDay',
  'weekend',
  'discharge',
] as const

/**
 * Order
 */
export const ChartStatusValues = ['none', 'discharge', 'dispense', 'both'] as const

export const OrderContextValues = ['personal', 'facility'] as const

export const OrderTypeValues = ['script', 'nonScript', 'chart'] as const

export const ScriptTypeValues = ['none', 'newScript', 'repeat'] as const

export const ChartSourceValues = ['fax', 'email', 'chartFlow'] as const

/**
 * Orders Request
 */
export const ClassificationValues = ['personal', 'group'] as const

/**
 * Order Filter
 */
export const OrderSortValues = ['none', 'ascending', 'descending'] as const

export const OrderSortByValues = [
  'none',
  'created',
  'endTime',
  'orderForName',
  'urn',
  'state',
  'chartStatus',
  'batchId',
] as const

/**
 * Entity
 */
export const UserStatusValues = ['active', 'deleted'] as const

/**
 * Audit
 */
export const AuditTypeValues = [
  'legacy',
  'notDefined',
  'patientRegistration',
  'createPatientFromSync',
  'createAdmission',
  'updateAdmission',
  'updateMedicationProfiles',
  'medicare',
  'chartOrderNew',
  'facilityChartOrderNew',
  'scriptOrderNew',
  'facilityScriptOrderNew',
  'nonScriptOrderNew',
  'facilityNonScriptOrderNew',
  'chartOrderUpdated',
  'facilityChartOrderUpdated',
  'scriptOrderUpdated',
  'facilityScriptOrderUpdated',
  'nonScriptOrderUpdated',
  'facilityNonScriptOrderUpdated',
  'addIntervention',
  'updateIntervention',
  'deleteIntervention',
  'updateBillingDetails',
  'updateContacts',
  'updateCreditCardDetails',
  'updatePersonalDetails',
  'deleteService',
  'updateService',
  'addService',
  'updatePatientFromSync',
  'createPatientFromImport',
  'updatePatientFromImport',
  'createDischargeReconciliation',
  'updateDischargeReconciliation',
  'finalizeDischargeReconciliation',
  'addCorporateGroup',
  'editCorporateGroup',
  'addBusinessUnit',
  'editBusinessUnit',
  'addFacility',
  'editFacility',
  'addEmployeeToBusinessUnit',
  'deleteEmployeeFromBusinessUnit',
  'addDoctor',
  'updateDoctor',
  'updateImportedDoctor',
  'addImportedDoctor',
  'addUserFromAD',
  'updateUserFromAD',
  'resetPin',
  'setPin',
  'visitSyncedAndCreated',
  'visitSyncedAndMerged',
  'visitSyncedAndUpdated',
  'visitManuallyCreated',
  'visitManuallyUpdated',
  'visitManuallyDeleted',
  'updateNurse',
] as const

/**
 * Doctor
 */
export const DoctorPrefixValues = ['doctor', 'profesional', 'mr', 'assocoateProfessor'] as const

export const DoctorTypeValues = <const>[
  'none',
  'generalPractitioner',
  'specialist',
  'nursePractitioner',
  'medicalOncologist',
  'radiationOncologist',
  'hematologist',
  'surgeon',
]

/**
 * Visit
 */
export const VisitStatusValues = [
  'notDefined',
  'scheduled',
  'checkedIn',
  'coded',
  'complete',
  'canceled',
  'anomaly',
] as const

/**
 * Medication Profile
 */
export const DoseDaysValues = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'] as const

export const FrequencyValues = [
  'none',
  'daily',
  'alternateDays',
  'every3Rd',
  'setDays',
  'fortnightly',
  'monthly',
  'biMonthly',
  'quarterly',
  'twiceYearly',
  'yearly',
] as const

export const ProfileTypeValues = ['admissionAndDischarge', 'dischargeOnly'] as const

export const MedicationStatusValues = ['continue', 'withhold', 'cease', 'change', 'new'] as const

/**
 * Intervention
 */
export const ConsequenceImpactValues = ['insignificant', 'minor', 'moderate', 'major', 'catastrophic'] as const

export const DrugProblemValues = [
  'drugSelection',
  'overOrUnderDose',
  'compliance',
  'underTreated',
  'monitoring',
  'educationOrInformation',
  'notClassifiable',
  'toxicityAdverseReaction',
] as const

export const DrugProblemDetailsValues = [
  'duplication',
  'drugInteraction',
  'wrongDrug',
  'incorrectStrength',
  'inappropriateDosageForm',
  'contraindicationApparent',
  'noIndicationApparent',
  'otherDrugSelectionProblem',
  'prescribedDoseTooHigh',
  'prescribedDoseTooLow',
  'incorrectOrUnclearDosingInstructions',
  'otherDoseProblem',
  'takingTooLittle',
  'takingTooMuch',
  'erraticUseOfMedication',
  'intentionalDrugMisuse',
  'difficultyUsingDosageForm',
  'otherComplianceProblem',
  'conditionUnderTreated',
  'conditionNotTreated',
  'preventativeTherapyRequired',
  'otherUnderTreatedIndicationProblem',
  'laboratoryMonitoring',
  'nonLaboratoryMonitoring',
  'otherMonitoringProblem',
  'patientRequestsDrugInformation',
  'patientRequestDiseaseManagementAdvice',
  'otherEducationOrInformationProblem',
  'notClassifiableUnderAnotherCategory',
  'toxicityAllergicReactionOrAdrPresent',
] as const

export const LikelihoodValues = ['almostCertain', 'likely', 'possible', 'unlikely', 'rare'] as const

export const RecommendationValues = [
  'changeInTherapy',
  'referralRequired',
  'provisionOfInformation',
  'monitor',
  'other',
] as const

export const RecommendationDetailsValues = [
  'doseIncrease',
  'doseDecrease',
  'drugChange',
  'drugFormulationChange',
  'drugBrandChange',
  'doseFrequencyScheduleChange',
  'prescriptionNotDispensed',
  'otherChangesToTherapy',
  'referToPrescriber',
  'referToMedicationReview',
  'referToHospital',
  'otherReferralRequired',
  'educationOrCounsellingSession',
  'writtenSummaryOfMedications',
  'recommendDoseAdministrationAid',
  'otherWrittenInformation',
  'monitoringNonLaboratory',
  'monitoringLaboratoryTest',
  'noRecommendationNecessary',
] as const

/**
 * Patient
 */
export const ConcessionEntitledValues = ['unknown', 'entitled', 'notEntitled'] as const

export const NonActiveReasonValues = [
  'none',
  'holiday',
  'discharged',
  'deceased',
  'discontinuedTreatment',
  'completedTreatment',
  'other',
] as const

export const RepatCardTypeValues = ['none', 'gold', 'orange', 'white'] as const

/**
 * Script Item
 */
export const PackingTypeValues = [
  'packed',
  'whenRequired',
  'additional',
  'shortCourse',
  'inactivePeriod',
  'other',
] as const

/**
 * Medical Service
 */
export const FacilityTypeValues = [
  'unknown',
  'agedCare',
  'hospital',
  'selfCare',
  'communityCare',
  'cancerCare',
] as const

export const InactiveServiceOtherReasonValues = [
  'none',
  'holiday',
  'discharged',
  'deceased',
  'discontinuedTreatment',
  'completedTreatment',
  'other',
] as const

export const ServiceTypeValues = [
  'notDefined',
  'chemotherapy',
  'chemotherapyConsultation',
  'radiationOncology',
  'radiationOncologyConsultation',
  'agedCare',
  'communityCare',
  'selfCare',
  'admission',
  'walkin',
] as const

export const ServiceStatusValues = ['active', 'inactive', 'deleted'] as const

/**
 * Referral
 */
export const ReferralTypeValues = ['notDefined', 'other', 'letter', 'phone', 'hospital', 'verbal', 'self'] as const

/**
 * Doctor Reference
 */
export const ReferenceTypeValues = ['unknown', 'gP', 'treating', 'referring', 'surgeon', 'specialist'] as const

/**
 * Registration Model
 */
export const AustralianSouthSeaIslanderStatusValues = ['unknown', 'yes', 'no'] as const

export const IndigenousStatusValues = ['unknown', 'none', 'aboriginal', 'torresStraitIslander', 'both'] as const

export const MaritalStatusValues = ['single', 'widowed', 'divorced', 'separated', 'married', 'deFacto'] as const

export const SexValues = ['unknown', 'male', 'female', 'other'] as const

/**
 * Success Response
 */
export const ResponseStatusValues = ['success', 'error'] as const

/**
 * Search Patient Results
 */
export const RolesValues = [
  'none',
  'user',
  'patient',
  'doctor',
  'contact',
  'technician',
  'pharmacist',
  'dispatcher',
  'pharmacyAdmin',
  'organizationAdmin',
  'globalAdmin',
  'epicEmployee',
  'nurse',
  'corporateAdmin',
  'cancerCareAdmin',
  'hospitalNurse',
  'all',
  'bot',
] as const

/**
 * Admission
 */
export const AdmissionStatusValues = ['none', 'preAdmission', 'admitted', 'discharged'] as const
export const ReconciliationPdfTypeValues = ['none', 'comprehensive', 'simple'] as const
export const SourceValues = ['onPremiseSql', 'johnOfGod', 'uch', 'aria', 'hL7', 'hub'] as const
export const SourceTypeValues = ['patty', 'hL7', 'hub'] as const
export const StatusValues = ['open', 'draft', 'complete'] as const

/**
 * Allergy
 */
export const TypeValues = ['none', 'general', 'medication'] as const

/**
 * Bank Account
 */
export const BankAcountType = ['creditCard', 'directDebitCard', 'bankDetails'] as const

/**
 * Notation
 */
export const NotationTypeValues = ['dot', 'tick', 'sign', 'line', 'rectangle', 'cross'] as const

/**
 * Pharmacy Order Process
 */
export const OrderStateValues = [
  'new',
  'open',
  'dispensed',
  'outOfStock',
  'dispatched',
  'checked',
  'notSupplied',
  'seekingInformation',
  'onHold',
  'canceled',
  'picked',
] as const

/**
 * Discharge Medication Profile
 */

export const DischargeMedicationStatusValues = [
  'new',
  'ceased',
  'decreased',
  'increased',
  'temporary',
  'unchanged',
] as const

/**
 * Chart Items
 */

export const SupplyAmountValues = ['none', 'single', 'full'] as const
