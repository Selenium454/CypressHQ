import { bind } from '@cypress/schema-tools'
import { formats } from '../../formats'
import { modelSchemas } from './models'
import { patientSchemas } from './endpoints/patients'
import { servicesSchemas } from './endpoints/services'
import { ordersSchemas } from './endpoints/orders'
import { administrationSchemas } from './endpoints/administration'
import { doctorsSchemas } from './endpoints/doctors'

export const ApiSchemaLibrary = bind(
  { schemas: patientSchemas, formats },
  { schemas: modelSchemas, formats },
  { schemas: servicesSchemas, formats },
  { schemas: ordersSchemas, formats },
  { schemas: administrationSchemas, formats },
  { schemas: doctorsSchemas, formats }
)

export const ApiPatientSchemas = patientSchemas
export const ApiOrdersSchemas = ordersSchemas
export const ApiServicesSchemas = servicesSchemas
export const ApiModelSchemas = modelSchemas
export const ApiAdministrationSchemas = administrationSchemas
export const ApiDoctorsSchemas = doctorsSchemas
